# سورس فقطِ گزارش غایبین ناهار

این آرشیو فقط قطعات سورسِ مربوط به گزارش مستقل «غایبین ناهار» را جدا کرده است؛ **بستهٔ آپدیت نیست، مستقیم قابل نصب نیست و فایل‌های کامل برنامه را ندارد**.

## محتوا

- `backend/food_ticket_api_absent.php` — تابع PHP که سفارش‌های بازه را با فیش‌های چاپ‌شده تطبیق می‌دهد و غایبین را برمی‌گرداند.
- `backend/absent-route-and-access.php` — قطعهٔ route مربوط به `GET /api/absent` و مجوز view با `food.reports`.
- `frontend/absent-report-module.js` — بازهٔ شمسی، دریافت API، شمارش پرس/افراد، انتخاب ستون، مرتب‌سازی، جدول، XLSX و چاپ.
- `frontend/absent-report-integration.js` — hookهای navigation/render و eventهای خود گزارش.
- `frontend/absent-report.css` — فقط selectorهای CSS همین گزارش.
- `dependencies/org-grouping-extract.js` — توابع لازم برای شناسایی افراد و گروه‌بندی بر اساس معاونت.
- `dependencies/xlsx-export-extract.js` — helper خروجی XLSX مورد استفادهٔ گزارش.
- `tests/food-absent-report.test.js` و `tests/test_food_absent_report_static.py` — آزمون‌های مربوط به گزارش.

## وابستگی و محل اصلی

قطعات از سورس‌های `food-ticket.php` و `food-ticket-web/index.html` استخراج شده‌اند. در پنل کامل از globals مشترکی مثل `api`, `state`, `render`, `persist`, `isoDateFor`, `faDate`, `heading`, `esc` و `toast` استفاده می‌کنند؛ پس برای اجرا باید در برنامهٔ موجود قرار گیرند و به‌تنهایی برنامه نیستند. این آرشیو عمداً سورس سایر بخش‌های پنل، راهنما، چت‌بات و ماکت طراحی را ندارد.
