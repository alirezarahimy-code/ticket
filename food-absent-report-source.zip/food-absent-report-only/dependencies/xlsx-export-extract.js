// Focused excerpt from food-ticket-web/assets/list-sort.js.
// This is the shared XLSX export helper used by the report.
(function (global) {
  'use strict';
  function saveBlob(blob, filename) {
    var url = URL.createObjectURL(blob);
    var a = document.createElement('a');
    a.href = url;
    a.download = filename;
    document.body.appendChild(a);
    a.click();
    setTimeout(function () { a.parentNode && a.parentNode.removeChild(a); URL.revokeObjectURL(url); }, 1000);
  }

  // ارسال نمای مرتب‌شده به سرور و دریافت XLSX واقعی
  function exportXlsx(title, headers, rows, filename, fallbackHref) {
    var token = window.ITSM_CSRF || window.FOOD_TICKET_CSRF || '';
    return fetch('index.php?action=export_view_xlsx', {
      method: 'POST',
      credentials: 'same-origin',
      headers: { 'Content-Type': 'application/json', 'X-CSRF-Token': token },
      body: JSON.stringify({ title: title, filename: filename, headers: headers, rows: rows })
    }).then(function (response) {
      if (!response.ok) throw new Error('export failed');
      return response.blob();
    }).then(function (blob) {
      saveBlob(blob, filename + '.xlsx');
    }).catch(function () {
      if (fallbackHref) window.location.href = fallbackHref;
    });
  }

  global.ITSM_LIST_SORT = { exportXlsx: exportXlsx };
}(typeof window !== 'undefined' ? window : this));
