// Focused excerpt from food-ticket-web/assets/food-org-groups.js.
// Only load, split, and identity functions used by this report are exported.
(function (global) {
  'use strict';
  var GROUPS_URL = 'food-menu/org-map';
  var cache = null;      // پاسخ آخرین دریافت موفق
  var pending = null;    // Promise در جریان
  var cacheAt = 0;
  var CACHE_MS = 60000;  // یک دقیقه کافی است؛ چارت سازمانی لحظه‌ای عوض نمی‌شود

  function typeOrder(type) {
    switch (type) {
      case 'deputy': return 0;
      case 'management': return 1;
      case 'liaison': return 2;
      case 'company': return 3;
      case 'ceo': return 4;
      default: return 5;
    }
  }

  function load(api) {
    var now = Date.now();
    if (cache && now - cacheAt < CACHE_MS) {
      return Promise.resolve(cache);
    }
    if (pending) {
      return pending;
    }
    if (typeof api !== 'function') {
      return Promise.resolve(null);
    }
    pending = api('/api/' + GROUPS_URL)
      .then(function (payload) {
        if (!payload || !payload.people) {
          return null;
        }
        cache = payload;
        cacheAt = Date.now();
        return cache;
      })
      .catch(function () {
        return null;
      })
      .then(function (result) {
        pending = null;
        return result;
      });
    return pending;
  }

  function keysForRow(row) {
    if (!row) {
      return [];
    }
    var keys = [];
    var uid = row.user_id != null ? Number(row.user_id) : (row.employee_id != null ? Number(row.employee_id) : 0);
    if (uid > 0) {
      keys.push('uid:' + uid);
    }
    var nat = digits(row.national_code != null ? row.national_code : row.nat);
    if (nat !== '') {
      keys.push('nat:' + nat);
    }
    var pc = digits(row.employee_number != null ? row.employee_number : row.pc);
    if (pc !== '') {
      keys.push('pc:' + pc);
    }
    return keys;
  }

  /** ارقام فارسی/عربی را به لاتین برمی‌گرداند تا کد ملی و پرسنلی تطبیق بخورند. */
  function digits(value) {
    return String(value == null ? '' : value)
      .replace(/[۰-۹]/g, function (ch) { return String(ch.charCodeAt(0) - 0x06F0); })
      .replace(/[٠-٩]/g, function (ch) { return String(ch.charCodeAt(0) - 0x0660); })
      .replace(/\D/g, '')
      .replace(/^0+(?=\d)/, '');
  }

  /** نگاشت یک ردیف به گروهش؛ اگر پیدا نشد گروه «بدون معاونت سازمانی». */
  function groupOf(map, row) {
    var none = { group: 'none', label: 'بدون معاونت سازمانی', type: 'none', path: '' };
    if (!map || !map.people) {
      return none;
    }
    var keys = keysForRow(row);
    for (var i = 0; i < keys.length; i++) {
      if (map.people[keys[i]]) {
        return map.people[keys[i]];
      }
    }
    return none;
  }

  /**
   * ردیف‌ها را به گروه‌ها می‌شکند.
   * @return {Array<{key,label,type,path,rows:Array}>}
   */
  function split(map, rows) {
    var buckets = {};
    (rows || []).forEach(function (row) {
      var group = groupOf(map, row);
      var key = group.group || 'none';
      if (!buckets[key]) {
        buckets[key] = {
          key: key,
          label: group.label || 'بدون معاونت سازمانی',
          type: group.type || 'none',
          rows: [],
        };
      }
      // مسیر (اداره ← معاونت) برای هر فرد جداگانه است، پس روی ردیف نگه می‌داریم.
      row.__orgPath = group.path || '';
      row.__orgLabel = group.label || 'بدون معاونت سازمانی';
      row.__orgType = group.type || 'none';
      buckets[key].rows.push(row);
    });
    return Object.keys(buckets)
      .map(function (key) { return buckets[key]; })
      .sort(function (a, b) {
        var byType = typeOrder(a.type) - typeOrder(b.type);
        if (byType !== 0) {
          return byType;
        }
        return String(a.label).localeCompare(String(b.label), 'fa');
      });
  }

  global.FoodOrgGroups = { load: load, split: split, keysForRow: keysForRow };
}(typeof window !== 'undefined' ? window : this));
