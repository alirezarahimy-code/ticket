<?php
// Exact API router fragment from food-ticket.php
        if ($_SERVER['REQUEST_METHOD'] === 'GET' && $route === 'absent') {
            $legacyDate = (string) ($_GET['date'] ?? $_GET['food_date'] ?? '');
            $fromRaw = isset($_GET['from']) ? (string) $_GET['from'] : ($legacyDate !== '' ? $legacyDate : date('Y-m-d'));
            $toRaw = isset($_GET['to']) ? (string) $_GET['to'] : ($legacyDate !== '' ? $legacyDate : $fromRaw);
            $from = food_ticket_parse_date($fromRaw);
            $to = food_ticket_parse_date($toRaw);
            if ($from === null || $to === null || $from > $to) {
                food_ticket_api_json(['error' => 'بازهٔ تاریخ گزارش معتبر نیست.'], 400);
            }
            food_ticket_api_json(['items' => food_ticket_api_absent($from, $to), 'from' => $from, 'to' => $to]);
        }

// Exact entry inside $fpViews (view authorization):
        'absent-report' => $fpCan('food.reports'),
