// Integration fragments extracted from food-ticket-web/index.html.
// These snippets belong inside the existing panel, not in a standalone script.

// Navigation item (inside const nav array)
['absent-report','غایبین ناهار']
// Page renderer mapping
'absent-report':absentReportView
// Load report when entering its view
else if(view==='absent-report'){ensureAbsentReportRange();loadAbsent(false)}
// Shared panel loader used by the report for deputy grouping.
/** نگاشت سازمانی را یک‌بار می‌گیرد و در state نگه می‌دارد (کش در ماژول). */
function loadOrgMap(){
 if(!window.FoodOrgGroups)return Promise.resolve(null);
 if(state.__orgMap)return Promise.resolve(state.__orgMap);
 return window.FoodOrgGroups.load(api).then(x=>{state.__orgMap=x;return x});
}
// Clear pending report range when leaving/changing view
document.addEventListener('click',e=>{if(e.target.closest('[data-report-tab],[data-view]')){reportFilterDirty=false;reportRenderPending=false;absentFilterDirty=false;absentRenderPending=false;delete state.absentReportDraft}},true);
// Toggle flat/deputy-grouped report
document.addEventListener('click',e=>{const b=e.target.closest('[data-absent-org-view]');if(!b)return;e.preventDefault();state.absentOrgView=b.dataset.absentOrgView==='on';persist();const p=state.absentOrgView?loadOrgMap():Promise.resolve();p.then(()=>{if(view==='absent-report')render()})},true);
// Track edited date-range draft
document.addEventListener('input',e=>{if(e.target.closest('#report-filter,#aggregate-filter'))reportFilterDirty=true;if(e.target.closest('#absent-report-filter'))markAbsentReportFilterDirty(e.target.closest('#absent-report-filter'))},true);
// Track changed date-range draft
document.addEventListener('change',e=>{if(e.target.closest('#report-filter,#aggregate-filter'))reportFilterDirty=true;if(e.target.closest('#absent-report-filter'))markAbsentReportFilterDirty(e.target.closest('#absent-report-filter'))},true);
// Sort/export/print/refresh/today report actions
document.addEventListener('click',e=>{const sort=e.target.closest('[data-absent-sort]');if(sort){e.preventDefault();const key=sort.dataset.absentSort,current=state.absentSort||{key:'',dir:'asc'};state.absentSort=current.key!==key?{key,dir:'asc'}:current.dir==='asc'?{key,dir:'desc'}:{key:'',dir:'asc'};persist();render();return}const action=e.target.closest('[data-action]');if(!action)return;const name=action.dataset.action;if(name==='absent-export'){e.preventDefault();e.stopImmediatePropagation();absentReportExportXlsx();return}if(name==='absent-print'){e.preventDefault();e.stopImmediatePropagation();absentReportPrint();return}if(name==='absent-refresh'){e.preventDefault();e.stopImmediatePropagation();refreshAbsentReport();return}if(name==='absent-today'){e.preventDefault();e.stopImmediatePropagation();setAbsentReportToday();return}},true);
// Persist selected report columns
// انتخاب ستون‌های گزارش مستقل غایبین ناهار
document.addEventListener('change',e=>{const box=e.target;if(!box||!box.matches||!box.matches('[data-absent-field]'))return;const boxes=Array.from(document.querySelectorAll('[data-absent-field]')),chosen=boxes.filter(item=>item.checked).map(item=>item.dataset.absentField);if(!chosen.length){box.checked=true;toast('حداقل یک ستون باید انتخاب شود.');return}absentSaveFields(chosen);render()},true);
// Submit the report date range
document.addEventListener('submit',e=>{if(e.target.id!=='absent-report-filter')return;e.preventDefault();e.stopImmediatePropagation();const o=formObject(e.target);markAbsentReportFilterDirty(e.target);commitAbsentReportRange(o.from,o.to)},true);
