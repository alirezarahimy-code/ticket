<?php
declare(strict_types=1);

if (PHP_SAPI !== 'cli') {
    http_response_code(404);
    exit("Not found\n");
}

require dirname(__DIR__) . '/bootstrap.php';

$alerts = [];
$spool = logging_spool_stats();
$counters = logging_health_counters();
$workerPath = APP_ROOT . '/storage/logs/logging-worker-status.json';
$worker = is_file($workerPath) ? json_decode((string) @file_get_contents($workerPath), true) : [];

if ($spool['files'] > 0 && $spool['age_seconds'] > 600) {
    $alerts['spool_stale'] = 'صف اضطراری لاگ بیش از ۱۰ دقیقه قدیمی است. اتصال دیتابیس و اجرای Worker بازپخش را بررسی کنید.';
}
if ($spool['bytes'] > 100 * 1024 * 1024) {
    $alerts['spool_large'] = 'حجم صف اضطراری از ۱۰۰ مگابایت عبور کرده است؛ سلامت دیتابیس و Worker باید بررسی شود.';
}
if (!empty($counters['dropped_last_at']) && strtotime((string) $counters['dropped_last_at']) >= time() - 86400) {
    $alerts['events_dropped'] = 'در ۲۴ ساعت اخیر حداقل یک رخداد لاگ به‌طور نهایی از دست رفته است. مجوزهای فایل، فضای دیسک و سرویس دیتابیس باید بررسی شود.';
}
if ($spool['files'] > 0) {
    $lastSuccess = !empty($worker['last_success_at']) ? strtotime((string) $worker['last_success_at']) : false;
    if ($lastSuccess === false || $lastSuccess < time() - 900) {
        $alerts['replay_stale'] = 'در ۱۵ دقیقهٔ اخیر بازپخش موفق صف ثبت نشده است. زمان‌بندی Worker و گزارش اجرای آن را بررسی کنید.';
    }
}
$free = @disk_free_space(APP_ROOT);
$total = @disk_total_space(APP_ROOT);
if ($free !== false && $total !== false && $total > 0 && ($free / $total) < 0.20) {
    $alerts['disk_low'] = 'فضای آزاد دیسک کمتر از ۲۰ درصد است؛ رشد لاگ‌ها و فضای پشتیبان را بررسی کنید.';
}
try {
    $dbErrors = (int) db()->query("SELECT COUNT(*) FROM system_logs WHERE code = 'SYS-DB-001' AND created_at >= NOW() - INTERVAL 24 HOUR")->fetchColumn();
    if ($dbErrors > 0) $alerts['db_errors'] = 'در ۲۴ ساعت گذشته ' . $dbErrors . ' خطای پایگاه داده ثبت شده است.';
} catch (Throwable) {
    $alerts['db_health_unknown'] = 'وضعیت خطاهای دیتابیس قابل خواندن نیست؛ اتصال و Migrationها بررسی شوند.';
}
try {
    $tableMb = (float) db()->query("SELECT COALESCE((DATA_LENGTH + INDEX_LENGTH) / 1048576, 0) FROM information_schema.TABLES WHERE TABLE_SCHEMA = DATABASE() AND TABLE_NAME = 'system_logs'")->fetchColumn();
    if ($tableMb >= 1024) $alerts['log_table_large'] = 'حجم جدول system_logs به ' . round($tableMb, 1) . ' مگابایت رسیده است.';
} catch (Throwable) {
    // اگر آمار جدول در دسترس نیست، خطای جداگانه‌ای به مدیر ارسال نمی‌شود تا اعلان کاذب ایجاد نشود.
}

$adminIds = [];
try {
    $adminIds = db()->query("SELECT id FROM users WHERE role = 'primary_admin'")->fetchAll(PDO::FETCH_COLUMN);
    if (function_exists('db_column_present') && db_column_present('users', 'is_primary_admin')) {
        $legacyIds = db()->query("SELECT id FROM users WHERE role = 'admin' AND is_primary_admin = 1")->fetchAll(PDO::FETCH_COLUMN);
        $adminIds = array_values(array_unique(array_merge($adminIds, $legacyIds)));
    }
} catch (Throwable $exception) {
    fwrite(STDERR, 'Cannot resolve primary administrators: ' . get_class($exception) . "\n");
    exit(2);
}

$sent = 0;
foreach ($alerts as $key => $message) {
    try {
        db()->prepare('INSERT IGNORE INTO logging_health_alerts (alert_key, last_state, occurrences) VALUES (?, \'active\', 0)')->execute([$key]);
        $gate = db()->prepare("UPDATE logging_health_alerts SET last_sent_at = NOW(), last_state = 'active', occurrences = occurrences + 1 WHERE alert_key = ? AND (last_sent_at IS NULL OR last_sent_at < DATE_SUB(NOW(), INTERVAL 30 MINUTE))");
        $gate->execute([$key]);
        if ($gate->rowCount() > 0) {
            foreach ($adminIds as $adminId) {
                notify_user((int) $adminId, 'system_health_alert', 'هشدار سلامت سیستم لاگینگ', $message);
                $sent++;
            }
        }
    } catch (Throwable $exception) {
        logging_emergency_failure('logging_health_alert_failed', get_class($exception));
    }
}

// وضعیت‌هایی که برطرف شده‌اند، بدون حذف تاریخچه به حالت clear برمی‌گردند.
try {
    $activeKeys = array_keys($alerts);
    if ($activeKeys === []) {
        db()->exec("UPDATE logging_health_alerts SET last_state = 'clear' WHERE last_state <> 'clear'");
    } else {
        $placeholders = implode(',', array_fill(0, count($activeKeys), '?'));
        db()->prepare("UPDATE logging_health_alerts SET last_state = 'clear' WHERE last_state <> 'clear' AND alert_key NOT IN ($placeholders)")->execute($activeKeys);
    }
} catch (Throwable) {
    // Clear-state failure does not block the health check.
}

fwrite(STDOUT, sprintf("Active alerts: %d | notifications sent: %d\n", count($alerts), $sent));
exit(0);
