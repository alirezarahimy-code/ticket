@echo off
setlocal
set "APP_ROOT=%~dp0.."
for %%I in ("%APP_ROOT%") do set "APP_ROOT=%%~fI"

if not defined PHP_EXE set "PHP_EXE=C:\PHP\php.exe"
if not exist "%PHP_EXE%" (
    for /f "delims=" %%P in ('where php 2^>nul') do if not defined PHP_EXE_FOUND set "PHP_EXE_FOUND=%%P"
    if defined PHP_EXE_FOUND set "PHP_EXE=%PHP_EXE_FOUND%"
)
if not exist "%PHP_EXE%" (
    echo PHP executable not found. Set PHP_EXE environment variable.
    exit /b 2
)

if not exist "%APP_ROOT%\storage\logs" mkdir "%APP_ROOT%\storage\logs"
"%PHP_EXE%" "%APP_ROOT%\cron\replay_logging_spool.php" >> "%APP_ROOT%\storage\logs\logging-worker-task.log" 2>&1
set "REPLAY_EXIT=%ERRORLEVEL%"
"%PHP_EXE%" "%APP_ROOT%\cron\check_logging_health.php" >> "%APP_ROOT%\storage\logs\logging-health-task.log" 2>&1
set "HEALTH_EXIT=%ERRORLEVEL%"

if not "%REPLAY_EXIT%"=="0" exit /b %REPLAY_EXIT%
exit /b %HEALTH_EXIT%
