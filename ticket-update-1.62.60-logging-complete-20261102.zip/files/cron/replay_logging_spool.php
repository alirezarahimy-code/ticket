<?php
declare(strict_types=1);

if (PHP_SAPI !== 'cli') {
    http_response_code(404);
    exit("Not found\n");
}

require dirname(__DIR__) . '/bootstrap.php';
require_once APP_ROOT . '/lib/logging-replay.php';

$spoolDir = APP_ROOT . '/storage/logs/spool';
$statusPath = APP_ROOT . '/storage/logs/logging-worker-status.json';
if (!is_dir($spoolDir)) {
    fwrite(STDOUT, "Logging spool is empty.\n");
    exit(0);
}

$lockPath = $spoolDir . DIRECTORY_SEPARATOR . 'replay.lock';
$lock = @fopen($lockPath, 'c');
if ($lock === false || !flock($lock, LOCK_EX | LOCK_NB)) {
    fwrite(STDOUT, "Another logging replay worker is active.\n");
    exit(0);
}
$writerLock = @fopen($spoolDir . DIRECTORY_SEPARATOR . '.writer.lock', 'c');
if ($writerLock === false || !flock($writerLock, LOCK_EX | LOCK_NB)) {
    flock($lock, LOCK_UN);
    fclose($lock);
    fwrite(STDOUT, "Spool writer is busy; retry on next schedule.\n");
    exit(0);
}

$workerStatus = static function (array $data) use ($statusPath): void {
    $existing = [];
    if (is_file($statusPath)) {
        $decoded = json_decode((string) @file_get_contents($statusPath), true);
        if (is_array($decoded)) $existing = $decoded;
    }
    $data = array_merge($existing, $data, ['updated_at' => date('c')]);
    $tmp = $statusPath . '.' . bin2hex(random_bytes(4)) . '.tmp';
    $json = json_encode($data, JSON_UNESCAPED_SLASHES | JSON_INVALID_UTF8_SUBSTITUTE);
    if (is_string($json) && @file_put_contents($tmp, $json, LOCK_EX) !== false) {
        @chmod($tmp, 0640);
        @rename($tmp, $statusPath);
    }
    if (is_file($tmp)) @unlink($tmp);
};
$workerStatus(['last_attempt_at' => date('c'), 'last_result' => 'running']);


$processed = 0;
$replayed = 0;
$failed = 0;
$maxPerRun = 500;
$startedAt = microtime(true);

try {
    $result = logging_replay_process_directory($spoolDir, $maxPerRun);
    $processed = (int) $result['processed'];
    $replayed = (int) $result['replayed'];
    $failed = (int) $result['failed'];

    $finalStatus = [
        'last_attempt_at' => date('c'),
        'last_result' => $failed === 0 ? 'success' : 'partial_failure',
        'processed' => $processed,
        'replayed' => $replayed,
        'pending' => $failed,
        'remaining_files' => (int) $result['remaining_files'],
        'remaining_bytes' => (int) $result['remaining_bytes'],
        'duration_ms' => (int) round((microtime(true) - $startedAt) * 1000),
    ];
    if ($failed === 0) $finalStatus['last_success_at'] = date('c');
    $workerStatus($finalStatus);
    fwrite(STDOUT, sprintf("Processed: %d | replayed/idempotent: %d | pending/errors: %d | remaining files: %d\n", $processed, $replayed, $failed, (int) $result['remaining_files']));
} catch (Throwable $exception) {
    $workerStatus(['last_result' => 'failure', 'last_error_class' => get_class($exception)]);
    throw $exception;
} finally {
    flock($writerLock, LOCK_UN);
    fclose($writerLock);
    flock($lock, LOCK_UN);
    fclose($lock);
}
