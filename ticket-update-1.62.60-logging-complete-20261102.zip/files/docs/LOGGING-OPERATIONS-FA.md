# راهنمای عملیاتی Logging — نسخه 1.62.60

## پیش‌نیاز

- PHP 8.1 یا جدیدتر؛ PHP 8.2/8.3/8.4 ترجیح دارد.
- افزونه PDO MySQL فعال باشد.
- افزونه‌های `mbstring` و `zip` برای امکانات عمومی برنامه توصیه می‌شوند؛ مسیر Logging برای کوتاه‌سازی متن، fallback به `iconv` و سپس `substr` دارد.
- پوشه‌های `storage/logs` و `storage/logs/spool` برای کاربر سرویس وب و کاربر Task Scheduler قابل نوشتن باشند؛ دسترسی عمومی وب به این پوشه‌ها باید مسدود باشد.
- قبل از Migration از دیتابیس و فایل‌ها نسخهٔ پشتیبان تهیه شود.

## ترتیب ارتقا

1. ابتدا روی Staging یک کپی از برنامه و دیتابیس تهیه کنید.
2. Migrationهای قبلی موردنیاز نسخهٔ 1.62.60 را بررسی کنید؛ اگر Migration 019 قبلاً اجرا نشده، ابتدا آن را اجرا کنید.
3. فایل `migrations/020-logging-issues-alerts.sql` را با کاربر دیتابیس دارای مجوز CREATE TABLE اجرا کنید.
4. سورس نسخه را جایگزین فایل‌های برنامه کنید؛ `config.php`، `storage/` و `uploads/` را بازنویسی نکنید.
5. صفحهٔ «سلامت سامانه» را باز کنید. بخش «ساختار جدید Logging» و «تجمیع و هشدار Logging» باید سبز باشند.
6. خطای آزمایشی کنترل‌شده در Staging ایجاد کنید و بررسی کنید یک ردیف در `system_logs` و یک Issue در `log_issues` ساخته شود.
7. در Staging دیتابیس را موقتاً از دسترس خارج کنید؛ رخداد باید در JSONL صف شود. پس از بازگشت دیتابیس، Worker را اجرا و خالی‌شدن صف و ایجاد Issue را بررسی کنید.

## Windows Server Task Scheduler

### بازپخش صف و هشدار سلامت

- Program/script: `C:\Windows\System32\cmd.exe`
- Arguments: `/c "D:\ITSM\cron\run_logging_maintenance.bat"`
- Start in: `D:\ITSM\cron`
- Trigger: هر ۵ دقیقه، با اجرای task حتی اگر کاربر وارد سیستم نباشد.
- حساب اجراکننده باید به PHP CLI، فایل config و پوشهٔ `storage/logs` و دیتابیس دسترسی داشته باشد.
- در صورت نصب PHP در مسیر دیگر، متغیر محیطی `PHP_EXE` را برای حساب Task Scheduler تعریف کنید.

### پاک‌سازی دوره‌ای

- Program/script: `C:\Windows\System32\cmd.exe`
- Arguments: `/c "D:\ITSM\cron\run_logging_retention.bat"`
- Trigger: روزانه در ساعت کم‌ترافیک (برای نمونه 02:30).

## آستانه‌ها

- صف قدیمی‌تر از ۱۰ دقیقه: هشدار؛ قدیمی‌تر از ۳۰ دقیقه: بحرانی.
- رخداد ازدست‌رفته در ۲۴ ساعت اخیر: بحرانی.
- بازپخش موفق در ۱۵ دقیقهٔ اخیر در حالی که صف وجود دارد: هشدار.
- فضای آزاد دیسک کمتر از ۲۰٪: هشدار؛ کمتر از ۱۰٪: بحرانی.
- حجم جدول `system_logs` از ۱ گیگابایت: هشدار؛ از ۵ گیگابایت: بحرانی.
- خطای دیتابیس در ۲۴ ساعت اخیر: هشدار؛ ۵ مورد یا بیشتر: بحرانی.
- اعلان هر کلید هشدار برای مدیر اصلی حداکثر هر ۳۰ دقیقه یک‌بار ارسال می‌شود.

## کلاس‌های نگهداری

| کلاس | مدت نگهداری |
|---|---:|
| Debug | ۷ روز |
| Info / Notice | ۳۰ روز |
| رخدادهای کسب‌وکار | ۶۰ روز |
| Warning / Error / Critical فنی | حداقل ۹۰ روز |
| امنیت، حسابرسی و عملیات حساس | حداقل ۱۸۳ روز |
| Issueهای resolved | ۳۶۵ روز پس از آخرین مشاهده؛ موارد باز/درحال بررسی حذف نمی‌شوند |

مقدار فرم نگهداری فقط می‌تواند دورهٔ خطاهای فنی را افزایش دهد؛ امکان کوتاه‌کردن کلاس‌های محافظت‌شده وجود ندارد.

## تست‌های Staging

- اجرای `php tests/test_logging_core_offline.php`
- اجرای `php tests/test_logging_issue_aggregator.php`
- اجرای `php tests/test_logging_spool_concurrency.php` (در محیط دارای pcntl)
- اجرای `php tests/test_logging_mysql_integration.php` با DSN پایگاه‌دادهٔ آزمایشی مجزا و تأیید متغیر `ITSM_TEST_ALLOW_DESTRUCTIVE=YES`.
- اجرای `php cron/replay_logging_spool.php` و سپس `php cron/check_logging_health.php`.
- بررسی فایل‌های `logging-worker-task.log`، `logging-health-task.log` و `logging-retention-task.log`.

## Rollback

1. Task Scheduler را موقتاً غیرفعال کنید.
2. نسخهٔ پشتیبان فایل‌ها و دیتابیس را بازیابی کنید.
3. Migration شمارهٔ 020 جدول‌های افزوده‌شده را حذف نمی‌کند؛ برای بازگشت معمولاً حذف آن‌ها لازم نیست. اگر حذف الزامی شد، ابتدا از `log_issues` و `logging_health_alerts` خروجی بگیرید و سپس فقط در پنجرهٔ نگهداری و با تأیید DBA حذف کنید.
4. فایل‌های `storage/logs/spool` را حذف نکنید؛ تا پایان بازیابی باید حفظ شوند.
5. پس از Rollback، Task Scheduler را با نسخهٔ سازگار دوباره فعال کنید.
