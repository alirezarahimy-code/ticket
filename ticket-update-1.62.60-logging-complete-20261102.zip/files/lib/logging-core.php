<?php
declare(strict_types=1);

/**
 * هستهٔ مرکزی Logging سامانه.
 * مسئول هم‌بستگی درخواست، پالایش داده، کاتالوگ رخداد و صف جایگزین ثبت است.
 * این فایل به زیرساخت خارجی وابسته نیست و با PHP 8.1+ سازگار است.
 */

if (!defined('APP_ROOT')) {
    exit;
}

require_once __DIR__ . '/log-catalog.php';

function logging_uuid(): string
{
    try {
        $bytes = random_bytes(16);
    } catch (Throwable) {
        $fallback = substr(hash('sha256', uniqid('', true) . mt_rand()), 0, 32);
        $bytes = hex2bin($fallback);
        if (!is_string($bytes) || strlen($bytes) !== 16) {
            $bytes = str_repeat("\0", 16);
        }
    }
    $bytes[6] = chr((ord($bytes[6]) & 0x0f) | 0x40);
    $bytes[8] = chr((ord($bytes[8]) & 0x3f) | 0x80);
    $hex = bin2hex($bytes);
    return substr($hex, 0, 8) . '-' . substr($hex, 8, 4) . '-' . substr($hex, 12, 4) . '-' . substr($hex, 16, 4) . '-' . substr($hex, 20);
}

function logging_request_id(): string
{
    if (!isset($GLOBALS['__logging_request_id'])) {
        $GLOBALS['__logging_request_id'] = logging_uuid();
    }
    return (string) $GLOBALS['__logging_request_id'];
}

function logging_bootstrap(): void
{
    $id = logging_request_id();
    if (PHP_SAPI !== 'cli' && !headers_sent()) {
        header('X-Request-Id: ' . $id);
    }
    $GLOBALS['__logging_started_at'] = microtime(true);
}

function logging_catalog_aliases(): array
{
    return [
        'PHP_ERROR' => 'SYS-PHP-001', 'PHP_FATAL' => 'SYS-PHP-001', 'DB_ERROR' => 'SYS-DB-001',
        'DATABASE_ERROR' => 'SYS-DB-001', 'LDAP_ERROR' => 'INT-LDAP-001', 'LOGIN_FAILED' => 'SEC-AUTH-001',
        'LOGIN_LOCKED' => 'SEC-AUTH-002', 'ACCESS_DENIED' => 'SEC-ACL-001', 'CSRF_419' => 'SEC-CSRF-001',
        'BACKUP_CREATED' => 'AUD-BKP-001', 'BACKUP_RESTORED' => 'AUD-BKP-002', 'SETTINGS_CHANGED' => 'AUD-SET-001',
    ];
}

function logging_event_catalog(): array
{
    $catalog = logging_catalog_definitions();
    $aliases = [];
    foreach (logging_catalog_aliases() as $alias => $canonical) $aliases[$canonical][] = $alias;
    foreach ($catalog as $code => &$definition) $definition['aliases'] = $aliases[$code] ?? [];
    unset($definition);
    return $catalog;
}

function logging_catalog_resolve(string $code, string $fallbackCategory = 'system', string $fallbackSeverity = 'error'): array
{
    $catalog = logging_event_catalog();
    $requestedCode = strtoupper(trim($code));
    $canonicalCode = logging_catalog_aliases()[$requestedCode] ?? $requestedCode;
    if (isset($catalog[$canonicalCode])) {
        return $catalog[$canonicalCode] + ['code' => $canonicalCode, 'requested_code' => $requestedCode];
    }
    return [
        'code' => preg_match('/^[A-Z0-9][A-Z0-9._-]{2,39}$/', $code) ? $code : 'SYS-LEGACY-001',
        'category' => in_array($fallbackCategory, ['system', 'security', 'audit', 'business', 'operation', 'integration', 'performance'], true) ? $fallbackCategory : 'system',
        'severity' => in_array($fallbackSeverity, ['debug', 'info', 'notice', 'warning', 'error', 'critical'], true) ? $fallbackSeverity : 'error',
        'title' => 'رخداد سامانه',
        'user_message' => 'عملیات انجام نشد. کد پیگیری را به پشتیبانی بدهید.',
        'admin_explanation' => 'کد رخداد در کاتالوگ شناخته‌شده نیست؛ مسیر سازگاری قدیمی استفاده شد.',
        'probable_cause' => 'برای تشخیص علت، اطلاعات فنی پالایش‌شده و رخدادهای هم‌بسته بررسی شوند.',
        'recommended_action' => 'با Request ID و زمان رخداد، جزئیات فنی را بررسی کنید.',
        'allowed_context_keys' => ['module', 'operation', 'target_type', 'target_id', 'request_id'],
        'aliases' => [],
    ];
}

function logging_action_event_definition(string $action): array
{
    $map = [
        'login_failed' => ['SEC-AUTH-001', 'security'],
        'login_locked' => ['SEC-AUTH-002', 'security'],
        'login' => ['SEC-AUTH-003', 'security'],
        'login_local' => ['SEC-AUTH-003', 'security'],
        'login_ldap' => ['SEC-AUTH-003', 'security'],
        'logout' => ['SEC-AUTH-004', 'security'],
        'access_denied' => ['SEC-ACL-001', 'security'],
        'permission_denied' => ['SEC-ACL-001', 'security'],
        'update_user_role' => ['AUD-ACL-001', 'audit'],
        'save_role_permissions' => ['AUD-ACL-001', 'audit'],
        'save_key_roles' => ['AUD-ACL-001', 'audit'],
        'reset_role_permissions' => ['AUD-ACL-001', 'audit'],
        'reset_role_defaults' => ['AUD-ACL-001', 'audit'],
        'update_setting' => ['AUD-SET-001', 'audit'],
        'save_settings' => ['AUD-SET-001', 'audit'],
        'update_system_settings' => ['AUD-SET-001', 'audit'],
        'config_changed' => ['AUD-SET-001', 'audit'],
        'http_403' => ['SEC-ACL-001', 'security'],
        'csrf_419' => ['SEC-CSRF-001', 'security'],
        'create_backup' => ['AUD-BKP-001', 'audit'],
        'backup_created' => ['AUD-BKP-001', 'audit'],
        'backup_restored' => ['AUD-BKP-002', 'audit'],
        'restore_backup' => ['AUD-BKP-002', 'audit'],
        'org_backup_restored' => ['AUD-BKP-002', 'audit'],
        'org_company_display_names_updated' => ['AUD-SET-001', 'audit'],
        'triangle_effect_saved' => ['AUD-SET-001', 'audit'],
        'inspection_food_absence_alarm_updated' => ['AUD-SET-001', 'audit'],
        'system_updated' => ['AUD-SET-001', 'audit'],
        'org_ceo_saved' => ['AUD-ORG-001', 'audit'],
        'user_org_updated' => ['AUD-ORG-001', 'audit'],
        'org_unit_saved' => ['AUD-ORG-001', 'audit'],
        'org_unit_deleted' => ['AUD-ORG-001', 'audit'],
        'org_users_assigned' => ['AUD-ORG-001', 'audit'],
        'org_manager_assigned' => ['AUD-ORG-001', 'audit'],
        'org_manager_removed' => ['AUD-ORG-001', 'audit'],
        'org_experts_removed' => ['AUD-ORG-001', 'audit'],
        'org_structure_reset' => ['AUD-ORG-001', 'audit'],
        'org_action_undone' => ['AUD-ORG-001', 'audit'],
        'org_action_redone' => ['AUD-ORG-001', 'audit'],
        'org_deputies_sorted' => ['AUD-ORG-001', 'audit'],
        'org_manager_primary_admin_repaired' => ['AUD-ORG-001', 'audit'],
        'org_manager_support_role_repaired' => ['AUD-ORG-001', 'audit'],
        'activity_logs_exported' => ['AUD-LOG-001', 'audit'],
        'activity_logs_pruned' => ['AUD-LOG-002', 'audit'],
        'system_incident_status' => ['AUD-LOG-003', 'audit'],
        'food_ticket_print_failed' => ['FOOD-PRT-003', 'operation'],
        'ldap_sync' => ['INT-LDAP-001', 'integration'],
        'sync_ldap_users' => ['INT-LDAP-001', 'integration'],
    ];
    if (isset($map[$action])) {
        return ['code' => $map[$action][0], 'category' => $map[$action][1]];
    }
    if (str_starts_with($action, 'food_')) {
        return ['code' => 'FOOD-LEGACY-001', 'category' => 'operation'];
    }
    if (str_starts_with($action, 'traffic_')) {
        return ['code' => 'BIZ-TRF-001', 'category' => 'business'];
    }
    if (str_starts_with($action, 'ticket_') || in_array($action, ['create_ticket', 'update_ticket', 'reply', 'rate_ticket'], true)) {
        return ['code' => 'BIZ-TKT-001', 'category' => 'business'];
    }
    if (str_contains($action, 'role') || str_contains($action, 'permission') || str_contains($action, 'backup')
        || str_contains($action, 'setting') || str_contains($action, 'org_') || str_starts_with($action, 'delete_')
        || str_starts_with($action, 'reset_') || str_starts_with($action, 'assign_') || str_starts_with($action, 'remove_')
        || str_starts_with($action, 'system_') || str_starts_with($action, 'maintenance_')) {
        return ['code' => 'AUD-LEGACY-001', 'category' => 'audit'];
    }
    return ['code' => 'BIZ-LEGACY-001', 'category' => 'business'];
}

function logging_sensitive_key(string $key): bool
{
    return (bool) preg_match('/(^|[_-])(password|passwd|pwd|secret|token|authorization|cookie|csrf|session|api[_-]?key|private[_-]?key|bind[_-]?password|national[_-]?(code|id)|ssn|email|phone|mobile|employee[_-]?(id|number)|personnel[_-]?code|birth[_-]?(date|place)|dob)([_-]|$)/i', $key)
        || in_array(strtolower($key), ['password', 'pass', 'pwd', 'authorization', 'cookie', 'set-cookie', 'session_id', 'csrf_token', 'access_token', 'refresh_token', 'ldap_bind_password'], true);
}

function logging_utf8_substr(string $value, int $start, int $length): string
{
    if (function_exists('mb_substr')) return mb_substr($value, $start, $length, 'UTF-8');
    if (function_exists('iconv_substr')) {
        $result = iconv_substr($value, $start, $length, 'UTF-8');
        if (is_string($result)) return $result;
    }
    return substr($value, $start, $length);
}

function logging_utf8_strlen(string $value): int
{
    if (function_exists('mb_strlen')) return mb_strlen($value, 'UTF-8');
    if (function_exists('iconv_strlen')) {
        $result = iconv_strlen($value, 'UTF-8');
        if (is_int($result)) return $result;
    }
    return strlen($value);
}

function logging_sanitize_text(string $value, int $limit = 2000): string
{
    $value = preg_replace('/Bearer\s+[A-Za-z0-9._~+\/-]+=*/i', 'Bearer [REDACTED]', $value) ?? $value;
    $value = preg_replace('/((?:password|passwd|pwd|secret|token|api[_-]?key|authorization|cookie|csrf)\s*[=:]\s*)[^\s,;]+/iu', '$1[REDACTED]', $value) ?? $value;
    $value = preg_replace('/\b[A-Z0-9._%+-]+@[A-Z0-9.-]+\.[A-Z]{2,}\b/i', '[EMAIL_REDACTED]', $value) ?? $value;
    $value = preg_replace('/(?<![0-9۰-۹٠-٩])[0-9۰-۹٠-٩]{10}(?![0-9۰-۹٠-٩])/u', '[NATIONAL_ID_REDACTED]', $value) ?? $value;
    $value = preg_replace('~(mysql:|pgsql:)[^\s]+~i', '[DATABASE_DSN_REDACTED]', $value) ?? $value;
    return logging_utf8_substr($value, 0, $limit);
}

function logging_sanitize_value($value, string $key = '', int $depth = 0)
{
    if (logging_sensitive_key($key)) {
        return '[REDACTED]';
    }
    if ($depth > 5) {
        return '[MAX_DEPTH]';
    }
    if (is_array($value)) {
        $clean = [];
        $count = 0;
        foreach ($value as $childKey => $childValue) {
            if (++$count > 100) {
                $clean['_truncated'] = true;
                break;
            }
            $clean[(string) $childKey] = logging_sanitize_value($childValue, (string) $childKey, $depth + 1);
        }
        return $clean;
    }
    if (is_object($value)) {
        return '[OBJECT:' . get_class($value) . ']';
    }
    if (is_string($value)) {
        return logging_sanitize_text($value, 2000);
    }
    if (is_float($value) && (!is_finite($value))) {
        return null;
    }
    if (is_resource($value)) {
        return '[RESOURCE]';
    }
    return is_scalar($value) || $value === null ? $value : '[UNSUPPORTED]';
}

function logging_safe_request_uri(): ?string
{
    $uri = (string) ($_SERVER['REQUEST_URI'] ?? '');
    if ($uri === '') {
        return null;
    }
    $path = (string) (parse_url($uri, PHP_URL_PATH) ?: '/');
    return substr(logging_sanitize_text($path, 255), 0, 255);
}

function logging_spool_write(string $stream, array $payload): bool
{
    // نام فایل صف فقط از جریان‌های شناخته‌شده ساخته می‌شود؛ ورودی دلخواه نباید مسیر فایل را کنترل کند.
    if (!in_array($stream, ['system', 'activity'], true)) {
        logging_emergency_failure('spool_stream_rejected');
        return false;
    }

    $dir = APP_ROOT . '/storage/logs/spool';
    try {
        if (!is_dir($dir) && !@mkdir($dir, 0750, true) && !is_dir($dir)) {
            throw new RuntimeException('spool directory unavailable');
        }
        $day = date('Ymd');
        $path = $dir . DIRECTORY_SEPARATOR . $stream . '-' . $day . '.jsonl';
        $record = [
            'version' => 1,
            'stream' => $stream,
            'queued_at' => date('c'),
            'payload' => logging_sanitize_value($payload),
        ];
        $json = json_encode($record, JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES | JSON_INVALID_UTF8_SUBSTITUTE);
        if (!is_string($json)) {
            throw new RuntimeException('spool JSON encoding failed');
        }
        // قفل مشترک نویسنده/Worker برای امکان بازنویسی اتمیک فایل در Windows و Linux.
        $writerLock = @fopen($dir . DIRECTORY_SEPARATOR . '.writer.lock', 'c');
        if ($writerLock === false || !flock($writerLock, LOCK_EX)) {
            if (is_resource($writerLock)) fclose($writerLock);
            throw new RuntimeException('spool writer lock unavailable');
        }
        $handle = @fopen($path, 'ab');
        if ($handle === false) {
            flock($writerLock, LOCK_UN);
            fclose($writerLock);
            throw new RuntimeException('spool file unavailable');
        }
        @chmod($path, 0640);
        try {
            if (!flock($handle, LOCK_EX)) {
                throw new RuntimeException('spool lock unavailable');
            }
            $offset = ftell($handle);
            if (!is_int($offset) || $offset < 0) {
                throw new RuntimeException('spool offset unavailable');
            }
            $data = $json . PHP_EOL;
            $length = strlen($data);
            $writtenTotal = 0;
            while ($writtenTotal < $length) {
                $written = fwrite($handle, substr($data, $writtenTotal));
                if ($written === false || $written === 0) {
                    break;
                }
                $writtenTotal += $written;
            }
            if ($writtenTotal !== $length || !fflush($handle)) {
                // خط ناقص را تا offset قبلی برمی‌گردانیم تا Worker JSON نیمه‌کاره نخواند.
                if (ftruncate($handle, $offset)) {
                    fflush($handle);
                }
                throw new RuntimeException('spool short write');
            }
            if (function_exists('fsync')) { @fsync($handle); }
            flock($handle, LOCK_UN);
        } finally {
            fclose($handle);
            flock($writerLock, LOCK_UN);
            fclose($writerLock);
        }
        return true;
    } catch (Throwable $exception) {
        logging_emergency_failure('spool_write_failed', $exception->getMessage());
        return false;
    }
}

function logging_spool_stats(): array
{
    $dir = APP_ROOT . '/storage/logs/spool';
    $files = is_dir($dir) ? (glob($dir . DIRECTORY_SEPARATOR . '*.jsonl') ?: []) : [];
    $bytes = 0;
    $oldest = null;
    foreach ($files as $file) {
        $size = (int) @filesize($file);
        $bytes += $size;
        $mtime = @filemtime($file);
        $queuedAt = false;
        $handle = @fopen($file, 'rb');
        if ($handle !== false) {
            $firstLine = fgets($handle);
            fclose($handle);
            if (is_string($firstLine)) {
                $firstRecord = json_decode($firstLine, true);
                if (is_array($firstRecord) && !empty($firstRecord['queued_at'])) {
                    $parsed = strtotime((string) $firstRecord['queued_at']);
                    $queuedAt = $parsed !== false ? $parsed : false;
                }
            }
        }
        $candidate = $queuedAt !== false ? $queuedAt : $mtime;
        if ($candidate !== false && ($oldest === null || $candidate < $oldest)) {
            $oldest = $candidate;
        }
    }
    return ['files' => count($files), 'bytes' => $bytes, 'oldest_at' => $oldest, 'age_seconds' => $oldest !== null ? max(0, time() - $oldest) : 0];
}

function logging_increment_counter(string $name): void
{
    if (!in_array($name, ['fallback_total', 'dropped_total'], true)) {
        return;
    }
    $path = APP_ROOT . '/storage/logs/logging-health.json';
    try {
        $dir = dirname($path);
        if (!is_dir($dir) && !@mkdir($dir, 0750, true) && !is_dir($dir)) {
            throw new RuntimeException('health directory unavailable');
        }
        $handle = @fopen($path, 'c+');
        if ($handle === false) {
            throw new RuntimeException('health counter unavailable');
        }
        try {
            if (!flock($handle, LOCK_EX)) {
                throw new RuntimeException('health counter lock unavailable');
            }
            rewind($handle);
            $raw = stream_get_contents($handle);
            $counts = json_decode((string) $raw, true);
            if (!is_array($counts)) {
                $counts = [];
            }
            $counts[$name] = (int) ($counts[$name] ?? 0) + 1;
            $counts['updated_at'] = date('c');
            if ($name === 'dropped_total') $counts['dropped_last_at'] = date('c');
            $json = json_encode($counts, JSON_UNESCAPED_SLASHES);
            rewind($handle);
            ftruncate($handle, 0);
            fwrite($handle, is_string($json) ? $json : '{}');
            fflush($handle);
            if (function_exists('fsync')) { @fsync($handle); }
            flock($handle, LOCK_UN);
        } finally {
            fclose($handle);
        }
    } catch (Throwable) {
        error_log('[LOGGING_FAILURE] counter_write_failed ' . date('c'));
    }
}

function logging_health_counters(): array
{
    $path = APP_ROOT . '/storage/logs/logging-health.json';
    if (!is_file($path)) {
        return ['fallback_total' => 0, 'dropped_total' => 0, 'dropped_last_at' => null];
    }
    $data = json_decode((string) @file_get_contents($path), true);
    return is_array($data) ? [
        'fallback_total' => (int) ($data['fallback_total'] ?? 0),
        'dropped_total' => (int) ($data['dropped_total'] ?? 0),
        'dropped_last_at' => isset($data['dropped_last_at']) ? (string) $data['dropped_last_at'] : null,
    ] : ['fallback_total' => 0, 'dropped_total' => 0, 'dropped_last_at' => null];
}

function logging_emergency_failure(string $code, string $detail = ''): void
{
    // آخرین مسیر مستقل از دیتابیس؛ از اطلاعات حساس و پیام خام اجتناب می‌شود.
    $line = '[LOGGING_FAILURE] ' . preg_replace('/[^A-Za-z0-9_.-]/', '_', $code) . ' ' . date('c');
    error_log($line);
    $GLOBALS['__logging_last_failure'] = $code;
}

function logging_record_failure(string $stream, array $payload): bool
{
    $payload['event_id'] = (string) ($payload['event_id'] ?? logging_uuid());
    $payload['request_id'] = (string) ($payload['request_id'] ?? logging_request_id());
    $payload['created_at'] = (string) ($payload['created_at'] ?? date('Y-m-d H:i:s'));
    logging_increment_counter('fallback_total');
    if (!logging_spool_write($stream, $payload)) {
        logging_increment_counter('dropped_total');
        logging_emergency_failure('event_dropped', $stream);
        return false;
    }
    return true;
}

function logging_json(array $value): ?string
{
    $json = json_encode(logging_sanitize_value($value), JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES | JSON_INVALID_UTF8_SUBSTITUTE);
    return is_string($json) ? substr($json, 0, 60000) : null;
}


function logging_append_legacy_file(string $line): bool
{
    $dir = APP_ROOT . '/storage/logs';
    try {
        if (!is_dir($dir) && !@mkdir($dir, 0750, true) && !is_dir($dir)) {
            return false;
        }
        $path = $dir . DIRECTORY_SEPARATOR . 'app.log';
        clearstatcache(true, $path);
        if (is_file($path)) {
            $mtime = (int) @filemtime($path);
            $dailyRotationDue = $mtime > 0 && date('Ymd', $mtime) < date('Ymd');
            $sizeRotationDue = (int) @filesize($path) >= 10 * 1024 * 1024;
            if ($dailyRotationDue || $sizeRotationDue) {
                $rotated = $dir . DIRECTORY_SEPARATOR . 'app-' . ($dailyRotationDue ? date('Ymd', $mtime) : date('Ymd')) . '-' . date('His') . '.log';
                if (@rename($path, $rotated)) {
                    $archives = glob($dir . DIRECTORY_SEPARATOR . 'app-*.log') ?: [];
                    rsort($archives, SORT_STRING);
                    foreach (array_slice($archives, 14) as $old) @unlink($old);
                }
            }
        }
        $handle = @fopen($path, 'ab');
        if ($handle === false) {
            return false;
        }
        try {
            if (!flock($handle, LOCK_EX)) {
                return false;
            }
            $data = $line . PHP_EOL;
            $written = fwrite($handle, $data);
            fflush($handle);
            if (function_exists('fsync')) { @fsync($handle); }
            flock($handle, LOCK_UN);
            return $written === strlen($data);
        } finally {
            fclose($handle);
        }
    } catch (Throwable) {
        return false;
    }
}

/** درج idempotent رخداد بازپخش‌شده؛ فقط جدول‌های ثابت مجازند. */
function logging_replay_insert(string $table, string $sql, array $params, string $eventId): bool
{
    if (!in_array($table, ['system_logs', 'activity_logs'], true)
        || !preg_match('/^[a-f0-9]{8}-[a-f0-9]{4}-4[a-f0-9]{3}-[89ab][a-f0-9]{3}-[a-f0-9]{12}$/i', $eventId)
        || !preg_match('/^\s*INSERT\s+INTO\s+' . preg_quote($table, '/') . '\s*\(/i', $sql)) {
        throw new InvalidArgumentException('Invalid replay target or event identifier.');
    }
    try {
        db()->prepare($sql)->execute($params);
        return true;
    } catch (PDOException $exception) {
        if ((string) $exception->getCode() !== '23000') throw $exception;
        $check = db()->prepare('SELECT 1 FROM `' . $table . '` WHERE event_id = ? LIMIT 1');
        $check->execute([$eventId]);
        if (!$check->fetchColumn()) throw $exception;
        return false;
    }
}

/** ثبت/به‌روزرسانی Issueهای تکرارشونده؛ شکست Aggregator نباید ثبت رخداد اصلی را مختل کند. */
function logging_issue_upsert(array $event): bool
{
    $severity = (string) ($event['level'] ?? 'error');
    if (!in_array($severity, ['warning', 'error', 'critical'], true)) return true;
    $category = (string) ($event['category'] ?? 'system');
    $code = (string) ($event['code'] ?? 'SYS-LEGACY-001');
    $context = logging_sanitize_text((string) ($event['context'] ?? 'system'), 120);
    $title = logging_sanitize_text((string) ($event['message'] ?? 'رخداد فنی'), 255);
    $normalizedTitle = preg_replace('/\s+/u', ' ', $title) ?? $title;
    $fingerprint = hash('sha256', strtolower($code . '|' . $context . '|' . $normalizedTitle));
    try {
        $sql = "INSERT INTO log_issues (fingerprint, code, category, severity, title, first_seen, last_seen, occurrences, last_event_id, last_request_id, status)
                VALUES (?, ?, ?, ?, ?, NOW(), NOW(), 1, ?, ?, 'open')
                ON DUPLICATE KEY UPDATE occurrences = occurrences + 1, last_seen = NOW(),
                    last_event_id = VALUES(last_event_id), last_request_id = VALUES(last_request_id),
                    severity = CASE WHEN FIELD(VALUES(severity),'debug','info','notice','warning','error','critical') > FIELD(severity,'debug','info','notice','warning','error','critical') THEN VALUES(severity) ELSE severity END,
                    resolution_note = IF(status = 'resolved', NULL, resolution_note),
                    status = IF(status = 'resolved', 'open', status)";
        db()->prepare($sql)->execute([$fingerprint, $code, $category, $severity, $title,
            (string) ($event['event_id'] ?? ''), (string) ($event['request_id'] ?? logging_request_id())]);

        // اعلان مسئله‌های پرتکرار برای مدیر اصلی؛ رخداد خام حذف نمی‌شود و فقط اعلان ۳۰ دقیقه rate-limit می‌شود.
        if (function_exists('notify_user')) {
            $gate = db()->prepare("UPDATE log_issues SET last_notified_at = NOW() WHERE fingerprint = ? AND occurrences >= 5 AND (last_notified_at IS NULL OR last_notified_at < DATE_SUB(NOW(), INTERVAL 30 MINUTE))");
            $gate->execute([$fingerprint]);
            if ($gate->rowCount() > 0) {
                $admins = db()->query("SELECT id FROM users WHERE role = 'primary_admin'")->fetchAll(PDO::FETCH_COLUMN);
                if (function_exists('db_column_present') && db_column_present('users', 'is_primary_admin')) {
                    $legacyAdmins = db()->query("SELECT id FROM users WHERE role = 'admin' AND is_primary_admin = 1")->fetchAll(PDO::FETCH_COLUMN);
                    $admins = array_values(array_unique(array_merge($admins, $legacyAdmins)));
                }
                foreach ($admins as $adminId) {
                    notify_user((int) $adminId, 'system_health_alert', 'خطای پرتکرار در سامانه', $code . ' — ' . $title . ' (۵ رخداد یا بیشتر؛ اعلان بعدی حداکثر هر ۳۰ دقیقه).');
                }
            }
        }
        return true;
    } catch (Throwable $exception) {
        logging_emergency_failure('issue_aggregation_failed', get_class($exception));
        return false;
    }
}

function logging_store_system(array $event): bool
{
    $event['event_id'] = (string) ($event['event_id'] ?? logging_uuid());
    $event['request_id'] = logging_request_id();
    $event['created_at'] = (string) ($event['created_at'] ?? date('Y-m-d H:i:s'));
    $event['message'] = logging_sanitize_text((string) ($event['message'] ?? ''), 2000);
    $event['context'] = logging_sanitize_text((string) ($event['context'] ?? 'system'), 120);
    $event['request_uri'] = logging_safe_request_uri();
    $event['meta_json'] = logging_json((array) ($event['meta'] ?? []));
    $event['fingerprint'] = (string) ($event['fingerprint'] ?? sha1($event['context'] . '|' . $event['message']));
    try {
        $pdo = db();
        if ($pdo->inTransaction()) {
            logging_record_failure('system', $event);
            return false;
        }
        $pdo->prepare('INSERT INTO system_logs (event_id, request_id, code, category, fingerprint, level, context, message, meta_json, user_id, request_uri, created_at) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)')->execute([
            $event['event_id'], $event['request_id'], $event['code'] ?? null, $event['category'] ?? 'system', $event['fingerprint'],
            $event['level'] ?? 'error', $event['context'], $event['message'], $event['meta_json'],
            isset($_SESSION['user_id']) ? (int) $_SESSION['user_id'] : null, $event['request_uri'], $event['created_at'],
        ]);
        logging_issue_upsert($event);
        return true;
    } catch (Throwable $exception) {
        logging_record_failure('system', $event);
        return false;
    }
}

/** پاک‌سازی نهایی فیلدهای فعالیت در مرز ذخیره‌سازی؛ مستقل از پاک‌سازی فراخواننده. */
function logging_normalize_activity_event(array $event): array
{
    $limits = [
        'username' => 190,
        'full_name' => 190,
        'role' => 40,
        'action_code' => 120,
        'action_label' => 190,
        'module' => 80,
        'target_type' => 40,
        'target_label' => 255,
        'computer_name' => 190,
        'hostname' => 190,
        'user_agent' => 255,
    ];
    foreach ($limits as $field => $limit) {
        if (array_key_exists($field, $event) && $event[$field] !== null) {
            $event[$field] = logging_sanitize_text((string) $event[$field], $limit);
        }
    }

    $result = (string) ($event['result'] ?? 'success');
    $event['result'] = in_array($result, ['success', 'failure', 'denied'], true) ? $result : 'success';

    $ip = trim((string) ($event['ip_address'] ?? ''));
    $event['ip_address'] = $ip !== '' && filter_var($ip, FILTER_VALIDATE_IP) ? $ip : null;
    $event['user_id'] = isset($event['user_id']) && (int) $event['user_id'] > 0 ? (int) $event['user_id'] : null;
    $event['target_id'] = isset($event['target_id']) ? (int) $event['target_id'] : null;
    $event['meta_json'] = logging_json(is_array($event['meta'] ?? null) ? $event['meta'] : []);
    return $event;
}

function logging_store_activity(array $event): bool
{
    $event['event_id'] = (string) ($event['event_id'] ?? logging_uuid());
    $event['request_id'] = logging_request_id();
    $event['created_at'] = (string) ($event['created_at'] ?? date('Y-m-d H:i:s'));
    $transactional = false;
    try {
        $pdo = db();
        $transactional = $pdo->inTransaction();
        $event = logging_normalize_activity_event($event);
        $pdo->prepare('INSERT INTO activity_logs (event_id, request_id, result, code, category, user_id, username, full_name, role, action_code, action_label, module, target_type, target_id, target_label, meta_json, ip_address, computer_name, hostname, user_agent, created_at) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)')->execute([
            $event['event_id'], $event['request_id'], $event['result'] ?? 'success', $event['code'] ?? 'AUD-LEGACY-001', $event['category'] ?? 'audit', $event['user_id'] ?? null,
            $event['username'] ?? null, $event['full_name'] ?? null, $event['role'] ?? null, $event['action_code'] ?? 'unknown',
            $event['action_label'] ?? null, $event['module'] ?? null, $event['target_type'] ?? null, $event['target_id'] ?? null,
            $event['target_label'] ?? null, $event['meta_json'], $event['ip_address'] ?? null, $event['computer_name'] ?? null,
            $event['hostname'] ?? null, $event['user_agent'] ?? null, $event['created_at'],
        ]);
        return true;
    } catch (Throwable $exception) {
        if ($transactional) {
            throw $exception;
        }
        logging_record_failure('activity', $event);
        return false;
    }
}

function log_event(string $code, string $message, array $context = []): string
{
    $definition = logging_catalog_resolve($code, (string) ($context['category'] ?? 'system'), (string) ($context['severity'] ?? 'error'));
    $eventId = logging_uuid();
    logging_store_system([
        'event_id' => $eventId,
        'code' => $definition['code'],
        'category' => $definition['category'],
        'level' => $definition['severity'],
        'context' => (string) ($context['context'] ?? $definition['category']),
        'message' => $message,
        'meta' => $context['meta'] ?? [],
    ]);
    return $eventId;
}

logging_bootstrap();
