<?php
declare(strict_types=1);

/**
 * lib/activity-audit.php — ثبت فعالیت، حسابرسی و رویداد درخواست‌ها — جداشده از bootstrap.php در نسخهٔ ۱.۶۲.۲۰ (فاز ۲ بازسازی).
 * محتوا: activity_log* (اسکیما، IP، نام رایانه، برچسب فارسی اکشن‌ها، ثبت و هرس) / ops_low_value_tables_prune / save_audit / log_ticket_event.
 * ترتیب تعریف توابع و کدهای سطح‌بالا عیناً مانند bootstrap قبلی حفظ شده است.
 */

if (!defined('APP_ROOT')) {
    exit;
}

function activity_logs_ensure(): void
{
    // DDL در مسیر درخواست اجرا نمی‌شود؛ جدول باید از schema.sql یا Migrationها آماده شده باشد.
    static $checked = false;
    if ($checked) return;
    $checked = true;
    try {
        if (!function_exists('db_table_exists') || !db_table_exists('activity_logs')) {
            logging_emergency_failure('activity_logs_table_missing', 'apply database schema/migrations');
        }
    } catch (Throwable $exception) {
        logging_emergency_failure('activity_logs_schema_check_failed', get_class($exception));
    }
}

function activity_client_ip(): string
{
    $remote = trim((string) ($_SERVER['REMOTE_ADDR'] ?? ''));
    if (!filter_var($remote, FILTER_VALIDATE_IP)) {
        return '';
    }
    $trusted = cfg('app.trusted_proxies', []);
    if (is_string($trusted)) {
        $trusted = array_filter(array_map('trim', explode(',', $trusted)));
    }
    if (!is_array($trusted) || !in_array($remote, $trusted, true)) {
        return $remote;
    }
    $forwarded = trim((string) ($_SERVER['HTTP_X_FORWARDED_FOR'] ?? ''));
    if ($forwarded === '') {
        return $remote;
    }
    $chain = array_map('trim', explode(',', $forwarded));
    $chain[] = $remote;
    for ($i = count($chain) - 1; $i >= 0; $i--) {
        $candidate = $chain[$i];
        if (!filter_var($candidate, FILTER_VALIDATE_IP)) {
            continue;
        }
        if (!in_array($candidate, $trusted, true)) {
            return substr($candidate, 0, 64);
        }
    }
    return $remote;
}

function activity_computer_name(?string $ip = null): string
{
    // نکته: reverse-DNS (gethostbyaddr) روی شبکه می‌تواند چند ثانیه معطل کند و
    // سایت را کند می‌کند؛ بنابراین فقط از نام میزبان سرور پنل استفاده می‌شود.
    if (!defined('ACTIVITY_RESOLVE_HOST')) {
        return '';
    }
    static $cache = [];
    $ip = $ip !== null && $ip !== '' ? $ip : activity_client_ip();
    if ($ip === '') {
        return '';
    }
    if (array_key_exists($ip, $cache)) {
        return $cache[$ip];
    }
    $name = '';
    try {
        if (filter_var($ip, FILTER_VALIDATE_IP, FILTER_FLAG_IPV4) && !in_array($ip, ['127.0.0.1', '::1'], true)) {
            $resolved = @gethostbyaddr($ip);
            if (is_string($resolved) && $resolved !== '' && $resolved !== $ip) {
                $name = $resolved;
            }
        }
    } catch (Throwable) {
        $name = '';
    }
    $cache[$ip] = substr($name, 0, 190);
    return $cache[$ip];
}

function activity_action_label(string $code): string
{
    static $map = [
        'login' => 'ورود به سامانه',
        'login_local' => 'ورود با حساب محلی',
        'login_ldap' => 'ورود با حساب دامین',
        'login_failed' => 'تلاش ناموفق ورود',
        'login_locked' => 'قفل‌شدن حساب پس از تلاش‌های ناموفق',
        'logout' => 'خروج از سامانه',
        'page_view' => 'مشاهدهٔ صفحه',
        'profile_updated' => 'به‌روزرسانی پروفایل',
        'user_theme_changed' => 'تغییر تم شخصی',
        'ticket_created' => 'ثبت درخواست جدید',
        'ticket_replied' => 'پاسخ در درخواست',
        'ticket_updated' => 'به‌روزرسانی درخواست',
        'ticket_rated' => 'امتیازدهی به درخواست',
        'ticket_reopened' => 'بازگشایی درخواست',
        'ticket_reopened_by_user' => 'بازگشایی درخواست توسط کاربر (مشکل حل نشده)',
        'ticket_cancelled_by_requester' => 'لغو درخواست توسط ثبت‌کننده',
        'ticket_cancellation_requested' => 'درخواست لغو درخواست',
        'ticket_cancellation_approved' => 'تأیید درخواست لغو درخواست',
        'ticket_cancellation_rejected' => 'رد درخواست لغو درخواست',
        'ticket_claimed' => 'برداشتن درخواست توسط کارشناس',
        'supervisor_approved' => 'تأیید سوپروایزر',
        'supervisor_rework' => 'برگشت درخواست برای اصلاح',
        'supervisor_reopened' => 'بازگشایی درخواست توسط سوپروایزر',
        'cd_dvd_in' => 'ثبت ورود رسانه (CD/DVD)',
        'cd_dvd_out' => 'ثبت خروج رسانه (CD/DVD)',
        'cd_dvd_updated' => 'ویرایش ثبت CD/DVD',
        'cd_dvd_deleted' => 'حذف ثبت CD/DVD',
        'backup_created' => 'ایجاد پشتیبان',
        'backup_restored' => 'بازگردانی پشتیبان',
        'server_inventory_collected' => 'استخراج شناسنامهٔ سرور',
        'agent_inventory_collected' => 'استخراج شناسنامهٔ کلاینت (Agent)',
        'domain_assets_imported' => 'ورود کامپیوترهای دامنه',
        'assets_pinged' => 'پینگ سیستم‌های انتخابی',
        'change_created' => 'ثبت تغییر',
        'change_updated' => 'ویرایش تغییر',
        'change_submitted' => 'ارسال تغییر',
        'problem_created' => 'ثبت مشکل',
        'problem_updated' => 'ویرایش مشکل',
        'food_ticket_config_saved' => 'ذخیرهٔ تنظیمات فیش غذا',
        'food_group_created' => 'ایجاد گروه غذا',
        'food_group_updated' => 'ویرایش گروه غذا',
        'food_group_deleted' => 'حذف گروه غذا',
        'food_group_uid_changed' => 'تغییر L_UID نمایندهٔ گروه',
        'food_group_member_added' => 'افزودن عضو به گروه غذا',
        'food_group_member_removed' => 'حذف عضو از گروه غذا',
        'food_day_visit_set' => 'خوداظهاری محل تحویل غذا برای امروز',
        'food_day_visit_cleared' => 'لغو خوداظهاری محل تحویل غذا',
        'order_cancel_request' => 'درخواست لغو سفارش غذا در روز بسته',
        'order_cancel_request_approved' => 'تأیید لغو سفارش غذا توسط پشتیبانی',
        'order_cancel_request_rejected' => 'رد درخواست لغو سفارش غذا',
        'food_absence_set' => 'ثبت غیبت روزانه',
        'food_absence_cleared' => 'حذف غیبت روزانه',
        'food_absence_override' => 'اصلاح غیبت بعد از قفل',
        'food_group_absence_frozen' => 'قفل شدن لیست غیبت (تردد نماینده)',
        'food_group_unknown_uid' => 'تردد با L_UID ناشناخته',
        'food_group_tickets_issued' => 'صدور فیش گروهی',
        'food_ticket_print_success' => 'چاپ موفق فیش',
        'food_ticket_print_failed' => 'شکست چاپ فیش',
        'food_ticket_retry' => 'چاپ مجدد فیش‌های خطادار',
        'food_ticket_ticket_held' => 'توقف چاپ فیش (اعلام غیبت)',
        'food_ticket_ticket_released' => 'بازگشت فیش به صف چاپ (حاضر شد)',
        'food_ticket_delivered' => 'ثبت تحویل غذا',
        'food_ticket_delivery_revoked' => 'لغو تحویل غذا',
        'settings_updated' => 'به‌روزرسانی تنظیمات',
        'activity_logs_pruned' => 'پاک‌سازی لاگ‌های قدیمی',
        'import_domain_users' => 'ورود کاربران دامین',
        'ldap_sync' => 'همگام‌سازی کاربران دامین',
        'activity_logs_exported' => 'خروجی Excel فعالیت کاربران',
        'save_profile' => 'به‌روزرسانی پروفایل',
        'add_category' => 'افزودن دسته‌بندی',
        'add_department' => 'افزودن واحد',
        'add_holiday' => 'افزودن تعطیلات',
        'add_knowledge' => 'افزودن مقالهٔ دانش‌نامه',
        'add_service' => 'افزودن خدمت',
        'add_service_field' => 'افزودن فیلد خدمت',
        'add_asset_relation' => 'افزودن ارتباط دارایی',
        'assign_org_manager' => 'انتصاب مدیر واحد',
        'remove_org_manager' => 'حذف مدیر واحد',
        'remove_org_experts' => 'حذف کارشناسان واحد',
        'save_org_assign_users' => 'ذخیرهٔ تخصیص کاربران واحد',
        'save_org_unit' => 'ذخیرهٔ واحد سازمانی',
        'save_org_node' => 'ذخیرهٔ گره سازمانی',
        'save_org_ceo' => 'ذخیرهٔ مدیرعامل',
        'save_user_org' => 'ذخیرهٔ سازمان کاربر',
        'reset_org_structure' => 'بازنشانی ساختار سازمان',
        'delete_org_unit' => 'حذف واحد سازمانی',
        'undo_org_action' => 'بازگردانی آخرین تغییر سازمان',
        'bulk_update_tickets' => 'عملیات گروهی روی درخواست‌ها',
        'create_ticket' => 'ثبت درخواست جدید',
        'update_ticket' => 'به‌روزرسانی درخواست',
        'reply' => 'پاسخ در درخواست',
        'rate_ticket' => 'امتیازدهی به درخواست',
        'mark_notification' => 'خواندن اعلان',
        'mark_all_notifications' => 'خواندن همهٔ اعلان‌ها',
        'food_order_cancel_decide' => 'رسیدگی به درخواست لغو غذا',
        'cd_dvd_create' => 'ثبت رکورد CD/DVD',
        'cd_dvd_update' => 'ویرایش رکورد CD/DVD',
        'cd_dvd_delete' => 'حذف رکورد CD/DVD',
        'save_cd_dvd_settings' => 'ذخیرهٔ تنظیمات CD/DVD',
        'traffic_create' => 'ثبت تردد مراجع',
        'traffic_update' => 'ویرایش تردد مراجع',
        'traffic_delete' => 'حذف تردد مراجع',
        'traffic_set_exit' => 'ثبت ساعت خروج مراجع',
        'traffic_add_destination' => 'افزودن مقصد ملاقات',
        'traffic_delete_destination' => 'حذف مقصد ملاقات',
        'traffic_visit_created' => 'ثبت تردد مراجع',
        'traffic_visit_updated' => 'ویرایش تردد مراجع',
        'traffic_visit_deleted' => 'حذف تردد مراجع',
        'traffic_visit_exit_set' => 'ثبت ساعت خروج مراجع',
        'traffic_records_imported' => 'ورود گروهی سوابق تردد از Excel',
        'save_inventory_form' => 'ذخیرهٔ شناسنامهٔ فنی',
        'collect_inventory' => 'استخراج اطلاعات سیستم',
        'create_backup' => 'ایجاد پشتیبان',
        'restore_backup' => 'بازگردانی پشتیبان',
        'import_domain_assets' => 'ورود کامپیوترهای دامنه',
        'ping_assets' => 'پینگ سیستم‌های انتخابی',
        'domain_scan_start' => 'شروع اسکن دامنه',
        'domain_scan_batch' => 'ادامهٔ اسکن دامنه',
        'save_settings' => 'ذخیرهٔ تنظیمات سامانه',
        'save_role_permissions' => 'ذخیرهٔ دسترسی‌های نقش',
        'reset_role_permissions' => 'بازگرداندن همهٔ نقش‌ها به پیش‌فرض',
        'reset_role_defaults' => 'بازگرداندن دسترسی یک نقش به پیش‌فرض کد',
        'save_key_roles' => 'ذخیرهٔ نقش‌های کلیدی',
        'save_department_members' => 'ذخیرهٔ اعضای واحد',
        'update_user_role' => 'تغییر نقش کاربر',
        'sync_ldap_users' => 'همگام‌سازی کاربران دامین',
        'save_service_category' => 'ذخیرهٔ دسته‌بندی خدمات',
        'delete_service' => 'حذف خدمت',
        'delete_service_category' => 'حذف دسته‌بندی خدمات',
        'edit_service' => 'ویرایش خدمت',
        'delete_holiday' => 'حذف تعطیلات',
        'toggle_holiday' => 'فعال/غیرفعال‌کردن تعطیلات',
        'import_holidays' => 'ورود تقویم تعطیلات',
        'prune_activity_logs' => 'پاک‌سازی لاگ‌های فعالیت',
    ];
    return $map[$code] ?? $code;
}

function activity_log(array $data): void
{
    $transactional = false;
    try {
        $transactional = db()->inTransaction();
        activity_logs_ensure();
        $user = $data['user'] ?? null;
        if (is_array($user)) {
            $userId = isset($user['id']) ? (int) $user['id'] : null;
            $username = (string) ($user['username'] ?? '');
            $fullName = (string) ($user['full_name'] ?? '');
            $role = (string) ($user['role'] ?? '');
        } else {
            $userId = isset($data['user_id']) ? (int) $data['user_id'] : (isset($_SESSION['user_id']) ? (int) $_SESSION['user_id'] : null);
            $username = (string) ($data['username'] ?? '');
            $fullName = (string) ($data['full_name'] ?? '');
            $role = (string) ($data['role'] ?? '');
        }
        if ($userId && ($username === '' || $fullName === '' || $role === '')) {
            $lookup = db()->prepare('SELECT username, full_name, role FROM users WHERE id = ? LIMIT 1');
            $lookup->execute([$userId]);
            $identity = $lookup->fetch() ?: [];
            $username = $username !== '' ? $username : (string) ($identity['username'] ?? '');
            $fullName = $fullName !== '' ? $fullName : (string) ($identity['full_name'] ?? '');
            $role = $role !== '' ? $role : (string) ($identity['role'] ?? '');
        }
        $code = substr((string) ($data['action_code'] ?? 'unknown'), 0, 120);
        $eventDefinition = logging_action_event_definition($code);
        $meta = is_array($data['meta'] ?? null) ? (array) logging_sanitize_value($data['meta']) : [];
        // IP حسابرسی فقط از اتصال واقعی یا پراکسی مورداعتماد استخراج می‌شود؛ مقدار ورودی تابع قابل اعتماد نیست.
        $ip = activity_client_ip();
        if (!filter_var($ip, FILTER_VALIDATE_IP)) {
            $ip = '';
        }
        $computer = (string) ($data['computer_name'] ?? activity_computer_name($ip));
        $hostname = (string) ($data['hostname'] ?? ($_SERVER['SERVER_NAME'] ?? ''));
        $event = [
            'event_id' => logging_uuid(),
            'user_id' => $userId,
            'username' => substr(logging_sanitize_text($username, 190), 0, 190),
            'full_name' => substr(logging_sanitize_text($fullName, 190), 0, 190),
            'role' => substr(logging_sanitize_text($role, 40), 0, 40),
            'action_code' => $code,
            'code' => $eventDefinition['code'],
            'category' => $eventDefinition['category'],
            'action_label' => substr(logging_sanitize_text((string) ($data['action_label'] ?? activity_action_label($code)), 190), 0, 190),
            'module' => isset($data['module']) && $data['module'] !== null ? substr((string) $data['module'], 0, 80) : null,
            'target_type' => isset($data['target_type']) && $data['target_type'] !== null ? substr((string) $data['target_type'], 0, 40) : null,
            'target_id' => isset($data['target_id']) && $data['target_id'] !== null ? (int) $data['target_id'] : null,
            'target_label' => isset($data['target_label']) && $data['target_label'] !== null ? substr(logging_sanitize_text((string) $data['target_label'], 255), 0, 255) : null,
            'meta' => $meta,
            'ip_address' => $ip !== '' ? $ip : null,
            'computer_name' => $computer !== '' ? substr($computer, 0, 190) : null,
            'hostname' => $hostname !== '' ? substr($hostname, 0, 190) : null,
            'user_agent' => substr(logging_sanitize_text((string) ($data['user_agent'] ?? ($_SERVER['HTTP_USER_AGENT'] ?? '')), 255), 0, 255),
            'result' => in_array(($data['result'] ?? ''), ['success', 'failure', 'denied'], true) ? (string) $data['result'] : (in_array($code, ['login_failed'], true) ? 'failure' : (in_array($code, ['login_locked'], true) ? 'denied' : 'success')),
        ];
        logging_store_activity($event);
    } catch (Throwable $exception) {
        if ($transactional) {
            throw $exception;
        }
        logging_record_failure('activity', ['action_code' => (string) ($data['action_code'] ?? 'unknown'), 'message' => 'Activity event preparation failed', 'exception_type' => get_class($exception)]);
    }
}

/**
 * بازدید صفحه (page_view) کم‌اهمیت و پرحجم است و جدول گزارش فعالیت را بی‌دلیل بزرگ و کند می‌کند.
 * تصمیم ۱.۵۵: خاموش. ثبت عملیات واقعی (ایجاد/ویرایش/ورود/خروج...) ادامه دارد.
 */
const ACTIVITY_LOG_PAGE_VIEWS = false;

function activity_log_view(string $page): void
{
    if (!ACTIVITY_LOG_PAGE_VIEWS) {
        return;
    }
    if (PHP_SAPI === 'cli' || ($_SERVER['REQUEST_METHOD'] ?? 'GET') !== 'GET') {
        return;
    }
    $isAjax = strtolower((string) ($_SERVER['HTTP_X_REQUESTED_WITH'] ?? '')) === 'xmlhttprequest' || isset($_GET['ajax']);
    if ($isAjax || str_starts_with($page, 'api') || $page === 'login' || $page === 'logout') {
        return;
    }
    $action = (string) ($_GET['action'] ?? '');
    // اپیندپوینت‌های فنی (feed/export/print/photo/...) بازدید صفحه نیستند و لاگ نمی‌شوند.
    static $skip = ['export_assets', 'export_report', 'export_cd_dvd', 'export_activity_logs', 'notification_feed', 'download_backup', 'download_attachment', 'profile_photo'];
    if ($action !== '' || in_array($action, $skip, true)) {
        return;
    }
    if (!empty($_GET['traffic_api']) || !empty($_GET['food_api'])) {
        return;
    }
    $lastKey = 'activity_view_' . md5($page);
    $now = time();
    if (isset($_SESSION[$lastKey]) && ($now - (int) $_SESSION[$lastKey]) < 300) {
        return;
    }
    $_SESSION[$lastKey] = $now;
    activity_log([
        'action_code' => 'page_view',
        'action_label' => 'مشاهدهٔ صفحه: ' . $page,
        'module' => $page,
        'computer_name' => '',
        'meta' => [],
    ]);
}

function activity_logs_prune(int $days = 60): int
{
    $days = max(60, min(3650, $days));
    $auditDays = max(183, $days);
    try {
        activity_logs_ensure();
        $businessDeleted = db_delete_in_batches('activity_logs', "category NOT IN ('security','audit','operation') AND created_at < (NOW() - INTERVAL ? DAY)", [$days]);
        $protectedDeleted = db_delete_in_batches('activity_logs', "category IN ('security','audit','operation') AND created_at < (NOW() - INTERVAL ? DAY)", [$auditDays]);
        return $businessDeleted + $protectedDeleted;
    } catch (Throwable $exception) {
        logging_emergency_failure('activity_logs_prune_failed', get_class($exception));
        return 0;
    }
}

/**
 * حداقل نگهداری برای داده‌های حسابرسی فیش غذا (چاپ و تحویل) — ۶ ماه.
 * هیچ کد پاک‌سازی نباید جدول‌های food_ticket_events و food_ticket_print_log را کمتر از این مدت حذف کند.
 */
const FOOD_AUDIT_RETENTION_DAYS = 183;

/**
 * پاک‌سازی جدول‌های کم‌اهمیت و پرحجم که داده‌ای برای حسابرسی ندارند:
 *  - chatbot_logs: بیش از ۹۰ روز
 *  - api_rate_limits: پنجرهٔ شمارش بیش از ۱ روز
 *  - login_attempts: پنجرهٔ قدیمی و بدون قفل فعال
 * فیش‌های غذا و لاگ چاپ هرگز اینجا پاک نمی‌شوند.
 * @return array<string,int> تعداد ردیف‌های حذف‌شده به تفکیک جدول
 */
function ops_low_value_tables_prune(): array
{
    $out = [];
    try {
        $out['chatbot_logs'] = db_delete_in_batches('chatbot_logs', 'created_at < (NOW() - INTERVAL ? DAY)', [90]);
    } catch (Throwable) {
        $out['chatbot_logs'] = 0;
    }
    try {
        $out['api_rate_limits'] = db_delete_in_batches('api_rate_limits', 'window_started < (NOW() - INTERVAL ? DAY)', [1]);
    } catch (Throwable) {
        $out['api_rate_limits'] = 0;
    }
    try {
        $out['login_attempts'] = db_delete_in_batches(
            'login_attempts',
            '(locked_until IS NULL OR locked_until < NOW()) AND window_started < (NOW() - INTERVAL ? DAY)',
            [1]
        );
    } catch (Throwable) {
        $out['login_attempts'] = 0;
    }
    return $out;
}

function activity_log_retention_days(): int
{
    $days = (int) (setting('activity_log_retention_days', '60') ?? '60');
    return max(60, min(3650, $days > 0 ? $days : 60));
}

function save_audit(int $userId, string $action, ?int $ticketId = null, array $meta = []): void
{
    $GLOBALS['activity_audited'] = true;
    activity_log([
        'user_id' => $userId,
        'action_code' => $action,
        'target_type' => $ticketId !== null ? 'ticket' : null,
        'target_id' => $ticketId,
        'meta' => $meta,
    ]);
}

function log_ticket_event(int $ticketId, ?int $userId, string $eventType, ?string $fromStatus = null, ?string $toStatus = null, array $details = []): void
{
    try {
        $query = db()->prepare('INSERT INTO ticket_events (event_id, request_id, ticket_id, user_id, event_type, from_status, to_status, details) VALUES (?, ?, ?, ?, ?, ?, ?, ?)');
        $query->execute([logging_uuid(), logging_request_id(), $ticketId, $userId, $eventType, $fromStatus, $toStatus, logging_json($details)]);
    } catch (PDOException $exception) {
        // سازگاری گذرا با دیتابیسی که هنوز مهاجرت 019 روی آن اجرا نشده است.
        if (stripos($exception->getMessage(), 'Unknown column') === false) {
            throw $exception;
        }
        $query = db()->prepare('INSERT INTO ticket_events (ticket_id, user_id, event_type, from_status, to_status, details) VALUES (?, ?, ?, ?, ?, ?)');
        $query->execute([$ticketId, $userId, $eventType, $fromStatus, $toStatus, logging_json($details)]);
    }
}
