<?php
declare(strict_types=1);

if (!defined('APP_ROOT')) exit;

/**
 * پردازش صف JSONL با مصرف حافظهٔ محدود و بازنویسی اتمیک فایل.
 * فراخواننده باید قفل replay.lock و .writer.lock را در اختیار داشته باشد.
 */
function logging_replay_process_directory(string $spoolDir, int $maxPerRun = 500): array
{
    $maxPerRun = max(1, min(5000, $maxPerRun));
    if (!is_dir($spoolDir)) return ['processed'=>0,'replayed'=>0,'failed'=>0,'remaining_files'=>0,'remaining_bytes'=>0];
    $processed = 0; $replayed = 0; $failed = 0;

    foreach (glob($spoolDir . DIRECTORY_SEPARATOR . '*.jsonl.processing') ?: [] as $processingFile) {
        $original = substr($processingFile, 0, -strlen('.processing'));
        if (!is_file($original)) @rename($processingFile, $original);
        else @unlink($processingFile);
    }
    foreach (glob($spoolDir . DIRECTORY_SEPARATOR . '*.jsonl.*.rewrite.tmp') ?: [] as $staleTemp) {
        $base = preg_replace('/\.[a-f0-9]+\.rewrite\.tmp$/', '', $staleTemp);
        if ($base && is_file($base)) @unlink($staleTemp);
    }

    $files = glob($spoolDir . DIRECTORY_SEPARATOR . '*.jsonl') ?: [];
    sort($files, SORT_STRING);
    foreach ($files as $file) {
        if ($processed >= $maxPerRun) break;
        $input = @fopen($file, 'rb');
        if ($input === false) { $failed++; continue; }
        $temp = $file . '.' . bin2hex(random_bytes(4)) . '.rewrite.tmp';
        $output = @fopen($temp, 'wb');
        if ($output === false) { fclose($input); $failed++; continue; }
        $pendingLines = 0;
        try {
            while (($line = fgets($input)) !== false) {
                if (trim($line) === '') continue;
                if ($processed >= $maxPerRun) {
                    if (fwrite($output, $line) !== strlen($line)) throw new RuntimeException('pending spool write failed');
                    $pendingLines++;
                    continue;
                }
                $processed++;
                try {
                    $record = json_decode($line, true, 32, JSON_THROW_ON_ERROR);
                    if (!is_array($record) || (int) ($record['version'] ?? 0) !== 1 || !is_array($record['payload'] ?? null)) throw new RuntimeException('invalid spool record');
                    $payload = $record['payload'];
                    $stream = (string) ($record['stream'] ?? '');
                    $eventId = (string) ($payload['event_id'] ?? '');
                    $requestId = (string) ($payload['request_id'] ?? '');
                    if (!preg_match('/^[a-f0-9]{8}-[a-f0-9]{4}-4[a-f0-9]{3}-[89ab][a-f0-9]{3}-[a-f0-9]{12}$/i', $eventId)
                        || !preg_match('/^[a-f0-9]{8}-[a-f0-9]{4}-4[a-f0-9]{3}-[89ab][a-f0-9]{3}-[a-f0-9]{12}$/i', $requestId)) throw new RuntimeException('invalid event/request id');
                    if ($stream === 'system') {
                        $meta = is_array($payload['meta'] ?? null) ? $payload['meta'] : [];
                        $metaJson = json_encode(logging_sanitize_value($meta), JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES | JSON_INVALID_UTF8_SUBSTITUTE);
                        $sql = 'INSERT INTO system_logs (event_id, request_id, code, category, fingerprint, level, context, message, meta_json, user_id, request_uri, created_at) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)';
                        $wasInserted = logging_replay_insert('system_logs', $sql, [
                            $eventId, $requestId, $payload['code'] ?? null, $payload['category'] ?? 'system',
                            $payload['fingerprint'] ?? sha1((string) ($payload['context'] ?? '') . '|' . (string) ($payload['message'] ?? '')),
                            $payload['level'] ?? 'error', logging_utf8_substr((string) ($payload['context'] ?? 'system'), 0, 120),
                            logging_sanitize_text((string) ($payload['message'] ?? ''), 2000), $metaJson,
                            isset($payload['user_id']) ? (int) $payload['user_id'] : null,
                            isset($payload['request_uri']) ? substr((string) $payload['request_uri'], 0, 255) : null,
                            $payload['created_at'] ?? date('Y-m-d H:i:s'),
                        ], $eventId);
                        if ($wasInserted) {
                            logging_issue_upsert([
                                'event_id'=>$eventId, 'request_id'=>$requestId,
                                'code'=>(string) ($payload['code'] ?? 'SYS-LEGACY-001'),
                                'category'=>(string) ($payload['category'] ?? 'system'),
                                'level'=>(string) ($payload['level'] ?? 'error'),
                                'context'=>(string) ($payload['context'] ?? 'system'),
                                'message'=>(string) ($payload['message'] ?? 'رخداد فنی'),
                            ]);
                        }
                    } elseif ($stream === 'activity') {
                        $meta = is_array($payload['meta'] ?? null) ? $payload['meta'] : [];
                        $metaJson = json_encode(logging_sanitize_value($meta), JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES | JSON_INVALID_UTF8_SUBSTITUTE);
                        $sql = 'INSERT INTO activity_logs (event_id, request_id, result, code, category, user_id, username, full_name, role, action_code, action_label, module, target_type, target_id, target_label, meta_json, ip_address, computer_name, hostname, user_agent, created_at) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)';
                        logging_replay_insert('activity_logs', $sql, [
                            $eventId, $requestId, $payload['result'] ?? 'success', $payload['code'] ?? 'AUD-LEGACY-001', $payload['category'] ?? 'audit', $payload['user_id'] ?? null,
                            $payload['username'] ?? null, $payload['full_name'] ?? null, $payload['role'] ?? null,
                            $payload['action_code'] ?? 'unknown', $payload['action_label'] ?? null, $payload['module'] ?? null,
                            $payload['target_type'] ?? null, $payload['target_id'] ?? null, $payload['target_label'] ?? null,
                            $metaJson, $payload['ip_address'] ?? null, $payload['computer_name'] ?? null,
                            $payload['hostname'] ?? null, $payload['user_agent'] ?? null, $payload['created_at'] ?? date('Y-m-d H:i:s'),
                        ], $eventId);
                    } else {
                        throw new RuntimeException('unknown spool stream');
                    }
                    $replayed++;
                } catch (Throwable) {
                    if (fwrite($output, $line) !== strlen($line)) throw new RuntimeException('pending spool write failed');
                    $pendingLines++; $failed++;
                }
            }
            if (!fflush($output)) throw new RuntimeException('pending spool flush failed');
        } catch (Throwable $exception) {
            fclose($input); fclose($output); @unlink($temp); throw $exception;
        }
        fclose($input); fclose($output);

        if ($pendingLines === 0) {
            @unlink($file); @unlink($temp);
        } else {
            $processing = $file . '.processing';
            if (!@rename($file, $processing)) { @unlink($temp); $failed++; continue; }
            if (!@rename($temp, $file)) { @rename($processing, $file); @unlink($temp); $failed++; continue; }
            @unlink($processing);
        }
    }
    $remainingFiles = glob($spoolDir . DIRECTORY_SEPARATOR . '*.jsonl') ?: [];
    $remainingBytes = 0;
    foreach ($remainingFiles as $remainingFile) $remainingBytes += (int) @filesize($remainingFile);
    return ['processed'=>$processed,'replayed'=>$replayed,'failed'=>$failed,'remaining_files'=>count($remainingFiles),'remaining_bytes'=>$remainingBytes];
}
