"""Guard the cumulative update's contents and truthful version metadata."""
import hashlib
import json
import unittest
import zipfile
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
PACKAGE = ROOT / 'downloads/ticket-update-1.62.60-logging-complete-20261102.zip'


class ReleasePackageTest(unittest.TestCase):
    def test_manifest_cumulative_files_and_hash(self):
        with zipfile.ZipFile(PACKAGE) as archive:
            manifest = json.loads(archive.read('manifest.json'))
            self.assertEqual(manifest['version'], '1.62.60')
            self.assertEqual(manifest['base_version'], '1.62.62')
            self.assertEqual(manifest['migrations'], ['019-central-logging.sql', '020-logging-issues-alerts.sql'])
            self.assertEqual(archive.read('files/VERSION').decode().strip(), manifest['version'])
            names = archive.namelist()
            self.assertEqual(len(names), len(set(names)))
            expected = {'manifest.json'} | {'migrations/' + p for p in manifest['migrations']} | {'files/' + p for p in manifest['files']}
            self.assertEqual(set(names), expected)
            for rel in ('lib/logging-core.php', 'lib/log-catalog.php', 'lib/logging-replay.php',
                        'lib/logging-csrf.php', 'lib/activity-audit.php', 'system-health.php',
                        'cron/replay_logging_spool.php', 'cron/check_logging_health.php',
                        'cron/run_logging_maintenance.bat', 'cron/run_logging_retention.bat',
                        'migrations/020-logging-issues-alerts.sql'):
                if rel.startswith('migrations/'):
                    self.assertIn('migrations/' + rel.split('/', 1)[1], names)
                else:
                    self.assertIn(rel, manifest['files'])
            for rel in manifest['files']:
                target = ROOT / rel
                self.assertEqual(archive.read('files/' + rel), target.read_bytes(), rel)
        self.assertEqual(hashlib.sha256(PACKAGE.read_bytes()).hexdigest(),
                         (PACKAGE.parent / (PACKAGE.name + '.sha256')).read_text().split()[0])



if __name__ == '__main__':
    unittest.main()
