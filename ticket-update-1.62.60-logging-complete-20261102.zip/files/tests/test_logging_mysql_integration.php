<?php
declare(strict_types=1);

$dsn = (string) getenv('ITSM_TEST_DSN');
$user = (string) getenv('ITSM_TEST_DB_USER');
$pass = (string) getenv('ITSM_TEST_DB_PASS');
$dbName = '';
if (preg_match('/dbname=([^;]+)/i', $dsn, $m)) $dbName = trim($m[1]);
if (getenv('ITSM_TEST_ALLOW_DESTRUCTIVE') !== 'YES' || $dsn === '' || !str_contains(strtolower($dbName), 'test')) {
    fwrite(STDOUT, "SKIP: set ITSM_TEST_ALLOW_DESTRUCTIVE=YES and ITSM_TEST_DSN to a dedicated database whose name contains 'test'.\n");
    exit(0);
}
if (!extension_loaded('pdo_mysql')) {
    fwrite(STDOUT, "SKIP: pdo_mysql is unavailable.\n");
    exit(0);
}

$pdo = new PDO($dsn, $user, $pass, [PDO::ATTR_ERRMODE => PDO::ERRMODE_EXCEPTION, PDO::ATTR_EMULATE_PREPARES => false]);
$pdo->exec('DROP TABLE IF EXISTS logging_health_alerts, log_issues, activity_logs, system_logs');
$pdo->exec("CREATE TABLE system_logs (
    id BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY, event_id CHAR(36) NULL UNIQUE, request_id CHAR(36) NULL,
    code VARCHAR(40) NULL, category VARCHAR(24) NOT NULL DEFAULT 'system', fingerprint CHAR(40) NULL,
    level VARCHAR(20) NOT NULL DEFAULT 'error', context VARCHAR(120) NULL, message TEXT NULL, meta_json JSON NULL,
    user_id INT UNSIGNED NULL, request_uri VARCHAR(255) NULL, created_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4");
$pdo->exec("CREATE TABLE activity_logs (id BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY, event_id CHAR(36) NULL UNIQUE, request_id CHAR(36) NULL, result VARCHAR(16) NOT NULL DEFAULT 'success', code VARCHAR(40) NULL, category VARCHAR(24) NOT NULL DEFAULT 'audit', user_id INT UNSIGNED NULL, username VARCHAR(190) NULL, full_name VARCHAR(190) NULL, role VARCHAR(40) NULL, action_code VARCHAR(120) NOT NULL DEFAULT 'test', action_label VARCHAR(190) NULL, module VARCHAR(80) NULL, target_type VARCHAR(40) NULL, target_id BIGINT UNSIGNED NULL, target_label VARCHAR(255) NULL, meta_json JSON NULL, ip_address VARCHAR(64) NULL, computer_name VARCHAR(190) NULL, hostname VARCHAR(190) NULL, user_agent VARCHAR(255) NULL, created_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4");
$root = sys_get_temp_dir() . DIRECTORY_SEPARATOR . 'itsm-mysql-logging-test-' . bin2hex(random_bytes(5));
mkdir($root, 0750, true);
define('APP_ROOT', $root);
$GLOBALS['__logging_mysql_test_pdo'] = $pdo;
function db(bool $reconnect = false): PDO { return $GLOBALS['__logging_mysql_test_pdo']; }
require dirname(__DIR__) . '/lib/logging-core.php';
require dirname(__DIR__) . '/lib/logging-replay.php';

$migration = file_get_contents(dirname(__DIR__) . '/migrations/020-logging-issues-alerts.sql');
if (!is_string($migration)) throw new RuntimeException('Migration 020 could not be read.');
foreach (preg_split('/;\s*(?:\r?\n|$)/', $migration) ?: [] as $statement) {
    $statement = preg_replace('/^\s*--.*$/m', '', trim($statement));
    if ($statement !== '') $pdo->exec($statement);
}

$checks = [];
$event = ['event_id'=>logging_uuid(),'code'=>'SYS-DB-001','category'=>'system','level'=>'error','context'=>'integration-test','message'=>'database integration failure','meta'=>[]];
$checks['system log inserts and creates one aggregated issue'] = logging_store_system($event)
    && (int) $pdo->query('SELECT COUNT(*) FROM system_logs')->fetchColumn() === 1
    && (int) $pdo->query('SELECT COUNT(*) FROM log_issues')->fetchColumn() === 1;
$event['event_id'] = logging_uuid();
$checks['repeated error increments the same issue'] = logging_store_system($event)
    && (int) $pdo->query('SELECT occurrences FROM log_issues')->fetchColumn() === 2;
$pdo->exec("UPDATE log_issues SET status='resolved' WHERE code='SYS-DB-001'");
$event['event_id'] = logging_uuid();
$checks['new occurrence reopens resolved issue'] = logging_store_system($event)
    && (string) $pdo->query('SELECT status FROM log_issues')->fetchColumn() === 'open';

$replayId = logging_uuid();
$insertSql = 'INSERT INTO system_logs (event_id, level, context, message) VALUES (?, ?, ?, ?)';
$first = logging_replay_insert('system_logs', $insertSql, [$replayId, 'error', 'replay', 'test'], $replayId);
$second = logging_replay_insert('system_logs', $insertSql, [$replayId, 'error', 'replay', 'test'], $replayId);
$checks['replay insert is idempotent by event id'] = $first === true && $second === false;

$pdo->beginTransaction();
$event['event_id'] = logging_uuid();
$spooled = logging_store_system($event) === false && logging_spool_stats()['files'] > 0;
$pdo->rollBack();
$checks['open transaction routes technical log to spool'] = $spooled;
$replayResult = logging_replay_process_directory($root . '/storage/logs/spool', 500);
$checks['actual replay worker drains transaction fallback into MySQL'] = $spooled
    && $replayResult['replayed'] === 1 && $replayResult['remaining_files'] === 0
    && (int) $pdo->query('SELECT COUNT(*) FROM system_logs')->fetchColumn() === 5;

$activityEventId = logging_uuid();
$activityRequestId = logging_uuid();
logging_spool_write('activity', ['event_id'=>$activityEventId,'request_id'=>$activityRequestId,'result'=>'denied','code'=>'SEC-ACL-001','category'=>'security','user_id'=>null,'username'=>'test','full_name'=>'Test','role'=>'user','action_code'=>'access_denied','action_label'=>'Denied','module'=>'test','target_type'=>null,'target_id'=>null,'target_label'=>null,'meta'=>[],'ip_address'=>null,'computer_name'=>null,'hostname'=>null,'user_agent'=>'test','created_at'=>date('Y-m-d H:i:s')]);
$activityReplay = logging_replay_process_directory($root . '/storage/logs/spool', 500);
$checks['actual replay worker restores activity audit events'] = $activityReplay['replayed'] === 1
    && (int) $pdo->query('SELECT COUNT(*) FROM activity_logs WHERE event_id = ' . $pdo->quote($activityEventId))->fetchColumn() === 1;

$badFile = $root . '/storage/logs/spool/system-' . date('Ymd') . '.jsonl';
@mkdir(dirname($badFile), 0750, true);
$badLine = "{not-json}\n";
$goodEvent = ['event_id'=>logging_uuid(),'request_id'=>logging_uuid(),'code'=>'SYS-PHP-001','category'=>'system','level'=>'error','context'=>'poison-test','message'=>'valid event after poison','meta'=>[],'created_at'=>date('Y-m-d H:i:s')];
$goodLine = json_encode(['version'=>1,'stream'=>'system','queued_at'=>date('c'),'payload'=>$goodEvent], JSON_UNESCAPED_SLASHES) . "\n";
file_put_contents($badFile, $badLine . $goodLine, FILE_APPEND | LOCK_EX);
$poisonResult = logging_replay_process_directory($root . '/storage/logs/spool', 500);
$remainingPoison = file_get_contents($badFile);
$checks['invalid spool line is retained without blocking later valid records'] = $poisonResult['replayed'] === 1
    && $poisonResult['failed'] === 1 && str_contains((string) $remainingPoison, '{not-json}')
    && (int) $pdo->query("SELECT COUNT(*) FROM system_logs WHERE context = 'poison-test'")->fetchColumn() === 1;
$checks['migration created alert throttle table'] = (int) $pdo->query("SELECT COUNT(*) FROM information_schema.TABLES WHERE TABLE_SCHEMA = DATABASE() AND TABLE_NAME = 'logging_health_alerts'")->fetchColumn() === 1;

$failed = [];
foreach ($checks as $name=>$passed) {
    echo ($passed ? '[PASS] ' : '[FAIL] ') . $name . PHP_EOL;
    if (!$passed) $failed[] = $name;
}
$pdo->exec('DROP TABLE IF EXISTS logging_health_alerts, log_issues, activity_logs, system_logs');
$iterator = new RecursiveIteratorIterator(new RecursiveDirectoryIterator($root, FilesystemIterator::SKIP_DOTS), RecursiveIteratorIterator::CHILD_FIRST);
foreach ($iterator as $item) $item->isDir() ? @rmdir($item->getPathname()) : @unlink($item->getPathname());
@rmdir($root);
if ($failed !== []) { fwrite(STDERR, count($failed) . " MySQL integration test(s) failed.\n"); exit(1); }
echo count($checks) . " MySQL integration tests passed.\n";
