param(
    [switch]$RunOperational
)
$ErrorActionPreference = 'Stop'
$Root = (Resolve-Path (Join-Path $PSScriptRoot '..')).Path
$Php = if ($env:PHP_EXE) { $env:PHP_EXE } else { (Get-Command php.exe -ErrorAction Stop).Source }

Write-Host '== PHP syntax checks =='
$PhpFiles = Get-ChildItem -Path $Root -Recurse -Filter '*.php' -File | Where-Object { $_.FullName -notmatch '\\updates\\' -and $_.FullName -notmatch '\\vendor\\' }
foreach ($File in $PhpFiles) {
    & $Php -l $File.FullName | Out-Null
    if ($LASTEXITCODE -ne 0) { throw "PHP lint failed: $($File.FullName)" }
}
Write-Host ("PASS: {0} PHP files" -f $PhpFiles.Count)

$Tests = @(
    'tests/test_logging_core_offline.php',
    'tests/test_logging_issue_aggregator.php',
    'tests/test_logging_replay_offline.php',
    'tests/test_logging_spool_concurrency.php'
)
foreach ($Test in $Tests) {
    Write-Host "== $Test =="
    & $Php (Join-Path $Root $Test)
    if ($LASTEXITCODE -ne 0) { throw "Test failed: $Test" }
}

if ($RunOperational) {
    Write-Host '== MySQL integration test =='
    & $Php (Join-Path $Root 'tests/test_logging_mysql_integration.php')
    if ($LASTEXITCODE -ne 0) { throw 'MySQL integration test failed.' }
    Write-Host '== Replay worker =='
    & $Php (Join-Path $Root 'cron/replay_logging_spool.php')
    if ($LASTEXITCODE -ne 0) { throw 'Replay worker failed.' }
    Write-Host '== Logging health alerts =='
    & $Php (Join-Path $Root 'cron/check_logging_health.php')
    if ($LASTEXITCODE -ne 0) { throw 'Logging health check failed.' }
}

Write-Host 'All selected Logging staging checks passed.'
