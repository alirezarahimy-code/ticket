<?php
declare(strict_types=1);

$root = sys_get_temp_dir() . DIRECTORY_SEPARATOR . 'itsm-replay-offline-' . bin2hex(random_bytes(5));
mkdir($root, 0750, true);
define('APP_ROOT', $root);

class ReplayFakePDO extends PDO
{
    public array $system = [];
    public array $activity = [];
    public array $issues = [];
    public function __construct() {}
    public function prepare(string $query, array $options = []): PDOStatement|false { return new ReplayFakeStatement($this, $query); }
}
class ReplayFakeStatement extends PDOStatement
{
    private array $params = [];
    public function __construct(private ReplayFakePDO $owner, private string $sql) {}
    public function execute(?array $params = null): bool
    {
        $this->params = $params ?? [];
        if (str_starts_with($this->sql, 'INSERT INTO system_logs')) {
            $id = (string) ($this->params[0] ?? '');
            if (isset($this->owner->system[$id])) throw new PDOException('duplicate event id', 23000);
            $this->owner->system[$id] = $this->params;
        } elseif (str_starts_with($this->sql, 'INSERT INTO activity_logs')) {
            $id = (string) ($this->params[0] ?? '');
            if (isset($this->owner->activity[$id])) throw new PDOException('duplicate event id', 23000);
            $this->owner->activity[$id] = $this->params;
        } elseif (str_starts_with($this->sql, 'INSERT INTO log_issues')) {
            $fp = (string) ($this->params[0] ?? '');
            if (isset($this->owner->issues[$fp])) $this->owner->issues[$fp]['occurrences']++;
            else $this->owner->issues[$fp] = ['occurrences'=>1,'status'=>'open'];
        } elseif (str_starts_with($this->sql, 'SELECT 1 FROM `system_logs`')) {
            $this->found = isset($this->owner->system[(string) ($this->params[0] ?? '')]);
        } elseif (str_starts_with($this->sql, 'SELECT 1 FROM `activity_logs`')) {
            $this->found = isset($this->owner->activity[(string) ($this->params[0] ?? '')]);
        }
        return true;
    }
    private bool $found = false;
    public function fetchColumn(int $column = 0): mixed { return $this->found ? 1 : false; }
}
$GLOBALS['__replay_fake_pdo'] = new ReplayFakePDO();
function db(bool $reconnect = false): PDO { return $GLOBALS['__replay_fake_pdo']; }
require dirname(__DIR__) . '/lib/logging-core.php';
require dirname(__DIR__) . '/lib/logging-replay.php';

$systemId = logging_uuid(); $systemRequest = logging_uuid();
$activityId = logging_uuid(); $activityRequest = logging_uuid();
logging_spool_write('system', ['event_id'=>$systemId,'request_id'=>$systemRequest,'code'=>'SYS-PHP-001','category'=>'system','level'=>'error','context'=>'offline-replay','message'=>'offline error','meta'=>[],'created_at'=>date('Y-m-d H:i:s')]);
logging_spool_write('activity', ['event_id'=>$activityId,'request_id'=>$activityRequest,'result'=>'denied','code'=>'SEC-ACL-001','category'=>'security','user_id'=>null,'username'=>'test','full_name'=>'Test','role'=>'user','action_code'=>'access_denied','action_label'=>'Denied','module'=>'test','target_type'=>null,'target_id'=>null,'target_label'=>null,'meta'=>[],'ip_address'=>null,'computer_name'=>null,'hostname'=>null,'user_agent'=>'test','created_at'=>date('Y-m-d H:i:s')]);

$first = logging_replay_process_directory($root . '/storage/logs/spool', 1);
$second = logging_replay_process_directory($root . '/storage/logs/spool', 10);
$checks = [];
$checks['batch cap leaves unprocessed lines for next run'] = $first['processed'] === 1 && $first['remaining_files'] === 1;
$checks['system and activity streams both replay'] = $second['replayed'] === 1 && $second['remaining_files'] === 0
    && isset($GLOBALS['__replay_fake_pdo']->system[$systemId]) && isset($GLOBALS['__replay_fake_pdo']->activity[$activityId]);
$issueCount = array_sum(array_column($GLOBALS['__replay_fake_pdo']->issues, 'occurrences'));
$duplicateFile = $root . '/storage/logs/spool/system-' . date('Ymd') . '.jsonl';
$record = ['version'=>1,'stream'=>'system','queued_at'=>date('c'),'payload'=>['event_id'=>$systemId,'request_id'=>$systemRequest,'code'=>'SYS-PHP-001','category'=>'system','level'=>'error','context'=>'offline-replay','message'=>'offline error','meta'=>[],'created_at'=>date('Y-m-d H:i:s')]];
file_put_contents($duplicateFile, json_encode($record, JSON_UNESCAPED_SLASHES) . "\n", LOCK_EX);
$duplicate = logging_replay_process_directory($root . '/storage/logs/spool', 10);
$checks['duplicate event replay is idempotent and does not double-count issue'] = $duplicate['replayed'] === 1
    && array_sum(array_column($GLOBALS['__replay_fake_pdo']->issues, 'occurrences')) === $issueCount;

$poisonFile = $root . '/storage/logs/spool/system-' . date('Ymd') . '.jsonl';
$goodId = logging_uuid(); $goodRequest = logging_uuid();
$goodRecord = ['version'=>1,'stream'=>'system','queued_at'=>date('c'),'payload'=>['event_id'=>$goodId,'request_id'=>$goodRequest,'code'=>'SYS-PHP-001','category'=>'system','level'=>'error','context'=>'after-poison','message'=>'valid','meta'=>[],'created_at'=>date('Y-m-d H:i:s')]];
file_put_contents($poisonFile, "{invalid-json}\n" . json_encode($goodRecord, JSON_UNESCAPED_SLASHES) . "\n", LOCK_EX);
$poison = logging_replay_process_directory($root . '/storage/logs/spool', 10);
$left = (string) @file_get_contents($poisonFile);
$checks['corrupt record is retained while later valid records still replay'] = $poison['failed'] === 1 && $poison['replayed'] === 1
    && str_contains($left, '{invalid-json}') && isset($GLOBALS['__replay_fake_pdo']->system[$goodId]);

$failed = [];
foreach ($checks as $label=>$passed) { echo ($passed ? '[PASS] ' : '[FAIL] ') . $label . PHP_EOL; if (!$passed) $failed[] = $label; }
$iterator = new RecursiveIteratorIterator(new RecursiveDirectoryIterator($root, FilesystemIterator::SKIP_DOTS), RecursiveIteratorIterator::CHILD_FIRST);
foreach ($iterator as $item) $item->isDir() ? @rmdir($item->getPathname()) : @unlink($item->getPathname());
@rmdir($root);
if ($failed) { fwrite(STDERR, count($failed) . " replay test(s) failed.\n"); exit(1); }
echo count($checks) . " offline replay tests passed.\n";
