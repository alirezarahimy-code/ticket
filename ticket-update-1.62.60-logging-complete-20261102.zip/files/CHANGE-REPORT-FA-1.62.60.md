# گزارش تحویل نسخهٔ 1.62.60 — تکمیل سیستم Logging

## وضعیت انتشار

- شمارهٔ نسخه در `VERSION` و `manifest.json`: `1.62.60` (طبق درخواست مالک سامانه).
- هیچ تغییری روی سامانهٔ زنده اعمال نشده است.
- بستهٔ به‌روزرسانی شامل Migrationهای 019 و 020 است.
- نکتهٔ نسخه: ZIP ورودی با نام `ticket-full-1.62.60-20261101.zip` در فایل داخلی `VERSION` مقدار `1.62.62` داشت. خروجی با شمارهٔ خواسته‌شدهٔ 1.62.60 ساخته شده؛ بنابراین روی نصب 1.62.62، Updater حالت Downgrade می‌خواهد.

## تغییرات اصلی

### 1. معماری و هسته

- تفکیک کاتالوگ رویدادها در `lib/log-catalog.php` از هستهٔ `lib/logging-core.php`.
- تعریف پیام قابل‌فهم کاربر، توضیح مدیریتی، علت احتمالی، اقدام پیشنهادی، کلیدهای مجاز زمینه و Alias برای کدهای پایدار.
- افزودن Aliasهای سازگار برای خطاهای PHP/DB/LDAP، ورود ناموفق، دسترسی غیرمجاز، CSRF و Backup.
- افزودن helperهای UTF-8 که در نبود `mbstring` از `iconv` و سپس fallback استفاده می‌کنند.
- حذف DDL زمان اجرا از `system_logs_ensure`، `activity_logs_ensure` و `system_health_ensure`; ساختار فقط از schema/Migration می‌آید.
- اصلاح مسیر خطای تراکنش: تابع void دیگر به‌عنوان مقدار بازگشتی استفاده نمی‌شود؛ رخداد فنی داخل تراکنش به Spool می‌رود و `false` برمی‌گردد.

### 2. تجمیع Issueها و اعلان

- ایجاد جدول `log_issues` با SHA-256 fingerprint، کد، دسته، شدت، عنوان، first/last seen، شمارنده، آخرین Event/Request ID، وضعیت، مسئول و یادداشت رسیدگی.
- تجمیع اتمیک خطاهای warning/error/critical؛ رویداد خام همچنان در `system_logs` باقی می‌ماند.
- رخداد جدید برای Issue رفع‌شده، آن را دوباره به open برمی‌گرداند.
- پس از ۵ رخداد، اعلان به مدیر اصلی ارسال می‌شود؛ هر Issue حداکثر هر ۳۰ دقیقه یک اعلان می‌دهد.
- حفظ داده‌های امنیتی/حسابرسی؛ هیچ سرکوبی برای رخداد خام امنیتی انجام نمی‌شود.

### 3. بازپخش صف و پایداری

- انتقال منطق بازپخش به `lib/logging-replay.php`.
- خواندن JSONL به‌صورت خط‌به‌خط و با سقف دسته‌ای؛ از بارگذاری کل فایل در حافظه جلوگیری می‌شود.
- قفل مشترک `.writer.lock` میان نویسنده و Worker.
- بازنویسی اتمیک با فایل `.processing` و بازیابی حالت crash.
- حفظ رکورد خراب در صف، بدون جلوگیری از پردازش رکوردهای سالم بعدی.
- جلوگیری از دوباره‌شماری Issue در بازپخش Event ID تکراری.
- ثبت آخرین تلاش/موفقیت، نتیجه، مدت اجرا و حجم باقی‌مانده در `logging-worker-status.json`.

### 4. امنیت و پوشش رخداد

- ثبت رخداد 403 در `require_permission` و `require_any_permission`.
- ثبت رخداد 419/CSRF در `require_csrf`.
- نگاشت صریح تغییر نقش/مجوز، تنظیمات حساس، Backup/Restore و عملیات ساختار سازمانی به کدهای Audit پایدار.
- خاموش‌کردن نمایش خطاهای خام PHP برای وب؛ Exception و Fatal Error پیام فارسی و Request ID نمایش می‌دهند.
- پالایش جزئیات حساس در متادیتای Audit و خروجی‌های گزارش.

### 5. پایش و گزارش

- افزودن `cron/check_logging_health.php` برای بررسی صف، رخداد ازدست‌رفته، Worker، فضای دیسک، خطاهای DB و حجم جدول لاگ.
- ایجاد `logging_health_alerts` برای Rate Limit اعلان‌های سلامت به مدیر اصلی (۳۰ دقیقه).
- افزودن Issue Management با فیلتر بازه/شدت/دسته/وضعیت، نمایش علت و اقدام پیشنهادی و تغییر وضعیت با ثبت Audit.
- افزودن برگهٔ Issueها به گزارش مدیریتی امن.
- افزودن گزارش فنی پالایش‌شدهٔ جداگانه، فقط برای مجوز `logs.view`.
- افزودن فیلتر کد، دسته، شدت، کاربر، نتیجه و Request ID در گزارش فعالیت/خطا.
- محدودکردن جست‌وجوی گزارش به ۹۰ روز پیش‌فرض و حداکثر ۳۶۵ روز.
- نمایش تفاوت‌های before/after در متادیتای Audit و پالایش کلیدهای محرمانه.

### 6. نگهداری

| کلاس | مدت |
|---|---:|
| Debug | ۷ روز |
| Info/Notice | ۳۰ روز |
| Business | ۶۰ روز |
| Warning/Error/Critical فنی | حداقل ۹۰ روز |
| Security/Audit/Operation حساس | حداقل ۱۸۳ روز |
| Issueهای resolved | ۳۶۵ روز پس از آخرین مشاهده؛ open/investigating حذف نمی‌شوند |

- چرخش `app.log` هم بر اساس روز و هم آستانهٔ ۱۰ مگابایت انجام می‌شود؛ حداکثر ۱۴ آرشیو حفظ می‌شود.
- حداقل دورهٔ فعالیت عادی به ۶۰ روز محدود شده است.

### 7. Windows Server

- افزودن `cron/run_logging_maintenance.bat` برای اجرای بازپخش و هشدار سلامت.
- افزودن `cron/run_logging_retention.bat` برای پاک‌سازی روزانه.
- افزودن راهنمای دقیق Task Scheduler در `docs/LOGGING-OPERATIONS-FA.md`.
- افزودن اسکریپت آزمون Staging در `tests/run_logging_staging_checks.ps1`.

## فایل‌های مهم افزوده‌شده

- `lib/log-catalog.php`
- `lib/logging-replay.php`
- `migrations/020-logging-issues-alerts.sql`
- `cron/check_logging_health.php`
- `cron/run_logging_maintenance.bat`
- `cron/run_logging_retention.bat`
- `docs/LOGGING-OPERATIONS-FA.md`
- `tests/test_logging_issue_aggregator.php`
- `tests/test_logging_replay_offline.php`
- `tests/test_logging_spool_concurrency.php`
- `tests/test_logging_mysql_integration.php`
- `tests/run_logging_staging_checks.ps1`

## آزمون‌های اجراشده در محیط ساخت

- PHP Lint: ۱۸۳ فایل جاری بدون خطای نحوی.
- Logging Offline: ۱۷/۱۷ موفق.
- Issue Aggregator: ۷/۷ موفق.
- Replay Offline: ۴/۴ موفق.
- Spool Concurrency: ۴۰۰/۴۰۰ رکورد JSONL سالم.
- Static tests مرتبط با Logging و System Health و بستهٔ انتشار: ۳۷ موفق، ۴ Skip.
- MySQL Integration: اجرا نشد؛ `pdo_mysql` و سرور MySQL/MariaDB در محیط ساخت موجود نیست.
- Windows Task Scheduler: قابل اجرا در محیط Linux ساخت نیست؛ فایل‌های اجرایی و دستورالعمل Staging آماده شده‌اند.
- کل مجموعهٔ pytest: ۳۵۱ موفق، ۵۳ ناموفق، ۹ Skip و ۱۸ subtest موفق. شکست‌های باقی‌مانده عمدتاً به بسته‌های تاریخی 1.62.2 تا 1.62.36 و Git history نیاز دارند که در ZIP ورودی موجود نبودند؛ چند آزمون قدیمی مستقل در Asset Inventory/Food نیز خارج از دامنهٔ Logging ناموفق‌اند.

## محدودیت‌های تأیید

کد و مسیرهای جایگزین/بازپخش با Fake PDO و تست هم‌زمانی آزمایش شده‌اند، اما هیچ ادعایی دربارهٔ اجرای موفق Migration یا اتصال واقعی MySQL/MariaDB و اجرای واقعی Task Scheduler در این محیط مطرح نمی‌شود. برای تأیید عملیاتی نهایی، اسکریپت MySQL Integration باید در یک دیتابیس آزمایشی اختصاصی با نام حاوی `test` اجرا شود و Task Scheduler روی Windows Server واقعی آزمایش شود.
