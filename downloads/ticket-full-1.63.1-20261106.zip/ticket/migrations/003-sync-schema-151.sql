-- نسخهٔ ۱.۵۱: همگام‌سازی جدول‌ها و ستون‌های مورد نیاز (idempotent).
-- هر دستور فقط در صورت نبودن جدول/ستون اجرا می‌شود؛ اجرای دوباره بی‌خطر است.
-- MariaDB لازم است (ADD COLUMN IF NOT EXISTS).

CREATE TABLE IF NOT EXISTS settings (
    `key` VARCHAR(100) PRIMARY KEY,
    `value` TEXT NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
CREATE TABLE IF NOT EXISTS departments (
    id INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
    name VARCHAR(150) NOT NULL UNIQUE,
    code VARCHAR(40) NULL UNIQUE,
    manager_user_id INT UNSIGNED NULL,
    is_active TINYINT(1) NOT NULL DEFAULT 1,
    created_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
    INDEX idx_departments_manager (manager_user_id)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
CREATE TABLE IF NOT EXISTS org_units (
    id INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
    name VARCHAR(190) NOT NULL,
    code VARCHAR(60) NULL,
    parent_id INT UNSIGNED NULL,
    unit_type VARCHAR(20) NOT NULL DEFAULT 'department',
    manager_user_id INT UNSIGNED NULL,
    is_primary_admin TINYINT(1) NOT NULL DEFAULT 0,
    is_active TINYINT(1) NOT NULL DEFAULT 1,
    created_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
    INDEX idx_org_parent (parent_id),
    INDEX idx_org_type (unit_type),
    INDEX idx_org_manager (manager_user_id)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
CREATE TABLE IF NOT EXISTS org_unit_managers (
    unit_id INT UNSIGNED NOT NULL,
    user_id INT UNSIGNED NOT NULL,
    is_primary TINYINT(1) NOT NULL DEFAULT 0,
    PRIMARY KEY (unit_id, user_id),
    INDEX idx_org_mgr_user (user_id)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
CREATE TABLE IF NOT EXISTS users (
    id INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
    username VARCHAR(190) NOT NULL UNIQUE,
    password_hash VARCHAR(255) NULL,
    full_name VARCHAR(190) NOT NULL,
    first_name VARCHAR(100) NULL,
    last_name VARCHAR(100) NULL,
    profile_photo VARCHAR(255) NULL,
    email VARCHAR(190) NULL,
    employee_number VARCHAR(100) NULL,
    UNIQUE KEY uq_users_employee_number (employee_number),
    national_code VARCHAR(30) NULL,
    phone VARCHAR(80) NULL,
    department VARCHAR(190) NULL,
    department_id INT UNSIGNED NULL,
    requesting_unit_id INT UNSIGNED NULL,
    org_unit_id INT UNSIGNED NULL,
    manager_user_id INT UNSIGNED NULL,
    handling_unit_id INT UNSIGNED NULL,
    is_it_agent TINYINT(1) NOT NULL DEFAULT 0,
    is_primary_admin TINYINT(1) NOT NULL DEFAULT 0,
    role ENUM('user','agent','manager','supervisor','admin','primary_admin','support_manager','inspector','local_user','guard') NOT NULL DEFAULT 'user',
    auth_source ENUM('local','ldap','food') NOT NULL DEFAULT 'local',
    is_active TINYINT(1) NOT NULL DEFAULT 1,
    last_login_at DATETIME NULL,
    must_change_password TINYINT(1) NOT NULL DEFAULT 0,
    created_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
    INDEX idx_users_role (role),
    INDEX idx_users_department (department),
    INDEX idx_users_department_id (department_id),
    INDEX idx_users_national_code (national_code),
    CONSTRAINT fk_users_department FOREIGN KEY (department_id) REFERENCES departments(id) ON DELETE SET NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
CREATE TABLE IF NOT EXISTS handling_units (
    id INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
    code ENUM('it','support') NOT NULL UNIQUE,
    name VARCHAR(150) NOT NULL,
    manager_user_id INT UNSIGNED NULL,
    is_active TINYINT(1) NOT NULL DEFAULT 1,
    created_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
    INDEX idx_handling_manager (manager_user_id),
    CONSTRAINT fk_handling_manager FOREIGN KEY (manager_user_id) REFERENCES users(id) ON DELETE SET NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
CREATE TABLE IF NOT EXISTS cd_dvd_types (
    id INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
    name VARCHAR(80) NOT NULL UNIQUE,
    is_default TINYINT(1) NOT NULL DEFAULT 0
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
CREATE TABLE IF NOT EXISTS cd_dvd_records (
    id BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
    media ENUM('CD','DVD') NOT NULL,
    direction ENUM('IN','OUT') NOT NULL,
    serial VARCHAR(20) NOT NULL,
    info_type VARCHAR(80) NOT NULL,
    info_desc TEXT NOT NULL,
    jy SMALLINT UNSIGNED NOT NULL,
    jm TINYINT UNSIGNED NOT NULL,
    jd TINYINT UNSIGNED NOT NULL,
    date_str VARCHAR(20) NOT NULL,
    sort_key INT UNSIGNED NOT NULL,
    receiver VARCHAR(190) NULL,
    receiver_unit VARCHAR(190) NULL,
    brought_by VARCHAR(190) NULL,
    brought_by_user_id INT UNSIGNED NULL,
    exit_sheet VARCHAR(100) NULL,
    note TEXT NULL,
    department_id INT UNSIGNED NULL,
    recorder_id INT UNSIGNED NOT NULL,
    recorder_name VARCHAR(190) NOT NULL,
    created_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
    updated_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    INDEX idx_cd_dvd_serial (serial, media, sort_key, id),
    INDEX idx_cd_dvd_department (department_id),
    INDEX idx_cd_dvd_recorder (recorder_id),
    INDEX idx_cd_dvd_brought_by_user (brought_by_user_id),
    INDEX idx_cd_dvd_direction (direction),
    CONSTRAINT fk_cd_dvd_department FOREIGN KEY (department_id) REFERENCES departments(id) ON DELETE SET NULL,
    CONSTRAINT fk_cd_dvd_recorder FOREIGN KEY (recorder_id) REFERENCES users(id) ON DELETE RESTRICT,
    CONSTRAINT fk_cd_dvd_brought_by_user FOREIGN KEY (brought_by_user_id) REFERENCES users(id) ON DELETE SET NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
CREATE TABLE IF NOT EXISTS traffic_destinations (
    id INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
    title VARCHAR(190) NOT NULL,
    approver_name VARCHAR(190) NULL,
    is_active TINYINT(1) NOT NULL DEFAULT 1,
    created_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
    UNIQUE KEY uq_traffic_destination (title)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
CREATE TABLE IF NOT EXISTS traffic_visits (
    id INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
    serial_no VARCHAR(30) NOT NULL,
    visit_date DATE NOT NULL,
    full_name VARCHAR(190) NOT NULL,
    national_code VARCHAR(10) DEFAULT NULL,
    phone VARCHAR(20) DEFAULT NULL,
    company VARCHAR(190) DEFAULT NULL,
    entry_time TIME DEFAULT NULL,
    exit_time TIME DEFAULT NULL,
    no_visit TINYINT(1) NOT NULL DEFAULT 0,
    with_car TINYINT(1) NOT NULL DEFAULT 0,
    with_mobile TINYINT(1) NOT NULL DEFAULT 0,
    meeting_with VARCHAR(190) DEFAULT NULL,
    approved_by VARCHAR(190) DEFAULT NULL,
    description TEXT,
    is_notice TINYINT(1) NOT NULL DEFAULT 0,
    created_by INT UNSIGNED DEFAULT NULL,
    created_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
    updated_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    KEY idx_traffic_national_code (national_code),
    KEY idx_traffic_visit_date (visit_date),
    KEY idx_traffic_serial (serial_no),
    KEY idx_traffic_created_by (created_by),
    CONSTRAINT fk_traffic_visits_user FOREIGN KEY (created_by) REFERENCES users(id) ON DELETE SET NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
CREATE TABLE IF NOT EXISTS categories (
    id INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
    name VARCHAR(150) NOT NULL,
    code VARCHAR(60) NULL UNIQUE,
    service_group ENUM('it','support') NOT NULL DEFAULT 'it',
    is_active TINYINT(1) NOT NULL DEFAULT 1,
    created_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
CREATE TABLE IF NOT EXISTS service_catalog (
    id INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
    name VARCHAR(190) NOT NULL,
    code VARCHAR(60) NOT NULL UNIQUE,
    description TEXT NULL,
    service_group ENUM('it','support') NOT NULL DEFAULT 'it',
    default_priority ENUM('normal','urgent','critical') NOT NULL DEFAULT 'normal',
    department_id INT UNSIGNED NULL,
    category_id INT UNSIGNED NULL,
    handling_unit_id INT UNSIGNED NULL,
    requires_asset TINYINT(1) NOT NULL DEFAULT 1,
    default_ticket_type ENUM('incident','request','problem','change') NOT NULL DEFAULT 'incident',
    is_active TINYINT(1) NOT NULL DEFAULT 1,
    created_by INT UNSIGNED NULL,
    created_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
    updated_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    INDEX idx_services_department (department_id),
    INDEX idx_services_group (service_group, is_active),
    INDEX idx_services_handling (handling_unit_id),
    INDEX idx_services_category (category_id),
    CONSTRAINT fk_services_department FOREIGN KEY (department_id) REFERENCES departments(id) ON DELETE SET NULL,
    CONSTRAINT fk_services_handling FOREIGN KEY (handling_unit_id) REFERENCES handling_units(id) ON DELETE SET NULL,
    CONSTRAINT fk_services_category FOREIGN KEY (category_id) REFERENCES categories(id) ON DELETE SET NULL,
    CONSTRAINT fk_services_creator FOREIGN KEY (created_by) REFERENCES users(id) ON DELETE SET NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
CREATE TABLE IF NOT EXISTS service_catalog_fields (
    id INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
    service_id INT UNSIGNED NOT NULL,
    field_key VARCHAR(80) NOT NULL,
    label VARCHAR(190) NOT NULL,
    field_type ENUM('text','textarea','number','select','date') NOT NULL DEFAULT 'text',
    options_json JSON NULL,
    is_required TINYINT(1) NOT NULL DEFAULT 0,
    sort_order SMALLINT UNSIGNED NOT NULL DEFAULT 0,
    UNIQUE KEY uq_service_field_key (service_id, field_key),
    CONSTRAINT fk_service_field_service FOREIGN KEY (service_id) REFERENCES service_catalog(id) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
CREATE TABLE IF NOT EXISTS tickets (
    id INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
    ticket_no VARCHAR(40) NULL,
    subject VARCHAR(255) NOT NULL,
    description TEXT NOT NULL,
    category_id INT UNSIGNED NULL,
    service_id INT UNSIGNED NULL,
    ticket_type ENUM('incident','request','problem','change') NOT NULL DEFAULT 'incident',
    parent_ticket_id INT UNSIGNED NULL,
    custom_fields JSON NULL,
    service_group ENUM('it','support') NOT NULL DEFAULT 'it',
    department_id INT UNSIGNED NULL,
    requesting_unit_id INT UNSIGNED NULL,
    asset_id INT UNSIGNED NULL,
    handling_unit_id INT UNSIGNED NULL,
    support_location VARCHAR(255) NULL,
    support_equipment TEXT NULL,
    priority ENUM('normal','urgent','critical') NOT NULL DEFAULT 'normal',
    status ENUM('new','manager_review','assigned','in_progress','waiting_user','pending','resolved','closed','cancelled') NOT NULL DEFAULT 'manager_review',
    requester_id INT UNSIGNED NOT NULL,
    assigned_to INT UNSIGNED NULL,
    assigned_at DATETIME NULL,
    first_response_at DATETIME NULL,
    resolved_at DATETIME NULL,
    closed_at DATETIME NULL,
    cancel_requested_at DATETIME NULL,
    cancel_requested_by INT UNSIGNED NULL,
    cancel_request_reason TEXT NULL,
    due_at DATETIME NULL,
    sla_minutes INT UNSIGNED NULL,
    ola_policy_id INT UNSIGNED NULL,
    ola_response_due_at DATETIME NULL,
    ola_due_at DATETIME NULL,
    ola_escalation_1_at DATETIME NULL,
    ola_escalation_2_at DATETIME NULL,
    sla_paused_at DATETIME NULL,
    sla_pause_minutes INT UNSIGNED NOT NULL DEFAULT 0,
    supervisor_id INT UNSIGNED NULL,
    supervisor_approved_at DATETIME NULL,
    supervisor_note TEXT NULL,
    created_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
    updated_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    INDEX idx_tickets_status (status),
    INDEX idx_tickets_requester (requester_id),
    UNIQUE KEY uq_tickets_no (ticket_no),
    INDEX idx_tickets_department (department_id),
    INDEX idx_tickets_service_group (service_group),
    INDEX idx_tickets_handling (handling_unit_id),
    INDEX idx_tickets_asset (asset_id),
    INDEX idx_tickets_service (service_id),
    INDEX idx_tickets_type (ticket_type),
    INDEX idx_tickets_parent (parent_ticket_id),
    INDEX idx_tickets_created (created_at),
    INDEX idx_tickets_status_created (status, created_at),
    INDEX idx_tickets_assignee_status (assigned_to, status),
    INDEX idx_tickets_requester_created (requester_id, created_at),
    INDEX idx_tickets_requesting_unit (requesting_unit_id),
    CONSTRAINT fk_tickets_category FOREIGN KEY (category_id) REFERENCES categories(id) ON DELETE SET NULL,
    CONSTRAINT fk_tickets_service FOREIGN KEY (service_id) REFERENCES service_catalog(id) ON DELETE SET NULL,
    CONSTRAINT fk_tickets_parent FOREIGN KEY (parent_ticket_id) REFERENCES tickets(id) ON DELETE SET NULL,
    CONSTRAINT fk_tickets_department FOREIGN KEY (department_id) REFERENCES departments(id) ON DELETE SET NULL,
    CONSTRAINT fk_tickets_handling FOREIGN KEY (handling_unit_id) REFERENCES handling_units(id) ON DELETE SET NULL,
    CONSTRAINT fk_tickets_requester FOREIGN KEY (requester_id) REFERENCES users(id) ON DELETE RESTRICT,
    CONSTRAINT fk_tickets_assigned FOREIGN KEY (assigned_to) REFERENCES users(id) ON DELETE SET NULL,
    CONSTRAINT fk_tickets_supervisor FOREIGN KEY (supervisor_id) REFERENCES users(id) ON DELETE SET NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
CREATE TABLE IF NOT EXISTS ticket_messages (
    id INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
    ticket_id INT UNSIGNED NOT NULL,
    user_id INT UNSIGNED NOT NULL,
    body TEXT NOT NULL,
    is_internal TINYINT(1) NOT NULL DEFAULT 0,
    created_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
    INDEX idx_messages_ticket (ticket_id),
    CONSTRAINT fk_messages_ticket FOREIGN KEY (ticket_id) REFERENCES tickets(id) ON DELETE CASCADE,
    CONSTRAINT fk_messages_user FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE RESTRICT
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
CREATE TABLE IF NOT EXISTS ticket_ratings (
    id BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
    ticket_id INT UNSIGNED NOT NULL UNIQUE,
    agent_id INT UNSIGNED NULL,
    requester_id INT UNSIGNED NOT NULL,
    score TINYINT UNSIGNED NOT NULL,
    comment TEXT NULL,
    created_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
    CONSTRAINT chk_ticket_rating_score CHECK (score BETWEEN 1 AND 5),
    CONSTRAINT fk_rating_ticket FOREIGN KEY (ticket_id) REFERENCES tickets(id) ON DELETE CASCADE,
    CONSTRAINT fk_rating_agent FOREIGN KEY (agent_id) REFERENCES users(id) ON DELETE SET NULL,
    CONSTRAINT fk_rating_requester FOREIGN KEY (requester_id) REFERENCES users(id) ON DELETE RESTRICT
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
CREATE TABLE IF NOT EXISTS ticket_attachments (
    id INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
    message_id INT UNSIGNED NOT NULL,
    original_name VARCHAR(255) NOT NULL,
    stored_name VARCHAR(255) NOT NULL UNIQUE,
    mime VARCHAR(150) NOT NULL,
    size_bytes INT UNSIGNED NOT NULL,
    created_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
    CONSTRAINT fk_attachments_message FOREIGN KEY (message_id) REFERENCES ticket_messages(id) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
CREATE TABLE IF NOT EXISTS activity_logs (
    id BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
    user_id INT UNSIGNED NULL,
    username VARCHAR(190) NULL,
    full_name VARCHAR(190) NULL,
    role VARCHAR(40) NULL,
    action_code VARCHAR(120) NOT NULL,
    action_label VARCHAR(190) NULL,
    module VARCHAR(80) NULL,
    target_type VARCHAR(40) NULL,
    target_id BIGINT UNSIGNED NULL,
    target_label VARCHAR(255) NULL,
    meta_json JSON NULL,
    ip_address VARCHAR(64) NULL,
    computer_name VARCHAR(190) NULL,
    hostname VARCHAR(190) NULL,
    user_agent VARCHAR(255) NULL,
    created_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
    INDEX idx_activity_created (created_at),
    INDEX idx_activity_user (user_id),
    INDEX idx_activity_action (action_code),
    INDEX idx_activity_module (module),
    INDEX idx_activity_ip (ip_address),
    CONSTRAINT fk_activity_user FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE SET NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
CREATE TABLE IF NOT EXISTS role_permissions (
    role VARCHAR(40) NOT NULL,
    permission VARCHAR(80) NOT NULL,
    PRIMARY KEY (role, permission),
    INDEX idx_role_perm_permission (permission)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
CREATE TABLE IF NOT EXISTS notifications (
    id BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
    user_id INT UNSIGNED NOT NULL,
    ticket_id INT UNSIGNED NULL,
    notification_type VARCHAR(80) NOT NULL,
    title VARCHAR(255) NOT NULL,
    body TEXT NOT NULL,
    is_read TINYINT(1) NOT NULL DEFAULT 0,
    created_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
    read_at DATETIME NULL,
    INDEX idx_notifications_user (user_id, is_read, created_at),
    CONSTRAINT fk_notifications_user FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE,
    CONSTRAINT fk_notifications_ticket FOREIGN KEY (ticket_id) REFERENCES tickets(id) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
CREATE TABLE IF NOT EXISTS login_attempts (
    attempt_key CHAR(64) PRIMARY KEY,
    attempts SMALLINT UNSIGNED NOT NULL DEFAULT 0,
    window_started DATETIME NOT NULL,
    locked_until DATETIME NULL,
    updated_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
CREATE TABLE IF NOT EXISTS ticket_sla_alerts (
    id BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
    ticket_id INT UNSIGNED NOT NULL,
    alert_type ENUM('due_soon','overdue') NOT NULL,
    due_at DATETIME NOT NULL,
    created_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
    UNIQUE KEY uq_ticket_sla_alert (ticket_id, alert_type, due_at),
    CONSTRAINT fk_sla_alert_ticket FOREIGN KEY (ticket_id) REFERENCES tickets(id) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
CREATE TABLE IF NOT EXISTS ticket_events (
    id BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
    ticket_id INT UNSIGNED NOT NULL,
    user_id INT UNSIGNED NULL,
    event_type VARCHAR(80) NOT NULL,
    from_status VARCHAR(40) NULL,
    to_status VARCHAR(40) NULL,
    details JSON NULL,
    created_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
    INDEX idx_events_ticket (ticket_id),
    INDEX idx_events_created (created_at),
    CONSTRAINT fk_events_ticket FOREIGN KEY (ticket_id) REFERENCES tickets(id) ON DELETE CASCADE,
    CONSTRAINT fk_events_user FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE SET NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
CREATE TABLE IF NOT EXISTS knowledge_articles (
    id INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
    title VARCHAR(255) NOT NULL,
    slug VARCHAR(190) NOT NULL UNIQUE,
    body MEDIUMTEXT NOT NULL,
    category VARCHAR(150) NULL,
    is_published TINYINT(1) NOT NULL DEFAULT 1,
    created_by INT UNSIGNED NULL,
    created_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
    updated_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    FULLTEXT KEY ft_knowledge (title, body),
    CONSTRAINT fk_knowledge_creator FOREIGN KEY (created_by) REFERENCES users(id) ON DELETE SET NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
CREATE TABLE IF NOT EXISTS holidays (
    id INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
    holiday_date DATE NOT NULL UNIQUE,
    title VARCHAR(190) NOT NULL,
    is_active TINYINT(1) NOT NULL DEFAULT 1,
    created_by INT UNSIGNED NULL,
    created_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
    CONSTRAINT fk_holiday_creator FOREIGN KEY (created_by) REFERENCES users(id) ON DELETE SET NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
CREATE TABLE IF NOT EXISTS assets (
    id INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
    asset_tag VARCHAR(100) NOT NULL UNIQUE,
    record_number VARCHAR(100) NULL,
    hostname VARCHAR(190) NULL,
    serial_number VARCHAR(190) NULL,
    computer_type VARCHAR(100) NULL,
    manufacturer VARCHAR(190) NULL,
    model VARCHAR(190) NULL,
    asset_number VARCHAR(100) NULL,
    seal_number VARCHAR(100) NULL,
    plaque_number VARCHAR(100) NULL,
    employee_number VARCHAR(100) NULL,
    person_number VARCHAR(100) NULL,
    city VARCHAR(100) NULL,
    phone VARCHAR(80) NULL,
    owner_user_id INT UNSIGNED NULL,
    department_id INT UNSIGNED NULL,
    operating_system VARCHAR(255) NULL,
    ip_address VARCHAR(100) NULL,
    mac_address VARCHAR(100) NULL,
    cpu VARCHAR(255) NULL,
    memory_mb INT UNSIGNED NULL,
    disks_json JSON NULL,
    software_json JSON NULL,
    hardware_json JSON NULL,
    peripherals_json JSON NULL,
    domain_username VARCHAR(190) NULL,
    antivirus VARCHAR(255) NULL,
    sound_card VARCHAR(255) NULL,
    network_card VARCHAR(255) NULL,
    os_architecture VARCHAR(40) NULL,
    os_serial VARCHAR(190) NULL,
    os_install_date DATETIME NULL,
    registered_users INT UNSIGNED NULL,
    source ENUM('manual','server_inventory','agent') NOT NULL DEFAULT 'manual',
    lifecycle_status ENUM('planned','in_stock','assigned','in_repair','retired','disposed') NOT NULL DEFAULT 'in_stock',
    purchase_date DATE NULL,
    warranty_until DATE NULL,
    vendor VARCHAR(190) NULL,
    acquisition_cost DECIMAL(15,2) NULL,
    disposal_note TEXT NULL,
    retired_at DATETIME NULL,
    last_inventory_at DATETIME NULL,
    created_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
    updated_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    INDEX idx_assets_department (department_id),
    INDEX idx_assets_hostname (hostname),
    CONSTRAINT fk_assets_owner FOREIGN KEY (owner_user_id) REFERENCES users(id) ON DELETE SET NULL,
    CONSTRAINT fk_assets_department FOREIGN KEY (department_id) REFERENCES departments(id) ON DELETE SET NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
CREATE TABLE IF NOT EXISTS asset_memory_modules (
    id BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
    asset_id INT UNSIGNED NOT NULL,
    slot_no SMALLINT UNSIGNED NOT NULL,
    manufacturer VARCHAR(190) NULL,
    model VARCHAR(190) NULL,
    capacity_mb INT UNSIGNED NULL,
    speed_mhz INT UNSIGNED NULL,
    serial_number VARCHAR(190) NULL,
    collected_at DATETIME NULL,
    created_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
    UNIQUE KEY uq_asset_memory_slot (asset_id, slot_no),
    CONSTRAINT fk_memory_asset FOREIGN KEY (asset_id) REFERENCES assets(id) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
CREATE TABLE IF NOT EXISTS asset_storage_devices (
    id BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
    asset_id INT UNSIGNED NOT NULL,
    slot_no SMALLINT UNSIGNED NOT NULL,
    device_type VARCHAR(60) NULL,
    model VARCHAR(190) NULL,
    capacity_bytes BIGINT UNSIGNED NULL,
    serial_number VARCHAR(190) NULL,
    media_type VARCHAR(100) NULL,
    interface_type VARCHAR(100) NULL,
    collected_at DATETIME NULL,
    created_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
    UNIQUE KEY uq_asset_storage_slot (asset_id, slot_no),
    CONSTRAINT fk_storage_asset FOREIGN KEY (asset_id) REFERENCES assets(id) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
CREATE TABLE IF NOT EXISTS asset_graphics_adapters (
    id BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
    asset_id INT UNSIGNED NOT NULL,
    slot_no SMALLINT UNSIGNED NOT NULL,
    model VARCHAR(255) NULL,
    vram_mb INT UNSIGNED NULL,
    driver_version VARCHAR(100) NULL,
    collected_at DATETIME NULL,
    created_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
    UNIQUE KEY uq_asset_graphics_slot (asset_id, slot_no),
    CONSTRAINT fk_graphics_asset FOREIGN KEY (asset_id) REFERENCES assets(id) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
CREATE TABLE IF NOT EXISTS asset_peripherals (
    id BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
    asset_id INT UNSIGNED NOT NULL,
    peripheral_type ENUM('monitor','printer','scanner','modem','network_card','sound_card','case','mouse','keyboard','other') NOT NULL,
    slot_no SMALLINT UNSIGNED NOT NULL DEFAULT 1,
    model VARCHAR(255) NULL,
    manufacturer VARCHAR(190) NULL,
    serial_number VARCHAR(190) NULL,
    asset_number VARCHAR(100) NULL,
    seal_number VARCHAR(100) NULL,
    details_json JSON NULL,
    source ENUM('manual','agent','server_inventory') NOT NULL DEFAULT 'manual',
    collected_at DATETIME NULL,
    created_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
    UNIQUE KEY uq_asset_peripheral_slot (asset_id, peripheral_type, slot_no),
    CONSTRAINT fk_peripheral_asset FOREIGN KEY (asset_id) REFERENCES assets(id) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
CREATE TABLE IF NOT EXISTS asset_inventory_history (
    id BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
    asset_id INT UNSIGNED NOT NULL,
    snapshot_json JSON NOT NULL,
    collected_by INT UNSIGNED NULL,
    collected_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
    INDEX idx_asset_history_asset (asset_id),
    CONSTRAINT fk_asset_history_asset FOREIGN KEY (asset_id) REFERENCES assets(id) ON DELETE CASCADE,
    CONSTRAINT fk_asset_history_user FOREIGN KEY (collected_by) REFERENCES users(id) ON DELETE SET NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
CREATE TABLE IF NOT EXISTS asset_history_events (
    id BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
    asset_id INT UNSIGNED NOT NULL,
    ticket_id INT UNSIGNED NULL,
    user_id INT UNSIGNED NULL,
    event_type VARCHAR(80) NOT NULL,
    title VARCHAR(255) NOT NULL,
    details TEXT NULL,
    before_json JSON NULL,
    after_json JSON NULL,
    created_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
    INDEX idx_asset_events_asset (asset_id),
    INDEX idx_asset_events_ticket (ticket_id),
    CONSTRAINT fk_asset_event_asset FOREIGN KEY (asset_id) REFERENCES assets(id) ON DELETE CASCADE,
    CONSTRAINT fk_asset_event_ticket FOREIGN KEY (ticket_id) REFERENCES tickets(id) ON DELETE SET NULL,
    CONSTRAINT fk_asset_event_user FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE SET NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
CREATE TABLE IF NOT EXISTS asset_relations (
    id BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
    source_asset_id INT UNSIGNED NOT NULL,
    target_asset_id INT UNSIGNED NOT NULL,
    relation_type ENUM('depends_on','connected_to','replaces','located_with','related_to') NOT NULL DEFAULT 'related_to',
    created_by INT UNSIGNED NULL,
    created_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
    UNIQUE KEY uq_asset_relation (source_asset_id, target_asset_id, relation_type),
    CONSTRAINT fk_relation_source FOREIGN KEY (source_asset_id) REFERENCES assets(id) ON DELETE CASCADE,
    CONSTRAINT fk_relation_target FOREIGN KEY (target_asset_id) REFERENCES assets(id) ON DELETE CASCADE,
    CONSTRAINT fk_relation_creator FOREIGN KEY (created_by) REFERENCES users(id) ON DELETE SET NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
CREATE TABLE IF NOT EXISTS asset_profiles (
    asset_id INT UNSIGNED NOT NULL PRIMARY KEY,
    record_number VARCHAR(100) NULL,
    registrar_name VARCHAR(190) NULL,
    registry_date DATETIME NULL,
    unit_name VARCHAR(190) NULL,
    computer_type VARCHAR(100) NULL,
    user_login VARCHAR(190) NULL,
    owner_full_name VARCHAR(190) NULL,
    education VARCHAR(190) NULL,
    phone VARCHAR(80) NULL,
    degree VARCHAR(190) NULL,
    skill_level VARCHAR(190) NULL,
    personnel_number VARCHAR(100) NULL,
    training_skills TEXT NULL,
    secure_info TEXT NULL,
    unit_software TEXT NULL,
    os_name VARCHAR(255) NULL,
    hostname VARCHAR(190) NULL,
    windows_serial VARCHAR(190) NULL,
    os_version VARCHAR(100) NULL,
    os_install_path VARCHAR(255) NULL,
    user_count VARCHAR(40) NULL,
    os_install_date DATETIME NULL,
    disk1_model VARCHAR(190) NULL,
    disk1_capacity VARCHAR(60) NULL,
    disk1_serial VARCHAR(190) NULL,
    disk2_model VARCHAR(190) NULL,
    disk2_capacity VARCHAR(60) NULL,
    disk2_serial VARCHAR(190) NULL,
    motherboard_model VARCHAR(190) NULL,
    motherboard_product VARCHAR(190) NULL,
    motherboard_serial VARCHAR(190) NULL,
    cpu_model VARCHAR(190) NULL,
    cpu_serial VARCHAR(190) NULL,
    cpu_cores VARCHAR(40) NULL,
    ram1 VARCHAR(190) NULL,
    ram2 VARCHAR(190) NULL,
    ram_total VARCHAR(60) NULL,
    gpu1_model VARCHAR(190) NULL,
    gpu1_memory VARCHAR(60) NULL,
    gpu2_model VARCHAR(190) NULL,
    gpu2_memory VARCHAR(60) NULL,
    audio VARCHAR(190) NULL,
    ip_address VARCHAR(100) NULL,
    mac_address VARCHAR(100) NULL,
    netcard VARCHAR(190) NULL,
    net_node VARCHAR(100) NULL,
    connected_internet TINYINT(1) NOT NULL DEFAULT 0,
    connected_network TINYINT(1) NOT NULL DEFAULT 0,
    lock_usb TINYINT(1) NOT NULL DEFAULT 0,
    lock_case TINYINT(1) NOT NULL DEFAULT 0,
    lock_cd_dvd TINYINT(1) NOT NULL DEFAULT 0,
    monitor_model VARCHAR(190) NULL,
    printer_model VARCHAR(190) NULL,
    scanner_model VARCHAR(190) NULL,
    keyboard_model VARCHAR(190) NULL,
    mouse_model VARCHAR(190) NULL,
    barcode_reader VARCHAR(190) NULL,
    antivirus VARCHAR(255) NULL,
    power_model VARCHAR(190) NULL,
    case_model VARCHAR(190) NULL,
    plaque_number VARCHAR(100) NULL,
    plaque_monitor VARCHAR(100) NULL,
    plaque_printer VARCHAR(100) NULL,
    plaque_printer2 VARCHAR(100) NULL,
    plaque_scanner VARCHAR(100) NULL,
    case_seal TEXT NULL,
    ad_dn VARCHAR(255) NULL,
    ad_os VARCHAR(255) NULL,
    ad_os_version VARCHAR(255) NULL,
    ad_last_logon DATETIME NULL,
    ad_last_seen DATETIME NULL,
    ad_scanned_at DATETIME NULL,
    ad_online TINYINT(1) NOT NULL DEFAULT 0,
    ad_description VARCHAR(255) NULL,
    updated_by INT UNSIGNED NULL,
    updated_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    CONSTRAINT fk_asset_profile_asset FOREIGN KEY (asset_id) REFERENCES assets(id) ON DELETE CASCADE,
    CONSTRAINT fk_asset_profile_user FOREIGN KEY (updated_by) REFERENCES users(id) ON DELETE SET NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
CREATE TABLE IF NOT EXISTS ola_policies (
    id INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
    name VARCHAR(190) NOT NULL,
    department_id INT UNSIGNED NULL,
    priority ENUM('normal','urgent','critical') NOT NULL,
    response_minutes INT UNSIGNED NOT NULL,
    resolution_minutes INT UNSIGNED NOT NULL,
    escalation_1_minutes INT UNSIGNED NOT NULL,
    escalation_2_minutes INT UNSIGNED NOT NULL,
    is_active TINYINT(1) NOT NULL DEFAULT 1,
    created_by INT UNSIGNED NULL,
    created_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
    updated_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    INDEX idx_ola_lookup (department_id, priority, is_active),
    CONSTRAINT fk_ola_department FOREIGN KEY (department_id) REFERENCES departments(id) ON DELETE CASCADE,
    CONSTRAINT fk_ola_creator FOREIGN KEY (created_by) REFERENCES users(id) ON DELETE SET NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
CREATE TABLE IF NOT EXISTS ticket_ola_alerts (
    id BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
    ticket_id INT UNSIGNED NOT NULL,
    alert_type ENUM('response_overdue','resolution_overdue','escalation_1','escalation_2') NOT NULL,
    due_at DATETIME NOT NULL,
    created_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
    UNIQUE KEY uq_ticket_ola_alert (ticket_id, alert_type, due_at),
    CONSTRAINT fk_ola_alert_ticket FOREIGN KEY (ticket_id) REFERENCES tickets(id) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
CREATE TABLE IF NOT EXISTS change_records (
    id INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
    change_number VARCHAR(40) NOT NULL UNIQUE,
    title VARCHAR(255) NOT NULL,
    description TEXT NOT NULL,
    justification TEXT NULL,
    risk_level ENUM('low','medium','high','critical') NOT NULL DEFAULT 'medium',
    impact TEXT NULL,
    planned_start DATETIME NULL,
    planned_end DATETIME NULL,
    status ENUM('draft','submitted','cab_review','approved','rejected','scheduled','implemented','rolled_back','closed') NOT NULL DEFAULT 'draft',
    department_id INT UNSIGNED NULL,
    requester_id INT UNSIGNED NOT NULL,
    owner_id INT UNSIGNED NULL,
    cab_decided_by INT UNSIGNED NULL,
    cab_decided_at DATETIME NULL,
    cab_note TEXT NULL,
    implementation_note TEXT NULL,
    created_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
    updated_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    INDEX idx_changes_status (status),
    INDEX idx_changes_department (department_id),
    INDEX idx_changes_owner (owner_id),
    CONSTRAINT fk_changes_department FOREIGN KEY (department_id) REFERENCES departments(id) ON DELETE SET NULL,
    CONSTRAINT fk_changes_requester FOREIGN KEY (requester_id) REFERENCES users(id) ON DELETE RESTRICT,
    CONSTRAINT fk_changes_owner FOREIGN KEY (owner_id) REFERENCES users(id) ON DELETE SET NULL,
    CONSTRAINT fk_changes_cab_user FOREIGN KEY (cab_decided_by) REFERENCES users(id) ON DELETE SET NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
CREATE TABLE IF NOT EXISTS change_approvals (
    id BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
    change_id INT UNSIGNED NOT NULL,
    approver_id INT UNSIGNED NULL,
    decision ENUM('submitted','approved','rejected','scheduled','implemented','rolled_back','closed') NOT NULL,
    note TEXT NULL,
    created_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
    INDEX idx_change_approvals_change (change_id),
    CONSTRAINT fk_change_approval_change FOREIGN KEY (change_id) REFERENCES change_records(id) ON DELETE CASCADE,
    CONSTRAINT fk_change_approval_user FOREIGN KEY (approver_id) REFERENCES users(id) ON DELETE SET NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
CREATE TABLE IF NOT EXISTS change_ticket_links (
    change_id INT UNSIGNED NOT NULL,
    ticket_id INT UNSIGNED NOT NULL,
    created_by INT UNSIGNED NULL,
    created_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
    PRIMARY KEY (change_id, ticket_id),
    CONSTRAINT fk_change_link_change FOREIGN KEY (change_id) REFERENCES change_records(id) ON DELETE CASCADE,
    CONSTRAINT fk_change_link_ticket FOREIGN KEY (ticket_id) REFERENCES tickets(id) ON DELETE CASCADE,
    CONSTRAINT fk_change_link_user FOREIGN KEY (created_by) REFERENCES users(id) ON DELETE SET NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
CREATE TABLE IF NOT EXISTS problem_records (
    id INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
    problem_number VARCHAR(40) NOT NULL UNIQUE,
    title VARCHAR(255) NOT NULL,
    description TEXT NOT NULL,
    root_cause TEXT NULL,
    workaround TEXT NULL,
    known_error TINYINT(1) NOT NULL DEFAULT 0,
    priority ENUM('normal','urgent','critical') NOT NULL DEFAULT 'normal',
    status ENUM('open','investigation','known_error','resolved','closed') NOT NULL DEFAULT 'open',
    department_id INT UNSIGNED NULL,
    created_by INT UNSIGNED NOT NULL,
    owner_id INT UNSIGNED NULL,
    resolved_at DATETIME NULL,
    created_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
    updated_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    INDEX idx_problems_status (status),
    INDEX idx_problems_department (department_id),
    INDEX idx_problems_owner (owner_id),
    CONSTRAINT fk_problems_department FOREIGN KEY (department_id) REFERENCES departments(id) ON DELETE SET NULL,
    CONSTRAINT fk_problems_creator FOREIGN KEY (created_by) REFERENCES users(id) ON DELETE RESTRICT,
    CONSTRAINT fk_problems_owner FOREIGN KEY (owner_id) REFERENCES users(id) ON DELETE SET NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
CREATE TABLE IF NOT EXISTS problem_ticket_links (
    problem_id INT UNSIGNED NOT NULL,
    ticket_id INT UNSIGNED NOT NULL,
    created_by INT UNSIGNED NULL,
    created_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
    PRIMARY KEY (problem_id, ticket_id),
    CONSTRAINT fk_problem_link_problem FOREIGN KEY (problem_id) REFERENCES problem_records(id) ON DELETE CASCADE,
    CONSTRAINT fk_problem_link_ticket FOREIGN KEY (ticket_id) REFERENCES tickets(id) ON DELETE CASCADE,
    CONSTRAINT fk_problem_link_user FOREIGN KEY (created_by) REFERENCES users(id) ON DELETE SET NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
CREATE TABLE IF NOT EXISTS food_ticket_config (
    id TINYINT UNSIGNED PRIMARY KEY,
    enabled TINYINT(1) NOT NULL DEFAULT 0,
    attendance_path VARCHAR(500) NOT NULL DEFAULT '',
    attendance_password_enc TEXT NULL,
    printer_mode ENUM('tcp_raw','windows_share') NOT NULL DEFAULT 'tcp_raw',
    printer_host VARCHAR(255) NOT NULL DEFAULT '',
    printer_port SMALLINT UNSIGNED NOT NULL DEFAULT 9100,
    printer_share VARCHAR(255) NOT NULL DEFAULT '',
    poll_seconds TINYINT UNSIGNED NOT NULL DEFAULT 2,
    max_batch SMALLINT UNSIGNED NOT NULL DEFAULT 100,
    guest_card_uids TEXT NULL,
    max_guest_daily SMALLINT UNSIGNED NOT NULL DEFAULT 20,
    cut_source_rows TINYINT(1) NOT NULL DEFAULT 1,
    updated_by INT UNSIGNED NULL,
    updated_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    CONSTRAINT fk_food_config_user FOREIGN KEY (updated_by) REFERENCES users(id) ON DELETE SET NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
CREATE TABLE IF NOT EXISTS food_ticket_events (
    id BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
    source_key CHAR(64) NOT NULL UNIQUE,
    source_uid VARCHAR(80) NULL,
    source_card VARCHAR(120) NULL,
    punch_date DATE NULL,
    punch_time TIME NULL,
    personnel_code VARCHAR(100) NULL,
    user_id INT UNSIGNED NULL,
    national_code VARCHAR(30) NULL,
    full_name VARCHAR(190) NULL,
    food_type VARCHAR(190) NULL,
    ticket_key VARCHAR(190) NULL UNIQUE,
    print_job_id VARCHAR(64) NULL,
    event_type ENUM('printed','print_error','no_food','unknown','inactive','repeat','guest','guest_limit','config_error') NOT NULL,
    print_status ENUM('not_printed','pending','printing','printed','print_error','failed','held_absent') NOT NULL DEFAULT 'not_printed',
    delivery_status ENUM('pending','delivered') NOT NULL DEFAULT 'pending',
    delivered_at DATETIME NULL,
    delivered_by INT UNSIGNED NULL,
    -- وضعیت واقعی حذف ردیف منبع از SOURCE_TABLE (۱.۳۳): ۱ = ردیف با اطمینان یکتا از SOURCE_TABLE پاک شده است.
    source_deleted TINYINT(1) NOT NULL DEFAULT 0,
    source_deleted_at DATETIME NULL,
    source_delete_note VARCHAR(255) NULL,
    print_attempts SMALLINT UNSIGNED NOT NULL DEFAULT 0,
    retry_count INT NOT NULL DEFAULT 0,
    last_error TEXT NULL,
    printer_name VARCHAR(190) NULL,
    source_payload LONGTEXT NULL,
    processed_at DATETIME NULL,
    next_retry_at DATETIME NULL,
    created_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
    updated_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    INDEX idx_food_events_date (punch_date, created_at),
    INDEX idx_food_events_status (print_status, event_type),
    INDEX idx_food_events_user (user_id),
    CONSTRAINT fk_food_event_user FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE SET NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
CREATE TABLE IF NOT EXISTS food_ticket_worker_status (
    id TINYINT UNSIGNED PRIMARY KEY,
    host_name VARCHAR(190) NOT NULL DEFAULT '',
    process_id INT UNSIGNED NOT NULL DEFAULT 0,
    last_seen DATETIME NULL,
    status ENUM('ok','warning','error') NOT NULL DEFAULT 'ok',
    last_message TEXT NULL,
    last_error TEXT NULL,
    processed_count INT UNSIGNED NOT NULL DEFAULT 0,
    printed_count INT UNSIGNED NOT NULL DEFAULT 0,
    error_count INT UNSIGNED NOT NULL DEFAULT 0,
    updated_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
CREATE TABLE IF NOT EXISTS food_ticket_guest_cards (
    id BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
    card_uid VARCHAR(120) NOT NULL,
    guest_name VARCHAR(190) NOT NULL DEFAULT 'مهمان',
    daily_limit SMALLINT UNSIGNED NOT NULL DEFAULT 0,
    is_active TINYINT(1) NOT NULL DEFAULT 1,
    updated_by INT UNSIGNED NULL,
    created_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
    updated_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    UNIQUE KEY uq_food_guest_card_uid (card_uid),
    INDEX idx_food_guest_card_active (is_active),
    CONSTRAINT fk_food_guest_card_user FOREIGN KEY (updated_by) REFERENCES users(id) ON DELETE SET NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
CREATE TABLE IF NOT EXISTS food_ticket_groups (
    id INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
    title VARCHAR(190) NOT NULL,
    -- شناسهٔ نمایندهٔ گروه: L_UID دستگاه حضور و غیاب (شناسهٔ اصلی شناسایی)
    l_uid VARCHAR(80) NULL,
    -- کارت RFID فقط برای سازگاری با گروه‌های قدیمی؛ مبنای شناسایی نماینده نیست
    rfid_card VARCHAR(120) NULL,
    description VARCHAR(500) NULL,
    status ENUM('active','inactive') NOT NULL DEFAULT 'active',
    created_by INT UNSIGNED NULL,
    created_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
    updated_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    UNIQUE KEY uq_food_group_uid (l_uid),
    UNIQUE KEY uq_food_group_card (rfid_card),
    INDEX idx_food_group_status (status)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
CREATE TABLE IF NOT EXISTS food_ticket_group_members (
    id INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
    group_id INT UNSIGNED NOT NULL,
    user_id INT UNSIGNED NOT NULL,
    created_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
    UNIQUE KEY uq_food_group_member_user (user_id),
    INDEX idx_food_group_member_group (group_id),
    CONSTRAINT fk_food_group_member_group FOREIGN KEY (group_id) REFERENCES food_ticket_groups(id) ON DELETE CASCADE,
    CONSTRAINT fk_food_group_member_user FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
CREATE TABLE IF NOT EXISTS food_ticket_group_runs (
    id BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
    group_id INT UNSIGNED NULL,
    group_title VARCHAR(190) NULL,
    rfid_card VARCHAR(120) NOT NULL DEFAULT '',
    trigger_kind ENUM('uid','card','legacy_card') NOT NULL DEFAULT 'card',
    trigger_uid VARCHAR(80) NULL,
    source_key CHAR(64) NOT NULL,
    punch_date DATE NOT NULL,
    punch_time TIME NULL,
    run_kind ENUM('first','repeat','inactive') NOT NULL,
    status ENUM('processing','done') NOT NULL DEFAULT 'done',
    members_total INT UNSIGNED NOT NULL DEFAULT 0,
    printed_count INT UNSIGNED NOT NULL DEFAULT 0,
    repeat_count INT UNSIGNED NOT NULL DEFAULT 0,
    no_food_count INT UNSIGNED NOT NULL DEFAULT 0,
    absent_count INT UNSIGNED NOT NULL DEFAULT 0,
    skipped_count INT UNSIGNED NOT NULL DEFAULT 0,
    error_count INT UNSIGNED NOT NULL DEFAULT 0,
    created_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
    updated_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    UNIQUE KEY uq_food_group_run_source (source_key),
    INDEX idx_food_group_run_day (group_id, punch_date, run_kind)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
CREATE TABLE IF NOT EXISTS food_ticket_daily_absence (
    id BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
    absence_date DATE NOT NULL,
    group_id INT UNSIGNED NULL,
    user_id INT UNSIGNED NOT NULL,
    reason VARCHAR(300) NULL,
    created_by INT UNSIGNED NULL,
    created_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
    updated_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    UNIQUE KEY uq_food_absence_day_user (absence_date, user_id),
    INDEX idx_food_absence_group_day (group_id, absence_date),
    CONSTRAINT fk_food_absence_user FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE,
    CONSTRAINT fk_food_absence_group FOREIGN KEY (group_id) REFERENCES food_ticket_groups(id) ON DELETE SET NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
CREATE TABLE IF NOT EXISTS food_ticket_group_uid_history (
    id BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
    uid VARCHAR(80) NOT NULL,
    group_id INT UNSIGNED NULL,
    action ENUM('set','changed','removed') NOT NULL,
    actor_id INT UNSIGNED NULL,
    created_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
    INDEX idx_food_uid_history_uid (uid),
    INDEX idx_food_uid_history_group (group_id)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
CREATE TABLE IF NOT EXISTS food_ticket_print_log (
  id BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
  created_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
  event_id BIGINT UNSIGNED NULL,
  print_job_id VARCHAR(64) NULL,
  source_key CHAR(64) NULL,
  ticket_key VARCHAR(190) NULL,
  printer VARCHAR(190) NULL,
  status VARCHAR(40) NOT NULL,
  retry_count INT NOT NULL DEFAULT 0,
  message VARCHAR(500) NULL,
  INDEX idx_ftpl_event (event_id),
  INDEX idx_ftpl_job (print_job_id),
  INDEX idx_ftpl_created (created_at)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
CREATE TABLE IF NOT EXISTS system_logs (
    id BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
    level VARCHAR(20) NOT NULL DEFAULT 'error',
    context VARCHAR(120) NULL,
    message TEXT NULL,
    meta_json JSON NULL,
    user_id INT UNSIGNED NULL,
    request_uri VARCHAR(255) NULL,
    created_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
    INDEX idx_system_logs_created (created_at),
    INDEX idx_system_logs_level (level)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
CREATE TABLE IF NOT EXISTS chatbot_faq (
    id INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
    question VARCHAR(255) NOT NULL,
    answer TEXT NOT NULL,
    keywords VARCHAR(500) NULL,
    is_active TINYINT(1) NOT NULL DEFAULT 1,
    created_by INT UNSIGNED NULL,
    created_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
    updated_at DATETIME NULL,
    INDEX idx_chatbot_faq_active (is_active)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
CREATE TABLE IF NOT EXISTS chatbot_logs (
    id BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
    user_id INT UNSIGNED NULL,
    question VARCHAR(500) NOT NULL,
    faq_id INT UNSIGNED NULL,
    intent VARCHAR(80) NULL,
    score DECIMAL(6,3) NOT NULL DEFAULT 0,
    helpful TINYINT(1) NULL,
    created_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
    INDEX idx_chatbot_logs_created (created_at),
    INDEX idx_chatbot_logs_faq (faq_id)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
CREATE TABLE IF NOT EXISTS system_incidents (
    fingerprint CHAR(40) NOT NULL PRIMARY KEY,
    title VARCHAR(255) NOT NULL,
    status ENUM('open','investigating','resolved') NOT NULL DEFAULT 'open',
    note TEXT NULL,
    updated_by INT UNSIGNED NULL,
    updated_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
CREATE TABLE IF NOT EXISTS ticket_number_seq (
    prefix VARCHAR(20) NOT NULL PRIMARY KEY,
    seq INT UNSIGNED NOT NULL DEFAULT 0
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
CREATE TABLE IF NOT EXISTS api_rate_limits (
    rate_key CHAR(64) PRIMARY KEY,
    attempts INT UNSIGNED NOT NULL DEFAULT 0,
    window_started DATETIME NOT NULL,
    updated_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    INDEX idx_api_rate_window (window_started)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
CREATE TABLE IF NOT EXISTS domain_scan_runs (
    id INT UNSIGNED NOT NULL AUTO_INCREMENT PRIMARY KEY,
    started_by INT UNSIGNED NULL,
    status VARCHAR(20) NOT NULL DEFAULT 'running',
    total INT NOT NULL DEFAULT 0,
    done INT NOT NULL DEFAULT 0,
    online INT NOT NULL DEFAULT 0,
    offline INT NOT NULL DEFAULT 0,
    failed INT NOT NULL DEFAULT 0,
    created_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
    updated_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
CREATE TABLE IF NOT EXISTS domain_scan_queue (
    id INT UNSIGNED NOT NULL AUTO_INCREMENT PRIMARY KEY,
    run_id INT UNSIGNED NOT NULL,
    asset_id INT UNSIGNED NULL,
    hostname VARCHAR(190) NOT NULL,
    status VARCHAR(20) NOT NULL DEFAULT 'pending',
    online TINYINT(1) NOT NULL DEFAULT 0,
    message VARCHAR(255) NULL,
    created_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
    updated_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    KEY run_status (run_id, status)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
CREATE TABLE IF NOT EXISTS food_ticket_card_map (
    card_key VARCHAR(120) NOT NULL PRIMARY KEY,
    user_id INT UNSIGNED NOT NULL,
    personnel_code VARCHAR(100) NULL,
    hits INT NOT NULL DEFAULT 1,
    created_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
    updated_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    INDEX idx_food_card_map_user (user_id)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
CREATE TABLE IF NOT EXISTS food_ticket_templates (
    id INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
    name VARCHAR(120) NOT NULL,
    paper_width DECIMAL(6,1) NOT NULL DEFAULT 80.0,
    paper_height DECIMAL(6,1) NOT NULL DEFAULT 0.0,
    template_json LONGTEXT NOT NULL,
    is_active TINYINT(1) NOT NULL DEFAULT 0,
    created_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
    updated_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    INDEX idx_food_tpl_active (is_active)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
CREATE TABLE IF NOT EXISTS food_catalog (
    id INT UNSIGNED NOT NULL AUTO_INCREMENT PRIMARY KEY,
    food_name VARCHAR(190) NOT NULL,
    category VARCHAR(40) NULL,
    active TINYINT(1) NOT NULL DEFAULT 1,
    created_by INT UNSIGNED NULL,
    created_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
    updated_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    UNIQUE KEY uq_food_catalog_name (food_name),
    INDEX idx_food_catalog_active (active)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
CREATE TABLE IF NOT EXISTS food_guest_requests (
    id INT UNSIGNED NOT NULL AUTO_INCREMENT PRIMARY KEY,
    request_date DATE NOT NULL,
    organization VARCHAR(190) NOT NULL,
    guest_count SMALLINT UNSIGNED NOT NULL,
    food_id INT UNSIGNED NULL,
    requester_name VARCHAR(150) NOT NULL,
    deputy_unit_id INT UNSIGNED NULL,
    note VARCHAR(500) NULL,
    status ENUM('active','cancelled') NOT NULL DEFAULT 'active',
    created_by INT UNSIGNED NULL,
    created_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
    cancelled_by INT UNSIGNED NULL,
    cancelled_at DATETIME NULL,
    KEY idx_food_guest_requests_date_status (request_date, status),
    KEY idx_food_guest_requests_deputy (deputy_unit_id, request_date),
    CONSTRAINT fk_food_guest_requests_food FOREIGN KEY (food_id) REFERENCES food_catalog (id) ON DELETE SET NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
CREATE TABLE IF NOT EXISTS food_calendar (
    id INT UNSIGNED NOT NULL AUTO_INCREMENT PRIMARY KEY,
    food_date DATE NOT NULL,
    order_status ENUM('open','closed') NOT NULL DEFAULT 'open',
    note VARCHAR(255) NULL,
    closed_by INT UNSIGNED NULL,
    closed_at DATETIME NULL,
    created_by INT UNSIGNED NULL,
    created_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
    updated_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    UNIQUE KEY uq_food_calendar_date (food_date),
    INDEX idx_food_calendar_status_date (order_status, food_date)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
CREATE TABLE IF NOT EXISTS food_calendar_items (
    id INT UNSIGNED NOT NULL AUTO_INCREMENT PRIMARY KEY,
    calendar_id INT UNSIGNED NOT NULL,
    food_id INT UNSIGNED NOT NULL,
    sort_order TINYINT UNSIGNED NOT NULL DEFAULT 0,
    active TINYINT(1) NOT NULL DEFAULT 1,
    created_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
    updated_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    UNIQUE KEY uq_food_calendar_item (calendar_id, food_id),
    INDEX idx_food_calendar_items_food (food_id),
    INDEX idx_food_calendar_items_active (calendar_id, active),
    CONSTRAINT fk_food_calendar_item_calendar FOREIGN KEY (calendar_id) REFERENCES food_calendar(id) ON DELETE CASCADE,
    CONSTRAINT fk_food_calendar_item_food FOREIGN KEY (food_id) REFERENCES food_catalog(id) ON DELETE RESTRICT
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
CREATE TABLE IF NOT EXISTS food_orders (
    id BIGINT UNSIGNED NOT NULL AUTO_INCREMENT PRIMARY KEY,
    employee_id INT UNSIGNED NOT NULL,
    calendar_item_id INT UNSIGNED NOT NULL,
    food_date DATE NOT NULL,
    created_by INT UNSIGNED NOT NULL,
    status ENUM('active','cancelled') NOT NULL DEFAULT 'active',
    created_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
    updated_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    UNIQUE KEY uq_food_order_employee_date (employee_id, food_date),
    INDEX idx_food_orders_date_status (food_date, status),
    INDEX idx_food_orders_item_status (calendar_item_id, status),
    CONSTRAINT fk_food_order_calendar_item FOREIGN KEY (calendar_item_id) REFERENCES food_calendar_items(id) ON DELETE RESTRICT
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
CREATE TABLE IF NOT EXISTS food_order_logs (
    id BIGINT UNSIGNED NOT NULL AUTO_INCREMENT PRIMARY KEY,
    order_id BIGINT UNSIGNED NULL,
    calendar_id INT UNSIGNED NULL,
    action VARCHAR(40) NOT NULL,
    user_id INT UNSIGNED NULL,
    old_value TEXT NULL,
    new_value TEXT NULL,
    reason VARCHAR(500) NULL,
    created_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
    INDEX idx_food_order_logs_order (order_id),
    INDEX idx_food_order_logs_calendar (calendar_id),
    INDEX idx_food_order_logs_created (created_at),
    CONSTRAINT fk_food_order_log_order FOREIGN KEY (order_id) REFERENCES food_orders(id) ON DELETE SET NULL,
    CONSTRAINT fk_food_order_log_calendar FOREIGN KEY (calendar_id) REFERENCES food_calendar(id) ON DELETE SET NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

ALTER TABLE `settings` ADD COLUMN IF NOT EXISTS `value` TEXT NOT NULL;
ALTER TABLE `departments` ADD COLUMN IF NOT EXISTS `name` VARCHAR(150) NOT NULL UNIQUE;
ALTER TABLE `departments` ADD COLUMN IF NOT EXISTS `code` VARCHAR(40) NULL UNIQUE;
ALTER TABLE `departments` ADD COLUMN IF NOT EXISTS `manager_user_id` INT UNSIGNED NULL;
ALTER TABLE `departments` ADD COLUMN IF NOT EXISTS `is_active` TINYINT(1) NOT NULL DEFAULT 1;
ALTER TABLE `departments` ADD COLUMN IF NOT EXISTS `created_at` DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP;
ALTER TABLE `org_units` ADD COLUMN IF NOT EXISTS `name` VARCHAR(190) NOT NULL;
ALTER TABLE `org_units` ADD COLUMN IF NOT EXISTS `code` VARCHAR(60) NULL;
ALTER TABLE `org_units` ADD COLUMN IF NOT EXISTS `parent_id` INT UNSIGNED NULL;
ALTER TABLE `org_units` ADD COLUMN IF NOT EXISTS `unit_type` VARCHAR(20) NOT NULL DEFAULT 'department';
ALTER TABLE `org_units` ADD COLUMN IF NOT EXISTS `manager_user_id` INT UNSIGNED NULL;
ALTER TABLE `org_units` ADD COLUMN IF NOT EXISTS `is_primary_admin` TINYINT(1) NOT NULL DEFAULT 0;
ALTER TABLE `org_units` ADD COLUMN IF NOT EXISTS `is_active` TINYINT(1) NOT NULL DEFAULT 1;
ALTER TABLE `org_units` ADD COLUMN IF NOT EXISTS `created_at` DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP;
ALTER TABLE `org_unit_managers` ADD COLUMN IF NOT EXISTS `unit_id` INT UNSIGNED NOT NULL;
ALTER TABLE `org_unit_managers` ADD COLUMN IF NOT EXISTS `user_id` INT UNSIGNED NOT NULL;
ALTER TABLE `org_unit_managers` ADD COLUMN IF NOT EXISTS `is_primary` TINYINT(1) NOT NULL DEFAULT 0;
ALTER TABLE `users` ADD COLUMN IF NOT EXISTS `username` VARCHAR(190) NOT NULL UNIQUE;
ALTER TABLE `users` ADD COLUMN IF NOT EXISTS `password_hash` VARCHAR(255) NULL;
ALTER TABLE `users` ADD COLUMN IF NOT EXISTS `full_name` VARCHAR(190) NOT NULL;
ALTER TABLE `users` ADD COLUMN IF NOT EXISTS `first_name` VARCHAR(100) NULL;
ALTER TABLE `users` ADD COLUMN IF NOT EXISTS `last_name` VARCHAR(100) NULL;
ALTER TABLE `users` ADD COLUMN IF NOT EXISTS `profile_photo` VARCHAR(255) NULL;
ALTER TABLE `users` ADD COLUMN IF NOT EXISTS `email` VARCHAR(190) NULL;
ALTER TABLE `users` ADD COLUMN IF NOT EXISTS `employee_number` VARCHAR(100) NULL;
ALTER TABLE `users` ADD COLUMN IF NOT EXISTS `national_code` VARCHAR(30) NULL;
ALTER TABLE `users` ADD COLUMN IF NOT EXISTS `phone` VARCHAR(80) NULL;
ALTER TABLE `users` ADD COLUMN IF NOT EXISTS `department` VARCHAR(190) NULL;
ALTER TABLE `users` ADD COLUMN IF NOT EXISTS `department_id` INT UNSIGNED NULL;
ALTER TABLE `users` ADD COLUMN IF NOT EXISTS `requesting_unit_id` INT UNSIGNED NULL;
ALTER TABLE `users` ADD COLUMN IF NOT EXISTS `org_unit_id` INT UNSIGNED NULL;
ALTER TABLE `users` ADD COLUMN IF NOT EXISTS `manager_user_id` INT UNSIGNED NULL;
ALTER TABLE `users` ADD COLUMN IF NOT EXISTS `handling_unit_id` INT UNSIGNED NULL;
ALTER TABLE `users` ADD COLUMN IF NOT EXISTS `is_it_agent` TINYINT(1) NOT NULL DEFAULT 0;
ALTER TABLE `users` ADD COLUMN IF NOT EXISTS `is_primary_admin` TINYINT(1) NOT NULL DEFAULT 0;
ALTER TABLE `users` ADD COLUMN IF NOT EXISTS `role` ENUM('user','agent','manager','supervisor','admin','primary_admin','support_manager','inspector','local_user','guard') NOT NULL DEFAULT 'user';
ALTER TABLE `users` ADD COLUMN IF NOT EXISTS `auth_source` ENUM('local','ldap','food') NOT NULL DEFAULT 'local';
ALTER TABLE `users` ADD COLUMN IF NOT EXISTS `is_active` TINYINT(1) NOT NULL DEFAULT 1;
ALTER TABLE `users` ADD COLUMN IF NOT EXISTS `last_login_at` DATETIME NULL;
ALTER TABLE `users` ADD COLUMN IF NOT EXISTS `must_change_password` TINYINT(1) NOT NULL DEFAULT 0;
ALTER TABLE `users` ADD COLUMN IF NOT EXISTS `created_at` DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP;
ALTER TABLE `handling_units` ADD COLUMN IF NOT EXISTS `code` ENUM('it','support') NOT NULL UNIQUE;
ALTER TABLE `handling_units` ADD COLUMN IF NOT EXISTS `name` VARCHAR(150) NOT NULL;
ALTER TABLE `handling_units` ADD COLUMN IF NOT EXISTS `manager_user_id` INT UNSIGNED NULL;
ALTER TABLE `handling_units` ADD COLUMN IF NOT EXISTS `is_active` TINYINT(1) NOT NULL DEFAULT 1;
ALTER TABLE `handling_units` ADD COLUMN IF NOT EXISTS `created_at` DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP;
ALTER TABLE `cd_dvd_types` ADD COLUMN IF NOT EXISTS `name` VARCHAR(80) NOT NULL UNIQUE;
ALTER TABLE `cd_dvd_types` ADD COLUMN IF NOT EXISTS `is_default` TINYINT(1) NOT NULL DEFAULT 0;
ALTER TABLE `cd_dvd_records` ADD COLUMN IF NOT EXISTS `media` ENUM('CD','DVD') NOT NULL;
ALTER TABLE `cd_dvd_records` ADD COLUMN IF NOT EXISTS `direction` ENUM('IN','OUT') NOT NULL;
ALTER TABLE `cd_dvd_records` ADD COLUMN IF NOT EXISTS `serial` VARCHAR(20) NOT NULL;
ALTER TABLE `cd_dvd_records` ADD COLUMN IF NOT EXISTS `info_type` VARCHAR(80) NOT NULL;
ALTER TABLE `cd_dvd_records` ADD COLUMN IF NOT EXISTS `info_desc` TEXT NOT NULL;
ALTER TABLE `cd_dvd_records` ADD COLUMN IF NOT EXISTS `jy` SMALLINT UNSIGNED NOT NULL;
ALTER TABLE `cd_dvd_records` ADD COLUMN IF NOT EXISTS `jm` TINYINT UNSIGNED NOT NULL;
ALTER TABLE `cd_dvd_records` ADD COLUMN IF NOT EXISTS `jd` TINYINT UNSIGNED NOT NULL;
ALTER TABLE `cd_dvd_records` ADD COLUMN IF NOT EXISTS `date_str` VARCHAR(20) NOT NULL;
ALTER TABLE `cd_dvd_records` ADD COLUMN IF NOT EXISTS `sort_key` INT UNSIGNED NOT NULL;
ALTER TABLE `cd_dvd_records` ADD COLUMN IF NOT EXISTS `receiver` VARCHAR(190) NULL;
ALTER TABLE `cd_dvd_records` ADD COLUMN IF NOT EXISTS `receiver_unit` VARCHAR(190) NULL;
ALTER TABLE `cd_dvd_records` ADD COLUMN IF NOT EXISTS `brought_by` VARCHAR(190) NULL;
ALTER TABLE `cd_dvd_records` ADD COLUMN IF NOT EXISTS `brought_by_user_id` INT UNSIGNED NULL;
ALTER TABLE `cd_dvd_records` ADD COLUMN IF NOT EXISTS `exit_sheet` VARCHAR(100) NULL;
ALTER TABLE `cd_dvd_records` ADD COLUMN IF NOT EXISTS `note` TEXT NULL;
ALTER TABLE `cd_dvd_records` ADD COLUMN IF NOT EXISTS `department_id` INT UNSIGNED NULL;
ALTER TABLE `cd_dvd_records` ADD COLUMN IF NOT EXISTS `recorder_id` INT UNSIGNED NOT NULL;
ALTER TABLE `cd_dvd_records` ADD COLUMN IF NOT EXISTS `recorder_name` VARCHAR(190) NOT NULL;
ALTER TABLE `cd_dvd_records` ADD COLUMN IF NOT EXISTS `created_at` DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP;
ALTER TABLE `cd_dvd_records` ADD COLUMN IF NOT EXISTS `updated_at` DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP;
ALTER TABLE `traffic_destinations` ADD COLUMN IF NOT EXISTS `title` VARCHAR(190) NOT NULL;
ALTER TABLE `traffic_destinations` ADD COLUMN IF NOT EXISTS `approver_name` VARCHAR(190) NULL;
ALTER TABLE `traffic_destinations` ADD COLUMN IF NOT EXISTS `is_active` TINYINT(1) NOT NULL DEFAULT 1;
ALTER TABLE `traffic_destinations` ADD COLUMN IF NOT EXISTS `created_at` DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP;
ALTER TABLE `traffic_visits` ADD COLUMN IF NOT EXISTS `serial_no` VARCHAR(30) NOT NULL;
ALTER TABLE `traffic_visits` ADD COLUMN IF NOT EXISTS `visit_date` DATE NOT NULL;
ALTER TABLE `traffic_visits` ADD COLUMN IF NOT EXISTS `full_name` VARCHAR(190) NOT NULL;
ALTER TABLE `traffic_visits` ADD COLUMN IF NOT EXISTS `national_code` VARCHAR(10) DEFAULT NULL;
ALTER TABLE `traffic_visits` ADD COLUMN IF NOT EXISTS `phone` VARCHAR(20) DEFAULT NULL;
ALTER TABLE `traffic_visits` ADD COLUMN IF NOT EXISTS `company` VARCHAR(190) DEFAULT NULL;
ALTER TABLE `traffic_visits` ADD COLUMN IF NOT EXISTS `entry_time` TIME DEFAULT NULL;
ALTER TABLE `traffic_visits` ADD COLUMN IF NOT EXISTS `exit_time` TIME DEFAULT NULL;
ALTER TABLE `traffic_visits` ADD COLUMN IF NOT EXISTS `no_visit` TINYINT(1) NOT NULL DEFAULT 0;
ALTER TABLE `traffic_visits` ADD COLUMN IF NOT EXISTS `with_car` TINYINT(1) NOT NULL DEFAULT 0;
ALTER TABLE `traffic_visits` ADD COLUMN IF NOT EXISTS `with_mobile` TINYINT(1) NOT NULL DEFAULT 0;
ALTER TABLE `traffic_visits` ADD COLUMN IF NOT EXISTS `meeting_with` VARCHAR(190) DEFAULT NULL;
ALTER TABLE `traffic_visits` ADD COLUMN IF NOT EXISTS `approved_by` VARCHAR(190) DEFAULT NULL;
ALTER TABLE `traffic_visits` ADD COLUMN IF NOT EXISTS `description` TEXT;
ALTER TABLE `traffic_visits` ADD COLUMN IF NOT EXISTS `is_notice` TINYINT(1) NOT NULL DEFAULT 0;
ALTER TABLE `traffic_visits` ADD COLUMN IF NOT EXISTS `created_by` INT UNSIGNED DEFAULT NULL;
ALTER TABLE `traffic_visits` ADD COLUMN IF NOT EXISTS `created_at` DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP;
ALTER TABLE `traffic_visits` ADD COLUMN IF NOT EXISTS `updated_at` DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP;
ALTER TABLE `categories` ADD COLUMN IF NOT EXISTS `name` VARCHAR(150) NOT NULL;
ALTER TABLE `categories` ADD COLUMN IF NOT EXISTS `code` VARCHAR(60) NULL UNIQUE;
ALTER TABLE `categories` ADD COLUMN IF NOT EXISTS `service_group` ENUM('it','support') NOT NULL DEFAULT 'it';
ALTER TABLE `categories` ADD COLUMN IF NOT EXISTS `is_active` TINYINT(1) NOT NULL DEFAULT 1;
ALTER TABLE `categories` ADD COLUMN IF NOT EXISTS `created_at` DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP;
ALTER TABLE `service_catalog` ADD COLUMN IF NOT EXISTS `name` VARCHAR(190) NOT NULL;
ALTER TABLE `service_catalog` ADD COLUMN IF NOT EXISTS `code` VARCHAR(60) NOT NULL UNIQUE;
ALTER TABLE `service_catalog` ADD COLUMN IF NOT EXISTS `description` TEXT NULL;
ALTER TABLE `service_catalog` ADD COLUMN IF NOT EXISTS `service_group` ENUM('it','support') NOT NULL DEFAULT 'it';
ALTER TABLE `service_catalog` ADD COLUMN IF NOT EXISTS `default_priority` ENUM('normal','urgent','critical') NOT NULL DEFAULT 'normal';
ALTER TABLE `service_catalog` ADD COLUMN IF NOT EXISTS `department_id` INT UNSIGNED NULL;
ALTER TABLE `service_catalog` ADD COLUMN IF NOT EXISTS `category_id` INT UNSIGNED NULL;
ALTER TABLE `service_catalog` ADD COLUMN IF NOT EXISTS `handling_unit_id` INT UNSIGNED NULL;
ALTER TABLE `service_catalog` ADD COLUMN IF NOT EXISTS `requires_asset` TINYINT(1) NOT NULL DEFAULT 1;
UPDATE `service_catalog` SET `requires_asset` = 1 WHERE `service_group` = 'it';
ALTER TABLE `service_catalog` ADD COLUMN IF NOT EXISTS `default_ticket_type` ENUM('incident','request','problem','change') NOT NULL DEFAULT 'incident';
ALTER TABLE `service_catalog` ADD COLUMN IF NOT EXISTS `is_active` TINYINT(1) NOT NULL DEFAULT 1;
ALTER TABLE `service_catalog` ADD COLUMN IF NOT EXISTS `created_by` INT UNSIGNED NULL;
ALTER TABLE `service_catalog` ADD COLUMN IF NOT EXISTS `created_at` DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP;
ALTER TABLE `service_catalog` ADD COLUMN IF NOT EXISTS `updated_at` DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP;
ALTER TABLE `service_catalog_fields` ADD COLUMN IF NOT EXISTS `service_id` INT UNSIGNED NOT NULL;
ALTER TABLE `service_catalog_fields` ADD COLUMN IF NOT EXISTS `field_key` VARCHAR(80) NOT NULL;
ALTER TABLE `service_catalog_fields` ADD COLUMN IF NOT EXISTS `label` VARCHAR(190) NOT NULL;
ALTER TABLE `service_catalog_fields` ADD COLUMN IF NOT EXISTS `field_type` ENUM('text','textarea','number','select','date') NOT NULL DEFAULT 'text';
ALTER TABLE `service_catalog_fields` ADD COLUMN IF NOT EXISTS `options_json` JSON NULL;
ALTER TABLE `service_catalog_fields` ADD COLUMN IF NOT EXISTS `is_required` TINYINT(1) NOT NULL DEFAULT 0;
ALTER TABLE `service_catalog_fields` ADD COLUMN IF NOT EXISTS `sort_order` SMALLINT UNSIGNED NOT NULL DEFAULT 0;
ALTER TABLE `tickets` ADD COLUMN IF NOT EXISTS `ticket_no` VARCHAR(40) NULL;
ALTER TABLE `tickets` ADD COLUMN IF NOT EXISTS `subject` VARCHAR(255) NOT NULL;
ALTER TABLE `tickets` ADD COLUMN IF NOT EXISTS `description` TEXT NOT NULL;
ALTER TABLE `tickets` ADD COLUMN IF NOT EXISTS `category_id` INT UNSIGNED NULL;
ALTER TABLE `tickets` ADD COLUMN IF NOT EXISTS `service_id` INT UNSIGNED NULL;
ALTER TABLE `tickets` ADD COLUMN IF NOT EXISTS `ticket_type` ENUM('incident','request','problem','change') NOT NULL DEFAULT 'incident';
ALTER TABLE `tickets` ADD COLUMN IF NOT EXISTS `parent_ticket_id` INT UNSIGNED NULL;
ALTER TABLE `tickets` ADD COLUMN IF NOT EXISTS `custom_fields` JSON NULL;
ALTER TABLE `tickets` ADD COLUMN IF NOT EXISTS `service_group` ENUM('it','support') NOT NULL DEFAULT 'it';
ALTER TABLE `tickets` ADD COLUMN IF NOT EXISTS `department_id` INT UNSIGNED NULL;
ALTER TABLE `tickets` ADD COLUMN IF NOT EXISTS `requesting_unit_id` INT UNSIGNED NULL;
ALTER TABLE `tickets` ADD COLUMN IF NOT EXISTS `asset_id` INT UNSIGNED NULL;
ALTER TABLE `tickets` ADD COLUMN IF NOT EXISTS `handling_unit_id` INT UNSIGNED NULL;
ALTER TABLE `tickets` ADD COLUMN IF NOT EXISTS `support_location` VARCHAR(255) NULL;
ALTER TABLE `tickets` ADD COLUMN IF NOT EXISTS `support_equipment` TEXT NULL;
ALTER TABLE `tickets` ADD COLUMN IF NOT EXISTS `priority` ENUM('normal','urgent','critical') NOT NULL DEFAULT 'normal';
ALTER TABLE `tickets` ADD COLUMN IF NOT EXISTS `status` ENUM('new','manager_review','assigned','in_progress','waiting_user','pending','resolved','closed','cancelled') NOT NULL DEFAULT 'manager_review';
ALTER TABLE `tickets` MODIFY COLUMN `status` ENUM('new','manager_review','assigned','in_progress','waiting_user','pending','resolved','closed','cancelled') NOT NULL DEFAULT 'manager_review';
ALTER TABLE `tickets` ADD COLUMN IF NOT EXISTS `requester_id` INT UNSIGNED NOT NULL;
ALTER TABLE `tickets` ADD COLUMN IF NOT EXISTS `assigned_to` INT UNSIGNED NULL;
ALTER TABLE `tickets` ADD COLUMN IF NOT EXISTS `assigned_at` DATETIME NULL;
ALTER TABLE `tickets` ADD COLUMN IF NOT EXISTS `first_response_at` DATETIME NULL;
ALTER TABLE `tickets` ADD COLUMN IF NOT EXISTS `resolved_at` DATETIME NULL;
ALTER TABLE `tickets` ADD COLUMN IF NOT EXISTS `closed_at` DATETIME NULL;
ALTER TABLE `tickets` ADD COLUMN IF NOT EXISTS `cancel_requested_at` DATETIME NULL;
ALTER TABLE `tickets` ADD COLUMN IF NOT EXISTS `cancel_requested_by` INT UNSIGNED NULL;
ALTER TABLE `tickets` ADD COLUMN IF NOT EXISTS `cancel_request_reason` TEXT NULL;
ALTER TABLE `tickets` ADD COLUMN IF NOT EXISTS `due_at` DATETIME NULL;
ALTER TABLE `tickets` ADD COLUMN IF NOT EXISTS `sla_minutes` INT UNSIGNED NULL;
ALTER TABLE `tickets` ADD COLUMN IF NOT EXISTS `ola_policy_id` INT UNSIGNED NULL;
ALTER TABLE `tickets` ADD COLUMN IF NOT EXISTS `ola_response_due_at` DATETIME NULL;
ALTER TABLE `tickets` ADD COLUMN IF NOT EXISTS `ola_due_at` DATETIME NULL;
ALTER TABLE `tickets` ADD COLUMN IF NOT EXISTS `ola_escalation_1_at` DATETIME NULL;
ALTER TABLE `tickets` ADD COLUMN IF NOT EXISTS `ola_escalation_2_at` DATETIME NULL;
ALTER TABLE `tickets` ADD COLUMN IF NOT EXISTS `sla_paused_at` DATETIME NULL;
ALTER TABLE `tickets` ADD COLUMN IF NOT EXISTS `sla_pause_minutes` INT UNSIGNED NOT NULL DEFAULT 0;
ALTER TABLE `tickets` ADD COLUMN IF NOT EXISTS `supervisor_id` INT UNSIGNED NULL;
ALTER TABLE `tickets` ADD COLUMN IF NOT EXISTS `supervisor_approved_at` DATETIME NULL;
ALTER TABLE `tickets` ADD COLUMN IF NOT EXISTS `supervisor_note` TEXT NULL;
ALTER TABLE `tickets` ADD COLUMN IF NOT EXISTS `created_at` DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP;
ALTER TABLE `tickets` ADD COLUMN IF NOT EXISTS `updated_at` DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP;
ALTER TABLE `ticket_messages` ADD COLUMN IF NOT EXISTS `ticket_id` INT UNSIGNED NOT NULL;
ALTER TABLE `ticket_messages` ADD COLUMN IF NOT EXISTS `user_id` INT UNSIGNED NOT NULL;
ALTER TABLE `ticket_messages` ADD COLUMN IF NOT EXISTS `body` TEXT NOT NULL;
ALTER TABLE `ticket_messages` ADD COLUMN IF NOT EXISTS `is_internal` TINYINT(1) NOT NULL DEFAULT 0;
ALTER TABLE `ticket_messages` ADD COLUMN IF NOT EXISTS `created_at` DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP;
ALTER TABLE `ticket_ratings` ADD COLUMN IF NOT EXISTS `ticket_id` INT UNSIGNED NOT NULL UNIQUE;
ALTER TABLE `ticket_ratings` ADD COLUMN IF NOT EXISTS `agent_id` INT UNSIGNED NULL;
ALTER TABLE `ticket_ratings` ADD COLUMN IF NOT EXISTS `requester_id` INT UNSIGNED NOT NULL;
ALTER TABLE `ticket_ratings` ADD COLUMN IF NOT EXISTS `score` TINYINT UNSIGNED NOT NULL;
ALTER TABLE `ticket_ratings` ADD COLUMN IF NOT EXISTS `comment` TEXT NULL;
ALTER TABLE `ticket_ratings` ADD COLUMN IF NOT EXISTS `created_at` DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP;
ALTER TABLE `ticket_attachments` ADD COLUMN IF NOT EXISTS `message_id` INT UNSIGNED NOT NULL;
ALTER TABLE `ticket_attachments` ADD COLUMN IF NOT EXISTS `original_name` VARCHAR(255) NOT NULL;
ALTER TABLE `ticket_attachments` ADD COLUMN IF NOT EXISTS `stored_name` VARCHAR(255) NOT NULL UNIQUE;
ALTER TABLE `ticket_attachments` ADD COLUMN IF NOT EXISTS `mime` VARCHAR(150) NOT NULL;
ALTER TABLE `ticket_attachments` ADD COLUMN IF NOT EXISTS `size_bytes` INT UNSIGNED NOT NULL;
ALTER TABLE `ticket_attachments` ADD COLUMN IF NOT EXISTS `created_at` DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP;
ALTER TABLE `activity_logs` ADD COLUMN IF NOT EXISTS `user_id` INT UNSIGNED NULL;
ALTER TABLE `activity_logs` ADD COLUMN IF NOT EXISTS `username` VARCHAR(190) NULL;
ALTER TABLE `activity_logs` ADD COLUMN IF NOT EXISTS `full_name` VARCHAR(190) NULL;
ALTER TABLE `activity_logs` ADD COLUMN IF NOT EXISTS `role` VARCHAR(40) NULL;
ALTER TABLE `activity_logs` ADD COLUMN IF NOT EXISTS `action_code` VARCHAR(120) NOT NULL;
ALTER TABLE `activity_logs` ADD COLUMN IF NOT EXISTS `action_label` VARCHAR(190) NULL;
ALTER TABLE `activity_logs` ADD COLUMN IF NOT EXISTS `module` VARCHAR(80) NULL;
ALTER TABLE `activity_logs` ADD COLUMN IF NOT EXISTS `target_type` VARCHAR(40) NULL;
ALTER TABLE `activity_logs` ADD COLUMN IF NOT EXISTS `target_id` BIGINT UNSIGNED NULL;
ALTER TABLE `activity_logs` ADD COLUMN IF NOT EXISTS `target_label` VARCHAR(255) NULL;
ALTER TABLE `activity_logs` ADD COLUMN IF NOT EXISTS `meta_json` JSON NULL;
ALTER TABLE `activity_logs` ADD COLUMN IF NOT EXISTS `ip_address` VARCHAR(64) NULL;
ALTER TABLE `activity_logs` ADD COLUMN IF NOT EXISTS `computer_name` VARCHAR(190) NULL;
ALTER TABLE `activity_logs` ADD COLUMN IF NOT EXISTS `hostname` VARCHAR(190) NULL;
ALTER TABLE `activity_logs` ADD COLUMN IF NOT EXISTS `user_agent` VARCHAR(255) NULL;
ALTER TABLE `activity_logs` ADD COLUMN IF NOT EXISTS `created_at` DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP;
ALTER TABLE `role_permissions` ADD COLUMN IF NOT EXISTS `role` VARCHAR(40) NOT NULL;
ALTER TABLE `role_permissions` ADD COLUMN IF NOT EXISTS `permission` VARCHAR(80) NOT NULL;
ALTER TABLE `notifications` ADD COLUMN IF NOT EXISTS `user_id` INT UNSIGNED NOT NULL;
ALTER TABLE `notifications` ADD COLUMN IF NOT EXISTS `ticket_id` INT UNSIGNED NULL;
ALTER TABLE `notifications` ADD COLUMN IF NOT EXISTS `notification_type` VARCHAR(80) NOT NULL;
ALTER TABLE `notifications` ADD COLUMN IF NOT EXISTS `title` VARCHAR(255) NOT NULL;
ALTER TABLE `notifications` ADD COLUMN IF NOT EXISTS `body` TEXT NOT NULL;
ALTER TABLE `notifications` ADD COLUMN IF NOT EXISTS `is_read` TINYINT(1) NOT NULL DEFAULT 0;
ALTER TABLE `notifications` ADD COLUMN IF NOT EXISTS `created_at` DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP;
ALTER TABLE `notifications` ADD COLUMN IF NOT EXISTS `read_at` DATETIME NULL;
ALTER TABLE `login_attempts` ADD COLUMN IF NOT EXISTS `attempts` SMALLINT UNSIGNED NOT NULL DEFAULT 0;
ALTER TABLE `login_attempts` ADD COLUMN IF NOT EXISTS `window_started` DATETIME NOT NULL;
ALTER TABLE `login_attempts` ADD COLUMN IF NOT EXISTS `locked_until` DATETIME NULL;
ALTER TABLE `login_attempts` ADD COLUMN IF NOT EXISTS `updated_at` DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP;
ALTER TABLE `ticket_sla_alerts` ADD COLUMN IF NOT EXISTS `ticket_id` INT UNSIGNED NOT NULL;
ALTER TABLE `ticket_sla_alerts` ADD COLUMN IF NOT EXISTS `alert_type` ENUM('due_soon','overdue') NOT NULL;
ALTER TABLE `ticket_sla_alerts` ADD COLUMN IF NOT EXISTS `due_at` DATETIME NOT NULL;
ALTER TABLE `ticket_sla_alerts` ADD COLUMN IF NOT EXISTS `created_at` DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP;
ALTER TABLE `ticket_events` ADD COLUMN IF NOT EXISTS `ticket_id` INT UNSIGNED NOT NULL;
ALTER TABLE `ticket_events` ADD COLUMN IF NOT EXISTS `user_id` INT UNSIGNED NULL;
ALTER TABLE `ticket_events` ADD COLUMN IF NOT EXISTS `event_type` VARCHAR(80) NOT NULL;
ALTER TABLE `ticket_events` ADD COLUMN IF NOT EXISTS `from_status` VARCHAR(40) NULL;
ALTER TABLE `ticket_events` ADD COLUMN IF NOT EXISTS `to_status` VARCHAR(40) NULL;
ALTER TABLE `ticket_events` ADD COLUMN IF NOT EXISTS `details` JSON NULL;
ALTER TABLE `ticket_events` ADD COLUMN IF NOT EXISTS `created_at` DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP;
ALTER TABLE `knowledge_articles` ADD COLUMN IF NOT EXISTS `title` VARCHAR(255) NOT NULL;
ALTER TABLE `knowledge_articles` ADD COLUMN IF NOT EXISTS `slug` VARCHAR(190) NOT NULL UNIQUE;
ALTER TABLE `knowledge_articles` ADD COLUMN IF NOT EXISTS `body` MEDIUMTEXT NOT NULL;
ALTER TABLE `knowledge_articles` ADD COLUMN IF NOT EXISTS `category` VARCHAR(150) NULL;
ALTER TABLE `knowledge_articles` ADD COLUMN IF NOT EXISTS `is_published` TINYINT(1) NOT NULL DEFAULT 1;
ALTER TABLE `knowledge_articles` ADD COLUMN IF NOT EXISTS `created_by` INT UNSIGNED NULL;
ALTER TABLE `knowledge_articles` ADD COLUMN IF NOT EXISTS `created_at` DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP;
ALTER TABLE `knowledge_articles` ADD COLUMN IF NOT EXISTS `updated_at` DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP;
ALTER TABLE `holidays` ADD COLUMN IF NOT EXISTS `holiday_date` DATE NOT NULL UNIQUE;
ALTER TABLE `holidays` ADD COLUMN IF NOT EXISTS `title` VARCHAR(190) NOT NULL;
ALTER TABLE `holidays` ADD COLUMN IF NOT EXISTS `is_active` TINYINT(1) NOT NULL DEFAULT 1;
ALTER TABLE `holidays` ADD COLUMN IF NOT EXISTS `created_by` INT UNSIGNED NULL;
ALTER TABLE `holidays` ADD COLUMN IF NOT EXISTS `created_at` DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP;
ALTER TABLE `assets` ADD COLUMN IF NOT EXISTS `asset_tag` VARCHAR(100) NOT NULL UNIQUE;
ALTER TABLE `assets` ADD COLUMN IF NOT EXISTS `record_number` VARCHAR(100) NULL;
ALTER TABLE `assets` ADD COLUMN IF NOT EXISTS `hostname` VARCHAR(190) NULL;
ALTER TABLE `assets` ADD COLUMN IF NOT EXISTS `serial_number` VARCHAR(190) NULL;
ALTER TABLE `assets` ADD COLUMN IF NOT EXISTS `computer_type` VARCHAR(100) NULL;
ALTER TABLE `assets` ADD COLUMN IF NOT EXISTS `manufacturer` VARCHAR(190) NULL;
ALTER TABLE `assets` ADD COLUMN IF NOT EXISTS `model` VARCHAR(190) NULL;
ALTER TABLE `assets` ADD COLUMN IF NOT EXISTS `asset_number` VARCHAR(100) NULL;
ALTER TABLE `assets` ADD COLUMN IF NOT EXISTS `seal_number` VARCHAR(100) NULL;
ALTER TABLE `assets` ADD COLUMN IF NOT EXISTS `plaque_number` VARCHAR(100) NULL;
ALTER TABLE `assets` ADD COLUMN IF NOT EXISTS `employee_number` VARCHAR(100) NULL;
ALTER TABLE `assets` ADD COLUMN IF NOT EXISTS `person_number` VARCHAR(100) NULL;
ALTER TABLE `assets` ADD COLUMN IF NOT EXISTS `city` VARCHAR(100) NULL;
ALTER TABLE `assets` ADD COLUMN IF NOT EXISTS `phone` VARCHAR(80) NULL;
ALTER TABLE `assets` ADD COLUMN IF NOT EXISTS `owner_user_id` INT UNSIGNED NULL;
ALTER TABLE `assets` ADD COLUMN IF NOT EXISTS `department_id` INT UNSIGNED NULL;
ALTER TABLE `assets` ADD COLUMN IF NOT EXISTS `operating_system` VARCHAR(255) NULL;
ALTER TABLE `assets` ADD COLUMN IF NOT EXISTS `ip_address` VARCHAR(100) NULL;
ALTER TABLE `assets` ADD COLUMN IF NOT EXISTS `mac_address` VARCHAR(100) NULL;
ALTER TABLE `assets` ADD COLUMN IF NOT EXISTS `cpu` VARCHAR(255) NULL;
ALTER TABLE `assets` ADD COLUMN IF NOT EXISTS `memory_mb` INT UNSIGNED NULL;
ALTER TABLE `assets` ADD COLUMN IF NOT EXISTS `disks_json` JSON NULL;
ALTER TABLE `assets` ADD COLUMN IF NOT EXISTS `software_json` JSON NULL;
ALTER TABLE `assets` ADD COLUMN IF NOT EXISTS `hardware_json` JSON NULL;
ALTER TABLE `assets` ADD COLUMN IF NOT EXISTS `peripherals_json` JSON NULL;
ALTER TABLE `assets` ADD COLUMN IF NOT EXISTS `domain_username` VARCHAR(190) NULL;
ALTER TABLE `assets` ADD COLUMN IF NOT EXISTS `antivirus` VARCHAR(255) NULL;
ALTER TABLE `assets` ADD COLUMN IF NOT EXISTS `sound_card` VARCHAR(255) NULL;
ALTER TABLE `assets` ADD COLUMN IF NOT EXISTS `network_card` VARCHAR(255) NULL;
ALTER TABLE `assets` ADD COLUMN IF NOT EXISTS `os_architecture` VARCHAR(40) NULL;
ALTER TABLE `assets` ADD COLUMN IF NOT EXISTS `os_serial` VARCHAR(190) NULL;
ALTER TABLE `assets` ADD COLUMN IF NOT EXISTS `os_install_date` DATETIME NULL;
ALTER TABLE `assets` ADD COLUMN IF NOT EXISTS `registered_users` INT UNSIGNED NULL;
ALTER TABLE `assets` ADD COLUMN IF NOT EXISTS `source` ENUM('manual','server_inventory','agent') NOT NULL DEFAULT 'manual';
ALTER TABLE `assets` ADD COLUMN IF NOT EXISTS `lifecycle_status` ENUM('planned','in_stock','assigned','in_repair','retired','disposed') NOT NULL DEFAULT 'in_stock';
ALTER TABLE `assets` ADD COLUMN IF NOT EXISTS `purchase_date` DATE NULL;
ALTER TABLE `assets` ADD COLUMN IF NOT EXISTS `warranty_until` DATE NULL;
ALTER TABLE `assets` ADD COLUMN IF NOT EXISTS `vendor` VARCHAR(190) NULL;
ALTER TABLE `assets` ADD COLUMN IF NOT EXISTS `acquisition_cost` DECIMAL(15,2) NULL;
ALTER TABLE `assets` ADD COLUMN IF NOT EXISTS `disposal_note` TEXT NULL;
ALTER TABLE `assets` ADD COLUMN IF NOT EXISTS `retired_at` DATETIME NULL;
ALTER TABLE `assets` ADD COLUMN IF NOT EXISTS `last_inventory_at` DATETIME NULL;
ALTER TABLE `assets` ADD COLUMN IF NOT EXISTS `created_at` DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP;
ALTER TABLE `assets` ADD COLUMN IF NOT EXISTS `updated_at` DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP;
ALTER TABLE `asset_memory_modules` ADD COLUMN IF NOT EXISTS `asset_id` INT UNSIGNED NOT NULL;
ALTER TABLE `asset_memory_modules` ADD COLUMN IF NOT EXISTS `slot_no` SMALLINT UNSIGNED NOT NULL;
ALTER TABLE `asset_memory_modules` ADD COLUMN IF NOT EXISTS `manufacturer` VARCHAR(190) NULL;
ALTER TABLE `asset_memory_modules` ADD COLUMN IF NOT EXISTS `model` VARCHAR(190) NULL;
ALTER TABLE `asset_memory_modules` ADD COLUMN IF NOT EXISTS `capacity_mb` INT UNSIGNED NULL;
ALTER TABLE `asset_memory_modules` ADD COLUMN IF NOT EXISTS `speed_mhz` INT UNSIGNED NULL;
ALTER TABLE `asset_memory_modules` ADD COLUMN IF NOT EXISTS `serial_number` VARCHAR(190) NULL;
ALTER TABLE `asset_memory_modules` ADD COLUMN IF NOT EXISTS `collected_at` DATETIME NULL;
ALTER TABLE `asset_memory_modules` ADD COLUMN IF NOT EXISTS `created_at` DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP;
ALTER TABLE `asset_storage_devices` ADD COLUMN IF NOT EXISTS `asset_id` INT UNSIGNED NOT NULL;
ALTER TABLE `asset_storage_devices` ADD COLUMN IF NOT EXISTS `slot_no` SMALLINT UNSIGNED NOT NULL;
ALTER TABLE `asset_storage_devices` ADD COLUMN IF NOT EXISTS `device_type` VARCHAR(60) NULL;
ALTER TABLE `asset_storage_devices` ADD COLUMN IF NOT EXISTS `model` VARCHAR(190) NULL;
ALTER TABLE `asset_storage_devices` ADD COLUMN IF NOT EXISTS `capacity_bytes` BIGINT UNSIGNED NULL;
ALTER TABLE `asset_storage_devices` ADD COLUMN IF NOT EXISTS `serial_number` VARCHAR(190) NULL;
ALTER TABLE `asset_storage_devices` ADD COLUMN IF NOT EXISTS `media_type` VARCHAR(100) NULL;
ALTER TABLE `asset_storage_devices` ADD COLUMN IF NOT EXISTS `interface_type` VARCHAR(100) NULL;
ALTER TABLE `asset_storage_devices` ADD COLUMN IF NOT EXISTS `collected_at` DATETIME NULL;
ALTER TABLE `asset_storage_devices` ADD COLUMN IF NOT EXISTS `created_at` DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP;
ALTER TABLE `asset_graphics_adapters` ADD COLUMN IF NOT EXISTS `asset_id` INT UNSIGNED NOT NULL;
ALTER TABLE `asset_graphics_adapters` ADD COLUMN IF NOT EXISTS `slot_no` SMALLINT UNSIGNED NOT NULL;
ALTER TABLE `asset_graphics_adapters` ADD COLUMN IF NOT EXISTS `model` VARCHAR(255) NULL;
ALTER TABLE `asset_graphics_adapters` ADD COLUMN IF NOT EXISTS `vram_mb` INT UNSIGNED NULL;
ALTER TABLE `asset_graphics_adapters` ADD COLUMN IF NOT EXISTS `driver_version` VARCHAR(100) NULL;
ALTER TABLE `asset_graphics_adapters` ADD COLUMN IF NOT EXISTS `collected_at` DATETIME NULL;
ALTER TABLE `asset_graphics_adapters` ADD COLUMN IF NOT EXISTS `created_at` DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP;
ALTER TABLE `asset_peripherals` ADD COLUMN IF NOT EXISTS `asset_id` INT UNSIGNED NOT NULL;
ALTER TABLE `asset_peripherals` ADD COLUMN IF NOT EXISTS `peripheral_type` ENUM('monitor','printer','scanner','modem','network_card','sound_card','case','mouse','keyboard','other') NOT NULL;
ALTER TABLE `asset_peripherals` ADD COLUMN IF NOT EXISTS `slot_no` SMALLINT UNSIGNED NOT NULL DEFAULT 1;
ALTER TABLE `asset_peripherals` ADD COLUMN IF NOT EXISTS `model` VARCHAR(255) NULL;
ALTER TABLE `asset_peripherals` ADD COLUMN IF NOT EXISTS `manufacturer` VARCHAR(190) NULL;
ALTER TABLE `asset_peripherals` ADD COLUMN IF NOT EXISTS `serial_number` VARCHAR(190) NULL;
ALTER TABLE `asset_peripherals` ADD COLUMN IF NOT EXISTS `asset_number` VARCHAR(100) NULL;
ALTER TABLE `asset_peripherals` ADD COLUMN IF NOT EXISTS `seal_number` VARCHAR(100) NULL;
ALTER TABLE `asset_peripherals` ADD COLUMN IF NOT EXISTS `details_json` JSON NULL;
ALTER TABLE `asset_peripherals` ADD COLUMN IF NOT EXISTS `source` ENUM('manual','agent','server_inventory') NOT NULL DEFAULT 'manual';
ALTER TABLE `asset_peripherals` ADD COLUMN IF NOT EXISTS `collected_at` DATETIME NULL;
ALTER TABLE `asset_peripherals` ADD COLUMN IF NOT EXISTS `created_at` DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP;
ALTER TABLE `asset_inventory_history` ADD COLUMN IF NOT EXISTS `asset_id` INT UNSIGNED NOT NULL;
ALTER TABLE `asset_inventory_history` ADD COLUMN IF NOT EXISTS `snapshot_json` JSON NOT NULL;
ALTER TABLE `asset_inventory_history` ADD COLUMN IF NOT EXISTS `collected_by` INT UNSIGNED NULL;
ALTER TABLE `asset_inventory_history` ADD COLUMN IF NOT EXISTS `collected_at` DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP;
ALTER TABLE `asset_history_events` ADD COLUMN IF NOT EXISTS `asset_id` INT UNSIGNED NOT NULL;
ALTER TABLE `asset_history_events` ADD COLUMN IF NOT EXISTS `ticket_id` INT UNSIGNED NULL;
ALTER TABLE `asset_history_events` ADD COLUMN IF NOT EXISTS `user_id` INT UNSIGNED NULL;
ALTER TABLE `asset_history_events` ADD COLUMN IF NOT EXISTS `event_type` VARCHAR(80) NOT NULL;
ALTER TABLE `asset_history_events` ADD COLUMN IF NOT EXISTS `title` VARCHAR(255) NOT NULL;
ALTER TABLE `asset_history_events` ADD COLUMN IF NOT EXISTS `details` TEXT NULL;
ALTER TABLE `asset_history_events` ADD COLUMN IF NOT EXISTS `before_json` JSON NULL;
ALTER TABLE `asset_history_events` ADD COLUMN IF NOT EXISTS `after_json` JSON NULL;
ALTER TABLE `asset_history_events` ADD COLUMN IF NOT EXISTS `created_at` DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP;
ALTER TABLE `asset_relations` ADD COLUMN IF NOT EXISTS `source_asset_id` INT UNSIGNED NOT NULL;
ALTER TABLE `asset_relations` ADD COLUMN IF NOT EXISTS `target_asset_id` INT UNSIGNED NOT NULL;
ALTER TABLE `asset_relations` ADD COLUMN IF NOT EXISTS `relation_type` ENUM('depends_on','connected_to','replaces','located_with','related_to') NOT NULL DEFAULT 'related_to';
ALTER TABLE `asset_relations` ADD COLUMN IF NOT EXISTS `created_by` INT UNSIGNED NULL;
ALTER TABLE `asset_relations` ADD COLUMN IF NOT EXISTS `created_at` DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP;
ALTER TABLE `asset_profiles` ADD COLUMN IF NOT EXISTS `record_number` VARCHAR(100) NULL;
ALTER TABLE `asset_profiles` ADD COLUMN IF NOT EXISTS `registrar_name` VARCHAR(190) NULL;
ALTER TABLE `asset_profiles` ADD COLUMN IF NOT EXISTS `registry_date` DATETIME NULL;
ALTER TABLE `asset_profiles` ADD COLUMN IF NOT EXISTS `unit_name` VARCHAR(190) NULL;
ALTER TABLE `asset_profiles` ADD COLUMN IF NOT EXISTS `computer_type` VARCHAR(100) NULL;
ALTER TABLE `asset_profiles` ADD COLUMN IF NOT EXISTS `user_login` VARCHAR(190) NULL;
ALTER TABLE `asset_profiles` ADD COLUMN IF NOT EXISTS `owner_full_name` VARCHAR(190) NULL;
ALTER TABLE `asset_profiles` ADD COLUMN IF NOT EXISTS `education` VARCHAR(190) NULL;
ALTER TABLE `asset_profiles` ADD COLUMN IF NOT EXISTS `phone` VARCHAR(80) NULL;
ALTER TABLE `asset_profiles` ADD COLUMN IF NOT EXISTS `degree` VARCHAR(190) NULL;
ALTER TABLE `asset_profiles` ADD COLUMN IF NOT EXISTS `skill_level` VARCHAR(190) NULL;
ALTER TABLE `asset_profiles` ADD COLUMN IF NOT EXISTS `personnel_number` VARCHAR(100) NULL;
ALTER TABLE `asset_profiles` ADD COLUMN IF NOT EXISTS `training_skills` TEXT NULL;
ALTER TABLE `asset_profiles` ADD COLUMN IF NOT EXISTS `secure_info` TEXT NULL;
ALTER TABLE `asset_profiles` ADD COLUMN IF NOT EXISTS `unit_software` TEXT NULL;
ALTER TABLE `asset_profiles` ADD COLUMN IF NOT EXISTS `os_name` VARCHAR(255) NULL;
ALTER TABLE `asset_profiles` ADD COLUMN IF NOT EXISTS `hostname` VARCHAR(190) NULL;
ALTER TABLE `asset_profiles` ADD COLUMN IF NOT EXISTS `windows_serial` VARCHAR(190) NULL;
ALTER TABLE `asset_profiles` ADD COLUMN IF NOT EXISTS `os_version` VARCHAR(100) NULL;
ALTER TABLE `asset_profiles` ADD COLUMN IF NOT EXISTS `os_install_path` VARCHAR(255) NULL;
ALTER TABLE `asset_profiles` ADD COLUMN IF NOT EXISTS `user_count` VARCHAR(40) NULL;
ALTER TABLE `asset_profiles` ADD COLUMN IF NOT EXISTS `os_install_date` DATETIME NULL;
ALTER TABLE `asset_profiles` ADD COLUMN IF NOT EXISTS `disk1_model` VARCHAR(190) NULL;
ALTER TABLE `asset_profiles` ADD COLUMN IF NOT EXISTS `disk1_capacity` VARCHAR(60) NULL;
ALTER TABLE `asset_profiles` ADD COLUMN IF NOT EXISTS `disk1_serial` VARCHAR(190) NULL;
ALTER TABLE `asset_profiles` ADD COLUMN IF NOT EXISTS `disk2_model` VARCHAR(190) NULL;
ALTER TABLE `asset_profiles` ADD COLUMN IF NOT EXISTS `disk2_capacity` VARCHAR(60) NULL;
ALTER TABLE `asset_profiles` ADD COLUMN IF NOT EXISTS `disk2_serial` VARCHAR(190) NULL;
ALTER TABLE `asset_profiles` ADD COLUMN IF NOT EXISTS `motherboard_model` VARCHAR(190) NULL;
ALTER TABLE `asset_profiles` ADD COLUMN IF NOT EXISTS `motherboard_product` VARCHAR(190) NULL;
ALTER TABLE `asset_profiles` ADD COLUMN IF NOT EXISTS `motherboard_serial` VARCHAR(190) NULL;
ALTER TABLE `asset_profiles` ADD COLUMN IF NOT EXISTS `cpu_model` VARCHAR(190) NULL;
ALTER TABLE `asset_profiles` ADD COLUMN IF NOT EXISTS `cpu_serial` VARCHAR(190) NULL;
ALTER TABLE `asset_profiles` ADD COLUMN IF NOT EXISTS `cpu_cores` VARCHAR(40) NULL;
ALTER TABLE `asset_profiles` ADD COLUMN IF NOT EXISTS `ram1` VARCHAR(190) NULL;
ALTER TABLE `asset_profiles` ADD COLUMN IF NOT EXISTS `ram2` VARCHAR(190) NULL;
ALTER TABLE `asset_profiles` ADD COLUMN IF NOT EXISTS `ram_total` VARCHAR(60) NULL;
ALTER TABLE `asset_profiles` ADD COLUMN IF NOT EXISTS `gpu1_model` VARCHAR(190) NULL;
ALTER TABLE `asset_profiles` ADD COLUMN IF NOT EXISTS `gpu1_memory` VARCHAR(60) NULL;
ALTER TABLE `asset_profiles` ADD COLUMN IF NOT EXISTS `gpu2_model` VARCHAR(190) NULL;
ALTER TABLE `asset_profiles` ADD COLUMN IF NOT EXISTS `gpu2_memory` VARCHAR(60) NULL;
ALTER TABLE `asset_profiles` ADD COLUMN IF NOT EXISTS `audio` VARCHAR(190) NULL;
ALTER TABLE `asset_profiles` ADD COLUMN IF NOT EXISTS `ip_address` VARCHAR(100) NULL;
ALTER TABLE `asset_profiles` ADD COLUMN IF NOT EXISTS `mac_address` VARCHAR(100) NULL;
ALTER TABLE `asset_profiles` ADD COLUMN IF NOT EXISTS `netcard` VARCHAR(190) NULL;
ALTER TABLE `asset_profiles` ADD COLUMN IF NOT EXISTS `net_node` VARCHAR(100) NULL;
ALTER TABLE `asset_profiles` ADD COLUMN IF NOT EXISTS `connected_internet` TINYINT(1) NOT NULL DEFAULT 0;
ALTER TABLE `asset_profiles` ADD COLUMN IF NOT EXISTS `connected_network` TINYINT(1) NOT NULL DEFAULT 0;
ALTER TABLE `asset_profiles` ADD COLUMN IF NOT EXISTS `lock_usb` TINYINT(1) NOT NULL DEFAULT 0;
ALTER TABLE `asset_profiles` ADD COLUMN IF NOT EXISTS `lock_case` TINYINT(1) NOT NULL DEFAULT 0;
ALTER TABLE `asset_profiles` ADD COLUMN IF NOT EXISTS `lock_cd_dvd` TINYINT(1) NOT NULL DEFAULT 0;
ALTER TABLE `asset_profiles` ADD COLUMN IF NOT EXISTS `monitor_model` VARCHAR(190) NULL;
ALTER TABLE `asset_profiles` ADD COLUMN IF NOT EXISTS `printer_model` VARCHAR(190) NULL;
ALTER TABLE `asset_profiles` ADD COLUMN IF NOT EXISTS `scanner_model` VARCHAR(190) NULL;
ALTER TABLE `asset_profiles` ADD COLUMN IF NOT EXISTS `mouse_model` VARCHAR(190) NULL;
ALTER TABLE `asset_profiles` ADD COLUMN IF NOT EXISTS `barcode_reader` VARCHAR(190) NULL;
ALTER TABLE `asset_profiles` ADD COLUMN IF NOT EXISTS `antivirus` VARCHAR(255) NULL;
ALTER TABLE `asset_profiles` ADD COLUMN IF NOT EXISTS `power_model` VARCHAR(190) NULL;
ALTER TABLE `asset_profiles` ADD COLUMN IF NOT EXISTS `case_model` VARCHAR(190) NULL;
ALTER TABLE `asset_profiles` ADD COLUMN IF NOT EXISTS `plaque_number` VARCHAR(100) NULL;
ALTER TABLE `asset_profiles` ADD COLUMN IF NOT EXISTS `plaque_monitor` VARCHAR(100) NULL;
ALTER TABLE `asset_profiles` ADD COLUMN IF NOT EXISTS `plaque_printer` VARCHAR(100) NULL;
ALTER TABLE `asset_profiles` ADD COLUMN IF NOT EXISTS `plaque_printer2` VARCHAR(100) NULL;
ALTER TABLE `asset_profiles` ADD COLUMN IF NOT EXISTS `plaque_scanner` VARCHAR(100) NULL;
ALTER TABLE `asset_profiles` ADD COLUMN IF NOT EXISTS `case_seal` TEXT NULL;
ALTER TABLE `asset_profiles` ADD COLUMN IF NOT EXISTS `ad_dn` VARCHAR(255) NULL;
ALTER TABLE `asset_profiles` ADD COLUMN IF NOT EXISTS `ad_os` VARCHAR(255) NULL;
ALTER TABLE `asset_profiles` ADD COLUMN IF NOT EXISTS `ad_os_version` VARCHAR(255) NULL;
ALTER TABLE `asset_profiles` ADD COLUMN IF NOT EXISTS `ad_last_logon` DATETIME NULL;
ALTER TABLE `asset_profiles` ADD COLUMN IF NOT EXISTS `ad_last_seen` DATETIME NULL;
ALTER TABLE `asset_profiles` ADD COLUMN IF NOT EXISTS `ad_scanned_at` DATETIME NULL;
ALTER TABLE `asset_profiles` ADD COLUMN IF NOT EXISTS `ad_online` TINYINT(1) NOT NULL DEFAULT 0;
ALTER TABLE `asset_profiles` ADD COLUMN IF NOT EXISTS `ad_description` VARCHAR(255) NULL;
ALTER TABLE `asset_profiles` ADD COLUMN IF NOT EXISTS `updated_by` INT UNSIGNED NULL;
ALTER TABLE `asset_profiles` ADD COLUMN IF NOT EXISTS `updated_at` DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP;
ALTER TABLE `ola_policies` ADD COLUMN IF NOT EXISTS `name` VARCHAR(190) NOT NULL;
ALTER TABLE `ola_policies` ADD COLUMN IF NOT EXISTS `department_id` INT UNSIGNED NULL;
ALTER TABLE `ola_policies` ADD COLUMN IF NOT EXISTS `priority` ENUM('normal','urgent','critical') NOT NULL;
ALTER TABLE `ola_policies` ADD COLUMN IF NOT EXISTS `response_minutes` INT UNSIGNED NOT NULL;
ALTER TABLE `ola_policies` ADD COLUMN IF NOT EXISTS `resolution_minutes` INT UNSIGNED NOT NULL;
ALTER TABLE `ola_policies` ADD COLUMN IF NOT EXISTS `escalation_1_minutes` INT UNSIGNED NOT NULL;
ALTER TABLE `ola_policies` ADD COLUMN IF NOT EXISTS `escalation_2_minutes` INT UNSIGNED NOT NULL;
ALTER TABLE `ola_policies` ADD COLUMN IF NOT EXISTS `is_active` TINYINT(1) NOT NULL DEFAULT 1;
ALTER TABLE `ola_policies` ADD COLUMN IF NOT EXISTS `created_by` INT UNSIGNED NULL;
ALTER TABLE `ola_policies` ADD COLUMN IF NOT EXISTS `created_at` DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP;
ALTER TABLE `ola_policies` ADD COLUMN IF NOT EXISTS `updated_at` DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP;
ALTER TABLE `ticket_ola_alerts` ADD COLUMN IF NOT EXISTS `ticket_id` INT UNSIGNED NOT NULL;
ALTER TABLE `ticket_ola_alerts` ADD COLUMN IF NOT EXISTS `alert_type` ENUM('response_overdue','resolution_overdue','escalation_1','escalation_2') NOT NULL;
ALTER TABLE `ticket_ola_alerts` ADD COLUMN IF NOT EXISTS `due_at` DATETIME NOT NULL;
ALTER TABLE `ticket_ola_alerts` ADD COLUMN IF NOT EXISTS `created_at` DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP;
ALTER TABLE `change_records` ADD COLUMN IF NOT EXISTS `change_number` VARCHAR(40) NOT NULL UNIQUE;
ALTER TABLE `change_records` ADD COLUMN IF NOT EXISTS `title` VARCHAR(255) NOT NULL;
ALTER TABLE `change_records` ADD COLUMN IF NOT EXISTS `description` TEXT NOT NULL;
ALTER TABLE `change_records` ADD COLUMN IF NOT EXISTS `justification` TEXT NULL;
ALTER TABLE `change_records` ADD COLUMN IF NOT EXISTS `risk_level` ENUM('low','medium','high','critical') NOT NULL DEFAULT 'medium';
ALTER TABLE `change_records` ADD COLUMN IF NOT EXISTS `impact` TEXT NULL;
ALTER TABLE `change_records` ADD COLUMN IF NOT EXISTS `planned_start` DATETIME NULL;
ALTER TABLE `change_records` ADD COLUMN IF NOT EXISTS `planned_end` DATETIME NULL;
ALTER TABLE `change_records` ADD COLUMN IF NOT EXISTS `status` ENUM('draft','submitted','cab_review','approved','rejected','scheduled','implemented','rolled_back','closed') NOT NULL DEFAULT 'draft';
ALTER TABLE `change_records` ADD COLUMN IF NOT EXISTS `department_id` INT UNSIGNED NULL;
ALTER TABLE `change_records` ADD COLUMN IF NOT EXISTS `requester_id` INT UNSIGNED NOT NULL;
ALTER TABLE `change_records` ADD COLUMN IF NOT EXISTS `owner_id` INT UNSIGNED NULL;
ALTER TABLE `change_records` ADD COLUMN IF NOT EXISTS `cab_decided_by` INT UNSIGNED NULL;
ALTER TABLE `change_records` ADD COLUMN IF NOT EXISTS `cab_decided_at` DATETIME NULL;
ALTER TABLE `change_records` ADD COLUMN IF NOT EXISTS `cab_note` TEXT NULL;
ALTER TABLE `change_records` ADD COLUMN IF NOT EXISTS `implementation_note` TEXT NULL;
ALTER TABLE `change_records` ADD COLUMN IF NOT EXISTS `created_at` DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP;
ALTER TABLE `change_records` ADD COLUMN IF NOT EXISTS `updated_at` DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP;
ALTER TABLE `change_approvals` ADD COLUMN IF NOT EXISTS `change_id` INT UNSIGNED NOT NULL;
ALTER TABLE `change_approvals` ADD COLUMN IF NOT EXISTS `approver_id` INT UNSIGNED NULL;
ALTER TABLE `change_approvals` ADD COLUMN IF NOT EXISTS `decision` ENUM('submitted','approved','rejected','scheduled','implemented','rolled_back','closed') NOT NULL;
ALTER TABLE `change_approvals` ADD COLUMN IF NOT EXISTS `note` TEXT NULL;
ALTER TABLE `change_approvals` ADD COLUMN IF NOT EXISTS `created_at` DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP;
ALTER TABLE `change_ticket_links` ADD COLUMN IF NOT EXISTS `change_id` INT UNSIGNED NOT NULL;
ALTER TABLE `change_ticket_links` ADD COLUMN IF NOT EXISTS `ticket_id` INT UNSIGNED NOT NULL;
ALTER TABLE `change_ticket_links` ADD COLUMN IF NOT EXISTS `created_by` INT UNSIGNED NULL;
ALTER TABLE `change_ticket_links` ADD COLUMN IF NOT EXISTS `created_at` DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP;
ALTER TABLE `problem_records` ADD COLUMN IF NOT EXISTS `problem_number` VARCHAR(40) NOT NULL UNIQUE;
ALTER TABLE `problem_records` ADD COLUMN IF NOT EXISTS `title` VARCHAR(255) NOT NULL;
ALTER TABLE `problem_records` ADD COLUMN IF NOT EXISTS `description` TEXT NOT NULL;
ALTER TABLE `problem_records` ADD COLUMN IF NOT EXISTS `root_cause` TEXT NULL;
ALTER TABLE `problem_records` ADD COLUMN IF NOT EXISTS `workaround` TEXT NULL;
ALTER TABLE `problem_records` ADD COLUMN IF NOT EXISTS `known_error` TINYINT(1) NOT NULL DEFAULT 0;
ALTER TABLE `problem_records` ADD COLUMN IF NOT EXISTS `priority` ENUM('normal','urgent','critical') NOT NULL DEFAULT 'normal';
ALTER TABLE `problem_records` ADD COLUMN IF NOT EXISTS `status` ENUM('open','investigation','known_error','resolved','closed') NOT NULL DEFAULT 'open';
ALTER TABLE `problem_records` ADD COLUMN IF NOT EXISTS `department_id` INT UNSIGNED NULL;
ALTER TABLE `problem_records` ADD COLUMN IF NOT EXISTS `created_by` INT UNSIGNED NOT NULL;
ALTER TABLE `problem_records` ADD COLUMN IF NOT EXISTS `owner_id` INT UNSIGNED NULL;
ALTER TABLE `problem_records` ADD COLUMN IF NOT EXISTS `resolved_at` DATETIME NULL;
ALTER TABLE `problem_records` ADD COLUMN IF NOT EXISTS `created_at` DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP;
ALTER TABLE `problem_records` ADD COLUMN IF NOT EXISTS `updated_at` DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP;
ALTER TABLE `problem_ticket_links` ADD COLUMN IF NOT EXISTS `problem_id` INT UNSIGNED NOT NULL;
ALTER TABLE `problem_ticket_links` ADD COLUMN IF NOT EXISTS `ticket_id` INT UNSIGNED NOT NULL;
ALTER TABLE `problem_ticket_links` ADD COLUMN IF NOT EXISTS `created_by` INT UNSIGNED NULL;
ALTER TABLE `problem_ticket_links` ADD COLUMN IF NOT EXISTS `created_at` DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP;
ALTER TABLE `food_ticket_config` ADD COLUMN IF NOT EXISTS `enabled` TINYINT(1) NOT NULL DEFAULT 0;
ALTER TABLE `food_ticket_config` ADD COLUMN IF NOT EXISTS `attendance_path` VARCHAR(500) NOT NULL DEFAULT '';
ALTER TABLE `food_ticket_config` ADD COLUMN IF NOT EXISTS `attendance_password_enc` TEXT NULL;
ALTER TABLE `food_ticket_config` ADD COLUMN IF NOT EXISTS `printer_mode` ENUM('tcp_raw','windows_share') NOT NULL DEFAULT 'tcp_raw';
ALTER TABLE `food_ticket_config` ADD COLUMN IF NOT EXISTS `printer_host` VARCHAR(255) NOT NULL DEFAULT '';
ALTER TABLE `food_ticket_config` ADD COLUMN IF NOT EXISTS `printer_port` SMALLINT UNSIGNED NOT NULL DEFAULT 9100;
ALTER TABLE `food_ticket_config` ADD COLUMN IF NOT EXISTS `printer_share` VARCHAR(255) NOT NULL DEFAULT '';
ALTER TABLE `food_ticket_config` ADD COLUMN IF NOT EXISTS `poll_seconds` TINYINT UNSIGNED NOT NULL DEFAULT 2;
ALTER TABLE `food_ticket_config` ADD COLUMN IF NOT EXISTS `max_batch` SMALLINT UNSIGNED NOT NULL DEFAULT 100;
ALTER TABLE `food_ticket_config` ADD COLUMN IF NOT EXISTS `guest_card_uids` TEXT NULL;
ALTER TABLE `food_ticket_config` ADD COLUMN IF NOT EXISTS `max_guest_daily` SMALLINT UNSIGNED NOT NULL DEFAULT 20;
ALTER TABLE `food_ticket_config` ADD COLUMN IF NOT EXISTS `cut_source_rows` TINYINT(1) NOT NULL DEFAULT 1;
ALTER TABLE `food_ticket_config` ADD COLUMN IF NOT EXISTS `updated_by` INT UNSIGNED NULL;
ALTER TABLE `food_ticket_config` ADD COLUMN IF NOT EXISTS `updated_at` DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP;
ALTER TABLE `food_ticket_events` ADD COLUMN IF NOT EXISTS `source_key` CHAR(64) NOT NULL UNIQUE;
ALTER TABLE `food_ticket_events` ADD COLUMN IF NOT EXISTS `source_uid` VARCHAR(80) NULL;
ALTER TABLE `food_ticket_events` ADD COLUMN IF NOT EXISTS `source_card` VARCHAR(120) NULL;
ALTER TABLE `food_ticket_events` ADD COLUMN IF NOT EXISTS `punch_date` DATE NULL;
ALTER TABLE `food_ticket_events` ADD COLUMN IF NOT EXISTS `punch_time` TIME NULL;
ALTER TABLE `food_ticket_events` ADD COLUMN IF NOT EXISTS `personnel_code` VARCHAR(100) NULL;
ALTER TABLE `food_ticket_events` ADD COLUMN IF NOT EXISTS `user_id` INT UNSIGNED NULL;
ALTER TABLE `food_ticket_events` ADD COLUMN IF NOT EXISTS `national_code` VARCHAR(30) NULL;
ALTER TABLE `food_ticket_events` ADD COLUMN IF NOT EXISTS `full_name` VARCHAR(190) NULL;
ALTER TABLE `food_ticket_events` ADD COLUMN IF NOT EXISTS `food_type` VARCHAR(190) NULL;
ALTER TABLE `food_ticket_events` ADD COLUMN IF NOT EXISTS `ticket_key` VARCHAR(190) NULL UNIQUE;
ALTER TABLE `food_ticket_events` ADD COLUMN IF NOT EXISTS `print_job_id` VARCHAR(64) NULL;
ALTER TABLE `food_ticket_events` ADD COLUMN IF NOT EXISTS `event_type` ENUM('printed','print_error','no_food','unknown','inactive','repeat','guest','guest_limit','config_error') NOT NULL;
ALTER TABLE `food_ticket_events` ADD COLUMN IF NOT EXISTS `print_status` ENUM('not_printed','pending','printing','printed','print_error','failed','held_absent') NOT NULL DEFAULT 'not_printed';
ALTER TABLE `food_ticket_events` ADD COLUMN IF NOT EXISTS `delivery_status` ENUM('pending','delivered') NOT NULL DEFAULT 'pending';
ALTER TABLE `food_ticket_events` ADD COLUMN IF NOT EXISTS `delivered_at` DATETIME NULL;
ALTER TABLE `food_ticket_events` ADD COLUMN IF NOT EXISTS `delivered_by` INT UNSIGNED NULL;
ALTER TABLE `food_ticket_events` ADD COLUMN IF NOT EXISTS `source_deleted` TINYINT(1) NOT NULL DEFAULT 0;
ALTER TABLE `food_ticket_events` ADD COLUMN IF NOT EXISTS `source_deleted_at` DATETIME NULL;
ALTER TABLE `food_ticket_events` ADD COLUMN IF NOT EXISTS `source_delete_note` VARCHAR(255) NULL;
ALTER TABLE `food_ticket_events` ADD COLUMN IF NOT EXISTS `print_attempts` SMALLINT UNSIGNED NOT NULL DEFAULT 0;
ALTER TABLE `food_ticket_events` ADD COLUMN IF NOT EXISTS `retry_count` INT NOT NULL DEFAULT 0;
ALTER TABLE `food_ticket_events` ADD COLUMN IF NOT EXISTS `last_error` TEXT NULL;
ALTER TABLE `food_ticket_events` ADD COLUMN IF NOT EXISTS `printer_name` VARCHAR(190) NULL;
ALTER TABLE `food_ticket_events` ADD COLUMN IF NOT EXISTS `source_payload` LONGTEXT NULL;
ALTER TABLE `food_ticket_events` ADD COLUMN IF NOT EXISTS `processed_at` DATETIME NULL;
ALTER TABLE `food_ticket_events` ADD COLUMN IF NOT EXISTS `next_retry_at` DATETIME NULL;
ALTER TABLE `food_ticket_events` ADD COLUMN IF NOT EXISTS `created_at` DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP;
ALTER TABLE `food_ticket_events` ADD COLUMN IF NOT EXISTS `updated_at` DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP;
ALTER TABLE `food_ticket_worker_status` ADD COLUMN IF NOT EXISTS `host_name` VARCHAR(190) NOT NULL DEFAULT '';
ALTER TABLE `food_ticket_worker_status` ADD COLUMN IF NOT EXISTS `process_id` INT UNSIGNED NOT NULL DEFAULT 0;
ALTER TABLE `food_ticket_worker_status` ADD COLUMN IF NOT EXISTS `last_seen` DATETIME NULL;
ALTER TABLE `food_ticket_worker_status` ADD COLUMN IF NOT EXISTS `status` ENUM('ok','warning','error') NOT NULL DEFAULT 'ok';
ALTER TABLE `food_ticket_worker_status` ADD COLUMN IF NOT EXISTS `last_message` TEXT NULL;
ALTER TABLE `food_ticket_worker_status` ADD COLUMN IF NOT EXISTS `last_error` TEXT NULL;
ALTER TABLE `food_ticket_worker_status` ADD COLUMN IF NOT EXISTS `processed_count` INT UNSIGNED NOT NULL DEFAULT 0;
ALTER TABLE `food_ticket_worker_status` ADD COLUMN IF NOT EXISTS `printed_count` INT UNSIGNED NOT NULL DEFAULT 0;
ALTER TABLE `food_ticket_worker_status` ADD COLUMN IF NOT EXISTS `error_count` INT UNSIGNED NOT NULL DEFAULT 0;
ALTER TABLE `food_ticket_worker_status` ADD COLUMN IF NOT EXISTS `updated_at` DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP;
ALTER TABLE `food_ticket_guest_cards` ADD COLUMN IF NOT EXISTS `card_uid` VARCHAR(120) NOT NULL;
ALTER TABLE `food_ticket_guest_cards` ADD COLUMN IF NOT EXISTS `guest_name` VARCHAR(190) NOT NULL DEFAULT 'مهمان';
ALTER TABLE `food_ticket_guest_cards` ADD COLUMN IF NOT EXISTS `daily_limit` SMALLINT UNSIGNED NOT NULL DEFAULT 0;
ALTER TABLE `food_ticket_guest_cards` ADD COLUMN IF NOT EXISTS `is_active` TINYINT(1) NOT NULL DEFAULT 1;
ALTER TABLE `food_ticket_guest_cards` ADD COLUMN IF NOT EXISTS `updated_by` INT UNSIGNED NULL;
ALTER TABLE `food_ticket_guest_cards` ADD COLUMN IF NOT EXISTS `created_at` DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP;
ALTER TABLE `food_ticket_guest_cards` ADD COLUMN IF NOT EXISTS `updated_at` DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP;
ALTER TABLE `food_ticket_groups` ADD COLUMN IF NOT EXISTS `title` VARCHAR(190) NOT NULL;
ALTER TABLE `food_ticket_groups` ADD COLUMN IF NOT EXISTS `l_uid` VARCHAR(80) NULL;
ALTER TABLE `food_ticket_groups` ADD COLUMN IF NOT EXISTS `rfid_card` VARCHAR(120) NULL;
ALTER TABLE `food_ticket_groups` ADD COLUMN IF NOT EXISTS `description` VARCHAR(500) NULL;
ALTER TABLE `food_ticket_groups` ADD COLUMN IF NOT EXISTS `status` ENUM('active','inactive') NOT NULL DEFAULT 'active';
ALTER TABLE `food_ticket_groups` ADD COLUMN IF NOT EXISTS `created_by` INT UNSIGNED NULL;
ALTER TABLE `food_ticket_groups` ADD COLUMN IF NOT EXISTS `created_at` DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP;
ALTER TABLE `food_ticket_groups` ADD COLUMN IF NOT EXISTS `updated_at` DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP;
ALTER TABLE `food_ticket_group_members` ADD COLUMN IF NOT EXISTS `group_id` INT UNSIGNED NOT NULL;
ALTER TABLE `food_ticket_group_members` ADD COLUMN IF NOT EXISTS `user_id` INT UNSIGNED NOT NULL;
ALTER TABLE `food_ticket_group_members` ADD COLUMN IF NOT EXISTS `created_at` DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP;
ALTER TABLE `food_ticket_group_runs` ADD COLUMN IF NOT EXISTS `group_id` INT UNSIGNED NULL;
ALTER TABLE `food_ticket_group_runs` ADD COLUMN IF NOT EXISTS `group_title` VARCHAR(190) NULL;
ALTER TABLE `food_ticket_group_runs` ADD COLUMN IF NOT EXISTS `rfid_card` VARCHAR(120) NOT NULL DEFAULT '';
ALTER TABLE `food_ticket_group_runs` ADD COLUMN IF NOT EXISTS `trigger_kind` ENUM('uid','card','legacy_card') NOT NULL DEFAULT 'card';
ALTER TABLE `food_ticket_group_runs` ADD COLUMN IF NOT EXISTS `trigger_uid` VARCHAR(80) NULL;
ALTER TABLE `food_ticket_group_runs` ADD COLUMN IF NOT EXISTS `source_key` CHAR(64) NOT NULL;
ALTER TABLE `food_ticket_group_runs` ADD COLUMN IF NOT EXISTS `punch_date` DATE NOT NULL;
ALTER TABLE `food_ticket_group_runs` ADD COLUMN IF NOT EXISTS `punch_time` TIME NULL;
ALTER TABLE `food_ticket_group_runs` ADD COLUMN IF NOT EXISTS `run_kind` ENUM('first','repeat','inactive') NOT NULL;
ALTER TABLE `food_ticket_group_runs` ADD COLUMN IF NOT EXISTS `status` ENUM('processing','done') NOT NULL DEFAULT 'done';
ALTER TABLE `food_ticket_group_runs` ADD COLUMN IF NOT EXISTS `members_total` INT UNSIGNED NOT NULL DEFAULT 0;
ALTER TABLE `food_ticket_group_runs` ADD COLUMN IF NOT EXISTS `printed_count` INT UNSIGNED NOT NULL DEFAULT 0;
ALTER TABLE `food_ticket_group_runs` ADD COLUMN IF NOT EXISTS `repeat_count` INT UNSIGNED NOT NULL DEFAULT 0;
ALTER TABLE `food_ticket_group_runs` ADD COLUMN IF NOT EXISTS `no_food_count` INT UNSIGNED NOT NULL DEFAULT 0;
ALTER TABLE `food_ticket_group_runs` ADD COLUMN IF NOT EXISTS `absent_count` INT UNSIGNED NOT NULL DEFAULT 0;
ALTER TABLE `food_ticket_group_runs` ADD COLUMN IF NOT EXISTS `skipped_count` INT UNSIGNED NOT NULL DEFAULT 0;
ALTER TABLE `food_ticket_group_runs` ADD COLUMN IF NOT EXISTS `error_count` INT UNSIGNED NOT NULL DEFAULT 0;
ALTER TABLE `food_ticket_group_runs` ADD COLUMN IF NOT EXISTS `created_at` DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP;
ALTER TABLE `food_ticket_group_runs` ADD COLUMN IF NOT EXISTS `updated_at` DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP;
ALTER TABLE `food_ticket_daily_absence` ADD COLUMN IF NOT EXISTS `absence_date` DATE NOT NULL;
ALTER TABLE `food_ticket_daily_absence` ADD COLUMN IF NOT EXISTS `group_id` INT UNSIGNED NULL;
ALTER TABLE `food_ticket_daily_absence` ADD COLUMN IF NOT EXISTS `user_id` INT UNSIGNED NOT NULL;
ALTER TABLE `food_ticket_daily_absence` ADD COLUMN IF NOT EXISTS `reason` VARCHAR(300) NULL;
ALTER TABLE `food_ticket_daily_absence` ADD COLUMN IF NOT EXISTS `created_by` INT UNSIGNED NULL;
ALTER TABLE `food_ticket_daily_absence` ADD COLUMN IF NOT EXISTS `created_at` DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP;
ALTER TABLE `food_ticket_daily_absence` ADD COLUMN IF NOT EXISTS `updated_at` DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP;
ALTER TABLE `food_ticket_group_uid_history` ADD COLUMN IF NOT EXISTS `uid` VARCHAR(80) NOT NULL;
ALTER TABLE `food_ticket_group_uid_history` ADD COLUMN IF NOT EXISTS `group_id` INT UNSIGNED NULL;
ALTER TABLE `food_ticket_group_uid_history` ADD COLUMN IF NOT EXISTS `action` ENUM('set','changed','removed') NOT NULL;
ALTER TABLE `food_ticket_group_uid_history` ADD COLUMN IF NOT EXISTS `actor_id` INT UNSIGNED NULL;
ALTER TABLE `food_ticket_group_uid_history` ADD COLUMN IF NOT EXISTS `created_at` DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP;
ALTER TABLE `food_ticket_print_log` ADD COLUMN IF NOT EXISTS `created_at` DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP;
ALTER TABLE `food_ticket_print_log` ADD COLUMN IF NOT EXISTS `event_id` BIGINT UNSIGNED NULL;
ALTER TABLE `food_ticket_print_log` ADD COLUMN IF NOT EXISTS `print_job_id` VARCHAR(64) NULL;
ALTER TABLE `food_ticket_print_log` ADD COLUMN IF NOT EXISTS `source_key` CHAR(64) NULL;
ALTER TABLE `food_ticket_print_log` ADD COLUMN IF NOT EXISTS `ticket_key` VARCHAR(190) NULL;
ALTER TABLE `food_ticket_print_log` ADD COLUMN IF NOT EXISTS `printer` VARCHAR(190) NULL;
ALTER TABLE `food_ticket_print_log` ADD COLUMN IF NOT EXISTS `status` VARCHAR(40) NOT NULL;
ALTER TABLE `food_ticket_print_log` ADD COLUMN IF NOT EXISTS `retry_count` INT NOT NULL DEFAULT 0;
ALTER TABLE `food_ticket_print_log` ADD COLUMN IF NOT EXISTS `message` VARCHAR(500) NULL;
ALTER TABLE `system_logs` ADD COLUMN IF NOT EXISTS `level` VARCHAR(20) NOT NULL DEFAULT 'error';
ALTER TABLE `system_logs` ADD COLUMN IF NOT EXISTS `context` VARCHAR(120) NULL;
ALTER TABLE `system_logs` ADD COLUMN IF NOT EXISTS `message` TEXT NULL;
ALTER TABLE `system_logs` ADD COLUMN IF NOT EXISTS `meta_json` JSON NULL;
ALTER TABLE `system_logs` ADD COLUMN IF NOT EXISTS `user_id` INT UNSIGNED NULL;
ALTER TABLE `system_logs` ADD COLUMN IF NOT EXISTS `request_uri` VARCHAR(255) NULL;
ALTER TABLE `system_logs` ADD COLUMN IF NOT EXISTS `created_at` DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP;
ALTER TABLE `chatbot_faq` ADD COLUMN IF NOT EXISTS `question` VARCHAR(255) NOT NULL;
ALTER TABLE `chatbot_faq` ADD COLUMN IF NOT EXISTS `answer` TEXT NOT NULL;
ALTER TABLE `chatbot_faq` ADD COLUMN IF NOT EXISTS `is_active` TINYINT(1) NOT NULL DEFAULT 1;
ALTER TABLE `chatbot_faq` ADD COLUMN IF NOT EXISTS `created_by` INT UNSIGNED NULL;
ALTER TABLE `chatbot_faq` ADD COLUMN IF NOT EXISTS `created_at` DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP;
ALTER TABLE `chatbot_faq` ADD COLUMN IF NOT EXISTS `updated_at` DATETIME NULL;
ALTER TABLE `chatbot_logs` ADD COLUMN IF NOT EXISTS `user_id` INT UNSIGNED NULL;
ALTER TABLE `chatbot_logs` ADD COLUMN IF NOT EXISTS `question` VARCHAR(500) NOT NULL;
ALTER TABLE `chatbot_logs` ADD COLUMN IF NOT EXISTS `faq_id` INT UNSIGNED NULL;
ALTER TABLE `chatbot_logs` ADD COLUMN IF NOT EXISTS `intent` VARCHAR(80) NULL;
ALTER TABLE `chatbot_logs` ADD COLUMN IF NOT EXISTS `score` DECIMAL(6,3) NOT NULL DEFAULT 0;
ALTER TABLE `chatbot_logs` ADD COLUMN IF NOT EXISTS `helpful` TINYINT(1) NULL;
ALTER TABLE `chatbot_logs` ADD COLUMN IF NOT EXISTS `created_at` DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP;
ALTER TABLE `system_incidents` ADD COLUMN IF NOT EXISTS `title` VARCHAR(255) NOT NULL;
ALTER TABLE `system_incidents` ADD COLUMN IF NOT EXISTS `status` ENUM('open','investigating','resolved') NOT NULL DEFAULT 'open';
ALTER TABLE `system_incidents` ADD COLUMN IF NOT EXISTS `note` TEXT NULL;
ALTER TABLE `system_incidents` ADD COLUMN IF NOT EXISTS `updated_by` INT UNSIGNED NULL;
ALTER TABLE `system_incidents` ADD COLUMN IF NOT EXISTS `updated_at` DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP;
ALTER TABLE `ticket_number_seq` ADD COLUMN IF NOT EXISTS `seq` INT UNSIGNED NOT NULL DEFAULT 0;
ALTER TABLE `api_rate_limits` ADD COLUMN IF NOT EXISTS `attempts` INT UNSIGNED NOT NULL DEFAULT 0;
ALTER TABLE `api_rate_limits` ADD COLUMN IF NOT EXISTS `window_started` DATETIME NOT NULL;
ALTER TABLE `api_rate_limits` ADD COLUMN IF NOT EXISTS `updated_at` DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP;
ALTER TABLE `domain_scan_runs` ADD COLUMN IF NOT EXISTS `started_by` INT UNSIGNED NULL;
ALTER TABLE `domain_scan_runs` ADD COLUMN IF NOT EXISTS `status` VARCHAR(20) NOT NULL DEFAULT 'running';
ALTER TABLE `domain_scan_runs` ADD COLUMN IF NOT EXISTS `total` INT NOT NULL DEFAULT 0;
ALTER TABLE `domain_scan_runs` ADD COLUMN IF NOT EXISTS `done` INT NOT NULL DEFAULT 0;
ALTER TABLE `domain_scan_runs` ADD COLUMN IF NOT EXISTS `online` INT NOT NULL DEFAULT 0;
ALTER TABLE `domain_scan_runs` ADD COLUMN IF NOT EXISTS `offline` INT NOT NULL DEFAULT 0;
ALTER TABLE `domain_scan_runs` ADD COLUMN IF NOT EXISTS `failed` INT NOT NULL DEFAULT 0;
ALTER TABLE `domain_scan_runs` ADD COLUMN IF NOT EXISTS `created_at` DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP;
ALTER TABLE `domain_scan_runs` ADD COLUMN IF NOT EXISTS `updated_at` DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP;
ALTER TABLE `domain_scan_queue` ADD COLUMN IF NOT EXISTS `run_id` INT UNSIGNED NOT NULL;
ALTER TABLE `domain_scan_queue` ADD COLUMN IF NOT EXISTS `asset_id` INT UNSIGNED NULL;
ALTER TABLE `domain_scan_queue` ADD COLUMN IF NOT EXISTS `hostname` VARCHAR(190) NOT NULL;
ALTER TABLE `domain_scan_queue` ADD COLUMN IF NOT EXISTS `status` VARCHAR(20) NOT NULL DEFAULT 'pending';
ALTER TABLE `domain_scan_queue` ADD COLUMN IF NOT EXISTS `online` TINYINT(1) NOT NULL DEFAULT 0;
ALTER TABLE `domain_scan_queue` ADD COLUMN IF NOT EXISTS `message` VARCHAR(255) NULL;
ALTER TABLE `domain_scan_queue` ADD COLUMN IF NOT EXISTS `created_at` DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP;
ALTER TABLE `domain_scan_queue` ADD COLUMN IF NOT EXISTS `updated_at` DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP;
ALTER TABLE `food_ticket_card_map` ADD COLUMN IF NOT EXISTS `user_id` INT UNSIGNED NOT NULL;
ALTER TABLE `food_ticket_card_map` ADD COLUMN IF NOT EXISTS `personnel_code` VARCHAR(100) NULL;
ALTER TABLE `food_ticket_card_map` ADD COLUMN IF NOT EXISTS `hits` INT NOT NULL DEFAULT 1;
ALTER TABLE `food_ticket_card_map` ADD COLUMN IF NOT EXISTS `created_at` DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP;
ALTER TABLE `food_ticket_card_map` ADD COLUMN IF NOT EXISTS `updated_at` DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP;
ALTER TABLE `food_ticket_templates` ADD COLUMN IF NOT EXISTS `name` VARCHAR(120) NOT NULL;
ALTER TABLE `food_ticket_templates` ADD COLUMN IF NOT EXISTS `paper_width` DECIMAL(6,1) NOT NULL DEFAULT 80.0;
ALTER TABLE `food_ticket_templates` ADD COLUMN IF NOT EXISTS `paper_height` DECIMAL(6,1) NOT NULL DEFAULT 0.0;
ALTER TABLE `food_ticket_templates` ADD COLUMN IF NOT EXISTS `template_json` LONGTEXT NOT NULL;
ALTER TABLE `food_ticket_templates` ADD COLUMN IF NOT EXISTS `is_active` TINYINT(1) NOT NULL DEFAULT 0;
ALTER TABLE `food_ticket_templates` ADD COLUMN IF NOT EXISTS `created_at` DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP;
ALTER TABLE `food_ticket_templates` ADD COLUMN IF NOT EXISTS `updated_at` DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP;
ALTER TABLE `food_catalog` ADD COLUMN IF NOT EXISTS `food_name` VARCHAR(190) NOT NULL;
ALTER TABLE `food_catalog` ADD COLUMN IF NOT EXISTS `category` VARCHAR(40) NULL;
ALTER TABLE `food_catalog` ADD COLUMN IF NOT EXISTS `active` TINYINT(1) NOT NULL DEFAULT 1;
ALTER TABLE `food_catalog` ADD COLUMN IF NOT EXISTS `created_by` INT UNSIGNED NULL;
ALTER TABLE `food_catalog` ADD COLUMN IF NOT EXISTS `created_at` DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP;
ALTER TABLE `food_catalog` ADD COLUMN IF NOT EXISTS `updated_at` DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP;
ALTER TABLE `food_guest_requests` ADD COLUMN IF NOT EXISTS `request_date` DATE NOT NULL;
ALTER TABLE `food_guest_requests` ADD COLUMN IF NOT EXISTS `organization` VARCHAR(190) NOT NULL;
ALTER TABLE `food_guest_requests` ADD COLUMN IF NOT EXISTS `guest_count` SMALLINT UNSIGNED NOT NULL;
ALTER TABLE `food_guest_requests` ADD COLUMN IF NOT EXISTS `food_id` INT UNSIGNED NULL;
ALTER TABLE `food_guest_requests` ADD COLUMN IF NOT EXISTS `requester_name` VARCHAR(150) NOT NULL;
ALTER TABLE `food_guest_requests` ADD COLUMN IF NOT EXISTS `deputy_unit_id` INT UNSIGNED NULL;
ALTER TABLE `food_guest_requests` ADD COLUMN IF NOT EXISTS `note` VARCHAR(500) NULL;
ALTER TABLE `food_guest_requests` ADD COLUMN IF NOT EXISTS `status` ENUM('active','cancelled') NOT NULL DEFAULT 'active';
ALTER TABLE `food_guest_requests` ADD COLUMN IF NOT EXISTS `created_by` INT UNSIGNED NULL;
ALTER TABLE `food_guest_requests` ADD COLUMN IF NOT EXISTS `created_at` DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP;
ALTER TABLE `food_guest_requests` ADD COLUMN IF NOT EXISTS `cancelled_by` INT UNSIGNED NULL;
ALTER TABLE `food_guest_requests` ADD COLUMN IF NOT EXISTS `cancelled_at` DATETIME NULL;
ALTER TABLE `food_calendar` ADD COLUMN IF NOT EXISTS `food_date` DATE NOT NULL;
ALTER TABLE `food_calendar` ADD COLUMN IF NOT EXISTS `order_status` ENUM('open','closed') NOT NULL DEFAULT 'open';
ALTER TABLE `food_calendar` ADD COLUMN IF NOT EXISTS `note` VARCHAR(255) NULL;
ALTER TABLE `food_calendar` ADD COLUMN IF NOT EXISTS `closed_by` INT UNSIGNED NULL;
ALTER TABLE `food_calendar` ADD COLUMN IF NOT EXISTS `closed_at` DATETIME NULL;
ALTER TABLE `food_calendar` ADD COLUMN IF NOT EXISTS `created_by` INT UNSIGNED NULL;
ALTER TABLE `food_calendar` ADD COLUMN IF NOT EXISTS `created_at` DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP;
ALTER TABLE `food_calendar` ADD COLUMN IF NOT EXISTS `updated_at` DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP;
ALTER TABLE `food_calendar_items` ADD COLUMN IF NOT EXISTS `calendar_id` INT UNSIGNED NOT NULL;
ALTER TABLE `food_calendar_items` ADD COLUMN IF NOT EXISTS `food_id` INT UNSIGNED NOT NULL;
ALTER TABLE `food_calendar_items` ADD COLUMN IF NOT EXISTS `sort_order` TINYINT UNSIGNED NOT NULL DEFAULT 0;
ALTER TABLE `food_calendar_items` ADD COLUMN IF NOT EXISTS `active` TINYINT(1) NOT NULL DEFAULT 1;
ALTER TABLE `food_calendar_items` ADD COLUMN IF NOT EXISTS `created_at` DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP;
ALTER TABLE `food_calendar_items` ADD COLUMN IF NOT EXISTS `updated_at` DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP;
ALTER TABLE `food_orders` ADD COLUMN IF NOT EXISTS `employee_id` INT UNSIGNED NOT NULL;
ALTER TABLE `food_orders` ADD COLUMN IF NOT EXISTS `calendar_item_id` INT UNSIGNED NOT NULL;
ALTER TABLE `food_orders` ADD COLUMN IF NOT EXISTS `food_date` DATE NOT NULL;
ALTER TABLE `food_orders` ADD COLUMN IF NOT EXISTS `created_by` INT UNSIGNED NOT NULL;
ALTER TABLE `food_orders` ADD COLUMN IF NOT EXISTS `status` ENUM('active','cancelled') NOT NULL DEFAULT 'active';
ALTER TABLE `food_orders` ADD COLUMN IF NOT EXISTS `created_at` DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP;
ALTER TABLE `food_orders` ADD COLUMN IF NOT EXISTS `updated_at` DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP;
ALTER TABLE `food_order_logs` ADD COLUMN IF NOT EXISTS `order_id` BIGINT UNSIGNED NULL;
ALTER TABLE `food_order_logs` ADD COLUMN IF NOT EXISTS `calendar_id` INT UNSIGNED NULL;
ALTER TABLE `food_order_logs` ADD COLUMN IF NOT EXISTS `action` VARCHAR(40) NOT NULL;
ALTER TABLE `food_order_logs` ADD COLUMN IF NOT EXISTS `user_id` INT UNSIGNED NULL;
ALTER TABLE `food_order_logs` ADD COLUMN IF NOT EXISTS `old_value` TEXT NULL;
ALTER TABLE `food_order_logs` ADD COLUMN IF NOT EXISTS `new_value` TEXT NULL;
ALTER TABLE `food_order_logs` ADD COLUMN IF NOT EXISTS `reason` VARCHAR(500) NULL;
ALTER TABLE `food_order_logs` ADD COLUMN IF NOT EXISTS `created_at` DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP;

-- ترددهای خاص: ستون کد ملی باید خالی بماند
ALTER TABLE traffic_visits MODIFY national_code VARCHAR(10) NULL;
