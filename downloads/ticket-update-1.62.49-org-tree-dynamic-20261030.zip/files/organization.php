<?php
declare(strict_types=1);

function org_ensure_schema(): void
{
    static $done = false;
    if ($done) {
        return;
    }
    $done = true;
    try {
    db()->exec(
        'CREATE TABLE IF NOT EXISTS org_units (
            id INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
            name VARCHAR(190) NOT NULL,
            code VARCHAR(60) NULL,
            parent_id INT UNSIGNED NULL,
            unit_type VARCHAR(20) NOT NULL DEFAULT "department",
            manager_user_id INT UNSIGNED NULL,
            is_primary_admin TINYINT(1) NOT NULL DEFAULT 0,
            is_active TINYINT(1) NOT NULL DEFAULT 1,
            created_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
            INDEX idx_org_parent (parent_id),
            INDEX idx_org_type (unit_type),
            INDEX idx_org_manager (manager_user_id)
        ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci'
    );
    db()->exec(
        'CREATE TABLE IF NOT EXISTS org_unit_managers (
            unit_id INT UNSIGNED NOT NULL,
            user_id INT UNSIGNED NOT NULL,
            is_primary TINYINT(1) NOT NULL DEFAULT 0,
            PRIMARY KEY (unit_id, user_id),
            INDEX idx_org_mgr_user (user_id)
        ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci'
    );
    foreach (['org_unit_id INT UNSIGNED NULL', 'manager_user_id INT UNSIGNED NULL'] as $column) {
        try {
            db()->exec('ALTER TABLE users ADD COLUMN IF NOT EXISTS ' . $column);
        } catch (Throwable $ignored) {
            try {
                db()->exec('ALTER TABLE users ADD COLUMN ' . $column);
            } catch (Throwable $alsoIgnored) {
            }
        }
    }
    // ۱.۶۲.۱۰: جایگاه نمایش واحدهای مستقل (نمایندگی) کنار مدیرعامل — right یا left.
    try {
        db()->exec('ALTER TABLE org_units ADD COLUMN IF NOT EXISTS chart_side VARCHAR(10) NULL');
    } catch (Throwable $ignored) {
        try {
            db()->exec('ALTER TABLE org_units ADD COLUMN chart_side VARCHAR(10) NULL');
        } catch (Throwable $alsoIgnored) {
        }
    }
    $hasCeo = (int) db()->query('SELECT COUNT(*) FROM org_units WHERE unit_type = "ceo"')->fetchColumn();
    if ($hasCeo === 0) {
        db()->prepare('INSERT INTO org_units (name, code, parent_id, unit_type, is_active) VALUES (?, ?, NULL, "ceo", 1)')
            ->execute(['مدیرعامل', 'CEO']);
    }
    } catch (Throwable $exception) {
        if (function_exists('system_log')) {
            system_log('error', 'org_schema', $exception->getMessage());
        }
    }
}


/**
 * ستون مستقل «معاونت درخواست‌کننده» روی درخواست‌ها (جدا از department_id که مسیر رسیدگی است).
 */
function org_ticket_schema_ensure(): void
{
    static $done = false;
    if ($done) {
        return;
    }
    $done = true;
    try {
        $columns = db()->query("SELECT COLUMN_NAME FROM information_schema.COLUMNS WHERE TABLE_SCHEMA = DATABASE() AND TABLE_NAME = 'tickets'")->fetchAll(PDO::FETCH_COLUMN);
        if (!in_array('requesting_unit_id', array_map('strtolower', $columns), true)) {
            db()->exec('ALTER TABLE tickets ADD COLUMN requesting_unit_id INT UNSIGNED NULL');
            db()->exec('ALTER TABLE tickets ADD INDEX idx_tickets_requesting_unit (requesting_unit_id)');
        }
    } catch (Throwable $exception) {
        if (function_exists('system_log')) {
            system_log('error', 'org_ticket_schema', $exception->getMessage());
        }
    }
}

function org_has_sort_order(): bool
{
    static $available = null;
    if ($available !== null) {
        return $available;
    }
    try {
        $stmt = db()->query("SELECT COUNT(*) FROM information_schema.COLUMNS WHERE TABLE_SCHEMA = DATABASE() AND TABLE_NAME = 'org_units' AND COLUMN_NAME = 'sort_order'");
        $available = (int) $stmt->fetchColumn() > 0;
    } catch (Throwable $ignored) {
        $available = false;
    }
    return $available;
}

function org_next_sort_order(int $parentId): int
{
    if ($parentId <= 0 || !org_has_sort_order()) {
        return 0;
    }
    $query = db()->prepare('SELECT COALESCE(MAX(sort_order), 0) + 10 FROM org_units WHERE parent_id = ? AND is_active = 1');
    $query->execute([$parentId]);
    return (int) $query->fetchColumn();
}

function org_units_all(bool $activeOnly = true): array
{
    $sql = 'SELECT ou.*, m.full_name AS manager_name FROM org_units ou LEFT JOIN users m ON m.id = ou.manager_user_id';
    if ($activeOnly) {
        $sql .= ' WHERE ou.is_active = 1';
    }
    $sql .= org_has_sort_order() ? ' ORDER BY ou.unit_type, COALESCE(ou.sort_order, 0), ou.name, ou.id' : ' ORDER BY ou.unit_type, ou.name, ou.id';
    return db()->query($sql)->fetchAll();
}

/**
 * معاونت‌های فعال چارت سازمانی برای فهرست «معاونت درخواست‌کننده» در فرم درخواست.
 * همهٔ نقش‌ها این فهرست را می‌بینند تا درخواست به همان معاونت مسیردهی شود.
 */
function org_deputy_units(): array
{
    static $cache = null;
    if ($cache !== null) {
        return $cache;
    }
    org_ensure_schema();
    $query = db()->query(
        'SELECT ou.id, ou.name, ou.code, ou.parent_id, m.full_name AS manager_name
         FROM org_units ou
         LEFT JOIN users m ON m.id = ou.manager_user_id
         WHERE ou.is_active = 1 AND ou.unit_type = "deputy"
         ORDER BY ou.name'
    );
    return $cache = $query->fetchAll();
}

/**
 * ۱.۶۲.۱۰ — واحدهای مستقل (نمایندگی) کنار مدیرعامل: unit_type = 'liaison'، بدون والد
 * و بدون هیچ اتصالی به زیرمجموعه‌های مدیرعامل. هر سمت (right/left) حداکثر یک واحد فعال دارد.
 *
 * @return array<string,array> کلید = سمت ('right'|'left')
 */
function org_liaison_units(): array
{
    org_ensure_schema();
    $result = [];
    try {
        $rows = db()->query(
            'SELECT ou.*, m.full_name AS manager_name FROM org_units ou
             LEFT JOIN users m ON m.id = ou.manager_user_id
             WHERE ou.is_active = 1 AND ou.unit_type = "liaison" ORDER BY ou.id'
        )->fetchAll();
        foreach ($rows as $row) {
            $side = (string) ($row['chart_side'] ?? '');
            if (in_array($side, ['right', 'left'], true) && !isset($result[$side])) {
                $result[$side] = $row;
            }
        }
    } catch (Throwable $ignored) {
    }
    return $result;
}

/**
 * تبدیل معاونت سازمانی انتخاب‌شده به معاونتِ مسیر رسیدگی (departments).
 * اگر department هم‌نام وجود داشته باشد همان برگردانده می‌شود، در غیر این صورت ساخته می‌شود.
 */
function org_unit_routing_department_id(int $unitId): int
{
    if ($unitId <= 0) {
        return 0;
    }
    $unit = org_unit_by_id($unitId);
    if ($unit === null || (string) ($unit['unit_type'] ?? '') !== 'deputy') {
        return 0;
    }
    $name = trim((string) $unit['name']);
    if ($name === '') {
        return 0;
    }
    $find = db()->prepare('SELECT id FROM departments WHERE name = ? LIMIT 1');
    $find->execute([$name]);
    $found = $find->fetchColumn();
    if ($found !== false) {
        return (int) $found;
    }
    $code = trim((string) ($unit['code'] ?? ''));
    try {
        $insert = db()->prepare('INSERT INTO departments (name, code, is_active) VALUES (?, ?, 1)');
        $insert->execute([$name, $code !== '' ? $code : null]);
        return (int) db()->lastInsertId();
    } catch (Throwable $exception) {
        $retry = db()->prepare('SELECT id FROM departments WHERE name = ? LIMIT 1');
        $retry->execute([$name]);
        return (int) ($retry->fetchColumn() ?: 0);
    }
}

function org_ceo_unit_id(): int
{
    $id = (int) db()->query('SELECT id FROM org_units WHERE unit_type = "ceo" ORDER BY id LIMIT 1')->fetchColumn();
    if ($id > 0) {
        return $id;
    }
    db()->prepare('INSERT INTO org_units (name, code, parent_id, unit_type, is_active) VALUES (?, ?, NULL, "ceo", 1)')->execute(['مدیرعامل', 'CEO']);
    return (int) db()->lastInsertId();
}

/** واحدهایی که می‌توان کارشناس مستقیم به آن‌ها وصل کرد: اداره یا معاونت. */
function org_unit_accepts_experts(?array $unit): bool
{
    if ($unit === null) {
        return false;
    }
    $type = (string) ($unit['unit_type'] ?? '');
    return in_array($type, ['department', 'deputy'], true) && (int) ($unit['is_active'] ?? 0) === 1;
}

function org_unit_by_id(int $id): ?array
{
    $query = db()->prepare('SELECT * FROM org_units WHERE id = ? LIMIT 1');
    $query->execute([$id]);
    $unit = $query->fetch();
    return $unit ?: null;
}

function org_unit_children(int $parentId): array
{
    $order = org_has_sort_order() ? 'COALESCE(sort_order, 0), name, id' : 'name, id';
    $query = db()->prepare('SELECT * FROM org_units WHERE parent_id = ? AND is_active = 1 ORDER BY ' . $order);
    $query->execute([$parentId]);
    return $query->fetchAll();
}

function org_unit_subtree_ids(int $rootId): array
{
    $ids = [$rootId];
    $stack = [$rootId];
    while ($stack) {
        $current = array_pop($stack);
        foreach (org_unit_children((int) $current) as $child) {
            $childId = (int) $child['id'];
            if (!in_array($childId, $ids, true)) {
                $ids[] = $childId;
                $stack[] = $childId;
            }
        }
    }
    return $ids;
}

function org_unit_path_names(int $unitId): string
{
    $names = [];
    $guard = 0;
    while ($unitId > 0 && $guard < 50) {
        $guard++;
        $unit = org_unit_by_id($unitId);
        if (!$unit) {
            break;
        }
        array_unshift($names, (string) $unit['name']);
        $unitId = (int) ($unit['parent_id'] ?? 0);
    }
    return implode(' / ', $names);
}

function org_unit_manager_ids(int $unitId): array
{
    $query = db()->prepare('SELECT user_id FROM org_unit_managers WHERE unit_id = ? ORDER BY is_primary DESC, user_id');
    $query->execute([$unitId]);
    return array_map('intval', $query->fetchAll(PDO::FETCH_COLUMN));
}

function org_unit_is_primary_admin(int $unitId): bool
{
    $unit = org_unit_by_id($unitId);
    return $unit !== null && (int) $unit['is_primary_admin'] === 1;
}

function user_org_unit_id(array $user): int
{
    return (int) ($user['org_unit_id'] ?? 0);
}

function user_is_unit_manager(array $user): bool
{
    $query = db()->prepare('SELECT COUNT(*) FROM org_unit_managers WHERE user_id = ?');
    $query->execute([(int) ($user['id'] ?? 0)]);
    return (int) $query->fetchColumn() > 0;
}

function user_managed_unit_ids(array $user): array
{
    static $cache = [];
    $userId = (int) ($user['id'] ?? 0);
    if ($userId <= 0) {
        return [];
    }
    if (isset($cache[$userId])) {
        return $cache[$userId];
    }
    if ((int) ($user['is_primary_admin'] ?? 0) === 1) {
        return $cache[$userId] = array_map('intval', db()->query('SELECT id FROM org_units WHERE is_active = 1')->fetchAll(PDO::FETCH_COLUMN));
    }
    $query = db()->prepare('SELECT unit_id FROM org_unit_managers WHERE user_id = ?');
    $query->execute([$userId]);
    return $cache[$userId] = array_map('intval', $query->fetchAll(PDO::FETCH_COLUMN));
}

function user_org_scope_unit_ids(array $user): array
{
    $scope = [];
    foreach (user_managed_unit_ids($user) as $unitId) {
        foreach (org_unit_subtree_ids((int) $unitId) as $childId) {
            $scope[$childId] = $childId;
        }
    }
    return array_values($scope);
}

function user_is_org_manager_of(array $user, int $targetUserId): bool
{
    $query = db()->prepare('SELECT org_unit_id FROM users WHERE id = ? LIMIT 1');
    $query->execute([$targetUserId]);
    $targetUnit = (int) $query->fetchColumn();
    return $targetUnit > 0 && in_array($targetUnit, user_org_scope_unit_ids($user), true);
}

function user_can_manage_organization(array $user): bool
{
    if ((int) ($user['is_primary_admin'] ?? 0) === 1) {
        return true;
    }
    return function_exists('is_admin_role') ? is_admin_role((string) ($user['role'] ?? '')) : (string) ($user['role'] ?? '') === 'admin';
}

function org_snapshot(): array
{
    $sortField = org_has_sort_order() ? ', sort_order' : '';
    return [
        'units' => db()->query('SELECT id, name, code, parent_id, unit_type, chart_side, manager_user_id, is_primary_admin, is_active' . $sortField . ' FROM org_units ORDER BY id')->fetchAll(),
        'unit_managers' => db()->query('SELECT unit_id, user_id, is_primary FROM org_unit_managers ORDER BY unit_id, user_id')->fetchAll(),
        // Undo فقط انتساب سازمانی را برمی‌گرداند؛ role، ادمین اصلی و وضعیت فعال کاربر عمداً خارج‌اند.
        'users' => db()->query('SELECT id, org_unit_id, manager_user_id FROM users ORDER BY id')->fetchAll(),
        'has_sort_order' => org_has_sort_order(),
    ];
}

function org_snapshot_maps(array $snapshot): array
{
    $maps = ['units' => [], 'unit_managers' => [], 'users' => []];
    foreach ((array) ($snapshot['units'] ?? []) as $row) $maps['units'][(int) $row['id']] = $row;
    foreach ((array) ($snapshot['unit_managers'] ?? []) as $row) $maps['unit_managers'][(int) $row['unit_id'] . ':' . (int) $row['user_id']] = $row;
    foreach ((array) ($snapshot['users'] ?? []) as $row) $maps['users'][(int) $row['id']] = $row;
    return $maps;
}

function org_snapshot_row_signature(string $table, ?array $row): string
{
    if ($row === null) return 'null';
    if ($table === 'units') {
        $keys = ['id', 'name', 'code', 'parent_id', 'unit_type', 'chart_side', 'manager_user_id', 'is_primary_admin', 'is_active'];
        if (array_key_exists('sort_order', $row)) $keys[] = 'sort_order';
        $value = [];
        foreach ($keys as $key) {
            $raw = $row[$key] ?? null;
            $value[$key] = in_array($key, ['id', 'parent_id', 'manager_user_id', 'is_primary_admin', 'is_active', 'sort_order'], true)
                ? ($raw === null || $raw === '' ? null : (int) $raw)
                : ($raw === null || $raw === '' ? null : (string) $raw);
        }
    } elseif ($table === 'unit_managers') {
        $value = ['unit_id' => (int) $row['unit_id'], 'user_id' => (int) $row['user_id'], 'is_primary' => (int) $row['is_primary']];
    } else {
        $value = ['id' => (int) $row['id']];
        foreach (['org_unit_id', 'manager_user_id'] as $key) $value[$key] = ($row[$key] ?? null) === null || ($row[$key] ?? '') === '' ? null : (int) $row[$key];
    }
    return serialize($value);
}

function org_snapshot_delta(array $before, array $after): array
{
    $beforeMaps = org_snapshot_maps($before);
    $afterMaps = org_snapshot_maps($after);
    $beforeDelta = ['units' => [], 'unit_managers' => [], 'users' => [], 'has_sort_order' => !empty($before['has_sort_order'])];
    $afterDelta = ['units' => [], 'unit_managers' => [], 'users' => [], 'has_sort_order' => !empty($after['has_sort_order'])];
    foreach (['units', 'unit_managers', 'users'] as $table) {
        $keys = array_unique(array_merge(array_keys($beforeMaps[$table]), array_keys($afterMaps[$table])));
        foreach ($keys as $key) {
            $old = $beforeMaps[$table][$key] ?? null;
            $new = $afterMaps[$table][$key] ?? null;
            if (org_snapshot_row_signature($table, $old) === org_snapshot_row_signature($table, $new)) continue;
            $beforeDelta[$table][$key] = $old;
            $afterDelta[$table][$key] = $new;
        }
    }
    return [$beforeDelta, $afterDelta];
}

function org_record_undo(string $label, array $snapshot): void
{
    [$before, $after] = org_snapshot_delta($snapshot, org_snapshot());
    $_SESSION['org_undo'] = [
        'label' => $label,
        'before' => $before,
        'after' => $after,
        'created_at' => time(),
        'can_undo' => true,
        'can_redo' => false,
    ];
}

function org_undo_state(): ?array
{
    $state = $_SESSION['org_undo'] ?? null;
    return is_array($state) && is_array($state['before'] ?? null) && is_array($state['after'] ?? null) ? $state : null;
}

/**
 * بازگردانی delta ساختاریِ یک عملیات؛ از بازنویسی تغییرات دیگر کاربران/ماژول‌ها جلوگیری می‌کند.
 * expected مقادیر مورد انتظار وضعیت فعلی است تا اگر همان رکورد بعداً تغییر کرده، Undo متوقف شود.
 */
function org_restore_snapshot(array $target, array $expected): void
{
    $pdo = db();
    $pdo->beginTransaction();
    try {
        foreach ((array) ($target['units'] ?? []) as $key => $targetRow) {
            $id = (int) $key;
            $expectedRow = $expected['units'][$key] ?? null;
            $lockUnit = $pdo->prepare('SELECT * FROM org_units WHERE id = ? LIMIT 1 FOR UPDATE');
            $lockUnit->execute([$id]);
            $current = $lockUnit->fetch() ?: null;
            if ($expectedRow === null) {
                $tombstone = $targetRow;
                if (is_array($tombstone)) { $tombstone['is_active'] = 0; $tombstone['manager_user_id'] = null; }
                if ($current !== null && (!is_array($tombstone) || org_snapshot_row_signature('units', $current) !== org_snapshot_row_signature('units', $tombstone))) throw new RuntimeException('این واحد پس از عملیات تغییر کرده است؛ برای جلوگیری از بازنویسی، Undo/Redo متوقف شد.');
            } elseif ($current === null || org_snapshot_row_signature('units', $current) !== org_snapshot_row_signature('units', $expectedRow)) {
                throw new RuntimeException('یکی از واحدها پس از عملیات تغییر کرده است؛ برای جلوگیری از بازنویسی، Undo/Redo متوقف شد.');
            }
        }
        foreach ((array) ($target['unit_managers'] ?? []) as $key => $targetRow) {
            [$unitId, $userId] = array_map('intval', explode(':', (string) $key, 2));
            $query = $pdo->prepare('SELECT unit_id, user_id, is_primary FROM org_unit_managers WHERE unit_id = ? AND user_id = ? LIMIT 1 FOR UPDATE');
            $query->execute([$unitId, $userId]); $current = $query->fetch() ?: null;
            $expectedRow = $expected['unit_managers'][$key] ?? null;
            if (org_snapshot_row_signature('unit_managers', $current) !== org_snapshot_row_signature('unit_managers', $expectedRow)) throw new RuntimeException('انتصاب یکی از مدیران پس از عملیات تغییر کرده است؛ Undo/Redo متوقف شد.');
        }
        foreach ((array) ($target['users'] ?? []) as $key => $targetRow) {
            $id = (int) $key;
            $query = $pdo->prepare('SELECT id, org_unit_id, manager_user_id FROM users WHERE id = ? LIMIT 1 FOR UPDATE');
            $query->execute([$id]); $current = $query->fetch() ?: null;
            $expectedRow = $expected['users'][$key] ?? null;
            if (org_snapshot_row_signature('users', $current) !== org_snapshot_row_signature('users', $expectedRow)) throw new RuntimeException('انتساب سازمانی یکی از کاربران پس از عملیات تغییر کرده است؛ Undo/Redo متوقف شد.');
        }

        $hasSort = org_has_sort_order();
        foreach ((array) ($target['units'] ?? []) as $key => $row) {
            $id = (int) $key;
            if ($row === null) {
                // رکورد جدید حذف فیزیکی نمی‌شود؛ برای حفظ تاریخچه فقط بایگانی می‌شود.
                $pdo->prepare('UPDATE org_units SET is_active = 0, manager_user_id = NULL WHERE id = ?')->execute([$id]);
                continue;
            }
            $sortSet = $hasSort && !empty($target['has_sort_order']) ? ', sort_order = ?' : '';
            $sql = 'UPDATE org_units SET name = ?, code = ?, parent_id = ?, unit_type = ?, chart_side = ?, manager_user_id = ?, is_primary_admin = ?, is_active = ?' . $sortSet . ' WHERE id = ?';
            $values = [(string) $row['name'], ($row['code'] ?? null) !== '' ? $row['code'] : null, (int) ($row['parent_id'] ?? 0) > 0 ? (int) $row['parent_id'] : null, (string) $row['unit_type'], ($row['chart_side'] ?? null) !== '' ? ($row['chart_side'] ?? null) : null, (int) ($row['manager_user_id'] ?? 0) > 0 ? (int) $row['manager_user_id'] : null, (int) $row['is_primary_admin'], (int) $row['is_active']];
            if ($sortSet !== '') $values[] = (int) ($row['sort_order'] ?? 0);
            $values[] = $id;
            $pdo->prepare($sql)->execute($values);
        }
        foreach ((array) ($target['unit_managers'] ?? []) as $key => $row) {
            [$unitId, $userId] = array_map('intval', explode(':', (string) $key, 2));
            $pdo->prepare('DELETE FROM org_unit_managers WHERE unit_id = ? AND user_id = ?')->execute([$unitId, $userId]);
            if ($row !== null) $pdo->prepare('INSERT INTO org_unit_managers (unit_id, user_id, is_primary) VALUES (?, ?, ?)')->execute([$unitId, $userId, (int) $row['is_primary']]);
        }
        foreach ((array) ($target['users'] ?? []) as $key => $row) {
            if ($row === null) continue;
            $pdo->prepare('UPDATE users SET org_unit_id = ?, manager_user_id = ? WHERE id = ?')->execute([(int) ($row['org_unit_id'] ?? 0) > 0 ? (int) $row['org_unit_id'] : null, (int) ($row['manager_user_id'] ?? 0) > 0 ? (int) $row['manager_user_id'] : null, (int) $key]);
        }
        $pdo->commit();
    } catch (Throwable $exception) {
        if ($pdo->inTransaction()) $pdo->rollBack();
        throw $exception;
    }
}

/**
 * ۱.۳۷.۸ — نقش خودکار بر اساس سمت در چارت سازمانی.
 * هر کاربری که مدیر (یا عضو مدیریت) یک معاونت/مدیریت/واحد فعال باشد، اگر نقشش «کاربر» یا «کارشناس» باشد
 * به «مدیر» تبدیل می‌شود. وقتی سمت برداشته شود و نقش را همین سازوکار تغییر داده باشد، به نقش قبلی برمی‌گردد.
 * نقش‌های استثنا (بازرسی، سوپروایزر، مدیر پشتیبانی، ادمین اصلی) هرگز توسط این سازوکار تغییر نمی‌کنند.
 */
function org_position_unit_types(): array
{
    return ['ceo', 'deputy', 'department'];
}

function org_exempt_roles(): array
{
    return ['supervisor', 'support_manager', 'inspector', 'primary_admin'];
}

function org_ensure_role_sync_columns(): void
{
    static $done = false;
    if ($done) {
        return;
    }
    $done = true;
    $columns = ['org_auto_role TINYINT(1) NOT NULL DEFAULT 0', 'org_prev_role VARCHAR(20) NULL'];
    foreach ($columns as $column) {
        try {
            db()->exec('ALTER TABLE users ADD COLUMN IF NOT EXISTS ' . $column);
        } catch (Throwable $ignored) {
            try {
                db()->exec('ALTER TABLE users ADD COLUMN ' . $column);
            } catch (Throwable $alsoIgnored) {
            }
        }
    }
}

/** @return int[] شناسهٔ کاربرانی که در حال حاضر سمت مدیریتی فعال دارند. */
function org_position_user_ids(): array
{
    $types = "'" . implode("','", org_position_unit_types()) . "'";
    $ids = [];
    foreach (db()->query("SELECT manager_user_id FROM org_units WHERE is_active = 1 AND manager_user_id > 0 AND unit_type IN ($types)")->fetchAll(PDO::FETCH_COLUMN) as $id) {
        $ids[] = (int) $id;
    }
    try {
        $rows = db()->query("SELECT m.user_id FROM org_unit_managers m JOIN org_units u ON u.id = m.unit_id WHERE u.is_active = 1 AND u.unit_type IN ($types)")->fetchAll(PDO::FETCH_COLUMN);
        foreach ($rows as $id) {
            $ids[] = (int) $id;
        }
    } catch (Throwable $ignored) {
    }
    return array_values(array_unique(array_filter($ids, static fn (int $v): bool => $v > 0)));
}

/** همگام‌سازی نقش مدیر با سمت‌های چارت سازمانی. */
function org_sync_position_roles(): void
{
    if (db()->inTransaction()) {
        return;
    }
    org_ensure_schema();
    org_ensure_role_sync_columns();
    $positions = org_position_user_ids();
    $exempt = "'" . implode("','", org_exempt_roles()) . "'";
    $placeholders = $positions ? implode(',', array_fill(0, count($positions), '?')) : '';

    // ۱) ارتقا: کاربر/کارشناس با سمت مدیریتی → مدیر
    if ($positions) {
        $promote = db()->prepare("UPDATE users SET org_prev_role = role, org_auto_role = 1, role = 'manager' WHERE id IN ($placeholders) AND role IN ('user','agent') AND role NOT IN ($exempt)");
        $promote->execute($positions);
    }

    // ۲) بازگردانی: کسانی که همین سازوکار مدیر کرده و دیگر سمت ندارند
    $sql = "SELECT id, org_prev_role FROM users WHERE org_auto_role = 1 AND role = 'manager'";
    if ($positions) {
        $sql .= " AND id NOT IN ($placeholders)";
    }
    $stmt = db()->prepare($sql);
    $stmt->execute($positions);
    foreach ($stmt->fetchAll(PDO::FETCH_ASSOC) as $row) {
        $previous = in_array((string) $row['org_prev_role'], ['user', 'agent'], true) ? (string) $row['org_prev_role'] : 'user';
        db()->prepare('UPDATE users SET role = ?, org_auto_role = 0, org_prev_role = NULL WHERE id = ?')->execute([$previous, (int) $row['id']]);
    }
}
