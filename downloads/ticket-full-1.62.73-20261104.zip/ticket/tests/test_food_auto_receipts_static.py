from __future__ import annotations

import unittest
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]


def read(path: str) -> str:
    return (ROOT / path).read_text(encoding="utf-8")


class FoodAutoReceiptStaticTests(unittest.TestCase):
    def test_helper_creates_idempotent_logical_events_without_print_queue(self) -> None:
        helper = read("food-ticket-auto-receipts.php")
        self.assertIn("'physical_print' => false", helper)
        self.assertIn("event_type, print_status, last_error", helper)
        self.assertIn(r"VALUES (?, ?, NULL, ?, NULL, ?, ?, ?, ?, ?, NULL, ?, \'printed\'", helper)
        self.assertIn("INSERT INTO food_ticket_events", helper)
        self.assertIn("hash('sha256', 'auto-food-receipt|'", helper)
        self.assertIn("hash('sha256', 'auto-guest-receipt|'", helper)
        self.assertIn("SELECT id FROM food_ticket_events WHERE source_key = ?", helper)
        self.assertIn(r"event_type IN (\'printed\', \'print\', \'guest\')", helper)
        self.assertIn(r"o.status = \'active\'", helper)
        self.assertIn(r"r.status = \'active\'", helper)
        self.assertIn("r.created_by IS NOT NULL", helper)
        self.assertIn("$mealType === 'lunch' && empty($holiday['holiday'])", helper)
        self.assertIn("isset($absentUserIds[$userId])", helper)
        self.assertNotIn("food_ticket_enqueue_print", helper)

    def test_worker_catches_up_after_midnight_tehran_and_retries_failures(self) -> None:
        worker = read("cron/food_ticket_worker.php")
        self.assertIn("new DateTimeImmutable('now', new DateTimeZone('Asia/Tehran'))", worker)
        self.assertIn("$tehranNow->modify('-1 day')", worker)
        self.assertIn("$lastAutoReceiptRunDay !== $tehranDay", worker)
        self.assertIn("(time() - $lastAutoReceiptAttemptAt) >= 60", worker)
        self.assertIn("food_ticket_auto_receipts_run($autoTargetDate)", worker)

    def test_migration_and_fresh_schema_support_two_meals_and_auto_event_types(self) -> None:
        migration = read("migrations/021-food-auto-receipts.sql")
        self.assertIn("information_schema.COLUMNS", migration)
        self.assertIn("ADD COLUMN meal_type ENUM(''lunch'',''dinner'') NOT NULL DEFAULT ''lunch''", migration)
        self.assertIn("auto_printed'',''auto_guest", migration)
        for path in ("schema.sql", "install-empty-db.sql"):
            schema = read(path)
            self.assertIn("event_type ENUM('printed','print','print_error','no_food','unknown','inactive','repeat','guest','auto_printed','auto_guest'", schema)
            self.assertIn("meal_type ENUM('lunch','dinner') NOT NULL DEFAULT 'lunch'", schema)
            self.assertIn("CREATE TABLE IF NOT EXISTS food_guest_requests", schema)

    def test_reports_keep_lunch_reconciliation_and_physical_delivery_separate(self) -> None:
        ticket = read("food-ticket.php")
        order = read("food-order.php")
        aggregate = ticket[ticket.index("function food_ticket_api_aggregate_report("):ticket.index("function food_ticket_aggregate_columns(")]
        self.assertIn("'printed_final'", aggregate)
        self.assertIn("'physical_printed_lunch'", aggregate)
        self.assertIn("'auto_printed_lunch'", aggregate)
        self.assertIn("$expected = $counts['lunch_orders'] - $counts['printed_final']", aggregate)
        self.assertIn("'auto_guest_printed_dinner'", aggregate)

        delivery_start = order.index("function food_order_printed_delivery_report(")
        delivery_end = order.index("function food_order_export_printed_delivery_report(", delivery_start)
        delivery = order[delivery_start:delivery_end]
        primary_query = delivery[delivery.index("FROM food_ticket_events e"):delivery.index("$stmt->execute([$from, $to]);")]
        self.assertIn("e.event_type IN ('printed','print')", primary_query)
        self.assertIn("OR e.event_type = 'guest'", primary_query)
        self.assertNotIn("auto_printed", primary_query)
        self.assertNotIn("auto_guest", primary_query)
        self.assertIn("'auto_receipt_counts' => $autoReceiptCounts", delivery)

    def test_report_dashboard_permissions_and_frontend_are_aligned(self) -> None:
        ticket = read("food-ticket.php")
        report_data = ticket[ticket.index("if ($_SERVER['REQUEST_METHOD'] === 'GET' && in_array($route, ['dashboard-data', 'report-data']"):ticket.index("if ($_SERVER['REQUEST_METHOD'] === 'GET' && $route === 'monitoring'")]
        self.assertIn("food_order_report_rows_range($from, $to)", report_data)
        self.assertIn("'order_summaries' => ['lunch' => $lunchSummary, 'dinner' => $dinnerSummary]", report_data)
        fallback = ticket[ticket.index("if (!function_exists('user_can'))"):ticket.index("if (in_array($route, ['login', 'sso-login'], true)")]
        for route in ("report-data", "guest-requests-report", "dashboard-data"):
            self.assertIn("'" + route + "'", fallback)

        panel = read("food-ticket-web/index.html")
        manager = read("assets/food-menu.js")
        self.assertEqual(manager, read("food-ticket-web/assets/food-menu.js"))
        self.assertIn("PANEL_VERSION='1.37.52'", panel)
        self.assertIn("food-menu.js?v=1.62.73", panel)
        self.assertIn("بدون چاپ فیزیکی", panel)
        self.assertIn("auto_receipt_counts", manager)
        self.assertIn("ثبت خودکارِ بدون چاپ فیزیکی", manager)


if __name__ == "__main__":
    unittest.main(verbosity=2)
