<?php
declare(strict_types=1);

/**
 * Role permissions with additive public access-group grants.
 *
 * Roles are stored in users.role (existing enum + new values added by upgrade-1.22).
 * Permissions per role are stored in role_permissions; optional user access groups
 * add grants through user_access_group_members / user_access_group_permissions.
 * A group grant never removes or replaces a role grant. primary_admin is implicit-full.
 */

function permission_roles(): array
{
    return [
        'primary_admin' => 'ادمین اصلی',
        'supervisor' => 'سوپروایز',
        'support_manager' => 'مدیر پشتیبانی',
        'inspector' => 'بازرسی',
        'manager' => 'مدیر',
        'agent' => 'کارشناس',
        'user' => 'کاربر',
        'local_user' => 'کاربر محلی',
        'guard' => 'بازرسی',
    ];
}

/**
 * Full catalog grouped by area: group label => [permission => label].
 */
function permission_catalog(): array
{
    return [
        [
            'key' => 'base',
            'label' => 'داشبورد و پایه',
            'items' => [
                ['code' => 'dash.view', 'label' => 'مشاهدهٔ داشبورد'],
                ['code' => 'search.global', 'label' => 'جست‌وجوی سراسری'],
                ['code' => 'notif.view', 'label' => 'اعلان‌های من'],
                ['code' => 'profile.edit', 'label' => 'ویرایش پروفایل خودم'],
                ['code' => 'chatbot.use', 'label' => 'استفاده از بات پاسخ‌گو'],
            ],
        ],
        [
            'key' => 'ticket',
            'label' => 'درخواست',
            'items' => [
                ['code' => 'ticket.create', 'label' => 'ثبت درخواست جدید'],
                ['code' => 'ticket.view_own', 'label' => 'مشاهدهٔ درخواست‌های خودم'],
                ['code' => 'ticket.view_unit', 'label' => 'مشاهدهٔ درخواست‌های واحد/زیرمجموعه'],
                ['code' => 'ticket.view_all', 'label' => 'مشاهدهٔ همهٔ درخواست‌ها'],
                ['code' => 'ticket.reply', 'label' => 'پاسخ/مکالمه در درخواست'],
                ['code' => 'ticket.edit', 'label' => 'ویرایش'],
                ['code' => 'ticket.assign', 'label' => 'ارجاع درخواست به کارشناس'],
                ['code' => 'ticket.bulk', 'label' => 'ویرایش'],
                ['code' => 'ticket.rate', 'label' => 'امتیازدهی به درخواست'],
                ['code' => 'ticket.attach_asset', 'label' => 'اتصال دارایی به درخواست'],
                ['code' => 'queue.view', 'label' => 'صف کاری'],
                ['code' => 'supervisor.panel', 'label' => 'پنل سوپروایزر'],
                ['code' => 'supervisor.decide', 'label' => 'ویرایش'],
                ['code' => 'supervisor.reopen', 'label' => 'بازگشایی/برگشت درخواست'],
            ],
        ],
        [
            'key' => 'services',
            'label' => 'خدمات و دسته‌بندی',
            'items' => [
                ['code' => 'services.view', 'label' => 'مشاهدهٔ خدمات'],
                ['code' => 'services.manage', 'label' => 'ویرایش'],
                ['code' => 'service_cat.manage', 'label' => 'مدیریت دسته‌بندی خدمات'],
                ['code' => 'service_field.manage', 'label' => 'مدیریت فیلدهای خدمت'],
            ],
        ],
        [
            'key' => 'knowledge',
            'label' => 'دانش‌نامه',
            'items' => [
                ['code' => 'knowledge.view', 'label' => 'مشاهدهٔ دانش‌نامه'],
                ['code' => 'knowledge.manage', 'label' => 'ویرایش'],
            ],
        ],
        [
            'key' => 'cddvd',
            'label' => 'کنترل CD/DVD',
            'items' => [
                ['code' => 'cddvd.view', 'label' => 'مشاهدهٔ فرم کنترل CD/DVD'],
                ['code' => 'cddvd.submit_out', 'label' => 'ثبت خروج رسانه'],
                ['code' => 'cddvd.submit_in', 'label' => 'ثبت ورود رسانه (بازرسی)'],
                ['code' => 'cddvd.edit', 'label' => 'ویرایش'],
                ['code' => 'cddvd.view_all', 'label' => 'مشاهدهٔ همهٔ ثبت‌ها (نه فقط واحد خود)'],
                ['code' => 'cddvd.history', 'label' => 'تاریخچهٔ سریال'],
                ['code' => 'cddvd.export', 'label' => 'خروجی Excel/CSV'],
            ],
        ],
        [
            'key' => 'traffic',
            'label' => 'کنترل تردد مراجعین',
            'items' => [
                ['code' => 'traffic.view', 'label' => 'مشاهدهٔ کنترل تردد'],
                ['code' => 'traffic.manage', 'label' => 'ثبت، ویرایش و ورود گروهی سوابق'],
                ['code' => 'traffic.destinations', 'label' => 'مقصدهای ملاقات'],
                ['code' => 'traffic.destinations_edit', 'label' => 'ویرایش'],
            ],
        ],
        [
            'key' => 'assets',
            'label' => 'دارایی و شناسنامه فنی',
            'items' => [
                ['code' => 'assets.view', 'label' => 'فهرست شناسنامه‌ها'],
                ['code' => 'assets.own_unit', 'label' => 'فقط دارایی‌های واحد خودم'],
                ['code' => 'asset.view', 'label' => 'مشاهدهٔ شناسنامهٔ دارایی'],
                ['code' => 'asset.edit', 'label' => 'ویرایش'],
                ['code' => 'asset.extract', 'label' => 'استخراج سخت‌افزار (همین سرور)'],
                ['code' => 'asset.remote_extract', 'label' => 'ویرایش'],
                ['code' => 'asset.remote_prepare', 'label' => 'آماده‌سازی سیستم‌های مقصد (فعال‌سازی WinRM)'],
                ['code' => 'asset.history', 'label' => 'تاریخچهٔ دارایی'],
                ['code' => 'asset.ping', 'label' => 'پینگ سیستم‌های انتخابی'],
                ['code' => 'inventory.view', 'label' => 'فهرست موجودی'],
                ['code' => 'inventory.diagnostics', 'label' => 'تشخیص موجودی'],
                ['code' => 'domain.import', 'label' => 'ورود کامپیوترهای دامنه'],
                ['code' => 'domain.scan', 'label' => 'اسکن دامنه'],
            ],
        ],
        [
            'key' => 'reports',
            'label' => 'گزارش و تحلیل',
            'items' => [
                ['code' => 'reports.view', 'label' => 'گزارش‌ها'],
                ['code' => 'analytics.view', 'label' => 'چارت‌ها'],
                ['code' => 'audit.view', 'label' => 'ممیزی'],
                ['code' => 'logs.view', 'label' => 'گزارش خطا'],
                ['code' => 'system.health', 'label' => 'سلامت سامانه و خطاهای فنی'],
                ['code' => 'system.health_edit', 'label' => 'ویرایش وضعیت و نگهداری لاگ'],
                ['code' => 'logs.activity', 'label' => 'فعالیت کاربران'],
                ['code' => 'logs.activity_export', 'label' => 'خروجی فعالیت کاربران'],
            ],
        ],
        [
            'key' => 'food',
            'label' => 'سامانه مدیریت غذا',
            'items' => [
                ['code' => 'food.dashboard', 'label' => 'داشبورد'],
                ['code' => 'food.monitor', 'label' => 'پایش لحظه‌ای'],
                ['code' => 'food.employees', 'label' => 'کارکنان'],
                ['code' => 'food.employees_edit', 'label' => 'ویرایش'],
                ['code' => 'food.menu', 'label' => 'برنامه غذایی'],
                ['code' => 'food.menu_edit', 'label' => 'ویرایش'],
                ['code' => 'food.groups', 'label' => 'گروه‌های غذا'],
                ['code' => 'food.groups_edit', 'label' => 'ویرایش'],
                ['code' => 'food.reports', 'label' => 'گزارش‌ها'],
                ['code' => 'food.absent.own_deputy', 'label' => 'غایبین ناهارِ معاونت خود'],
            ],
        ],
        [
            'key' => 'food_settings',
            'label' => 'تنظیمات سیستم مدیریت غذا',
            'items' => [
                ['code' => 'food.db', 'label' => 'اتصال پایگاه‌ها و تردد'],
                ['code' => 'food.db_edit', 'label' => 'ویرایش'],
                ['code' => 'food.printer', 'label' => 'چاپگر سیستم'],
                ['code' => 'food.printer_edit', 'label' => 'ویرایش'],
                ['code' => 'food.guest', 'label' => 'کارت مهمان'],
                ['code' => 'food.guest_edit', 'label' => 'ویرایش'],
                ['code' => 'food.design', 'label' => 'طراحی فیش'],
                ['code' => 'food.design_edit', 'label' => 'ویرایش'],
                ['code' => 'food.health', 'label' => 'سلامت سیستم'],
                ['code' => 'food.health_edit', 'label' => 'ویرایش'],
                ['code' => 'food.manual_attendance', 'label' => 'ثبت دستی فیش/تردد'],
                ['code' => 'food.manual_attendance_edit', 'label' => 'ویرایش'],
                ['code' => 'food.emergency_window', 'label' => 'مدیریت مهلت اضطراری سفارش غذا'],
                ['code' => 'food.emergency_window_edit', 'label' => 'ویرایش'],
            ],
        ],
        [
            'key' => 'foodorder',
            'label' => 'سفارش غذای کارکنان',
            'items' => [
                ['code' => 'foodorder.self', 'label' => 'ثبت و مشاهدهٔ سفارش خود'],
            ],
        ],
        [
            'key' => 'org',
            'label' => 'سازمان',
            'items' => [
                ['code' => 'org.view', 'label' => 'مشاهدهٔ چارت سازمانی'],
                ['code' => 'org.manage', 'label' => 'ویرایش'],
            ],
        ],
        [
            'key' => 'system',
            'label' => 'تنظیمات و سیستم',
            'items' => [
                ['code' => 'settings.general', 'label' => 'تنظیمات عمومی و افکت نمایشی'],
                ['code' => 'settings.general_edit', 'label' => 'ویرایش تنظیمات عمومی و افکت نمایشی'],
                ['code' => 'settings.domain', 'label' => 'اتصال دامین و اسکن دامنه'],
                ['code' => 'settings.domain_edit', 'label' => 'ویرایش'],
                ['code' => 'settings.users', 'label' => 'مدیریت کاربران و دسترسی‌ها'],
                ['code' => 'settings.users_edit', 'label' => 'ویرایش'],
                ['code' => 'settings.key_roles', 'label' => 'نقش‌های کلیدی'],
                ['code' => 'settings.key_roles_edit', 'label' => 'ویرایش'],
                ['code' => 'backup.view', 'label' => 'پشتیبان‌گیری/بازگردانی'],
                ['code' => 'backup.manage', 'label' => 'ویرایش'],
                ['code' => 'update.view', 'label' => 'مشاهدهٔ به‌روزرسانی سامانه'],
                ['code' => 'update.apply', 'label' => 'اجرای به‌روزرسانی سامانه'],
                ['code' => 'chatbot.manage', 'label' => 'مدیریت پرسش‌ها و پاسخ‌های بات'],
                ['code' => 'ola.view', 'label' => 'تنظیمات OLA/SLA'],
                ['code' => 'ola.manage', 'label' => 'ویرایش'],
                ['code' => 'governance.view', 'label' => 'تغییر و مشکل'],
                ['code' => 'governance.manage', 'label' => 'ویرایش'],
                ['code' => 'holidays.view', 'label' => 'مدیریت تعطیلات'],
                ['code' => 'holidays.manage', 'label' => 'ویرایش'],
            ],
        ],
    ];
}

function permission_all_codes(): array
{
    $codes = [];
    foreach (permission_catalog() as $group) {
        foreach ($group['items'] as $item) {
            $codes[] = $item['code'];
        }
    }
    return $codes;
}

/**
 * نقشهٔ «مشاهده ← ویرایش»: کد ویرایش مستقل است؛ انتخاب ویرایش، مشاهده را هم می‌دهد،
 * اما انتخاب مشاهده به‌تنهایی هرگز مجوز ویرایش را اضافه نمی‌کند.
 */
/** Roles permitted to directly edit or delete CD/DVD history records. */
function permission_cddvd_direct_edit_roles(): array
{
    return ['primary_admin', 'supervisor', 'inspector', 'guard'];
}

/** Remove the fixed-allowlist CD/DVD grant from every other role, including stale saved rows. */
function permission_filter_role_codes(string $role, array $codes): array
{
    if (!in_array($role, permission_cddvd_direct_edit_roles(), true)) {
        $codes = array_values(array_diff($codes, ['cddvd.edit']));
    }
    return $codes;
}

function permission_edit_map(): array
{
    return [
        'services.view' => 'services.manage',
        'knowledge.view' => 'knowledge.manage',
        'traffic.view' => 'traffic.manage',
        'traffic.destinations' => 'traffic.destinations_edit',
        'asset.view' => 'asset.edit',
        'org.view' => 'org.manage',
        'system.health' => 'system.health_edit',
        'food.groups' => 'food.groups_edit',
        'food.employees' => 'food.employees_edit',
        'food.guest' => 'food.guest_edit',
        'food.db' => 'food.db_edit',
        'food.printer' => 'food.printer_edit',
        'food.design' => 'food.design_edit',
        'food.health' => 'food.health_edit',
        'food.menu' => 'food.menu_edit',
        'food.manual_attendance' => 'food.manual_attendance_edit',
        'food.emergency_window' => 'food.emergency_window_edit',
        'ola.view' => 'ola.manage',
        'governance.view' => 'governance.manage',
        'holidays.view' => 'holidays.manage',
        'backup.view' => 'backup.manage',
        'settings.general' => 'settings.general_edit',
        'settings.domain' => 'settings.domain_edit',
        'settings.users' => 'settings.users_edit',
        'settings.key_roles' => 'settings.key_roles_edit',
        'ticket.view_unit' => 'ticket.edit',
        'queue.view' => 'ticket.bulk',
        'supervisor.panel' => 'supervisor.decide',
        'domain.scan' => 'asset.remote_extract',
    ];
}

/** اگر کد ویرایش داده شود، کد مشاهدهٔ والد هم در مجموعهٔ مؤثر قرار می‌گیرد. */
function role_permissions_add_parents(array $codes): array
{
    $set = array_fill_keys($codes, true);
    foreach (permission_edit_map() as $parent => $child) {
        if (isset($set[$child])) {
            $set[$parent] = true;
        }
    }
    return array_keys($set);
}

/**
 * Default permissions per role. primary_admin implicitly has all.
 */
/** نقش‌هایی که به ماژول چاپ فیش دسترسی دارند؛ بقیه هیچ کد food.* ندارند. */
function print_fish_allowed_roles(): array
{
    return ['primary_admin', 'support_manager', 'inspector'];
}

/** پیش‌فرض کدهای چاپ فیش برای نقش‌های غیرادمین مجاز. ادمین اصلی همهٔ کدها را دارد. */
function print_fish_role_targets(): array
{
    return [
        // مدیر پشتیبانی: داشبورد، پایش، گزارش، کارکنان، گروه‌ها، برنامهٔ غذایی و بستن روز؛ بدون تنظیمات.
        'support_manager' => ['system.health', 'food.dashboard', 'food.monitor', 'food.reports', 'food.employees', 'food.employees_edit', 'food.groups', 'food.groups_edit', 'food.menu', 'food.menu_edit'],
        // بازرس: فقط داشبورد و مشاهدهٔ گروه‌های غذا.
        'inspector' => ['food.dashboard', 'food.groups'],
    ];
}

/** کدهای چاپ فیش یک نقش را با پیش‌فرض‌های مجاز جایگزین می‌کند (ادمین اصلی دست‌نخورده). */
function print_fish_role_codes(string $role, array $codes): array
{
    if ($role === 'primary_admin') {
        return $codes;
    }
    $codes = permission_food_legacy_codes($codes);
    $kept = array_values(array_filter($codes, static fn ($c): bool => !str_starts_with((string) $c, 'food.')));
    $targets = print_fish_role_targets();
    return array_values(array_unique(array_merge($kept, $targets[$role] ?? [])));
}

function permission_defaults(): array
{
    $defaults = permission_defaults_raw();
    foreach ($defaults as $role => $codes) {
        $codes = permission_food_legacy_codes($codes);
        // ویرایشِ بی‌والد نباشد؛ دسترسی‌های پیش‌فرض دیگری اضافه نمی‌شود.
        $codes = role_permissions_add_parents($codes);
        // ویرایش درخواست: پیش‌تر کسانی درخواست را تغییر می‌دادند که مدیر ارجاع (ticket.assign) یا کارشناس قابل ارجاع بودند.
        if (in_array('ticket.assign', $codes, true) || in_array($role, assignable_role_codes(), true)) {
            $codes[] = 'ticket.edit';
        }
        // بعد از افزودن ویرایش‌های قدیمی هم فیلتر می‌شود تا چیزی از چاپ فیش به نقش‌های غیرمجاز نرسد.
        $codes = print_fish_role_codes($role, $codes);
        $codes = permission_filter_role_codes($role, $codes);
        $defaults[$role] = array_values(array_unique($codes));
    }
    return $defaults;
}

/** کدهایی که از پیش‌فرض نقش user برداشته شدند (تصمیم کاربر). */
function user_default_removed_codes(): array
{
    return ['cddvd.view', 'cddvd.submit_out', 'traffic.view', 'food.dashboard', 'food.monitor', 'food.orders', 'food.reports', 'food.orders_edit', 'governance.view', 'governance.manage'];
}

function permission_defaults_raw(): array
{
    $all = ['dash.view', 'search.global', 'notif.view', 'profile.edit', 'chatbot.use', 'ticket.create', 'ticket.view_own', 'ticket.reply', 'ticket.rate', 'services.view', 'knowledge.view', 'cddvd.view', 'cddvd.submit_out', 'traffic.view', 'food.dashboard', 'food.monitor', 'food.orders', 'food.reports', 'foodorder.self', 'org.view', 'governance.manage'];
    $common = array_merge($all, ['ticket.view_unit', 'queue.view', 'assets.view', 'assets.own_unit', 'asset.view', 'asset.history', 'reports.view', 'inventory.view', 'cddvd.history', 'cddvd.export', 'traffic.manage']);
    return [
        'primary_admin' => permission_all_codes(),
        // ۱.۳۷.۷ — پیش‌فرض نقش قدیمی «admin» (قابل ویرایش از تنظیمات ← نقش‌ها).
        'supervisor' => array_values(array_unique(array_merge($common, ['ticket.view_all', 'ticket.edit', 'supervisor.panel', 'supervisor.decide', 'supervisor.reopen', 'analytics.view', 'asset.edit', 'asset.extract', 'asset.ping', 'domain.import', 'domain.scan', 'knowledge.manage', 'cddvd.edit', 'cddvd.view_all', 'traffic.destinations', 'logs.activity', 'food.dashboard', 'food.monitor', 'food.orders', 'food.reports', 'food.employees', 'food.guest', 'food.groups', 'food.groups_override']))),
        'support_manager' => array_values(array_unique(array_merge($common, ['ticket.edit', 'ticket.assign', 'ticket.bulk', 'ticket.attach_asset', 'services.manage', 'service_cat.manage', 'service_field.manage', 'knowledge.manage', 'cddvd.view_all', 'traffic.destinations', 'analytics.view', 'asset.edit', 'asset.extract', 'asset.ping', 'asset.remote_extract', 'asset.remote_prepare', 'inventory.diagnostics', 'domain.import', 'domain.scan', 'audit.view', 'logs.view', 'logs.activity', 'logs.activity_export', 'food.dashboard', 'food.monitor', 'food.orders', 'food.reports', 'food.employees', 'food.guest', 'food.groups', 'food.groups_override', 'food.menu', 'food.menu_edit', 'settings.general', 'settings.domain', 'holidays.manage']))),
        'inspector' => array_values(array_unique(array_merge($all, ['ticket.view_unit', 'ticket.view_all', 'ticket.edit', 'queue.view', 'assets.view', 'asset.view', 'asset.history', 'asset.ping', 'reports.view', 'analytics.view', 'audit.view', 'inventory.view', 'cddvd.submit_in', 'cddvd.edit', 'cddvd.view_all', 'cddvd.history', 'cddvd.export', 'traffic.manage']))),
        'manager' => array_values(array_unique(array_merge($common, ['ticket.edit', 'ticket.assign', 'ticket.bulk', 'ticket.attach_asset', 'knowledge.manage', 'asset.edit', 'asset.extract', 'asset.ping', 'analytics.view']))),
        'agent' => array_values(array_unique(array_merge($common, ['ticket.attach_asset', 'knowledge.manage', 'asset.edit', 'asset.extract', 'asset.ping']))),
        // کاربر عادی (از جمله کاربران AD): بخش‌های چاپ فیش، نظارت و سیاست‌های دارایی/ترافیک ندارد.
        // «سفارش غذای خود» (foodorder.self) عمداً باقی است تا کاربر بتواند برای خودش سفارش دهد.
        'user' => array_values(array_diff($all, user_default_removed_codes())),
        // کاربر محلی (پرسنل غذایی که در دامین نیستند): فقط سفارش غذای خود و پروفایل.
        'local_user' => ['foodorder.self', 'profile.edit'],
        // بازرسی: سفارش غذا، پروفایل، و کنترل CD/DVD و تردد با دسترسی کامل.
        'guard' => ['foodorder.self', 'profile.edit', 'cddvd.view', 'cddvd.submit_in', 'cddvd.edit', 'traffic.view', 'traffic.manage', 'traffic.destinations'],
    ];
}

function permission_table_ready(): bool
{
    static $ready = null;
    if ($ready !== null) {
        return $ready;
    }
    try {
        db()->query('SELECT 1 FROM role_permissions LIMIT 1');
        $ready = true;
    } catch (Throwable $e) {
        $ready = false;
    }
    return $ready;
}

/**
 * Stored permission codes for a role (fallback to defaults when table missing/empty).
 */
/**
 * ۱.۳۷.۷ — قانون «قابل‌مدیریت» دسترسی نقش‌ها (تصمیم کاربر، ۲۰۲۶-۱۰-۰۶):
 *   • تا وقتی نقش از فرم «نقش‌ها و دسترسی‌ها» ذخیره نشده ⇒ پیش‌فرض‌های همین فایل اعمال می‌شود
 *     (تغییر پیش‌فرض‌ها در نسخه‌های بعدی خودکار به این نقش‌ها می‌رسد).
 *   • به‌محض «ذخیره» از فرم ⇒ دقیقاً همان مجموعه اولویت دارد؛ حتی اگر خالی باشد یا بعداً
 *     پیش‌فرض کد عوض شود.
 *   • «بازگردانی به پیش‌فرض کد» نقش را دوباره دست‌نخورده می‌کند.
 * نشانهٔ «دست‌خورده» در جدول settings با کلید role_permissions_custom_<role> نگه داشته می‌شود؛
 * هیچ ستون یا جدول تازه‌ای ساخته نمی‌شود.
 */
function role_permissions_custom(string $role): bool
{
    if (!function_exists('setting')) {
        return false;
    }
    return setting('role_permissions_custom_' . $role) === '1';
}

function role_permissions_mark_custom(string $role, bool $custom = true): void
{
    if (!function_exists('save_setting')) {
        return;
    }
    save_setting('role_permissions_custom_' . $role, $custom ? '1' : '0');
}

function role_permissions_normalize_codes(array $codes): array
{
    $codes = array_map('strval', $codes);
    return array_values(array_unique(array_filter($codes, static fn (string $code): bool => $code !== '')));
}

/** Map retired food capabilities into the agreed section-level grants. */
function permission_food_legacy_codes(array $codes): array
{
    $codes = role_permissions_normalize_codes($codes);
    $set = array_fill_keys($codes, true);
    if (isset($set['food.order_close']) || isset($set['food.emergency'])) {
        $set['food.menu_edit'] = true;
        $set['food.menu'] = true;
    }
    if (isset($set['food.groups_override'])) {
        $set['food.groups_edit'] = true;
        $set['food.groups'] = true;
    }
    // Monitoring is now a single view-only grant; old edit grant folds into it.
    if (isset($set['food.monitor_edit'])) {
        $set['food.monitor'] = true;
    }
    // The manual-attendance section replaces the old primary-admin-only permission.
    if (isset($set['food.manual_ticket'])) {
        $set['food.manual_attendance_edit'] = true;
        $set['food.manual_attendance'] = true;
    }
    foreach (['food.order_close', 'food.emergency', 'food.groups_override', 'food.monitor_edit', 'food.manual_ticket', 'food.orders', 'food.orders_edit', 'foodorder.proxy'] as $retired) {
        unset($set[$retired]);
    }
    return array_keys($set);
}

/**
 * مجموعهٔ مؤثر یک نقش (تابع خالص؛ بدون دیتابیس قابل آزمون است).
 */
function role_permission_effective_codes(string $role, array $storedCodes, bool $custom): array
{
    if ($custom) {
        // مجوز صدور فیش دستی از داده‌های سفارشی قدیمی/دستی به نقش غیرادمین نشت نمی‌کند.
        $storedCodes = permission_food_legacy_codes($storedCodes);
        $storedCodes = permission_filter_role_codes($role, $storedCodes);
        // نقش‌های ذخیره‌شده: ویرایش بدون بخش (داده‌های قدیمی) بخش را هم می‌گیرد تا دسترسی قبلی حفظ شود.
        return role_permissions_add_parents(role_permissions_normalize_codes($storedCodes));
    }
    $defaults = permission_defaults();
    return permission_filter_role_codes($role, role_permissions_normalize_codes($defaults[$role] ?? []));
}

/** مقایسهٔ مجموعه‌ای دو فهرست کد؛ ترتیب و تکرار مهم نیست. */
function role_permissions_same_set(array $a, array $b): bool
{
    $a = role_permissions_normalize_codes($a);
    $b = role_permissions_normalize_codes($b);
    sort($a);
    sort($b);
    return $a === $b;
}

/** پاک‌کردن کش درون‌درخواستی (بعد از ذخیره/بازگردانی). */
function role_permissions_flush_cache(?string $role = null): void
{
    if ($role === null) {
        $GLOBALS['__role_permission_codes'] = [];
        $GLOBALS['__role_permission_sets'] = [];
        return;
    }
    unset($GLOBALS['__role_permission_codes'][$role], $GLOBALS['__role_permission_sets'][$role]);
}

/**
 * مهاجرت یک‌باره: نقش‌هایی که «گروه‌های غذا» را داشتند، ویرایش آن را هم می‌گیرند (دسترسی قبلی حفظ شود).
 */
function role_permissions_migrate_once(): void
{
    static $done = false;
    if ($done) {
        return;
    }
    $done = true;
    if (!permission_table_ready() || !function_exists('setting') || !function_exists('save_setting')) {
        return;
    }
    if (setting('print_fish_roles_v2') !== '1') {
        // دسترسی‌های سامانهٔ غذا برای همهٔ نقش‌ها قابل مدیریت است؛ این آشتی فقط نشانگر تازه را ثبت می‌کند و مجوزی را حذف نمی‌کند.
        try {
            save_setting('print_fish_roles_v2', '1');
            role_permissions_flush_cache();
        } catch (Throwable $exception) {
            // دفعهٔ بعد دوباره تلاش می‌شود.
        }
    }
    if (setting('user_defaults_narrowed_v1') !== '1') {
        // ردیف‌های ذخیره‌شدهٔ نقش user هم باید همین تغییر را ببینند. اگر ادمین آن را دستی تنظیم کرده باشد، دست نمی‌خورد.
        try {
            if (setting('role_permissions_custom_user') !== '1') {
                $removed = user_default_removed_codes();
                $placeholders = implode(',', array_fill(0, count($removed), '?'));
                $delete = db()->prepare("DELETE FROM role_permissions WHERE role = 'user' AND permission IN ($placeholders)");
                $delete->execute($removed);
                save_setting('user_defaults_narrowed_report', (string) $delete->rowCount());
            } else {
                save_setting('user_defaults_narrowed_report', 'custom');
            }
            save_setting('user_defaults_narrowed_v1', '1');
            role_permissions_flush_cache();
        } catch (Throwable $exception) {
            // دفعهٔ بعد دوباره تلاش می‌شود.
        }
    }
    if (setting('legacy_admin_removed_v1') !== '1') {
        // نقش قدیمی «admin» حذف شد. ادمین اصلی به primary_admin می‌رود و بقیه به supervisor.
        // هیچ ادمینی بی‌صدا تنزل نمی‌یابد؛ تعداد هر گروه در تنظیمات ثبت می‌شود.
        try {
            $countPrimary = (int) db()->query("SELECT COUNT(*) FROM users WHERE role = 'admin' AND is_primary_admin = 1")->fetchColumn();
            $countOther = (int) db()->query("SELECT COUNT(*) FROM users WHERE role = 'admin' AND (is_primary_admin = 0 OR is_primary_admin IS NULL)")->fetchColumn();
            db()->exec("UPDATE users SET role = 'primary_admin', is_primary_admin = 1 WHERE role = 'admin' AND is_primary_admin = 1");
            db()->exec("UPDATE users SET role = 'supervisor' WHERE role = 'admin'");
            db()->exec("DELETE FROM role_permissions WHERE role = 'admin'");
            save_setting('legacy_admin_removed_report', json_encode(['to_primary_admin' => $countPrimary, 'to_supervisor' => $countOther], JSON_UNESCAPED_UNICODE));
            save_setting('legacy_admin_removed_v1', '1');
            role_permissions_flush_cache();
        } catch (Throwable $exception) {
            // دفعهٔ بعد دوباره تلاش می‌شود.
        }
    }
    if (setting('perm_edit_v3') !== '1') {
        try {
            // پاسخ به درخواست پیش‌تر با کد کنترل نمی‌شد؛ پس به هر نقش ذخیره‌شده‌ای داده می‌شود تا دسترسی حفظ شود.
            db()->exec("INSERT IGNORE INTO role_permissions (role, permission) SELECT DISTINCT role, 'ticket.reply' FROM role_permissions");
            // امتیازدهی به درخواست هم پیش‌تر کد نداشت؛ به همهٔ نقش‌های ذخیره‌شده داده می‌شود.
            db()->exec("INSERT IGNORE INTO role_permissions (role, permission) SELECT DISTINCT role, 'ticket.rate' FROM role_permissions");
            // داشبورد پیش‌تر همیشه باز بود؛ کد دیدنش به همهٔ نقش‌های ذخیره‌شده داده می‌شود.
            db()->exec("INSERT IGNORE INTO role_permissions (role, permission) SELECT DISTINCT role, 'dash.view' FROM role_permissions");
            // اسکن دامنه پیش‌تر استخراج از راه دور هم بود؛ همان دسترسی برای کد ویرایش حفظ می‌شود.
            db()->exec("INSERT IGNORE INTO role_permissions (role, permission) SELECT DISTINCT role, 'asset.remote_extract' FROM role_permissions WHERE permission = 'domain.scan'");
            $assignableList = implode(',', array_map(static fn (string $r): string => db()->quote($r), assignable_role_codes()));
            db()->exec("INSERT IGNORE INTO role_permissions (role, permission) SELECT DISTINCT role, 'ticket.edit' FROM role_permissions WHERE permission = 'ticket.assign' OR role IN ($assignableList)");
            save_setting('perm_edit_v3', '1');
            role_permissions_flush_cache();
        } catch (Throwable $exception) {
            // دفعهٔ بعد دوباره تلاش می‌شود.
        }
    }
    if (setting('perm_edit_v4') !== '1') {
        try {
            // مشاهده به‌تنهایی نباید ویرایش را فعال کند؛ مجوزهای ویرایش فقط از انتخاب صریح نقش می‌آیند.
            db()->exec("DELETE FROM role_permissions WHERE permission = 'cddvd.edit' AND role NOT IN ('primary_admin', 'supervisor', 'inspector', 'guard')");
            db()->exec("DELETE FROM role_permissions WHERE permission = 'foodorder.proxy'");
            save_setting('perm_edit_v4', '1');
            role_permissions_flush_cache();
        } catch (Throwable $exception) {
            // Retry this additive permission reconciliation on the next request.
        }
    }
    if (setting('perm_edit_v5') !== '1') {
        try {
            // آماده‌سازی راه‌دور مقصدها (فعال‌سازی WinRM) همان جمعیتی را می‌گیرد که استخراج از راه دور دارد.
            db()->exec("INSERT IGNORE INTO role_permissions (role, permission) SELECT DISTINCT role, 'asset.remote_prepare' FROM role_permissions WHERE permission = 'asset.remote_extract'");
            save_setting('perm_edit_v5', '1');
            role_permissions_flush_cache();
        } catch (Throwable $exception) {
            // Retry this additive permission reconciliation on the next request.
        }
    }

}

function role_permission_codes(string $role): array
{
    role_permissions_migrate_once();
    $role = permission_roles()[$role] ?? null ? $role : 'user';
    if (!isset($GLOBALS['__role_permission_codes']) || !is_array($GLOBALS['__role_permission_codes'])) {
        $GLOBALS['__role_permission_codes'] = [];
    }
    if (!array_key_exists($role, $GLOBALS['__role_permission_codes'])) {
        $stored = [];
        if (permission_table_ready()) {
            try {
                $query = db()->prepare('SELECT permission FROM role_permissions WHERE role = ?');
                $query->execute([$role]);
                $stored = array_map('strval', $query->fetchAll(PDO::FETCH_COLUMN));
            } catch (Throwable $exception) {
                $stored = [];
            }
        }
        $GLOBALS['__role_permission_codes'][$role] = role_permission_effective_codes($role, $stored, role_permissions_custom($role));
    }
    return $GLOBALS['__role_permission_codes'][$role];
}

/**
 * نسخهٔ هش‌ست مجوزهای نقش برای بررسی سریع user_can (به‌جای in_array خطی).
 */
function role_permission_set(string $role): array
{
    $role = permission_roles()[$role] ?? null ? $role : 'user';
    if (!isset($GLOBALS['__role_permission_sets']) || !is_array($GLOBALS['__role_permission_sets'])) {
        $GLOBALS['__role_permission_sets'] = [];
    }
    if (!array_key_exists($role, $GLOBALS['__role_permission_sets'])) {
        $GLOBALS['__role_permission_sets'][$role] = array_fill_keys(role_permission_codes($role), true);
    }
    return $GLOBALS['__role_permission_sets'][$role];
}

/**
 * Additive permissions granted to a user through any of their access groups.
 * A request-local cache keeps the extra lookup to at most one query per user.
 * Missing migration tables intentionally mean "no group grants", never a fatal error.
 */
function user_access_group_permission_set(array $user): array
{
    $userId = (int) ($user['id'] ?? 0);
    if ($userId <= 0) {
        return [];
    }

    if (!isset($GLOBALS['__user_access_group_permission_codes']) || !is_array($GLOBALS['__user_access_group_permission_codes'])) {
        $GLOBALS['__user_access_group_permission_codes'] = [];
    }
    if (!array_key_exists($userId, $GLOBALS['__user_access_group_permission_codes'])) {
        $codes = [];
        try {
            $query = db()->prepare(
                'SELECT DISTINCT gp.permission_code
                 FROM user_access_group_members gm
                 INNER JOIN user_access_groups g ON g.id = gm.group_id
                 INNER JOIN user_access_group_permissions gp ON gp.group_id = g.id
                 INNER JOIN users group_user ON group_user.id = gm.user_id
                 WHERE gm.user_id = ? AND group_user.is_active = 1 AND group_user.auth_source <> \'food\''
            );
            $query->execute([$userId]);
            $codes = array_map('strval', $query->fetchAll(PDO::FETCH_COLUMN));
        } catch (Throwable) {
            // A not-yet-applied additive migration must not break role-only access.
            $codes = [];
        }

        $codes = permission_food_legacy_codes($codes);
        $codes = array_values(array_intersect($codes, permission_all_codes()));
        $GLOBALS['__user_access_group_permission_codes'][$userId] = array_values(array_unique($codes));
    }

    // Preserve the explicit CD/DVD role allowlist even when that capability is group-assigned.
    $codes = permission_filter_role_codes(user_role_code($user), $GLOBALS['__user_access_group_permission_codes'][$userId]);
    $codes = role_permissions_add_parents($codes);
    return array_fill_keys($codes, true);
}

/** Drop the request-local effective-group cache after a group or membership update. */
function user_access_group_permissions_flush_cache(?int $userId = null): void
{
    if (!isset($GLOBALS['__user_access_group_permission_codes']) || !is_array($GLOBALS['__user_access_group_permission_codes'])) {
        return;
    }
    if ($userId === null) {
        unset($GLOBALS['__user_access_group_permission_codes']);
        return;
    }
    unset($GLOBALS['__user_access_group_permission_codes'][$userId]);
}

function role_permissions_seeded(): bool
{
    if (!permission_table_ready()) {
        return false;
    }
    try {
        return (int) db()->query('SELECT COUNT(*) FROM role_permissions')->fetchColumn() > 0;
    } catch (Throwable $e) {
        return false;
    }
}

/**
 * ۱.۳۷.۷ — پیش‌فرض‌های کد دیگر داخل جدول role_permissions ریخته نمی‌شوند.
 * دلیل: با ریختن پیش‌فرض‌ها در جدول، همهٔ نقش‌ها از همان نصب اول «دست‌خورده» حساب می‌شدند و
 * از آن به بعد هیچ تغییر پیش‌فرضی در نسخه‌های بعدی به آن‌ها نمی‌رسید.
 *
 * این تابع فقط یک‌بار وضعیت نصب‌های قبلی را آشتی می‌دهد: اگر دسترسی‌های ذخیره‌شدهٔ یک نقش با
 * پیش‌فرض کد تفاوت داشته باشد (یعنی قبلاً دستی ویرایش شده)، همان نقش «ویرایش‌شده» علامت می‌خورد
 * تا تغییرش حفظ شود. نقش‌هایی که تفاوتی ندارند، دست‌نخورده می‌مانند و پیش‌فرض‌های آینده به آن‌ها می‌رسد.
 */
function role_permissions_seed(bool $force = false): void
{
    if (!permission_table_ready()) {
        return;
    }
    if (!$force && function_exists('setting') && setting('role_permissions_reconciled') === '2026-10-07') {
        return;
    }
    foreach (array_keys(permission_roles()) as $role) {
        if ($role === 'primary_admin' || role_permissions_custom($role)) {
            continue;
        }
        $stored = [];
        try {
            $query = db()->prepare('SELECT permission FROM role_permissions WHERE role = ?');
            $query->execute([$role]);
            $stored = array_map('strval', $query->fetchAll(PDO::FETCH_COLUMN));
        } catch (Throwable $exception) {
            $stored = [];
        }
        if ($stored !== [] && !role_permissions_same_set($stored, role_permission_effective_codes($role, [], false))) {
            role_permissions_mark_custom($role, true);
        }
    }
    save_setting('role_permissions_reconciled', '2026-10-07');
}

/**
 * ذخیرهٔ دسترسی‌های یک نقش از فرم. از این پس تا وقتی «بازگردانی به پیش‌فرض» زده نشود،
 * همین مجموعه اولویت دارد.
 */
function role_permissions_save(string $role, array $codes): void
{
    if (!isset(permission_roles()[$role])) {
        return;
    }
    $valid = permission_all_codes();
    $codes = role_permissions_normalize_codes($codes);
    if ($role !== 'primary_admin') {
        $codes = permission_food_legacy_codes($codes);
    }
    $codes = array_values(array_intersect($codes, $valid));
    $codes = permission_filter_role_codes($role, $codes);
    // مجوز ویرایش، مشاهدهٔ والد را هم دارد؛ اما مشاهده هرگز مجوز ویرایش اضافه نمی‌کند.
    $codes = role_permissions_add_parents($codes);
    if ($role === 'primary_admin') {
        $codes = $valid;
    }
    if (permission_table_ready()) {
        $delete = db()->prepare('DELETE FROM role_permissions WHERE role = ?');
        $delete->execute([$role]);
        $insert = db()->prepare('INSERT IGNORE INTO role_permissions (role, permission) VALUES (?, ?)');
        foreach ($codes as $code) {
            $insert->execute([$role, $code]);
        }
    }
    // اگر مجموعه دقیقاً همان پیش‌فرض کد شد، نقش دوباره «دست‌نخورده» می‌ماند تا پیش‌فرض‌های
    // نسخه‌های بعدی خودکار به آن برسد.
    role_permissions_mark_custom($role, !role_permissions_same_set($codes, role_permission_effective_codes($role, [], false)));
    role_permissions_flush_cache($role);
}

/**
 * ۱.۳۷.۷ — بازگرداندن یک نقش به پیش‌فرض‌های داخل کد.
 */
function role_permissions_reset(string $role): void
{
    if (!isset(permission_roles()[$role])) {
        return;
    }
    $defaults = role_permission_effective_codes($role, [], false);
    if (permission_table_ready()) {
        $delete = db()->prepare('DELETE FROM role_permissions WHERE role = ?');
        $delete->execute([$role]);
        $insert = db()->prepare('INSERT IGNORE INTO role_permissions (role, permission) VALUES (?, ?)');
        foreach ($defaults as $code) {
            $insert->execute([$role, $code]);
        }
    }
    role_permissions_mark_custom($role, false);
    role_permissions_flush_cache($role);
}

function user_role_code(array $user): string
{
    return (string) ($user['role'] ?? 'user');
}

function user_is_primary_admin(array $user): bool
{
    return user_role_code($user) === 'primary_admin'
        || (user_role_code($user) === 'admin' && (int) ($user['is_primary_admin'] ?? 0) === 1);
}

/**
 * True when the user's role or any public access group grants the permission.
 * primary_admin (and admin+is_primary_admin) always pass.
 */
function user_can(array $user, string $permission): bool
{
    if (!$user) {
        return false;
    }
    if (user_is_primary_admin($user)) {
        return true;
    }
    // تصمیم مالک (۲۰۲۶-۱۱-۱۶): «سوپروایز» در تنظیمات ← کاربران یک نقش **اعطایی**
    // است، نه تبدیل نقش. کاربر با هر نقش اصلی (agent، manager، inspector، user…)
    // می‌تواند در فهرست سوپروایزرها باشد و دسترسی‌های سرپرستی را بگیرد، بدون
    // اینکه نقشش عوض شود.
    //
    // چرا اینجا؟ user_can() تنها نقطهٔ مشترک همهٔ بررسی‌های دسترسی است، پس
    // سوپروایزر بودن یک‌جا و بی‌پراکندگی اعمال می‌شود.
    if (function_exists('user_is_key_role')) {
        if (in_array($permission, user_can_supervisor_grants(), true)
            && user_is_key_role($user, 'supervisor')) {
            return true;
        }
        // تصمیم مالک (۲۰۲۶-۱۱-۱۶): کاربری که در تنظیمات ← کاربران «کارشناس آی تی»
        // یا «کارشناس پشتیبانی» تعیین شده باید واقعاً بتواند تیکت‌های حوزه‌اش را
        // **رسیدگی** کند — نه فقط مسئولِ اسمی باشد. پیش از این فقط نقش سیستمی
        // (agent/manager) `ticket.edit` داشت، پس کارشناسِ تعیین‌شده از فهرست
        // هیچ تیکتی نمی‌توانست باز کند یا پاسخ دهد.
        //
        // مرز: فقط کدهای «رسیدگی به تیکت»، نه هیچ دسترسی مدیریتی یا سراسری.
        if (in_array($permission, user_can_expert_grants(), true)
            && (user_is_key_role($user, 'it_expert') || user_is_key_role($user, 'support_expert'))) {
            return true;
        }
    }
    return isset(role_permission_set(user_role_code($user))[$permission])
        || isset(user_access_group_permission_set($user)[$permission]);
}

/**
 * دسترسی‌هایی که «بودن در فهرست سوپروایزرها» مستقلاً می‌دهد.
 *
 * تصمیم مالک (۲۰۲۶-۱۱-۱۶): **«دسترسی‌های اضافی سوپروایزر هم گرفته شود.»**
 * پس این فهرست به کارهای پایهٔ سرپرستی محدود شد.
 *
 * کدام حذف شد و چرا:
 *   • supervisor.decide (ویرایش/تصمیم) — وظیفهٔ تصمیم‌گیری، نه دیدن پنل
 *   • supervisor.reopen (بازگشایی)     — وظیفهٔ جداگانه
 *   • queue.view (صف)                  — کارشناسانه است، نه سرپرستانه
 *
 * هر سه همچنان از **نقش** می‌آیند اگر نقش داشته باشد (مثلاً نقش supervisor
 * قدیمی دست‌نخورده است). کسی که فقط در فهرست است، پنل را می‌بیند و تمام.
 */
function user_can_supervisor_grants(): array
{
    return ['supervisor.panel'];
}

/**
 * دسترسی‌هایی که «بودن در فهرست کارشناسان» مستقلاً می‌دهد.
 *
 * حداقلی و دقیقاً هم‌اندازهٔ کاری که یک کارشناس رسیدگی‌کننده لازم دارد:
 * دیدن صف حوزهٔ خودش، باز کردن تیکت، پاسخ دادن، و برداشتنِ کار.
 *
 * عمداً `ticket.view_all` این‌جا **نیست**: کارشناس فقط حوزهٔ خدمت خودش را
 * می‌بیند (`ticket_scope()` مرز را اعمال می‌کند). و `ticket.assign` هم نیست —
 * تخصیص کارِ سرپرست/مدیر است.
 */
function user_can_expert_grants(): array
{
    return ['ticket.edit', 'ticket.view_unit', 'ticket.reply', 'ticket.view_own', 'queue.view'];
}

function user_can_any(array $user, array $permissions): bool
{
    foreach ($permissions as $permission) {
        if (user_can($user, $permission)) {
            return true;
        }
    }
    return false;
}

/** Requires an authenticated user with the given permission, else 403. */
function require_permission(string $permission): array
{
    $user = require_login();
    if (!user_can($user, $permission)) {
        http_response_code(403);
        exit('دسترسی به این بخش مجاز نیست.');
    }
    return $user;
}

function require_any_permission(array $permissions): array
{
    $user = require_login();
    if (!user_can_any($user, $permissions)) {
        http_response_code(403);
        exit('دسترسی به این بخش مجاز نیست.');
    }
    return $user;
}

/**
 * Inline SVG icon for role/group cards. Keeps the panel look consistent
 * with the organization page (no emoji).
 */
function permission_icon(string $key): string
{
    $paths = [
        'owner' => '<path d="M12 3l2.4 4.9 5.4.8-3.9 3.8.9 5.4-4.8-2.5-4.8 2.5.9-5.4L4.2 8.7l5.4-.8z"/>',
        'supervisor' => '<path d="M12 3l7 3v5c0 4.4-2.9 8.3-7 9.5C7.9 19.3 5 15.4 5 11V6z"/><path d="M9.5 11.5l1.8 1.8 3.4-3.6"/>',
        'manager' => '<path d="M4 20v-1.5a4 4 0 0 1 4-4h8a4 4 0 0 1 4 4V20"/><circle cx="12" cy="8" r="3.4"/>',
        'inspector' => '<circle cx="11" cy="11" r="6"/><path d="M20 20l-3.6-3.6"/>',
        'expert' => '<path d="M14.5 5.5l4 4-8.5 8.5H6v-4z"/><path d="M13 7l4 4"/>',
        'user' => '<circle cx="12" cy="8" r="3.4"/><path d="M5 20v-1.5A4.5 4.5 0 0 1 9.5 14h5A4.5 4.5 0 0 1 19 18.5V20"/>',
        'g-base' => '<rect x="4" y="4" width="7" height="7" rx="1.6"/><rect x="13" y="4" width="7" height="7" rx="1.6"/><rect x="4" y="13" width="7" height="7" rx="1.6"/><rect x="13" y="13" width="7" height="7" rx="1.6"/>',
        'g-ticket' => '<path d="M4 9V7a2 2 0 0 1 2-2h12a2 2 0 0 1 2 2v2a2.4 2.4 0 0 0 0 6v2a2 2 0 0 1-2 2H6a2 2 0 0 1-2-2v-2a2.4 2.4 0 0 0 0-6z"/><path d="M12 7v10"/>',
        'g-services' => '<circle cx="12" cy="12" r="3"/><path d="M12 3v3M12 18v3M3 12h3M18 12h3M5.6 5.6l2.1 2.1M16.3 16.3l2.1 2.1M18.4 5.6l-2.1 2.1M7.7 16.3l-2.1 2.1"/>',
        'g-knowledge' => '<path d="M4 6a2 2 0 0 1 2-2h5v16H6a2 2 0 0 1-2-2z"/><path d="M20 6a2 2 0 0 0-2-2h-5v16h5a2 2 0 0 0 2-2z"/>',
        'g-cddvd' => '<circle cx="12" cy="12" r="8"/><circle cx="12" cy="12" r="2.6"/>',
        'g-traffic' => '<path d="M6 21V5a2 2 0 0 1 2-2h8a2 2 0 0 1 2 2v16"/><path d="M4 21h16"/><circle cx="12" cy="9" r="2.4"/><path d="M9 16.5c0-1.7 1.3-2.8 3-2.8s3 1.1 3 2.8"/>',
        'g-assets' => '<rect x="4" y="5" width="16" height="11" rx="2"/><path d="M2 19h20"/>',
        'g-reports' => '<path d="M4 20V6M10 20V10M16 20v-7M22 20H2"/>',
        'g-food' => '<path d="M5 3v8a3 3 0 0 0 6 0V3"/><path d="M8 11v10"/><path d="M17 3c-1.7 1-2.5 3-2.5 5.5S15 13 17 13v8"/>',
        'g-org' => '<rect x="9" y="3" width="6" height="5" rx="1.4"/><rect x="3" y="16" width="6" height="5" rx="1.4"/><rect x="15" y="16" width="6" height="5" rx="1.4"/><path d="M12 8v4M6 16v-4h12v4"/>',
        'g-system' => '<circle cx="12" cy="12" r="3"/><path d="M12 3v2M12 19v2M3 12h2M19 12h2M5.6 5.6l1.4 1.4M17 17l1.4 1.4M18.4 5.6L17 7M7 17l-1.4 1.4"/>',
    ];
    $path = $paths[$key] ?? $paths['user'];
    return '<svg class="perm-svg" viewBox="0 0 24 24" aria-hidden="true" focusable="false" fill="none" stroke="currentColor" stroke-width="1.7" stroke-linecap="round" stroke-linejoin="round">' . $path . '</svg>';
}

/** Roles treated as staff (see queue/assignee logic). */
function staff_role_codes(): array
{
    return ['agent', 'manager', 'supervisor', 'primary_admin', 'support_manager', 'inspector'];
}

function is_staff_role(?string $role): bool
{
    return in_array((string) $role, staff_role_codes(), true);
}

/** Roles that can administer the whole system. */
function admin_role_codes(): array
{
    return ['primary_admin'];
}

function is_admin_role(?string $role): bool
{
    return in_array((string) $role, admin_role_codes(), true);
}

/** Roles allowed to see/handle the whole ticket pool. */
function global_ticket_role_codes(): array
{
    // مدیر پشتیبانی سراسری نیست؛ فقط حوزه پشتیبانی را می‌بیند (بدون دسترسی به درخواست‌های IT).
    return ['supervisor', 'primary_admin', 'inspector'];
}

function is_global_ticket_role(?string $role): bool
{
    return in_array((string) $role, global_ticket_role_codes(), true);
}

/** Roles scoped to their own unit/department (not the whole pool). */
function is_department_scoped_role(?string $role): bool
{
    // فقط مدیر واحد (manager) به معاونت خودش محدود است؛ مدیر پشتیبانی کل حوزه پشتیبانی را می‌بیند.
    return in_array((string) $role, ['manager'], true);
}

/** Roles that may be assigned tickets (ticket handlers). */
function assignable_role_codes(): array
{
    return ['agent', 'manager', 'support_manager', 'primary_admin'];
}

function is_assignable_role(?string $role): bool
{
    return in_array((string) $role, assignable_role_codes(), true);
}
