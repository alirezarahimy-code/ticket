(function () {
    'use strict';

    var codeField = document.getElementById('traffic-national-code');
    var hint = document.getElementById('traffic-lookup-hint');
    var quickExitForm = document.getElementById('traffic-quick-exit-form');
    var quickExitId = document.getElementById('traffic-quick-exit-id');
    if (!codeField || !hint) {
        return;
    }

    var fields = {
        full_name: document.getElementById('traffic-full-name'),
        phone: document.getElementById('traffic-phone'),
        phoneTail: document.getElementById('traffic-phone-tail'),
        company: document.getElementById('traffic-company'),
        meeting_with: document.getElementById('traffic-meeting-with'),
        approved_by: document.getElementById('traffic-approved-by'),
    };

    function fireChange(element) {
        try {
            element.dispatchEvent(new Event('change', { bubbles: true }));
        } catch (ignore) {
            var event = document.createEvent('Event');
            event.initEvent('change', true, false);
            element.dispatchEvent(event);
        }
    }

    function setHint(html, kind) {
        hint.className = 'alert ' + (kind || 'info');
        hint.innerHTML = html;
        hint.hidden = false;
    }

    function clearHint() {
        hint.hidden = true;
        hint.innerHTML = '';
    }

    function asciiDigitsOnly(value) {
        return String(value || '')
            .replace(/[۰-۹]/g, function (digit) { return String('۰۱۲۳۴۵۶۷۸۹'.indexOf(digit)); })
            .replace(/[٠-٩]/g, function (digit) { return String('٠١٢٣٤٥٦٧٨٩'.indexOf(digit)); })
            .replace(/\D/g, '');
    }

    // جست‌وجوی سابقهٔ قبلی با کد ملی، تلفن همراه یا نام؛ فقط فیلدهای خالی پر می‌شوند.
    function lookupBy(query, quiet) {
        fetch('index.php?page=traffic-control&traffic_api=lookup&' + query, {
            headers: { Accept: 'application/json' },
            credentials: 'same-origin',
        })
            .then(function (res) { return res.json(); })
            .then(function (data) {
                if (!data.valid) {
                    if (!quiet) setHint('کد ملی وارد شده معتبر نیست.', 'danger');
                    return;
                }
                if (!data.found) {
                    if (!quiet) setHint('مهمان جدید — لطفاً بقیه‌ی اطلاعات را کامل وارد کنید.', 'info');
                    return;
                }
                if (data.needs_exit_only) {
                    setHint(
                        'این مراجعه‌کننده امروز قبلاً ثبت شده و ساعت خروج ندارد (' + data.last_visit_label + ').' +
                        ' <button type="button" class="mini-button" id="traffic-quick-exit-btn">فقط ثبت ساعت خروج</button>' +
                        ' یا برای ثبت یک تردد جدید همین فرم را کامل و ذخیره کنید.',
                        'info'
                    );
                    if (quickExitForm && quickExitId) {
                        quickExitId.value = data.record_id;
                        var btn = document.getElementById('traffic-quick-exit-btn');
                        if (btn) {
                            btn.addEventListener('click', function () { quickExitForm.submit(); });
                        }
                    }
                } else {
                    setHint('آخرین تردد: ' + data.last_visit_label + '. اطلاعات پیشنهادی پر شد؛ در صورت نیاز اصلاح کنید.', 'success');
                }
                if (fields.full_name && !fields.full_name.value) fields.full_name.value = data.full_name || '';
                if (codeField && !codeField.value.trim() && data.national_code) codeField.value = asciiDigitsOnly(data.national_code);
                if (fields.phone && fields.phoneTail && !fields.phoneTail.value && data.phone) {
                    var previousPhone = asciiDigitsOnly(data.phone);
                    if (/^09\d{9}$/.test(previousPhone)) {
                        fields.phoneTail.value = previousPhone.slice(2);
                        fields.phone.value = previousPhone;
                    }
                }
                if (fields.company && !fields.company.value) fields.company.value = data.company || '';
                if (fields.meeting_with && data.meeting_with && !fields.meeting_with.value) {
                    fields.meeting_with.value = data.meeting_with;
                    fireChange(fields.meeting_with);
                }
            })
            .catch(function () { if (!quiet) clearHint(); });
    }

    function lookup() {
        var code = asciiDigitsOnly(codeField.value);
        if (code.length !== 10) {
            clearHint();
            return;
        }
        lookupBy('code=' + encodeURIComponent(code), false);
    }

    codeField.addEventListener('blur', lookup);
    codeField.addEventListener('input', function () {
        if (asciiDigitsOnly(codeField.value).length === 10) {
            lookup();
        }
    });

    // همان جست‌وجو با تلفن همراه: به‌محض کامل شدن ۹ رقم پایانی.
    function lookupByPhone() {
        var tail = fields.phoneTail ? asciiDigitsOnly(fields.phoneTail.value) : '';
        if (tail.length !== 9) return;
        lookupBy('phone=' + encodeURIComponent('09' + tail), true);
    }
    if (fields.phoneTail) {
        fields.phoneTail.addEventListener('input', lookupByPhone);
        fields.phoneTail.addEventListener('blur', lookupByPhone);
    }

    // همان جست‌وجو با نام و نام خانوادگی (تطبیق دقیق)، هنگام خروج از فیلد نام.
    if (fields.full_name) {
        fields.full_name.addEventListener('blur', function () {
            var name = fields.full_name.value.trim();
            if (name.length < 3) return;
            if (asciiDigitsOnly(codeField.value).length === 10) return; // کد ملی خودش جست‌وجو را انجام داده است
            lookupBy('name=' + encodeURIComponent(name), true);
        });
    }
}());

// تأییدکننده(ها) فقط از تنظیم مقصد خوانده می‌شوند؛ مقصد چندتأییدکننده قابل انتخاب می‌شود.
(function () {
    'use strict';

    function parseApprovers(option) {
        if (!option) return [];
        var json = option.getAttribute('data-approvers');
        if (json) {
            try {
                var list = JSON.parse(json);
                if (Object.prototype.toString.call(list) === '[object Array]') {
                    return list.filter(function (item) { return typeof item === 'string' && item.trim() !== ''; });
                }
            } catch (ignore) {}
        }
        var single = option.getAttribute('data-approver');
        return single ? [single] : [];
    }

    function populate(destSelect, approverSelect, preferred) {
        var option = destSelect.options[destSelect.selectedIndex];
        var approvers = parseApprovers(option);
        while (approverSelect.firstChild) approverSelect.removeChild(approverSelect.firstChild);
        if (!approvers.length) {
            var placeholder = document.createElement('option');
            placeholder.value = '';
            placeholder.textContent = approverSelect.getAttribute('data-empty-label') || '—';
            approverSelect.appendChild(placeholder);
            return;
        }
        approvers.forEach(function (name) {
            var item = document.createElement('option');
            item.value = name;
            item.textContent = name;
            approverSelect.appendChild(item);
        });
        if (preferred && approvers.indexOf(preferred) !== -1) approverSelect.value = preferred;
    }

    [['traffic-meeting-with', 'traffic-approved-by'], ['traffic-edit-meeting-with', 'traffic-edit-approved-by']].forEach(function (pair) {
        var destSelect = document.getElementById(pair[0]);
        var approverSelect = document.getElementById(pair[1]);
        if (!destSelect || !approverSelect) return;
        destSelect.addEventListener('change', function () {
            populate(destSelect, approverSelect, approverSelect.value);
        });
        populate(destSelect, approverSelect, approverSelect.getAttribute('data-current') || '');
    });
}());

(function () {
    'use strict';
    var form = document.getElementById('traffic-report-form');
    var all = document.getElementById('traffic-report-all');
    if (!form || !all) return;

    var destinations = Array.prototype.slice.call(form.querySelectorAll('input[name="destinations[]"]'));
    all.addEventListener('change', function () {
        all.setCustomValidity('');
        destinations.forEach(function (input) { input.checked = all.checked; });
    });
    destinations.forEach(function (input) {
        input.addEventListener('change', function () {
            all.setCustomValidity('');
            if (!input.checked) all.checked = false;
            else all.checked = destinations.length > 0 && destinations.every(function (item) { return item.checked; });
        });
    });
    form.addEventListener('submit', function (event) {
        if (all.checked || destinations.some(function (input) { return input.checked; })) return;
        event.preventDefault();
        all.setCustomValidity('یک مقصد را انتخاب کنید یا گزینهٔ «همه» را علامت بزنید.');
        all.reportValidity();
    });
}());

/* جست‌وجوی آنی در سوابق تردد: به‌محض تایپ، ردیف‌های غیرمرتبط مخفی می‌شوند. */
// Server-side filtering and pagination: every search covers the whole permitted data set.
(function () {
    'use strict';
    function liveList(mode) {
        var form = document.getElementById('traffic-' + mode + '-form');
        var rows = document.getElementById('traffic-' + mode + '-rows');
        var status = document.getElementById('traffic-' + mode + '-status');
        var prev = document.getElementById('traffic-' + mode + '-prev');
        var next = document.getElementById('traffic-' + mode + '-next');
        if (!form || !rows || !status || !prev || !next) return;
        var offset = 0, revision = 0, timer = null, more = false;
        function schedule(reset, delay) {
            revision++;
            var current = revision;
            if (reset) offset = 0;
            prev.disabled = true; next.disabled = true;
            clearTimeout(timer);
            status.textContent = 'در حال دریافت اطلاعات…';
            timer = setTimeout(function () { load(current); }, delay);
        }
        function load(current) {
            var params = new URLSearchParams(new FormData(form));
            params.delete('action');
            params.set('page', 'traffic-control');
            params.set('traffic_api', mode);
            params.set('offset', String(offset));
            if (mode === 'history') {
                var urlParams = new URLSearchParams(window.location.search);
                ['sort_t', 'dir_t'].forEach(function (key) { if (urlParams.has(key)) params.set(key, urlParams.get(key)); });
            }
            fetch('index.php?' + params.toString(), { credentials: 'same-origin', headers: { 'Accept': 'application/json' } })
                .then(function (response) { return response.json().then(function (data) { if (!response.ok) throw new Error(data.error || 'دریافت اطلاعات ناموفق بود.'); return data; }); })
                .then(function (data) {
                    if (current !== revision) return;
                    more = !!data.more;
                    if (mode === 'history') {
                        rows.innerHTML = data.html; // HTML is escaped and rendered by the trusted server.
                        var empty = document.getElementById('traffic-history-empty');
                        if (empty) empty.hidden = data.count !== 0;
                    } else {
                        rows.replaceChildren();
                        var keys = ['serial', 'date', 'name', 'national', 'phone', 'company', 'meeting', 'approver', 'entry', 'exit', 'no_visit', 'with_car', 'with_mobile', 'description', 'recorder'];
                        data.items.forEach(function (item) {
                            var tr = document.createElement('tr');
                            keys.forEach(function (key) { var td = document.createElement('td'); td.textContent = item[key] || '—'; tr.appendChild(td); });
                            rows.appendChild(tr);
                        });
                    }
                    status.textContent = data.count ? 'نمایش ' + (offset + 1) + ' تا ' + (offset + data.count) + (more ? ' — نتایج بیشتری وجود دارد.' : ' — پایان نتایج.') : 'رکوردی با این معیارها یافت نشد.';
                    prev.disabled = offset === 0; next.disabled = !more;
                })
                .catch(function (error) {
                    if (current !== revision) return;
                    rows.replaceChildren();
                    status.textContent = error.message || 'ارتباط با سرور برقرار نشد.';
                    prev.disabled = true; next.disabled = true;
                });
        }
        form.addEventListener('input', function (event) {
            if (event.target.name === 'search' || event.target.matches('input[type=text], input[type=date]')) schedule(true, 300);
        });
        form.addEventListener('change', function () { schedule(true, 0); });
        if (mode === 'history') {
            form.addEventListener('submit', function (event) { event.preventDefault(); schedule(true, 0); });
            document.querySelectorAll('#traffic-history-table .log-sort').forEach(function (link) {
                link.addEventListener('click', function (event) {
                    event.preventDefault();
                    var url = new URL(link.href, window.location.href);
                    var values = new FormData(form);
                    ['search', 'range', 'open_only'].forEach(function (key) { url.searchParams.delete(key); if (values.has(key)) url.searchParams.set(key, values.get(key)); });
                    window.location.href = url.toString();
                });
            });
        }
        prev.addEventListener('click', function () { offset = Math.max(0, offset - 100); schedule(false, 0); });
        next.addEventListener('click', function () { if (more) { offset += 100; schedule(false, 0); } });
        if (mode === 'history') schedule(true, 0);
        else {
            var from = form.querySelector('[name=from_date]'), to = form.querySelector('[name=to_date]');
            if (from && to && from.value && to.value) schedule(true, 0);
        }
    }
    liveList('history'); liveList('report');
}());

(function () {
    'use strict';
    var alertBox = document.querySelector('[data-focus-form], #traffic-form-error');
    if (!alertBox) {
        return;
    }
    var formId = alertBox.getAttribute('data-focus-form');
    var name = alertBox.getAttribute('data-focus-field');
    var form = formId ? document.getElementById(formId) : null;
    var field = form && name ? form.querySelector('[name="' + name + '"]') : null;
    if (form && name === 'phone') field = form.querySelector('[data-phone-tail-for]') || field;
    if (alertBox.scrollIntoView) {
        alertBox.scrollIntoView({ block: 'center' });
    }
    if (field) {
        field.focus();
        if (field.select) {
            field.select();
        }
    } else if (alertBox.focus) {
        alertBox.focus();
    }
})();

// تردد خاص: با تیک «فقط اطلاع ورود»، فیلدهای اضافی پنهان و غیرفعال می‌شوند (ثبت ارسال نمی‌شوند).
(function () {
    'use strict';
    var box = document.getElementById('traffic-notice-only');
    var hint = document.getElementById('traffic-notice-hint');
    var form = document.getElementById('traffic-new-form');
    if (!box || !form) {
        return;
    }
    function apply() {
        var on = box.checked;
        var parts = form.querySelectorAll('.traffic-full-only');
        for (var i = 0; i < parts.length; i++) {
            parts[i].style.display = on ? 'none' : 'contents';
            var fields = parts[i].querySelectorAll('input, select, textarea');
            for (var j = 0; j < fields.length; j++) {
                fields[j].disabled = on;
            }
        }
        if (hint) {
            hint.hidden = !on;
        }
    }
    box.addEventListener('change', apply);
    form.addEventListener('reset', function () {
        setTimeout(apply, 0);
    });
    apply();
})();

// ورودی ساعت ثابت و صریح ۲۴ساعته؛ ورود چهار رقم مثل 1430 به 14:30 تبدیل می‌شود.
(function () {
    'use strict';
    var fields = document.querySelectorAll('.traffic-time-24h');
    if (!fields.length) return;
    var persian = '۰۱۲۳۴۵۶۷۸۹';
    var arabic = '٠١٢٣٤٥٦٧٨٩';
    function asciiDigits(value) {
        return String(value || '')
            .replace(/[۰-۹]/g, function (digit) { return String(persian.indexOf(digit)); })
            .replace(/[٠-٩]/g, function (digit) { return String(arabic.indexOf(digit)); })
            .replace(/：/g, ':');
    }
    fields.forEach(function (field) {
        field.addEventListener('input', function () {
            var current = asciiDigits(field.value);
            if (current.indexOf(':') !== -1) {
                if (current !== field.value) field.value = current;
                return;
            }
            var digits = current.replace(/\D/g, '').slice(0, 4);
            if (digits.length > 2) {
                var caret = field.selectionStart || current.length;
                field.value = digits.slice(0, 2) + ':' + digits.slice(2);
                var nextCaret = caret > 2 ? caret + 1 : caret;
                try { field.setSelectionRange(nextCaret, nextCaret); } catch (ignore) {}
            } else if (current !== field.value) {
                field.value = digits;
            }
        });
        field.addEventListener('blur', function () {
            var value = asciiDigits(field.value).trim();
            var match = value.match(/^(\d{1,2}):(\d{1,2})$/);
            if (match) field.value = match[1].padStart(2, '0') + ':' + match[2].padStart(2, '0');
        });
    });
}());


// پیش‌شمارهٔ ۰۹ ثابت است؛ فیلد قابل‌ویرایش فقط ۹ رقم پایانی را می‌پذیرد.
(function () {
    'use strict';
    var tails = document.querySelectorAll('[data-phone-tail-for]');
    var persian = '۰۱۲۳۴۵۶۷۸۹';
    var arabic = '٠١٢٣٤٥٦٧٨٩';
    function asciiDigits(value) {
        return String(value || '')
            .replace(/[۰-۹]/g, function (digit) { return String(persian.indexOf(digit)); })
            .replace(/[٠-٩]/g, function (digit) { return String(arabic.indexOf(digit)); });
    }
    tails.forEach(function (field) {
        var fullNumber = document.getElementById(field.getAttribute('data-phone-tail-for'));
        if (!fullNumber) return;
        function sync() {
            var digits = asciiDigits(field.value).replace(/\D/g, '');
            if (digits.length === 11 && digits.indexOf('09') === 0) digits = digits.slice(2);
            field.value = digits.slice(0, 9);
            fullNumber.value = field.value ? '09' + field.value : (field.required ? '09' : '');
        }
        field.addEventListener('input', sync);
        field.addEventListener('paste', function (event) {
            var text = event.clipboardData && event.clipboardData.getData('text');
            if (typeof text !== 'string') return;
            var digits = asciiDigits(text).replace(/\D/g, '');
            if (digits.length === 11 && digits.indexOf('09') === 0) digits = digits.slice(2);
            event.preventDefault();
            field.value = digits.slice(0, 9);
            sync();
        });
        sync();
    });
}());


