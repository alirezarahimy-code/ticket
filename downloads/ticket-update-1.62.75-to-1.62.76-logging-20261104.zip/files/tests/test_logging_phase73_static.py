from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]

def read(path):
    return (ROOT / path).read_text(encoding='utf-8')

def test_release_version_and_fingerprint_schema_are_aligned():
    assert read('VERSION').strip() == '1.62.76'
    assert 'fingerprint CHAR(64) NULL' in read('schema.sql')
    assert 'fingerprint CHAR(64) NULL' in read('install-empty-db.sql')
    migration = read('migrations/023-logging-fingerprint-v2.sql')
    assert 'information_schema.COLUMNS' in migration
    assert 'CHAR(64)' in migration and 'PREPARE' in migration
    result_migration = read('migrations/024-activity-result-default-unknown.sql')
    assert "DEFAULT ''unknown''" in result_migration
    assert "DEFAULT 'unknown'" in read('schema.sql')

def test_fingerprint_v2_is_shared_by_all_event_paths():
    core = read('lib/logging-core.php')
    csrf = read('lib/logging-csrf.php')
    replay = read('lib/logging-replay.php')
    assert 'function logging_fingerprint_v2' in core
    assert 'logging_fingerprint_current($definition[\'code\']' in csrf
    assert 'logging_fingerprint_current(' in replay
    assert 'logging_fingerprint_current($code, $context, $rawMessage)' in core

def test_cli_exception_handlers_and_trace_capture_are_enabled():
    csrf = read('lib/logging-csrf.php')
    assert "system_error_record('error', 'خطای نهایی‌نشده'" in csrf
    assert 'logging_exception_trace($exception, 12)' in csrf
    catalog = read('lib/log-catalog.php')
    assert "'stack_trace'" in catalog
    assert "PHP_SAPI === 'cli'" in csrf and 'STDERR' in csrf
    assert 'if (PHP_SAPI !== \'cli\') {' not in csrf

def test_audit_payload_is_built_before_db_and_session_snapshot_is_used():
    audit = read('lib/activity-audit.php')
    auth = read('lib/auth-scope.php')
    start = audit.index('function activity_log(array $data)')
    end = audit.index('function activity_log_view', start)
    body = audit[start:end]
    assert body.index("$event = [") < body.index('logging_store_activity($event)')
    assert "$_SESSION['audit_user']" in body
    assert "$_SESSION['audit_user']" in auth
    assert 'db()->prepare' not in body
    assert 'function activity_default_result' in audit

def test_replay_only_quarantines_structurally_invalid_lines():
    replay = read('lib/logging-replay.php')
    assert 'logging_replay_error_classify($lineError)' in replay
    assert "$lineError instanceof JsonException || $lineError instanceof UnexpectedValueException" in replay or "$exception instanceof JsonException || $exception instanceof UnexpectedValueException" in replay
    assert 'پس از ۸ تلاش' in replay or 'پس از ۸' in replay
    assert "'result'] ?? 'unknown'" in replay

def test_db_circuit_breaker_and_spool_stats_cache_are_present():
    core = read('lib/logging-core.php')
    assert 'function logging_db_circuit_should_skip' in core
    assert 'function logging_db_error_is_transient' in core
    assert 'LOCK_EX | LOCK_NB' in core
    assert 'function logging_spool_stats_cache_invalidate' in core
    assert "time() - 5" in core
