# راهنمای نصب، ارتقاء و بازگشت — مرکز درخواست (Request Center)

**نسخهٔ ماژول:** ۱.۶۲.۹۲ (کاندید)  **آخرین به‌روزرسانی:** ۱۴۰۵/۰۸/۱۶ (2026-11-07)
**وضعیت سند:** معتبر برای بستهٔ کاندید موجود در `downloads/ticket-update-1.62.90-to-1.62.92-request-center-rc-candidate-20261107.zip`.

> این راهنما جایگزین تصمیم‌های حاکمیتی (R6، T07، copy قانونی، تگ انتشار) نیست.
> تمام نصب‌ها روی سامانهٔ عملیاتی فقط پس از تأیید مالک و در یک پنجرهٔ نگهداری مشخص انجام می‌شود.

## ۱) دامنه و پیش‌نیازها

- PHP 8.2 با `pdo_mysql`، `pdo_sqlite`، `mbstring`، `xml`، `zip` (نصب SQLite برای محیط‌های آزمایشی)
- MariaDB 10.4+ / 10.11 (در CI هر دو بررسی می‌شوند)، `utf8mb4`، timezone معادل `Asia/Tehran` در اپ
- دسترسی `mariadb-dump`/`mysqldump` و `mariadb`/`mysql` برای بکاپ و اعمال مهاجرت
- گواهی `request-center.php` در دسترس وب (مجوز اجرای PHP مثل `index.php`)
- نسخهٔ پایهٔ هدف باید **۱.۶۲.۹۰** (موجودی `main`، کامیت `d30d7df`) باشد؛ مهاجرتهای ۰۳۲/۰۳۳/۰۳۴ روی آن موجود و اعمال‌شده‌اند.

## ۲) اصل ایمنی پیش از هر تغییری

همهٔ مراحل با این سه قانون شروع می‌شوند؛ هیچ‌کدام را رد نکنید:

1. بکاپ کامل دیتابیس و فایل کد مقصد را بگیرید و **بازآوری آن را روی یک دیتابیس/مسیر disposable آزمایشی سبز کنید.**
2. روی نسخهٔ نصب‌شده `cat VERSION` بزنید و مطمئن شوید `1.62.90` (یا همان نسخه‌ای که manifest می‌خواهد) است.
3. هیچ فایلی را دستی کپی نکنید؛ فقط بستهٔ رسمی (`system-update.php` یا overlay) و فقط از PR/کامیت ثبت‌شده استفاده کنید.

## ۳) نصب روی نسخهٔ تازه (Fresh Install)

1. سورس را از تگ/شاخهٔ تأییدشدهٔ مالک چیده کنید.
2. دیتابیس را با `install-empty-db.sql` بسازید (این مسیر شامل `request_center_appointments` نیز هست — قابلیت تکرار دارد).
3. `config.sample.php` را به `config.php` کپی و مقداردهی کنید (هر config محلی، هرگز در git ثبت نمی‌شود).
4. بررسی نصب:
   - `SHOW TABLES LIKE 'request_center_appointments';` → ۱ ردیف
   - `SHOW TABLES LIKE 'holidays';` → ۱ ردیف
   - `php -l request-center.php` و راهیابی صفحات `request-center.php` برای هر ۴ نقش با یک حساب تست.
5. دادهٔ اولیه را با بستهٔ `install.php` ادی‌گپ/پنل عادی انجام دهید؛ هیچ seed مصنوعی در این ماژول تصمیم گرفته نشده است.

## ۴) ارتقاء از ۱.۶۲.۹۰ به ۱.۶۲.۹۲ (مسیر پیش‌فرض)

### مرحلهٔ ۱ — بکاپ (قبل از هر چیزی)
```bash
mariadb-dump --single-transaction --quick --routines <dbname> | gzip > rc-upgrade-backup-$(date +%F).sql.gz
git -C <target> log --oneline -1   # باید کامیت دقیق ۱.۶۲.۹۰ را نشان دهد
```

### مرحلهٔ ۲ — اعمال بستهٔ ارتقا
دو مسیر، هر دو معتبر؛ یکی را انتخاب کنید:

- **مسیر رسمی (پیشنهادی):** از شمارهٔ کاربر Admin → «به‌روزرسانی سامانه» → بارگذاری `…rc-candidate-20261107.zip`.
  `system-update.php` به‌صورت خودکار ایمن‌زدایی مسیرها، بررسی `requires_version >= 1.62.90`، اعمال مهاجرت `035` (در صورت عدم ثبت در `schema_updates`) و ثبت نسخهٔ جدید را انجام می‌دهد. ساختار ZIP: `manifest.json` + `migrations/035-request-center-appointments.sql` + `files/…`.
- **مسیر دستی (فقط برای کارشناسان ارشد):**
  ```bash
  cd <target>
  git fetch origin && git checkout <release-commit>   # تگ/کامیت تأییدشدهٔ مالک، نه کاریهٔ محلی
  mariadb <dbname> < migrations/035-request-center-appointments.sql   # امن برای تکرار
  INSERT IGNORE INTO schema_updates (version, migration) VALUES ('1.62.92','035-request-center-appointments.sql');
  ```

### مرحلهٔ ۳ — بررسی پس از نصب (Regression smoke)
1. **ورود و خروج** با سه نقش (requester، agent، supervisor) و یک حساب primary_admin.
2. **چهار Workspace:** از منوی ماژول، هر Workspace بارگذاری شود؛ تعویض Workspace توسط کاربر چندنقشی کار کند و ناوبری با مجوزهای جدید نوسازی شود.
3. **ثبت یک درخواست واقعی-تست** (مثلاً «تست ارتقای مرکز درخواست») → تایید شود و `id` بازگردد.
4. **انتقال وضعیت**: ثبت → ارجاع → در انتظار کارشناس → بستن — و در هر مرحله تاریخچه (`activity_log`) رشد کند.
5. **تقویم شمسی**: باز کردن Workspace کارشناس → صفحهٔ تقویم → ثبت یک نوبت آزمایشی روی درخواست تست → لغو آن؛ شاهد `request_center_appointments` (۲ ردیف audit) و بروزرسانی SLA/OLA باشد.
6. **خروجی‌ها:** گزارش Excel از خروجی همان صفحه (مسیر `action=export_report`) باید ۲۰۰ و فایل قابل بازکردن بدهد.
7. **اعلان‌ها:** دست‌کم یک نوتیفیکیشن ناشی از نوبت به assignee رسیده باشد (جدول `notifications`) با كلیدهای `dedup_key` یکتا.
8. **بدون خطای PHP:** لاگ سطحِ هر Workspace خالی از `Fatal`/`Uncaught` باشد.

در صورت شکست هرکدام از ۲ تا ۷: **همان‌جا متوقف شوید و به بخش ۶ (بازگشت) بروید.**

## ۵) چک‌لیست پیش‌نیاز امنیتی

- [ ] CSRF روی همهٔ فرم‌ها و رجیستری RC سبز (`lib/http-post.php` الزامی است)
- [ ] دسترسی مستقیم به `modules/request-center/*` بدون bootstrap → ۴۰۴
- [ ] `Pages/*.php` بدون مجوز → ۴۰۳/۴۰۴ (تست ایستای `tests/test_request_center_access_matrix_static.py` در CI قفل شده)
- [ ] `detail.php` برای درخواست خارج از حوزهٔ کاربر → ۴۰۴ (نه «وجود دارد ولی ممنوع»)
- [ ] پیوست‌ها فقط از مسیرِ تأییدشدهٔ upload/redownload؛ هیچ مسیر ارجاعی فایل به کاربر نمی‌رود
- [ ] لاگ‌های حساس (رمز، توکن) در `activity_log`/`system_logs` هرگز ذخیره نمی‌شوند

## ۶) بازگشت (Rollback)

**سطح داده (قابل‌برگشت، بهتر):**
```bash
gunzip -c rc-upgrade-backup-YYYY-MM-DD.sql.gz | mariadb <dbname>   # روی هدف (یا clone آن) بازآوری کامل
```
**سطح کد (سریع):**
```bash
git -C <target> checkout <previous-release-tag-or-commit> && <redeploy/restart>
```
نکته‌های عملی:
- مهاجرت ۰۳۵ فقط `request_center_appointments` را می‌سازد؛ بازگشت کد بدون restore هم سامانه را خراب نمی‌کند (جدول به حال خود رها می‌شود) ولی **برای بهره‌برداری پیش‌فرض restore کامل + checkout قبلی است.**
- اگر نوبت‌های واقعی روی نسخهٔ جدید ثبت شده‌اند، آن‌ها را قبل از restore استخراج (`SELECT * …` یا خروجی اکسل) کنید؛restore آن‌ها را حذف می‌کند.
- پس از rollback، همان smoke بخش ۴-مطابق نسخهٔ قبلی را تکرار کنید تا ثِبات تأیید شود.

## ۷) موارد صریحاً بر عهدهٔ مالک (خارج از این راهنما)

- خروج PR #30 از Draft، merge به `main`، انتخاب نام نسخهٔ نهایی (VERSION شاخه اکنون ۱.۶۲.۹۲، جلوتر از main ۱.۶۲.۹۰) و تگ انتشار.
- تصمیم T07/D1 و هرگونه کژتویی سیاست Logging (D3).
- بارگذاری بسته در محیط عملیاتی، برنامهٔ نگهداری، ارتباط با بهره‌برداران.
- دریافت امضای پذیرش (پذیرش کاربران نمایندهٔ نقش‌ها) پس از نصب.

## ۸) پیوست: شواهد ساخت بستهٔ کاندید

- مسیر: `downloads/ticket-update-1.62.90-to-1.62.92-request-center-rc-candidate-20261107.zip`
- SHA-256: `fe98b36938d640bae018be217f3b3d5ec459f290056772f135dc002fd9f8b13d` (فایل کناری `.sha256` در همان پوشه) — بازسازی پس از اصلاح قفل ثبت نوبت (۶۱ فایل، ۳۴۱٬۰۰۰ بایت)
- اجزاء: `manifest.json` با `release_status=RC_CANDIDATE_NOT_FOR_PRODUCTION`، `migrations/035-…`، ۶۱ فایل به‌همراه `VERSION` (۱.۶۲.۹۲) و مستندات معماری
- ساخت و اعتبارسنجی لوکال: `python3 tools/build_rc_update.py` (CRC، مسیرهای امن، یکتایی مسیرها، تطبیق بایت‌به‌بایت manifest و sha256 هر فایل)

