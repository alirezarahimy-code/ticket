# بسته‌بندی نهایی — فازهای ۱ تا ۳ ارتقاء مرکز درخواست‌ها

**تاریخ:** ۲۰۲۶-۱۱-۰۷ | **نسخه:** ۱٫۰ | **شاخه‌های مربوط (به ترتیب):** `feature/request-center-module-1.62.88` (f952e02 — PR #30, base `main`) ← `arena/22d4eba7-ticket` (f8f0c44 — حاوی فاز ۲ و ۳ روی آن)

**معنای «بسته بودن» در این سند:** تمام کارها، راستی‌آزمایی‌ها و ریسک‌های شناخته‌شدهٔ سه فاز اول ثبت شده‌اند؛ محصول این سه فاز از نظر «چه بسازند و چه تضمینی بدهند» تعیین و تأیید شده است؛ هیچ بدهی یا قلمرو بازِ نامعلومی در این سه فاز باقی نمانده است. بسته بودن یعنی «نباید دیگر در فازهای بعد به این سه فاز رجوع کرد مگر با دستور صریح مالک پروژه». بسته بودن به‌معنی ادغام در `main`، تأیید نصب عملیاتی یا تحویل نهایی پروژه **نیست**.

> هشدار مهم: این سند هیچ‌یک از ادعاهای زیر را ندارد: کار روی `main` انجام شده، نصب عملیاتی شده است، مجوز ورود به محیط تولید صادر شده است، یا «ارتقاء» به عنوان یک محصول تحویل داده شده است. `main` هیچ‌کدام از کارهای این شاخه را در خود ندارد.

---

## ۱. دامنهٔ این سه فاز و نگاشت به سند معماری مصوب

| شمارهٔ این سند (شمارهٔ کار شاخه) | معادل در سند معماری | موضوع |
|---|---|---|
| فاز ۱ | فاز صفر + فاز یک | خط مبنا، ممیزی، ایجاد ماژول مستقل، خروج منطق از `index.php` |
| فاز ۲ | فاز یک (ادامه) | استقلال ماژول: مالکیت فیزیکی کد و قراردادهای RC در مسیرهای ماژول |
| فاز ۳ | فاز یک (ادامه) / پل به فاز چهار | چرخهٔ عمر Bridgeها: قرارداد مشترک POST و اجرای مستقل رجیستری اکشن‌های RC |

توجه: «فاز سهٔ سند» (تقویم کارشناسان) و «فاز چهار سند» (تکمیل UX و تحویل) جزو این بسته نیستند و عمداً بازند.

---

## ۲. وضعیت نهایی هر فاز

### فاز ۱ — خط‌مبنا و ایجاد ماژول (تحویل روی شاخهٔ `feature/request-center-module-1.62.88` (tip f952e02))

**تکمیل شده و بسته:**

- ممیزی AS-IS و شناخت schema (docs/architecture: AS-IS-AUDIT، DATABASE-DUMP-ASSESSMENT، DECISION-REGISTER)
- ورودی مستقل `request-center.php` با قرارداد **zero-DDL** و **fail-closed** روی schema ناقص (HTTP 503، بدون ترمیم) — با CI اثبات شده
- Repository فقط‌خواندنی با رعایت `ticket_scope()` و مجوزهای مشاهدهٔ رکوردمحور
- UI مدرن (فضاهای کاری درخواست‌دهنده/کارشناس/سوپروایزر/ادمین + صفحات analytics/reports/services/calendar/create/detail)
- `RequestCenterWorkflowService` — گذار رسمی وضعیت با قفل `FOR UPDATE` و guard هم‌زمانی
- انتقال مالکیت Actionهای RC از `index.php` به `modules/request-center/Actions/` (bridge سازگاری حفظ)
- Contract CI: گیت‌های T01–T06، T08، T09، T10، T11 — **PASS** روی هر دو MariaDB 10.4.32 و 10.11؛ T10 اثبات رقابت Claim بین ۵۰worker → دقیقاً یک برنده
- زیرآزمون manifest واقعی بستهٔ 1.62.88 برای T07 **PASS**

**قرمزهای شناخته‌شده (مصوب/خارج دامنه؛ به‌تصویب مالک):**

| مورد | وضعیت | تصمیم مالک |
|---|---|---|
| T07 replay کامل 001–033 | FAIL در هر دو MariaDB | D1: خارج از دامنه؛ مانع ادغام نیست |
| T04 کل سامانه (DDL در مسیر production) | باز | خارج از دامنهٔ RC؛ فقط قید fail-closed ورودی مستقل تضمین شده |
| Logging contract | FAIL (روی main هم قرمز فنری) | D3: خارج دامنه؛ هماهنگی با Logging مستقل لازم است |

### فاز ۲ — استقلال ماژول (تحویل به شاخهٔ `arena/22d4eba7-ticket` (tip f8f0c44))

**تکمیل شده و بسته:**

- برش‌ها (هر کدام با کامیت جدا، push شده): توابع دامنهٔ RC → `modules/request-center/lib/functions.php` (store_attachment/fetch_ticket/can_view_ticket/choose_handling_agent/ticket_allowed_transitions/notify_ticket_resolved/report_query_filters/…)؛ chrome مشترک → `lib/render.php`؛ endpoints GET/POST (export_report/download_attachment با قاعدهٔ relationship-محور `ticket_can_see_internal`، داشبورد `request_center_dashboard_rows`، `request_center_global_search`) → `modules/request-center/lib/endpoints.php`
- `index.php`: **۲۹۸۹ → ۲۴۴۱ خط** (جابه‌جایی کد به مالکیت ماژول؛ نه حذف)
- بایت‌به‌بایت دیده‌شد (SQL و بدنهٔ توابع؛ تنها استثنای مجاز: نام پارامتر `$searchUser` → `$user` در تابعِ تازه‌امضاشدهٔ ماژول)
- اصلاح Regression آزمون T04 (config نامعتبر از `da1fa4d` با بک‌اسلش مضاعف) — diagnostic اکنون تا انتها اجرا می‌شود
- نگهبان‌های three_views به مسیر ماژول هدایت شدند
- **دروازهٔ Phase-2 smoke در Contract CI** — اجرای واقعی HTTP: dashboard=200، search=200، export XLSX (بایت `PK`)، download=404
- ثبت فارسی: `docs/architecture/REQUEST-CENTER-PHASE2-EVIDENCE-REGISTER-FA.md` (بعد از این سند «بسته‌شده» علامت می‌خورد)

### فاز ۳ — چرخهٔ عمر Bridgeها / POST مستقل (تحویل شاخهٔ arena/22d4eba7-ticket)

**تکمیل شده و بسته:**

- پروتکل POST مشترک در `lib/http-post.php` (`post_context_begin` / `post_context_on_error`): CSRF/419، `logging_begin_operation`، shutdown-لاگر، rollback، `activity_log('post_action_failed')`، `app_error_log`، flash و redirect Goalهای legacy **یکسان**
- `index.php` حالا در ناحیهٔ ۴ فقط دو فراخوان دارد؛ رفتار تریت به‌طور diff دیده‌شد
- رجیستری ۱۹ اکشن RC در `modules/request-center/post-handler.php`؛ ورودی مستقل `request-center.php` اکنون POST-aware است: اکشن RC → مسیر ماژول؛ غیر RC → **forward درجا** (بدون redirect، payload سالم)
- `require_csrf()` در هر دو مسیر مشترک است؛ مسیر legacy به همان `dispatch.php` مستقیماً می‌رسد (هیچ تغییر رفتاری در ترافیک فعلی)
- smoke ×۳ جدید: POST بدون csrf = 419؛ `create_ticket` کامل با csrf از ورودی مستقل = 302 به `index.php?page=ticket&id=N` + ردیف واقعی `tickets` ساخته شد؛ اکشن ناشناخته → forward درجا 200
- سه باگ یافت‌شده با CI diagnostics و رف‌شده: (۱) نبود try/catch در runner مستقل → 500؛ (۲) نبود لایهٔ ریشهٔ org/inventory/cd-dvd؛ (۳) تداخل fixture smoke با fixture preflight روی `service_catalog.id=1`
- شاخهٔ workbench روی شاخهٔ feature است (`merge-base = f952e02`): `arena` = feature + تمام کارهای فاز ۲ و ۳
- ثبت فارسی: `docs/architecture/REQUEST-CENTER-PHASE3-BRIDGE-LIFECYCLE-FA.md`

---

## ۳. کارنامهٔ راستی‌آزمایی (نهایی این سه فاز)

| مورد | نتیجه |
|---|---|
| `Request Center T12 Scenario Characterization` (هر دو MariaDB) | **SUCCESS** در تمام pushهای فاز ۲ و ۳ (از جمله `f8f0c44`) |
| `Request Center Contract` (run `42379825414` و `42379983966`) | قرمزی **فقط** گام T07 replay تاریخی (D1)؛ گام‌های T01–T06/T08–T11 و **Phase-2 smoke سبز** (شامل دور کامل POST مستقل) |
| ۵ مجموعهٔ safety-static محلی | **33 passed** |
| `php -l` روی همهٔ فایل‌های جدید/تغییریافته | سبز |
| `git diff --check` | تمیز |
| موج‌سازی نقشهٔ ماشینی (`test_system_map_blocks`) | **قرمز روی شاخهٔ arena** — عمداً: بازتولید نقشه وظیفهٔ workflow شاخهٔ `feature/request-center-module-1.62.88` است (push به آن شاخه ربات refresh را اجرا می‌کند و Commit نقشه را می‌گذارد)؛ به‌جای دستی‌نویسی BLOCKS.json روی این شاخه، در گام ادغام حل می‌شود |

---

## ۴. تحویل‌های واقعی این سه فاز (چک‌لیست بستن)

- [x] ممیزی و Registryها (PHASE1/PHASE2/PHASE3 evidence registers)
- [x] ورودی مستقل GET (zero-DDL + fail-closed)
- [x] ورودی مستقل POST (registry RC، قرارداد legacy یکسان)
- [x] خروج کامل منطق RC از بدنهٔ `index.php` به ماژول (Bridgeها نازک و عمدی)
- [x] chrome مشترک و توابع دامنهٔ RC در مالکیت ماژول
- [x] Contract/T12 سبز باقی ماند در تمام تغییرات
- [x] stale CI (T04 config) کشف و رف شد
- [x] قرمزهای باقی‌مانده با D1/D3 مصوب مالک تفکیک شدند

---

## ۵. آنچه در این سه فاز نیست (و نباید دوباره به آن رجوع کرد جز با دستور مالک)

1. فرم‌های RC هنوز به `index.php` پست می‌زنند؛ ورودی مستقل POST فقط «ظرفیت اجرای آزموده‌شده» است — سوییچ فرم‌ها تصمیم بعدی مالک است و در صورت تأیید، کار مستقلی است.
2. `index.php` هنوز ۲۴۴۱ خط است: صفحات غیراین (تنظیمات/دارایی/غذا/سازمان/...)، تفکیک کامل فرایندها، و Bridgeهای عمدی. حذف این باقی‌مانده کار فازهای بعد است.
3. تکمیل چهار Workspace و ناوبری فضاهای کاری (فاز چهار سند)
4. تقویم کارشناسان/برنامه‌ریزی رسیدگی — فقط پیش‌نویس موجود است (AppointmentRepository + migration 035 + Pages/calendar.php + appointment-actions.php)؛ ظرفیت تیمی، تعاملات هم‌زمانی مقیاس‌بالا، اعلان و مجوزهای تیمی **نیامده است**
5. داشبوردها/گزارش‌ها/خروجی‌ها/تصمیم فناوری نهایی SATEL/OLA — در انحصار فاز چهار
6. بستهٔ نصب/راهنمای اپراتور/پیش‌نمایش نصب غیرعملیاتی/Restore هماهنگ ـ **انجام نشده**
7. VERSION/همگام‌سازی با `main` (شاخه 1.62.88 مقابل main 1.62.90) — مالک تصمیم نگرفته؛ طبق دستور قبلی شما عمداً متوقف
8. فایل‌های بیرون از دامنه (Logging، تعاملات، ambl سازمانی غیر RC) — تغییری داده نشده و نمی‌شود
9. T04 کل سامانه و DDL اسپرینت اصلی — خارج از اختیار این شاخه
10. T07 historical replay و Logging contract — با تصویب شما خارج از دامنه هستند

---

## ۶. قواعد نگشودن دوباره

- هیچ فایل/خط/قاعدهٔ تثبیت‌شدهٔ این سه فاز «به‌خاطر تمیزتر کردن» دست‌نمی‌خورد؛ هر تغییر آتی فقط با دستور صریح مالک و با گیت کامل (T12 + Contract + پنج مجموعهٔ static).
- Bridgeهای `Actions/*.php` و پروتکل‌های `lib/http-post.php` «نباید ساده شوند» مگر هنگام تصمیم R6 روی سوییچ تدریجی.
- `index.php` دیگر مقصد هیچ منطق جدید RC نیست؛ هر نیاز جدید RC فقط در `modules/request-center/` ثبت و با گیت می‌آید.
- قرمزهای معلوم (T07/Logging) دوباره به‌عنوان «باگ این پروژه» بحث نمی‌شوند؛ هر تغییر جدیدی این‌ها را بهانهٔ شکست نمی‌گیرد؛ آن‌ها فقط در مسیرهای تخصصی خودشان قابل بررسی‌اند.

---

## ۷. مسیرهای ادغام (تصمیم R6 — بر عهدهٔ مالک است)

نکتهٔ فنی مهم برای R6:

- شاخهٔ اجرای این PR (`feature/request-center-module-1.62.88`) شامل نتیجهٔ فاز ۱ است؛ شاخهٔ `arena/22d4eba7-ticket` = آن شاخه **+ فاز ۲ و ۳ + اصلاحیه‌های CI diagnostics**.
- من اجازه ندارم هیچ شاخهٔ دیگری را push کنم؛ مسیرها:
  - **الف)** شما صریحاً بگویید «PR داخلی از این شاخه به همان شاخه باز کن» ← یک PR کوچک `arena → feature` باز می‌کنم تا فاز ۲/۳ وارد PR #30 شود.
  - **ب)** شما بگویید « arena را به feature منتقل کن» ← اجازهٔ push مستقیم به feature می‌دهم و خط طی می‌شود، سپس workflow refresh-map در push بعدی feature خودش نقشهٔ ماشینی را می‌سازد (آزمون system_map_blocks این‌جا سبز می‌شود).
  - **ج)** ادغام به `main` ← فقط بعد از تصمیم قطعی VERSION/همگام‌سازی با main (شاخه 1.62.88 < main 1.62.90 هستند) و تأیید نهایی شما.

**هیچ‌کدام از الف/ب/ج بدون دستور شما انجام نمی‌شود؛ من «تأیید R6» را امضا نمی‌کنم.**

گام‌های لازم برای ادغام به main (پیش‌شرط‌های R6):

1. تصمیم صریح روی VERSION شاخه (ارتقا به 1.62.91 یا حل، یا ادغام گذشته)
2. همگام‌سازی با `main` (merge یا rebase — مالک انتخاب می‌کند)
3. بازنشانی VERSION و فایل‌های wrapper بستهٔ 1.62.88/به‌روزرسانی ZIP بسته
4. اجرای مجدد کامل CI روی tip جدید (Contract + T12 + safety static + system-map refresh خودکار)
5. تصمیم T07 و Logging: باقی‌ماندن یا تعیین تکلیف مستقل (خارج از این PR)
6. تصمیم درخواست پیش‌نمایش/بستهٔ نصب و تأیید نهایی قابل نصب بودن

---

## ۸. ضمیمه — آخرین tip مستقر وقتِ بستن

`f8f0c44` روی `arena/22d4eba7-ticket`؛ شامل تمام فاز ۲ و ۳ + diagnostics‌های CI؛ `merge-base(arena, feature) = f952e02` (tip فعلی PR #30). ۲۸ کامیت فاز ۲/۳ روی این شاخه + کامیت‌های diagnoستیک که خودکار از ربات CI اضافه شدند.
