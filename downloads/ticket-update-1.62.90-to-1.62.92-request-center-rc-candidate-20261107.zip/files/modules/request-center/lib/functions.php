<?php
declare(strict_types=1);

/**
 * قالب‌بندی نشده — توابع مالکیت مالک ماژول Request Center است.
 * انتقال بایت‌به‌بایت از index.php (برش فاز استقلال)؛ هیچ تغییری در بدنه مجاز نیست.
 * تعیین مالکیت: این توابع صرفاً دامنهٔ درخواست را پیاده می‌کنند؛ توابع مشترک
 * (layout/HTTP نرمال‌ساز) جای جدا دارند.
 */

function store_attachment(int $messageId, array $file): void
{
    if (($file['error'] ?? UPLOAD_ERR_NO_FILE) === UPLOAD_ERR_NO_FILE) {
        return;
    }
    if (($file['error'] ?? 1) !== UPLOAD_ERR_OK) {
        throw new RuntimeException('بارگذاری فایل انجام نشد.');
    }
    $max = (int) cfg('security.max_upload_mb', 8) * 1024 * 1024;
    $extension = strtolower(pathinfo((string) $file['name'], PATHINFO_EXTENSION));
    if ((int) $file['size'] > $max || !in_array($extension, (array) cfg('security.allowed_uploads', []), true)) {
        throw new RuntimeException('نوع یا حجم فایل مجاز نیست.');
    }
    $mime = 'application/octet-stream';
    $mimeChecked = false;
    if (function_exists('finfo_open')) {
        $finfo = finfo_open(FILEINFO_MIME_TYPE);
        if ($finfo) {
            $mime = (string) (finfo_file($finfo, (string) $file['tmp_name']) ?: $mime);
            $mimeChecked = true;
            finfo_close($finfo);
        }
    }
    $allowedMimes = [
        'pdf' => ['application/pdf'],
        'png' => ['image/png'],
        'jpg' => ['image/jpeg'],
        'jpeg' => ['image/jpeg'],
        'doc' => ['application/msword', 'application/octet-stream'],
        'docx' => ['application/vnd.openxmlformats-officedocument.wordprocessingml.document', 'application/zip'],
        'xls' => ['application/vnd.ms-excel', 'application/octet-stream'],
        'xlsx' => ['application/vnd.openxmlformats-officedocument.spreadsheetml.sheet', 'application/zip'],
        'txt' => ['text/plain', 'text/csv', 'application/octet-stream'],
        'zip' => ['application/zip', 'application/x-zip-compressed'],
    ];
    if ($mimeChecked && isset($allowedMimes[$extension]) && !in_array($mime, $allowedMimes[$extension], true)) {
        throw new RuntimeException('محتوای فایل با پسوند آن مطابقت ندارد.');
    }
    $directory = APP_ROOT . '/storage/uploads';
    if (!is_dir($directory) && !mkdir($directory, 0750, true) && !is_dir($directory)) {
        throw new RuntimeException('پوشه ذخیره فایل قابل ایجاد نیست.');
    }
    $stored = bin2hex(random_bytes(18)) . '.' . $extension;
    if (!move_uploaded_file((string) $file['tmp_name'], $directory . '/' . $stored)) {
        throw new RuntimeException('ذخیره فایل انجام نشد.');
    }
    try {
        $query = db()->prepare('INSERT INTO ticket_attachments (message_id, original_name, stored_name, mime, size_bytes) VALUES (?, ?, ?, ?, ?)');
        $query->execute([$messageId, basename((string) $file['name']), $stored, $mime, (int) $file['size']]);
    } catch (Throwable $exception) {
        @unlink($directory . '/' . $stored);
        throw $exception;
    }
}

function fetch_ticket(int $id): ?array
{
    $query = db()->prepare('SELECT t.*, c.name AS category_name, sc.name AS service_name, sc.code AS service_code, d.name AS department_name, ou.name AS requesting_unit_name, r.full_name AS requester_name, r.username AS requester_username, a.full_name AS assignee_name, ass.asset_tag, ass.hostname, tr.score AS rating_score, tr.comment AS rating_comment, tr.created_at AS rating_at FROM tickets t LEFT JOIN categories c ON c.id = t.category_id LEFT JOIN service_catalog sc ON sc.id = t.service_id LEFT JOIN departments d ON d.id = t.department_id LEFT JOIN org_units ou ON ou.id = t.requesting_unit_id JOIN users r ON r.id = t.requester_id LEFT JOIN users a ON a.id = t.assigned_to LEFT JOIN assets ass ON ass.id = t.asset_id LEFT JOIN ticket_ratings tr ON tr.ticket_id = t.id WHERE t.id = ? LIMIT 1');
    $query->execute([$id]);
    return $query->fetch() ?: null;
}

function can_view_ticket(array $ticket, array $user): bool
{
    return ticket_user_can_view($ticket, $user);
}

/**
 * ۱.۶۲.۶ — آیا زیرساخت چارت سازمانی برای تشخیص «مدیر سازمانی» در دسترس است؟
 * نتیجه کش می‌شود تا ثبت درخواست روی نصب‌های قدیمیِ بدون این جدول‌ها خطا نگیرد.
 */
function ticket_org_manager_rank_sql(): string
{
    static $ready = null;
    if ($ready === null) {
        try {
            db()->query('SELECT 1 FROM org_units LIMIT 1');
            db()->query('SELECT 1 FROM org_unit_managers LIMIT 1');
            $ready = true;
        } catch (Throwable) {
            $ready = false;
        }
    }
    return $ready
        ? 'CASE WHEN EXISTS (SELECT 1 FROM org_units ou WHERE ou.is_active = 1 AND (ou.manager_user_id = u.id OR EXISTS (SELECT 1 FROM org_unit_managers oum WHERE oum.unit_id = ou.id AND oum.user_id = u.id))) THEN 1 ELSE 0 END, '
        : '';
}

function choose_handling_agent(string $serviceGroup, ?int $departmentId = null, int $requesterId = 0): ?int
{
    $serviceGroup = in_array($serviceGroup, ['it', 'support'], true) ? $serviceGroup : 'it';
    $departmentId = (int) ($departmentId ?? 0);
    $loadJoin = ' LEFT JOIN tickets t ON t.assigned_to = u.id AND t.status NOT IN ("resolved", "closed", "cancelled")';
    // ۱.۶۲.۶ — مدیران چارت سازمانی (معاون/مدیر اداره) آخرِ صف ارجاع خودکار می‌روند تا اگر
    // نقش/پرچم اشتباهی (مثل «ادمین اصلی» شدن ناخواسته) داشته باشند، تا وقتی کاندیدای
    // واقعی فعال هست انتخاب نشوند. برای اصلاح ریشه‌ای، نقش‌ها از صفحهٔ سازمان ترمیم شوند.
    $orgManagerRank = ticket_org_manager_rank_sql();

    // مالک اصلی هر حوزه اولویت دارد: IT ← ادمین اصلی؛ پشتیبانی ← مدیر پشتیبانی.
    // اگر برای یک حوزه چند مالک فعال تعریف شده باشد، کمترین بارِ باز ملاک می‌شود.
    $ownerCondition = $serviceGroup === 'it'
        ? '(u.role = "primary_admin" OR (u.role = "admin" AND u.is_primary_admin = 1))'
        : 'u.role = "support_manager"';
    $candidateFields = 'u.id, u.role, u.is_active, u.is_primary_admin, u.department_id, u.is_it_agent, hu.code AS handling_unit_code';
    $routingTicket = ['requester_id' => $requesterId, 'service_group' => $serviceGroup, 'department_id' => $departmentId];
    $ownerQuery = db()->query('SELECT ' . $candidateFields . ' FROM users u LEFT JOIN handling_units hu ON hu.id = u.handling_unit_id' . $loadJoin . ' WHERE u.is_active = 1 AND ' . $ownerCondition . ' GROUP BY u.id, u.role, u.is_active, u.is_primary_admin, u.department_id, u.is_it_agent, hu.code ORDER BY ' . $orgManagerRank . 'COUNT(t.id), u.id');
    foreach ($ownerQuery->fetchAll() as $candidate) {
        if (ticket_assignee_is_eligible($routingTicket, $candidate, 'ticket_notification_user_can')) {
            return (int) $candidate['id'];
        }
    }

    // اگر مسئول اصلی غیرفعال/تعریف‌نشده باشد، فقط کارشناس همان حوزه جایگزین می‌شود.
    // عمداً دیگر به کارشناس حوزهٔ دیگر ارجاع نمی‌دهیم؛ در نبود جایگزین، درخواست در manager_review می‌ماند.
    $fallback = db()->prepare(
        'SELECT ' . $candidateFields . ' FROM users u '
        . 'LEFT JOIN handling_units hu ON hu.id = u.handling_unit_id'
        . $loadJoin
        . ' WHERE u.is_active = 1 AND u.role IN ("agent", "manager") AND hu.code = ?'
        // مدیر عادی فقط مسئول همان معاونت/واحدِ ثبت‌شده روی درخواست است؛ از معاونت دیگری انتخاب نشود.
        . ' AND (u.role <> "manager" OR (? > 0 AND u.department_id = ?))'
        . ' GROUP BY u.id, u.role, u.is_active, u.is_primary_admin, u.department_id, u.is_it_agent, hu.code ORDER BY ' . $orgManagerRank . 'COUNT(t.id), u.id'
    );
    $fallback->execute([$serviceGroup, $departmentId, $departmentId]);
    foreach ($fallback->fetchAll() as $candidate) {
        if (ticket_assignee_is_eligible($routingTicket, $candidate, 'ticket_notification_user_can')) {
            return (int) $candidate['id'];
        }
    }
    return null;
}

/**
 * مسیر مجاز تغییر وضعیت توسط کارکنان (مدل رسمی گردش درخواست).
 * new/manager_review -> assigned -> in_progress <-> waiting_user -> resolved -> (امتیاز کاربر) -> closed توسط سوپروایزر
 */
function ticket_allowed_transitions(string $from): array
{
    // pending یک وضعیت میراثی است؛ سیاست متمرکز در WorkflowService نگهداری می‌شود.
    return RequestCenterWorkflowService::allowedTransitions($from);
}
function ticket_requester_cancelable_statuses(): array
{
    // درخواست حل‌شده هم تا پیش از بسته‌شدن نهایی، با تأیید مسئول قابل لغو است.
    return ['new', 'manager_review', 'assigned', 'in_progress', 'waiting_user', 'pending', 'resolved'];
}

function ticket_requester_can_cancel_directly(array $ticket): bool
{
    return in_array((string) ($ticket['status'] ?? ''), ['new', 'manager_review'], true)
        && empty($ticket['assigned_to'])
        && empty($ticket['first_response_at'])
        && empty($ticket['resolved_at']);
}

function ticket_requester_can_cancel(array $ticket, array $user): bool
{
    return user_can($user, 'ticket.create')
        && (int) ($ticket['requester_id'] ?? 0) === (int) ($user['id'] ?? 0)
        && in_array((string) ($ticket['status'] ?? ''), ticket_requester_cancelable_statuses(), true)
        && empty($ticket['cancel_requested_at']);
}

/** اعلان «حل شد» به کاربر (برای ثبت امتیاز یا بازگشایی) و به مسئولان (برای پیگیری تأیید نهایی). */
function notify_ticket_resolved(int $ticketId, int $actorId): void
{
    $resolvedTicket = fetch_ticket($ticketId);
    if (!$resolvedTicket) {
        return;
    }
    notify_user((int) $resolvedTicket['requester_id'], 'ticket_resolved', 'درخواست شما انجام شد', 'درخواست ' . ticket_number($ticketId) . ' حل شد. لطفاً نتیجه را بررسی و امتیاز رضایت خود را ثبت کنید؛ اگر مشکل برطرف نشده است درخواست را بازگشایی کنید.', $ticketId);
    notify_ticket_staff($ticketId, 'ticket_resolved', 'درخواست حل شد و منتظر امتیاز کاربر است', 'درخواست ' . ticket_number($ticketId) . ' حل‌شده است و پس از ثبت امتیاز کاربر قابل تأیید نهایی است.', $actorId);
}

function report_query_filters(array $user): array
{
    [$scope, $params] = ticket_scope($user);
    $conditions = $scope !== '' ? [substr($scope, 6)] : [];
    $ticketColumns = db_table_columns('tickets');
    $status = valid_choice((string) ($_GET['status'] ?? ''), ['new', 'manager_review', 'assigned', 'in_progress', 'waiting_user', 'pending', 'resolved', 'closed', 'cancelled', 'active', 'all'], '');
    if ($status === 'active') {
        // «در حال پیگیری» = همهٔ وضعیت‌های باز (کارت داشبورد)
        $conditions[] = 't.status IN ("new", "manager_review", "assigned", "in_progress", "waiting_user", "pending")';
    } elseif ($status === 'resolved') {
        // «حل‌شده» در داشبورد شامل درخواست‌های بسته‌شده هم می‌شود
        $conditions[] = 't.status IN ("resolved", "closed")';
    } elseif ($status !== '' && $status !== 'all') {
        $conditions[] = 't.status = ?';
        $params[] = $status;
    }
    $priority = valid_choice((string) ($_GET['priority'] ?? ''), ['normal', 'urgent', 'critical'], '');
    if ($priority !== '') {
        $conditions[] = 't.priority = ?';
        $params[] = $priority;
    }
    $ticketType = valid_choice((string) ($_GET['ticket_type'] ?? ''), ['incident', 'request', 'problem', 'change'], '');
    if ($ticketType !== '' && isset($ticketColumns['ticket_type'])) {
        $conditions[] = 't.ticket_type = ?';
        $params[] = $ticketType;
    }
    $serviceGroup = valid_choice((string) ($_GET['service_group'] ?? ''), ['it', 'support'], '');
    if ($serviceGroup !== '' && isset($ticketColumns['service_group'])) {
        $conditions[] = 't.service_group = ?';
        $params[] = $serviceGroup;
    }
    foreach (['from' => '>=', 'to' => '<='] as $key => $operator) {
        $value = (string) ($_GET[$key] ?? '');
        $converted = jalali_input_to_gregorian($value, $key === 'to');
        if ($converted !== null) {
            $conditions[] = 't.created_at ' . $operator . ' ?';
            $params[] = $converted;
        }
    }
    foreach (['department_id', 'assigned_to'] as $key) {
        $value = (int) ($_GET[$key] ?? 0);
        if ($value > 0) {
            $conditions[] = 't.' . $key . ' = ?';
            $params[] = $value;
        }
    }
    $search = trim((string) ($_GET['q'] ?? ''));
    if ($search !== '') {
        $conditions[] = '(t.subject LIKE ? OR t.description LIKE ? OR r.full_name LIKE ?)';
        $params[] = '%' . $search . '%';
        $params[] = '%' . $search . '%';
        $params[] = '%' . $search . '%';
    }
    return [$conditions ? 'WHERE ' . implode(' AND ', $conditions) : '', $params];
}
