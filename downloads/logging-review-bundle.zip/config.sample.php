<?php
declare(strict_types=1);

/* Reference only. install.php creates config.php with fresh random secrets. */
return [
    'app' => [
        'name' => 'سامانه درخواست پشتیبانی',
        'logo' => '',
        'timezone' => 'Asia/Tehran',
        'base_url' => '',
        'key' => '',
    ],
    'database' => [
        'host' => '[MASKED-IP]',
        'port' => 3306,
        'name' => 'persian_ticketing',
        'user' => 'root',
        'password' => '[REDACTED]',
        'charset' => 'utf8mb4',
    ],
    'ldap' => [
        'enabled' => false,
        'host' => '',
        'port' => 389,
        'ssl' => false,
        'base_dn' => '',
        'bind_dn' => '',
        'bind_password' => '[REDACTED]',
        'domain_suffix' => '',
        'user_filter' => '(&(objectCategory=person)(objectClass=user)(sAMAccountName=%s))',
        'default_role' => 'user',
        'group_map' => [
            'agent' => [],
            'manager' => [],
            'supervisor' => [],
            'admin' => [],
        ],
    ],
    'security' => [
        'max_upload_mb' => 8,
        'allowed_uploads' => ['pdf', 'png', 'jpg', 'jpeg', 'doc', 'docx', 'xls', 'xlsx', 'txt', 'zip'],
        'inventory_token' => '[REDACTED]',
    ],
    'food_ticket' => [
        'odbc_driver' => 'Microsoft Access Driver (*.mdb, *.accdb)',
        'web_url' => 'http://[MASKED-IP]:8080/',
        'sso_key' => '',
    ],
];
