<?php

declare(strict_types=1);

/**
 * actions/food-order-actions.php — ۱ اکشن POST تصمیم سرپرست روی درخواست لغو سفارش غذا (۱.۶۳ r5).
 *
 * شرح فارسی بخش‌ها (به ترتیب داخل فایل):
 *   food_order_cancel_decide  رسیدگی سرپرست به درخواست لغو غذای ثبت‌شده
 *
 * این اکشن تا ۱.۶۲.۹۵ داخل actions/supervisor-actions.php بود؛ چون به دامنهٔ سفارش غذا مربوط است
 * (نه مرکز درخواست)، در ۱.۶۳ به فایل مستقل منتقل شد. متن اکشن از ۱.۶۲.۹۵ بایت‌به‌بایت منتقل شده است.
 * این فایل فقط از دل بلوک try در «ناحیهٔ ۴» index.php با require بارگذاری می‌شود و در
 * همان حوزهٔ متغیرها اجرا می‌شود.
 */

// محافظ: این فایل فقط از طریق index.php بارگذاری می‌شود؛ دسترسی مستقیم ممنوع.
if (!defined('APP_ROOT')) {
    http_response_code(404);
    exit;
}

        // ───── گروه اکشن: تصمیم لغو سفارش غذا ─────
        if ($action === 'food_order_cancel_decide') {
            $reviewer = require_login();
            if (!function_exists('food_order_cancel_request_decide')) {
                throw new RuntimeException('ماژول سفارش غذا در دسترس نیست.');
            }
            $result = food_order_cancel_request_decide(
                (int) ($_POST['request_id'] ?? 0),
                (string) ($_POST['decision'] ?? ''),
                $reviewer,
                (string) ($_POST['note'] ?? '')
            );
            flash('success', (string) ($result['message'] ?? 'انجام شد.'));
            redirect('index.php?page=dashboard#food-cancel-requests');
        }
