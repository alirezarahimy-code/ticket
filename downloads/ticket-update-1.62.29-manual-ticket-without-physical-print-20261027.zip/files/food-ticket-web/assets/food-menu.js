/* مدیر برنامهٔ غذایی در پنل چاپ فیش. */
(function (global) {
  'use strict';

  var Cal = global.FoodOrderCalendar;
  var canMenu = global.FOOD_TICKET_CAN_MENU_EDIT === true;
  var canClose = global.FOOD_TICKET_CAN_ORDER_CLOSE === true;
  var isPrimary = global.FOOD_TICKET_IS_PRIMARY_ADMIN === true;
  var apiBase = String(global.FOOD_TICKET_API_BASE || '');
  var csrf = String(global.FOOD_TICKET_CSRF || '');
  var root = null;
  var state = {
    mounted: false,
    tab: canMenu ? 'calendar' : 'orders',
    year: 1405,
    month: 1,
    selectedDate: '',
    ordersDate: '',
    statisticsFrom: '',
    statisticsTo: '',
    statisticsMode: 'food',
    statistics: [],
    statisticsLoaded: false,
    statisticsRequestId: 0,
    deliveredReport: [],
    deliveredReportLoaded: false,
    deliveredReportRange: '',
    deliveredReportRequestId: 0,
    deliveredReportLoading: false,
    deliveredReportEmployeeCount: 0,
    deliveredReportGuestCount: 0,
    deliveredReportView: 'list',
    deliveredReportSort: { key: 'row', dir: 'asc' },
    deliveredReportFields: ['row', 'national_code', 'employee_number', 'full_name', 'food_name', 'food_date', 'punch_time', 'record_type', 'menu_no', 'delivered_at'],

    monthData: null,
    catalog: [],
    orders: [],
    ordersLoaded: false,
    ordersSort: { key: 'row', dir: 'asc' },
    ordersView: 'list',
    status: null,
    loading: false,
    loadingOrders: false,
    loadingCancelRequests: false,
    cancelRequests: [],
    loadingStatistics: false,
    error: '',
    notice: '',
    pendingImpact: null,
    pendingImpactExpected: 0,
    pendingImpactMessage: '',
    activeRequest: 0,
  };

  function esc(value) {
    return String(value == null ? '' : value).replace(/[&<>"']/g, function (m) {
      return ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' })[m];
    });
  }
  function faDigits(value) { return String(value).replace(/[0-9]/g, function (d) { return '۰۱۲۳۴۵۶۷۸۹'[Number(d)]; }); }
  function asciiDigits(value) {
    return String(value == null ? '' : value).replace(/[۰-۹٠-٩]/g, function (d) {
      var p = '۰۱۲۳۴۵۶۷۸۹'.indexOf(d); return p >= 0 ? String(p) : String('٠١٢٣٤٥٦٧٨٩'.indexOf(d));
    });
  }
  function isoFromJalali(value) {
    var normalized = asciiDigits(value).trim().replace(/[.-]/g, '/');
    var match = normalized.match(/^(\d{4})\/(\d{1,2})\/(\d{1,2})$/);
    if (!match || !Cal) return null;
    try {
      var year = Number(match[1]), month = Number(match[2]), day = Number(match[3]);
      if (month < 1 || month > 12 || day < 1 || day > Cal.monthLength(year, month)) return null;
      return Cal.isoDate(year, month, day);
    } catch (e) { return null; }
  }
  function jalaliFromIso(iso) {
    if (!Cal || !iso) return '';
    try {
      var d = Cal.jalaliDateFromIso(iso);
      return d ? String(d[0]).padStart(4, '0') + '/' + String(d[1]).padStart(2, '0') + '/' + String(d[2]).padStart(2, '0') : '';
    } catch (e) { return ''; }
  }
  function normalizeIsoDate(value) {
    var normalized = asciiDigits(value).trim();
    if (/^\d{4}-\d{2}-\d{2}$/.test(normalized)) {
      try { return Cal && Cal.jalaliDateFromIso(normalized) ? normalized : null; } catch (e) { return null; }
    }
    return isoFromJalali(normalized);
  }
  function jalaliMonthFromIso(iso) {
    if (!Cal || !iso) return null;
    try { var d = Cal.jalaliDateFromIso(iso); return d ? [Number(d[0]), Number(d[1])] : null; } catch (e) { return null; }
  }
  function localTodayIso() {
    var d = new Date();
    return d.getFullYear() + '-' + String(d.getMonth() + 1).padStart(2, '0') + '-' + String(d.getDate()).padStart(2, '0');
  }
  function monthKey() { return String(state.year).padStart(4, '0') + '-' + String(state.month).padStart(2, '0'); }
  function monthTitle() { return Cal.months[state.month - 1] + ' ' + faDigits(state.year); }
  function getDay(iso) { return state.monthData && state.monthData.days ? state.monthData.days[iso] || null : null; }
  function activeOrderCount(day) {
    if (!day || !Array.isArray(day.items)) return 0;
    return day.items.reduce(function (sum, item) { return sum + Number(item.order_count || 0); }, 0);
  }
  function holiday(iso, day) {
    if (day && day.holiday_title) return day.holiday_title;
    var list = global.ITSM_HOLIDAYS || [];
    var jalali = jalaliFromIso(iso);
    for (var i = 0; i < list.length; i++) {
      var item = list[i] || {};
      if (String(item.date || '').slice(0, 10) === iso || String(item.jalali || '').replace(/-/g, '/') === jalali) return item.title || 'تعطیل رسمی';
    }
    return '';
  }
  function buildUrl(route, params) {
    var query = params ? new URLSearchParams(params).toString() : '';
    var base = apiBase;
    if (!base) base = 'index.php?page=food-ticket&food_api=';
    return base + encodeURIComponent(String(route).replace(/^\/+/, '').replace(/^api\//, '')) + (query ? '&' + query : '');
  }
  async function request(route, params, options) {
    var opts = Object.assign({ method: 'GET', credentials: 'same-origin', headers: {} }, options || {});
    opts.headers = Object.assign({ 'Content-Type': 'application/json' }, opts.headers || {});
    if (opts.method !== 'GET' && csrf) opts.headers['X-CSRF-Token'] = csrf;
    var response = await fetch(buildUrl(route, params), opts);
    var text = await response.text();
    var payload = {};
    try { payload = text ? JSON.parse(text) : {}; } catch (e) {
      var parseError = new Error(response.ok ? 'پاسخ نامعتبر از سرور دریافت شد.' : ('خطای سرور ' + response.status));
      parseError.status = response.status; throw parseError;
    }
    if (!response.ok) {
      var error = new Error(payload.error || payload.message || ('خطای سرویس ' + response.status));
      error.status = response.status; error.payload = payload; throw error;
    }
    return payload || {};
  }
  function notify(message, bad) {
    state.notice = String(message || '');
    state.error = bad ? state.notice : '';
    if (!bad) state.notice = String(message || '');
    render();
  }

  function navTabs() {
    var tabs = [];
    if (canMenu) tabs.push(['calendar', 'برنامهٔ روزانه'], ['catalog', 'بانک غذا']);
    if (canClose) {
      var cancelCount = (state.cancelRequests || []).length;
      var cancelLabel = 'درخواست‌های لغو' + (cancelCount ? (' (' + faDigits(cancelCount) + ')') : '');
      tabs.push(['orders', 'سفارش‌های روز'], ['cancel-requests', cancelLabel], ['statistics', 'آمار سفارش‌ها']);
    }
    return '<div class="fm-tabs" role="tablist">' + tabs.map(function (tab) {
      return '<button class="fm-tab ' + (state.tab === tab[0] ? 'active' : '') + '" type="button" role="tab" aria-selected="' + (state.tab === tab[0] ? 'true' : 'false') + '" data-fm-tab="' + tab[0] + '">' + tab[1] + '</button>';
    }).join('') + '</div>';
  }

  function renderCalendar() {
    if (!state.monthData && state.loading) return '<div class="fm-card fm-spinner">در حال خواندن برنامهٔ ماه…</div>';
    var days = state.monthData && state.monthData.days ? state.monthData.days : {};
    var cells = Cal.monthCells(state.year, state.month);
    var weekdayHeaders = Cal.weekdays.map(function (name) { return '<div class="fo-weekday" role="columnheader">' + esc(name) + '</div>'; }).join('');
    var cellsHtml = cells.map(function (cell) {
      var day = days[cell.iso] || null;
      var holidayName = holiday(cell.iso, day);
      var meals = day && Array.isArray(day.items) ? day.items : [];
      var orderState = day && day.order_status ? day.order_status : '';
      var count = activeOrderCount(day);
      var status = holidayName ? 'تعطیل رسمی' : (orderState === 'closed' ? 'سفارش بسته' : orderState === 'open' && meals.some(function (x) { return x.food_active !== false; }) ? 'سفارش باز' : (meals.length ? 'غذا غیرفعال' : 'بدون برنامه'));
      var classes = ['fo-day'];
      var adjacentAttrs = cell.isCurrentMonth ? '' : ' disabled aria-disabled="true" tabindex="-1"';
      if (!cell.isCurrentMonth) classes.push('is-adjacent');
      if (cell.isWeekend) classes.push('is-weekend');
      if (holidayName) classes.push('is-holiday');
      if (cell.iso === (state.status && state.status.today ? state.status.today : '')) classes.push('is-today');
      if (orderState === 'closed') classes.push('is-closed');
      if (count > 0) classes.push('has-order');
      if (state.selectedDate === cell.iso) classes.push('fm-day is-selected');
      var tip = [cell.jalali, status, holidayName, meals.map(function (x) { return x.food_name + (x.food_active === false ? ' (غیرفعال)' : ''); }).join('، '), count ? faDigits(count) + ' سفارش فعال' : ''].filter(Boolean).join(' • ');
      var mealText = meals.map(function (item) { return '<span class="fo-day-meal">' + esc(item.food_name) + (item.food_active === false ? ' · غیرفعال' : '') + '</span>'; }).join('');
      if (count) mealText += '<span class="fo-day-count">' + faDigits(count) + ' سفارش فعال</span>';
      var orderMarker = count ? '<span class="fo-day-order-marker" title="' + faDigits(count) + ' سفارش فعال">✓ ' + faDigits(count) + ' سفارش</span>' : '';
      return '<button class="' + classes.join(' ') + '" type="button" data-fm-day="' + esc(cell.iso) + '" data-fm-current="' + (cell.isCurrentMonth ? '1' : '0') + '" data-has-food="' + (meals.length ? '1' : '0') + '" data-has-order="' + (count ? '1' : '0') + '" data-tooltip="' + esc(tip) + '" aria-label="' + esc(cell.jalali + '، ' + status + (holidayName ? '، ' + holidayName : '') + (meals.length ? '، ' + meals.map(function (x) { return x.food_name; }).join('، ') : '') + (count ? '، ' + faDigits(count) + ' سفارش فعال' : '')) + '"' + adjacentAttrs + '><span class="fo-day-number-row"><span class="fo-day-number">' + faDigits(cell.day) + '</span>' + (holidayName ? '<span class="fo-day-status is-holiday">تعطیل</span>' : '') + '</span><span class="fo-day-status ' + (orderState === 'open' ? 'is-open' : orderState === 'closed' ? 'is-closed' : '') + '">' + esc(status) + '</span>' + orderMarker + '<span class="fo-day-meals">' + mealText + '</span></button>';
    }).join('');
    return '<div class="fm-grid"><div class="fm-card fm-calendar-card"><div class="fm-toolbar"><div><h3>برنامهٔ غذایی — ' + esc(monthTitle()) + '</h3></div><div class="fm-actions"><button class="btn secondary" type="button" data-fm-action="month-prev">ماه قبل</button><button class="btn secondary" type="button" data-fm-action="month-today">امروز</button><button class="btn secondary" type="button" data-fm-action="month-next">ماه بعد</button></div></div><div class="fo-calendar-grid" role="grid" aria-label="تقویم برنامه غذایی">' + weekdayHeaders + cellsHtml + '</div><div class="fo-legend"><span><i class="legend-open"></i> روز باز</span><span><i class="legend-closed"></i> روز بسته</span><span><i class="legend-holiday"></i> تعطیل رسمی / پنجشنبه و جمعه</span><span><i class="legend-order"></i> سفارش ثبت‌شده</span><span><i class="legend-today"></i> امروز</span></div></div>' + renderDayEditor() + '</div>';
  }

  function renderDayEditor() {
    if (!state.selectedDate) return '<div class="fm-card"><div class="fm-empty">یک روز از تقویم انتخاب کنید.</div></div>';
    var iso = state.selectedDate;
    var day = getDay(iso);
    var scheduled = day && Array.isArray(day.items) ? day.items : [];
    var scheduledIds = scheduled.map(function (item) { return Number(item.food_id); });
    var title = jalaliFromIso(iso);
    var inactiveSchedule = scheduled.filter(function (item) { return item.food_active === false; });
    var dayReadOnly = state.status && state.status.today && iso < state.status.today;
    var impactPending = Boolean(state.pendingImpact && state.pendingImpact.date === iso);
    var editorLocked = Boolean(state.daySaving || impactPending || (day && day.order_status === 'closed' && !canClose) || (dayReadOnly && !isPrimary));
    var lockedMessage = day && day.order_status === 'closed' && !canClose ? 'این روز بسته است؛ برای تغییر برنامهٔ روز بسته مجوز food.order_close لازم است.' : (dayReadOnly && !isPrimary ? 'روز گذشته فقط‌خواندنی است؛ فقط ادمین اصلی می‌تواند برنامه‌اش را اصلاح کند.' : '');
    var choiceHtml = function (food) {
      var included = scheduledIds.indexOf(Number(food.id)) >= 0;
      var inactive = !food.active;
      var label = food.food_name + (inactive ? ' · غیرفعال' : '');
      var disabled = editorLocked || (inactive && !included);
      return '<label class="fm-food-check"><input type="checkbox" name="food_ids" value="' + Number(food.id) + '" ' + (included ? 'checked' : '') + (disabled ? ' disabled' : '') + '><span>' + esc(label) + (inactive && included ? ' (فقط حفظ/حذف از برنامه)' : '') + '</span></label>';
    };
    // دسته‌ها ریشه‌اند: «+» غذاهای دسته را دو ستونه باز می‌کند و «-» جمع می‌کند.
    // بدنه همیشه در فرم می‌ماند (فقط hidden)، پس تیک‌های انتخاب‌شده هنگام جمع/باز شدن گم نمی‌شوند.
    var choices = catalogCategoryNames().map(function (name) {
      var foods = (state.catalog || []).filter(function (food) { return (food.category || 'سایر') === name; });
      if (!foods.length) return '';
      var open = !!dayCatalogOpen[name];
      var picked = foods.filter(function (food) { return scheduledIds.indexOf(Number(food.id)) >= 0; }).length;
      return '<div class="fm-cat-group' + (open ? ' open' : '') + '">'
        + '<button type="button" class="fm-cat-toggle" data-fm-daycat="' + esc(name) + '" aria-expanded="' + (open ? 'true' : 'false') + '">'
        + '<span class="fm-cat-sign" aria-hidden="true">' + (open ? '-' : '+') + '</span>'
        + '<strong>' + esc(name) + '</strong>'
        + '<span class="fm-small">' + faDigits(String(foods.length)) + ' غذا' + (picked ? ' · ' + faDigits(String(picked)) + ' انتخاب‌شده' : '') + '</span></button>'
        + '<div class="fm-cat-items fm-food-checks"' + (open ? '' : ' hidden') + '>' + foods.map(choiceHtml).join('') + '</div></div>';
    }).join('');
    var selectedStatus = day && day.order_status ? day.order_status : 'open';
    var statusControl = canClose
      ? '<fieldset class="fm-field fm-status-choice"><legend>وضعیت سفارش‌گیری</legend><label class="fm-radio"><input type="radio" name="order_status" value="open" ' + (selectedStatus === 'open' ? 'checked' : '') + (editorLocked ? ' disabled' : '') + '>باز</label><label class="fm-radio"><input type="radio" name="order_status" value="closed" ' + (selectedStatus === 'closed' ? 'checked' : '') + (editorLocked ? ' disabled' : '') + '>بسته</label></fieldset>'
      : '<div class="fm-alert">وضعیت روز: ' + esc(selectedStatus === 'closed' ? 'بسته' : 'باز') + ' — برای تغییر وضعیت دسترسی food.order_close لازم است.</div>';
    var impactButtonsDisabled = state.daySaving ? ' disabled' : '';
    var pending = state.pendingImpact && state.pendingImpact.date === iso ? '<div class="fm-confirm-box"><strong>' + esc(state.pendingImpactMessage || 'این تغییر سفارش فعال را لغو می‌کند.') + '</strong><span>برای انجام تغییر و ثبت لغوها، تأیید کنید. حذف فیزیکی سفارش انجام نمی‌شود.</span><button class="btn danger" type="button" data-fm-action="confirm-impact"' + impactButtonsDisabled + '>تأیید و ادامه</button><button class="btn secondary" type="button" data-fm-action="cancel-impact"' + impactButtonsDisabled + '>بازگشت</button></div>' : '';
    var message = state.dayError ? '<div class="fm-alert error">' + esc(state.dayError) + '</div>' : '';
    var itemsLabel = state.catalog.length ? '<div class="fm-cat-list">' + choices + '</div>' : '<div class="fm-empty">ابتدا از تب «بانک غذا» حداقل یک غذا ثبت کنید.</div>';
    return '<div class="fm-card"><div class="fm-toolbar"><div><h3>ویرایش برنامهٔ ' + esc(faDigits(title)) + '</h3><span class="fm-small">برای هر روز حداکثر سه گزینهٔ غذا می‌توانید ثبت کنید.</span></div>' + '' + '</div>' + (day && day.holiday_title ? '<div class="fm-alert warn">تعطیل رسمی: ' + esc(day.holiday_title) + ' — در صورت تصمیم سازمان، سفارش باز می‌تواند برقرار باشد.</div>' : '') + (lockedMessage ? '<div class="fm-alert warn">' + esc(lockedMessage) + '</div>' : '') + (inactiveSchedule.length ? '<div class="fm-alert warn">این برنامه شامل غذای غیرفعال است. آن را می‌توان برای حفظ سوابق نگه داشت یا پس از تأیید حذف کرد؛ سفارش جدید برای آن غذا ثبت نمی‌شود.</div>' : '') + message + pending + '<form id="fm-day-form" class="fm-day-editor"><div class="fm-field fm-food-selection"><div class="fm-food-selection-head"><strong>غذاهای این روز</strong><span class="fm-small">برای آینده؛ بدون تغییر سفارش‌های گذشته</span></div>' + '<div class="fm-food-search"><input type="search" data-fm-day-search placeholder="جستجوی غذا..." autocomplete="off" aria-label="جستجوی غذا"></div>' + itemsLabel + '</div>' + (canClose ? statusControl : '') + '<label class="fm-field">یادداشت کوتاه<input name="note" maxlength="255" value="' + esc(day && day.note ? day.note : '') + '" placeholder="اختیاری" ' + (editorLocked ? 'disabled' : '') + '></label><div class="fm-actions"><button class="btn primary" type="submit" ' + (editorLocked ? 'disabled' : '') + '>ذخیره برنامه</button><button class="btn secondary" type="button" data-fm-action="reload-month">بازخوانی</button></div></form></div>';
  }

  var FOOD_CATEGORY_ORDER = ['کبابی', 'خورشتی', 'ساندویچ', 'پلو', 'خوراک', 'رژیمی', 'سایر'];
  var catalogOpen = {};
  var dayCatalogOpen = {};

  function categoryOptions(selected) {
    return FOOD_CATEGORY_ORDER.map(function (name) {
      return '<option value="' + esc(name) + '"' + (name === (selected || 'سایر') ? ' selected' : '') + '>' + esc(name) + '</option>';
    }).join('');
  }

  function catalogCategoryNames() {
    var names = FOOD_CATEGORY_ORDER.slice();
    (state.catalog || []).forEach(function (food) {
      var name = food.category || 'سایر';
      if (names.indexOf(name) < 0) names.push(name);
    });
    return names;
  }

  function foodCardHtml(food) {
    return '<form class="fm-bank-item" data-fm-catalog-edit>'
      + '<input type="hidden" name="id" value="' + Number(food.id) + '">'
      + '<label class="fm-bank-field">نام غذا<input type="text" name="food_name" maxlength="190" value="' + esc(food.food_name) + '" aria-label="نام غذا"></label>'
      + '<label class="fm-bank-field">دسته‌بندی<select name="category" aria-label="دسته‌بندی">' + categoryOptions(food.category) + '</select></label>'
      + '<label class="fm-bank-field">وضعیت<select name="active" aria-label="وضعیت"><option value="1" ' + (food.active ? 'selected' : '') + '>فعال</option><option value="0" ' + (!food.active ? 'selected' : '') + '>غیرفعال</option></select></label>'
      + '<button class="btn secondary" type="submit">ذخیره</button>'
      + '</form>';
  }

  function renderCatalog() {
    var catalog = state.catalog || [];
    var groups = catalogCategoryNames().map(function (name) {
      var foods = catalog.filter(function (food) { return (food.category || 'سایر') === name; });
      var open = !!catalogOpen[name];
      var body = '';
      if (open) {
        body = foods.length
          ? '<div class="fm-bank-grid fm-cat-grid">' + foods.map(foodCardHtml).join('') + '</div>'
          : '<div class="fm-empty">در این دسته غذایی ثبت نشده است.</div>';
      }
      return '<div class="fm-cat-group' + (open ? ' open' : '') + '">'
        + '<button type="button" class="fm-cat-toggle" data-fm-cat="' + esc(name) + '" aria-expanded="' + (open ? 'true' : 'false') + '">'
        + '<span class="fm-cat-sign" aria-hidden="true">' + (open ? '-' : '+') + '</span>'
        + '<strong>' + esc(name) + '</strong>'
        + '<span class="fm-small">' + faDigits(String(foods.length)) + ' غذا</span></button>'
        + body + '</div>';
    }).join('');
    var list = catalog.length ? '<div class="fm-cat-list">' + groups + '</div>' : '<div class="fm-empty">غذایی ثبت نشده است.</div>' + groups;
    return '<div class="fm-card"><div class="fm-toolbar"><div><h3>بانک غذا</h3><span class="fm-small">هر غذا یک بار و با یک نام ثبت می‌شود؛ نام تکراری پذیرفته نمی‌شود. دسته‌بندی‌ها ریشه‌اند: با «+» غذاهای آن دسته (دو ستونه) باز می‌شود و با «-» جمع می‌شود. غیرفعال‌سازی به‌جای حذف فیزیکی انجام می‌شود. غذای استفاده‌شده در تقویم قابل تغییر نام نیست تا سابقهٔ سفارش حفظ شود.</span></div></div>'
      + '<form id="fm-catalog-add" class="fm-catalog-form"><label class="fm-field">نام غذای جدید<input type="text" name="food_name" maxlength="190" required placeholder="مثلاً چلو مرغ"></label><label class="fm-field">دسته‌بندی<select name="category" aria-label="دسته‌بندی غذای جدید">' + categoryOptions('سایر') + '</select></label><button class="btn primary" type="submit">افزودن غذا</button></form>'
      + list + '</div>';
  }

  var ORDER_COLUMNS = [
    { key: 'row', label: 'ردیف' },
    { key: 'national_code', label: 'کد ملی' },
    { key: 'employee_number', label: 'کد پرسنلی' },
    { key: 'full_name', label: 'نام' },
    { key: 'food_name', label: 'غذا' },
    { key: 'food_date', label: 'تاریخ غذا' },
    { key: 'reserve_at', label: 'ثبت رزرو' },
    { key: 'status_label', label: 'وضعیت' },
    { key: 'record_type', label: 'نوع ثبت' },
  ];

  function orderSortValue(row, key, index) {
    if (key === 'row') return index;
    if (key === 'reserve_at') return (row.reserve_date || '') + ' ' + (row.reserve_time || '');
    if (key === 'status_label') return row.status === 'active' ? 0 : 1;
    if (key === 'record_type') return row.is_proxy ? 1 : 0;
    return row[key] == null ? '' : row[key];
  }

  function sortOrderRows(rows) {
    var key = state.ordersSort.key;
    var dir = state.ordersSort.dir === 'desc' ? -1 : 1;
    var decorated = rows.map(function (row, index) {
      return { row: row, index: index, value: orderSortValue(row, key, index) };
    });
    decorated.sort(function (a, b) {
      var c;
      if (typeof a.value === 'number' && typeof b.value === 'number') c = a.value - b.value;
      else c = String(a.value).localeCompare(String(b.value), 'fa', { numeric: true });
      if (c === 0) c = a.index - b.index;
      return c * dir;
    });
    return decorated.map(function (d) { return d.row; });
  }

  function orderRowHtml(row, position) {
    var active = row.status === 'active';
    var recordType = row.is_proxy ? 'نیابتی' : 'شخصی';
    return '<tr><td>' + faDigits(position + 1) + '</td><td>' + esc(faDigits(row.national_code || '—')) + '</td><td>' + esc(faDigits(row.employee_number || '—')) + '</td><td>' + esc(row.full_name || '—') + '</td><td>' + esc(row.food_name || '—') + '</td><td>' + esc(faDigits(jalaliFromIso(row.food_date))) + '</td><td>' + esc(faDigits(jalaliFromIso(row.reserve_date))) + ' ' + esc(faDigits((row.reserve_time || '').slice(0, 5))) + '</td><td><span class="fm-order-state ' + (active ? '' : 'cancelled') + '">' + (active ? 'فعال' : 'لغوشده') + '</span></td><td>' + recordType + '</td></tr>';
  }

  function orderTableHtml(rows) {
    var sorted = sortOrderRows(rows);
    var s = state.ordersSort;
    var head = ORDER_COLUMNS.map(function (col) {
      var mark = s.key === col.key ? (s.dir === 'desc' ? ' ▼' : ' ▲') : '';
      return '<th><button type="button" class="fm-sort-btn" data-fm-sort="' + col.key + '">' + esc(col.label) + mark + '</button></th>';
    }).join('');
    var body = sorted.map(function (row, i) { return orderRowHtml(row, i); }).join('');
    return '<table class="fm-rows" data-no-sort><thead><tr>' + head + '</tr></thead><tbody>'
      + (body || '<tr><td colspan="' + ORDER_COLUMNS.length + '" class="fm-empty">برای این روز سفارشی پیدا نشد.</td></tr>')
      + '</tbody></table>';
  }

  function orderByMenuHtml(rows) {
    var groups = {};
    rows.forEach(function (row) {
      var key = Number(row.menu_no || 0);
      (groups[key] = groups[key] || []).push(row);
    });
    var keys = Object.keys(groups).map(Number).sort(function (a, b) {
      if (a === 0) return 1;
      if (b === 0) return -1;
      return a - b;
    });
    if (!keys.length) return orderTableHtml([]);
    return keys.map(function (key) {
      var list = groups[key];
      var title = key > 0 ? 'منوی ' + faDigits(key) : 'بدون منو';
      var foods = [];
      list.forEach(function (row) { if (row.food_name && foods.indexOf(row.food_name) < 0) foods.push(row.food_name); });
      return '<div class="fm-menu-group"><h4>' + esc(title) + ' — ' + esc(foods.join('، ') || '—')
        + ' <span class="fm-small">(' + faDigits(list.length) + ' سفارش)</span></h4>' + orderTableHtml(list) + '</div>';
    }).join('');
  }

  var DELIVERED_REPORT_COLUMNS = [
    { key: 'row', label: 'ردیف' },
    { key: 'national_code', label: 'کد ملی' },
    { key: 'employee_number', label: 'کد پرسنلی' },
    { key: 'full_name', label: 'نام و نام خانوادگی' },
    { key: 'food_name', label: 'نوع غذا' },
    { key: 'food_date', label: 'تاریخ غذا' },
    { key: 'punch_time', label: 'ساعت تردد' },
    { key: 'record_type', label: 'نوع فیش' },
    { key: 'menu_no', label: 'شماره منو' },
    { key: 'delivered_at', label: 'زمان تحویل' },
  ];
  var deliveredFieldsStorageKey = 'itsm-food-printed-delivery-report-fields-v1';
  function readDeliveredReportFields() {
    try {
      var saved = global.localStorage && global.localStorage.getItem(deliveredFieldsStorageKey);
      var parsed = saved ? JSON.parse(saved) : null;
      if (!Array.isArray(parsed)) return null;
      var allowed = DELIVERED_REPORT_COLUMNS.map(function (column) { return column.key; });
      var fields = parsed.filter(function (key, index) { return allowed.indexOf(key) >= 0 && parsed.indexOf(key) === index; });
      return fields.length ? fields : null;
    } catch (error) { return null; }
  }
  function saveDeliveredReportFields(fields) {
    try { if (global.localStorage) global.localStorage.setItem(deliveredFieldsStorageKey, JSON.stringify(fields)); } catch (error) { /* storage may be disabled */ }
  }
  state.deliveredReportFields = readDeliveredReportFields() || state.deliveredReportFields;

  function deliveredReportFieldValue(row, key, position) {
    if (key === 'row') return faDigits(position + 1);
    if (key === 'national_code') return faDigits(row.national_code || '—');
    if (key === 'employee_number') return faDigits(row.employee_number || '—');
    if (key === 'full_name') return row.full_name || '—';
    if (key === 'food_name') return row.food_name || '—';
    if (key === 'food_date') return faDigits(jalaliFromIso(row.food_date) || '—');
    if (key === 'punch_time') return faDigits((row.punch_time || '').slice(0, 5) || '—');
    if (key === 'record_type') return row.event_type === 'guest' ? 'مهمان' : 'پرسنل';
    if (key === 'menu_no') return Number(row.menu_no || 0) > 0 ? 'منوی ' + faDigits(row.menu_no) : (row.event_type === 'guest' ? 'مهمان' : 'بدون منو');
    if (key === 'delivered_at') return faDigits(String(row.delivered_at || '—').replace(/-/g, '/').slice(0, 16));
    return '—';
  }
  function selectedDeliveredReportColumns() {
    var selected = Array.isArray(state.deliveredReportFields) ? state.deliveredReportFields : [];
    return DELIVERED_REPORT_COLUMNS.filter(function (column) { return selected.indexOf(column.key) >= 0; });
  }
  function sortDeliveredReportRows(rows) {
    var key = state.deliveredReportSort.key;
    var direction = state.deliveredReportSort.dir === 'desc' ? -1 : 1;
    return rows.map(function (row, index) {
      var value = key === 'row' ? index : key === 'menu_no' ? Number(row.menu_no || 0) : (row[key] || '');
      if (key === 'record_type') value = row.event_type === 'guest' ? 1 : 0;
      return { row: row, index: index, value: value };
    }).sort(function (a, b) {
      var cmp = typeof a.value === 'number' && typeof b.value === 'number'
        ? a.value - b.value : String(a.value).localeCompare(String(b.value), 'fa', { numeric: true });
      return (cmp || a.index - b.index) * direction;
    }).map(function (item) { return item.row; });
  }
  function deliveredReportTableHtml(rows) {
    var sorted = sortDeliveredReportRows(rows);
    var columns = selectedDeliveredReportColumns();
    if (!columns.length) return '<div class="fm-empty">حداقل یک فیلد گزارش را انتخاب کنید.</div>';
    var blocks = columns.length <= 3 ? 3 : (columns.length <= 5 ? 2 : 1);
    var head = '';
    for (var block = 0; block < blocks; block++) {
      columns.forEach(function (column, colIndex) {
        var mark = block === 0 && state.deliveredReportSort.key === column.key ? (state.deliveredReportSort.dir === 'desc' ? ' ▼' : ' ▲') : '';
        var divider = block > 0 && colIndex === 0 ? ' class="fm-order-block-start"' : '';
        head += '<th' + divider + '><button type="button" class="fm-sort-btn" data-fm-delivery-sort="' + column.key + '">' + esc(column.label + mark) + '</button></th>';
      });
    }
    var body = [];
    for (var line = 0; line < Math.ceil(sorted.length / blocks); line++) {
      var cells = '';
      for (var group = 0; group < blocks; group++) {
        var position = line * blocks + group;
        var row = sorted[position];
        columns.forEach(function (column, colIndex) {
          var divider = group > 0 && colIndex === 0 ? ' class="fm-order-block-start"' : '';
          if (!row) { cells += '<td class="fm-order-empty-cell' + (divider ? ' fm-order-block-start' : '') + '"></td>'; return; }
          cells += '<td' + divider + '>' + esc(deliveredReportFieldValue(row, column.key, position)) + '</td>';
        });
      }
      body.push('<tr>' + cells + '</tr>');
    }
    return '<table class="fm-rows fm-order-report-table' + (blocks > 1 ? ' is-compact' : '') + '" data-no-sort><thead><tr>' + head + '</tr></thead><tbody>'
      + (body.join('') || '<tr><td colspan="' + (columns.length * blocks) + '" class="fm-empty">در این بازه فیش چاپ‌شده و تحویل‌شده‌ای ثبت نشده است.</td></tr>')
      + '</tbody></table>';
  }
  function deliveredReportByMenuHtml(rows) {
    var groups = {};
    rows.forEach(function (row) {
      var key = Number(row.menu_no || 0);
      (groups[key] = groups[key] || []).push(row);
    });
    var keys = Object.keys(groups).map(Number).sort(function (a, b) {
      if (a === 0) return 1;
      if (b === 0) return -1;
      return a - b;
    });
    if (!keys.length) return deliveredReportTableHtml([]);
    return keys.map(function (key) {
      var list = groups[key];
      var title = key > 0 ? 'منوی ' + faDigits(key) : (list.every(function (row) { return row.event_type === 'guest'; }) ? 'فیش مهمان' : 'بدون منو');
      var foods = [];
      list.forEach(function (row) { if (row.food_name && foods.indexOf(row.food_name) < 0) foods.push(row.food_name); });
      return '<div class="fm-menu-group"><h4>' + esc(title) + ' — ' + esc(foods.join('، ') || '—')
        + ' <span class="fm-small">(' + faDigits(list.length) + ' فیش)</span></h4>' + deliveredReportTableHtml(list) + '</div>';
    }).join('');
  }
  function deliveredReportOrderedRows() {
    var rows = state.deliveredReport || [];
    if (state.deliveredReportView !== 'menu') return sortDeliveredReportRows(rows);
    var groups = {};
    rows.forEach(function (row) {
      var key = Number(row.menu_no || 0);
      (groups[key] = groups[key] || []).push(row);
    });
    return Object.keys(groups).map(Number).sort(function (a, b) {
      if (a === 0) return 1;
      if (b === 0) return -1;
      return a - b;
    }).reduce(function (all, key) { return all.concat(sortDeliveredReportRows(groups[key])); }, []);
  }
  function renderPrintedDeliveryReport() {
    var fields = DELIVERED_REPORT_COLUMNS.map(function (column) {
      var checked = state.deliveredReportFields.indexOf(column.key) >= 0 ? ' checked' : '';
      return '<label class="fm-report-field"><input type="checkbox" data-fm-delivery-field="' + column.key + '"' + checked + '><span>' + esc(column.label) + '</span></label>';
    }).join('');
    var viewBar = '<div class="fm-view-switch"><button class="btn ' + (state.deliveredReportView === 'list' ? 'primary' : 'secondary') + '" type="button" data-fm-action="delivered-report-view" data-view="list">فهرست یکجا</button><button class="btn ' + (state.deliveredReportView === 'menu' ? 'primary' : 'secondary') + '" type="button" data-fm-action="delivered-report-view" data-view="menu">نمایش بر اساس منو</button></div>';
    var dateRange = jalaliFromIso(state.statisticsFrom || '') + (state.statisticsFrom === state.statisticsTo ? '' : ' تا ' + jalaliFromIso(state.statisticsTo || ''));
    var results = state.deliveredReportLoading
      ? '<div class="fm-spinner">در حال دریافت فهرست فیش‌های تحویل‌شده…</div>'
      : '<div class="fm-delivery-counts"><div><span>پرسنل</span><strong>' + faDigits(state.deliveredReportEmployeeCount) + '</strong></div><div><span>فیش مهمان چاپ‌شده</span><strong>' + faDigits(state.deliveredReportGuestCount) + '</strong></div></div>'
        + viewBar + '<div class="fm-table-wrap fm-delivery-report-results">' + (state.deliveredReportView === 'menu' ? deliveredReportByMenuHtml(state.deliveredReport) : deliveredReportTableHtml(state.deliveredReport)) + '</div>';
    var actionsEnabled = state.deliveredReportLoaded && !state.deliveredReportLoading;
    return '<section class="fm-card fm-daily-orders fm-printed-delivery-report"><div class="fm-toolbar"><div><h3>فیش‌های چاپ‌شده و غذای تحویل‌شده</h3><span class="fm-small">بازه: ' + esc(faDigits(dateRange || '—')) + ' — پرسنل فقط با فیش چاپ‌شده و وضعیت تحویل‌شده؛ مهمان با فیش چاپ‌شده. وضعیت تحویل در سامانه از ثبت چاپ می‌آید و تأیید مستقل دریافت غذا نیست.</span></div><div class="fm-actions"><button class="btn secondary" type="button" data-fm-action="delivered-report-export"' + (actionsEnabled ? '' : ' disabled') + '>استخراج Excel</button><button class="btn secondary" type="button" data-fm-action="delivered-report-print"' + (actionsEnabled ? '' : ' disabled') + '>چاپ</button></div></div>'
      + '<div class="fm-report-fields"><strong>فیلدهای گزارش</strong>' + fields + '</div>'
      + (state.deliveredReportLoaded || state.deliveredReportLoading ? results : '<div class="fm-empty">برای نمایش گزارش، بازهٔ تاریخ آمار سفارش‌ها را انتخاب کنید.</div>')
      + '</section>';
  }
  async function loadPrintedDeliveryReport(fromDate, toDate) {
    var from = normalizeIsoDate(fromDate || '');
    var to = normalizeIsoDate(toDate || '');
    if (!from || !to || from > to) return;
    var key = from + '|' + to;
    if (state.deliveredReportRange === key && (state.deliveredReportLoaded || state.deliveredReportLoading)) return;
    state.deliveredReportRange = key;
    state.deliveredReportLoaded = false;
    state.deliveredReportLoading = true;
    state.deliveredReport = [];
    var requestId = ++state.deliveredReportRequestId;
    render();
    try {
      var response = await request('food-menu/printed-delivery', { from: from, to: to });
      if (requestId !== state.deliveredReportRequestId) return;
      state.deliveredReport = Array.isArray(response.items) ? response.items : [];
      state.deliveredReportEmployeeCount = Number(response.employee_count || 0);
      state.deliveredReportGuestCount = Number(response.guest_count || 0);
      state.deliveredReportLoaded = true;
      state.error = '';
    } catch (error) {
      if (requestId !== state.deliveredReportRequestId) return;
      state.deliveredReport = [];
      state.deliveredReportRange = '';
      state.error = error.message || 'گزارش فیش‌های تحویل‌شده بارگذاری نشد.';
    } finally {
      if (requestId === state.deliveredReportRequestId) {
        state.deliveredReportLoading = false;
        render();
      }
    }
  }
  function exportPrintedDeliveryReport() {
    if (!state.deliveredReportLoaded || state.deliveredReportLoading) return;
    var columns = selectedDeliveredReportColumns();
    if (!columns.length) return;
    var rows = deliveredReportOrderedRows().map(function (row, index) {
      return columns.map(function (column) { return deliveredReportFieldValue(row, column.key, index); });
    });
    var exportApi = global.ITSM_LIST_SORT;
    if (exportApi && typeof exportApi.exportXlsx === 'function') {
      exportApi.exportXlsx('فیش‌های چاپ‌شده و تحویل‌شده ' + faDigits(jalaliFromIso(state.statisticsFrom) || ''), columns.map(function (column) { return column.label; }), rows, 'food-delivered-' + state.statisticsFrom + '-' + state.statisticsTo, null);
      return;
    }
    global.location.href = buildUrl('food-menu/printed-delivery-export', {
      from: state.statisticsFrom, to: state.statisticsTo,
      fields: columns.map(function (column) { return column.key; }).join(','), view: state.deliveredReportView,
    });
  }
  function printPrintedDeliveryReport() {
    if (!state.deliveredReportLoaded || state.deliveredReportLoading) return;
    printScopedReport('.fm-printed-delivery-report .fm-delivery-report-results', 'fm-print-delivered-report');
  }

  function renderOrders() {
    var fallbackDate = state.ordersDate || state.selectedDate || (state.status && state.status.today) || localTodayIso();
    var inputDate = jalaliFromIso(fallbackDate) || '';
    var dateLabel = faDigits(inputDate || '—');
    var actionsEnabled = state.ordersLoaded && !state.loadingOrders;
    var rows = state.orders || [];
    var viewButton = function (view, label) {
      return '<button class="btn ' + (state.ordersView === view ? 'primary' : 'secondary') + '" type="button" data-fm-action="orders-view" data-orders-view="' + view + '">' + label + '</button>';
    };
    var viewBar = '<div class="fm-view-switch">' + viewButton('list', 'فهرست یکجا') + viewButton('menu', 'نمایش بر اساس منو') + '</div>';
    var body = state.ordersView === 'menu' ? orderByMenuHtml(rows) : orderTableHtml(rows);
    var daily = '<section class="fm-card fm-daily-orders"><div class="fm-toolbar"><div><h3>سفارش‌های روز</h3><span class="fm-small">تاریخ: ' + esc(dateLabel) + ' — فهرست سفارش‌های تاریخ انتخاب‌شده</span></div></div><form id="fm-orders-date" class="fm-order-date"><label class="fm-field">تاریخ روز شمسی<input type="text" name="date" data-jalali inputmode="numeric" placeholder="۱۴۰۵/۰۷/۰۱" value="' + esc(faDigits(inputDate)) + '" required></label><button class="btn primary" type="submit">مشاهده</button><button class="btn secondary" type="button" data-fm-action="orders-today">امروز</button><button class="btn secondary" type="button" data-fm-action="orders-export"' + (actionsEnabled ? '' : ' disabled') + '>استخراج Excel</button><button class="btn secondary" type="button" data-fm-action="orders-print"' + (actionsEnabled ? '' : ' disabled') + '>چاپ</button></form>'
      + (state.loadingOrders ? '<div class="fm-spinner">در حال بارگذاری سفارش‌ها…</div>' : viewBar + '<div class="fm-table-wrap fm-manager-data-warning">' + body + '</div>')
      + '</section>';
    return daily;
  }

  function renderCancelRequests() {
    var rows = state.cancelRequests || [];
    var body;
    if (state.loadingCancelRequests) {
      body = '<div class="fm-spinner">در حال بارگذاری درخواست‌های لغو…</div>';
    } else if (!rows.length) {
      body = '<div class="fm-empty">درخواست لغو بازی برای روزهای بسته‌شده نیست.</div>';
    } else {
      body = '<div class="fm-table-wrap"><table class="fm-rows"><thead><tr><th>تاریخ غذا</th><th>نام پرسنل</th><th>غذا</th><th>درخواست‌دهنده</th><th>عملیات</th></tr></thead><tbody>'
        + rows.map(function (row) {
          return '<tr><td>' + esc(faDigits(row.food_date_jalali || jalaliFromIso(row.food_date) || row.food_date || '')) + '</td><td>' + esc(row.employee_name || '—') + '</td><td>' + esc(row.food_name || '—') + '</td><td>' + esc(row.requester_name || '—') + '</td><td>'
            + '<button class="btn danger" type="button" data-fm-action="cancel-req-approve" data-id="' + Number(row.id) + '">لغو سفارش</button> '
            + '<button class="btn secondary" type="button" data-fm-action="cancel-req-reject" data-id="' + Number(row.id) + '">رد درخواست</button></td></tr>';
        }).join('') + '</tbody></table></div>';
    }
    return '<section class="fm-card"><div class="fm-toolbar"><div><h3>درخواست لغو روزهای بسته‌شده</h3><span class="fm-small">کاربر وقتی روز سفارش بسته است درخواست می‌فرستد. همین فهرست در داشبورد مدیر پشتیبانی و مدیر اصلی هم هست؛ اعلان در زنگولهٔ سامانه ثبت می‌شود.</span></div><button class="btn secondary" type="button" data-fm-action="cancel-req-reload">تازه‌سازی</button></div>' + body + '</section>';
  }

  function renderStatistics() {
    var fallbackDate = state.selectedDate || (state.status && state.status.today) || localTodayIso();
    var from = jalaliFromIso(state.statisticsFrom || fallbackDate) || '';
    var to = jalaliFromIso(state.statisticsTo || fallbackDate) || '';
    var mode = state.statisticsMode === 'employee' ? 'employee' : 'food';
    var modeTitle = mode === 'employee' ? 'آمار سفارش نفرات' : 'آمار نوع غذا';
    var rangeText = from === to ? faDigits(from) : faDigits(from) + ' تا ' + faDigits(to);
    var actionsEnabled = state.statisticsLoaded && !state.loadingStatistics;
    var result = '';
    if (state.loadingStatistics) {
      result = '<div class="fm-spinner">در حال محاسبهٔ آمار…</div>';
    } else if (!state.statisticsLoaded) {
      result = '<div class="fm-empty">برای مشاهده، بازهٔ موردنظر را انتخاب کنید.</div>';
    } else if (mode === 'employee') {
      var people = state.statistics || [];
      var peopleRows = [];
      for (var line = 0; line < Math.ceil(people.length / 3); line++) {
        var cells = '';
        for (var group = 0; group < 3; group++) {
          var person = people[line * 3 + group];
          if (person) {
            cells += '<td>' + faDigits(line * 3 + group + 1) + '</td><td>' + esc(person.full_name || '—') + '</td><td>' + faDigits(Number(person.count || 0)) + '</td>';
          } else {
            cells += '<td class="fm-statistics-empty-cell"></td><td class="fm-statistics-empty-cell"></td><td class="fm-statistics-empty-cell"></td>';
          }
        }
        peopleRows.push('<tr>' + cells + '</tr>');
      }
      result = '<div class="fm-table-wrap fm-statistics-results fm-statistics-results--people"><table class="fm-rows"><thead><tr><th>ردیف</th><th>نام پرسنل</th><th>تعداد</th><th>ردیف</th><th>نام پرسنل</th><th>تعداد</th><th>ردیف</th><th>نام پرسنل</th><th>تعداد</th></tr></thead><tbody>' + (peopleRows.join('') || '<tr><td colspan="9" class="fm-empty">در بازهٔ انتخاب‌شده سفارش فعالی ثبت نشده است.</td></tr>') + '</tbody></table></div>';
    } else {
      var foodRows = (state.statistics || []).map(function (item, index) {
        return '<tr><td>' + faDigits(index + 1) + '</td><td>' + esc(item.food_name || '—') + '</td><td>' + faDigits(Number(item.count || 0)) + '</td></tr>';
      }).join('');
      result = '<div class="fm-table-wrap fm-statistics-results"><table class="fm-rows"><thead><tr><th>ردیف</th><th>نوع غذا</th><th>تعداد</th></tr></thead><tbody>' + (foodRows || '<tr><td colspan="3" class="fm-empty">در بازهٔ انتخاب‌شده سفارشی ثبت نشده است.</td></tr>') + '</tbody></table></div>';
    }
    return '<section class="fm-card fm-statistics"><div class="fm-toolbar"><div><h3>' + modeTitle + '</h3><span class="fm-small">بازه: ' + esc(rangeText) + '</span></div></div><form id="fm-statistics-date" class="fm-statistics-form"><div class="fm-stats-modes" role="radiogroup" aria-label="نوع آمار"><label class="fm-stats-mode"><input type="radio" name="statistics_mode" value="food"' + (mode === 'food' ? ' checked' : '') + ' required><span>آمار نوع غذا</span></label><label class="fm-stats-mode"><input type="radio" name="statistics_mode" value="employee"' + (mode === 'employee' ? ' checked' : '') + ' required><span>آمار سفارش نفرات</span></label></div><div class="fm-order-date"><label class="fm-field">از تاریخ شمسی<input type="text" name="from" data-jalali inputmode="numeric" placeholder="۱۴۰۵/۰۷/۰۱" value="' + esc(faDigits(from)) + '" required></label><label class="fm-field">تا تاریخ شمسی<input type="text" name="to" data-jalali inputmode="numeric" placeholder="۱۴۰۵/۰۷/۳۰" value="' + esc(faDigits(to)) + '" required></label><button class="btn primary" type="submit">مشاهده</button><button class="btn secondary" type="button" data-fm-action="statistics-export"' + (actionsEnabled ? '' : ' disabled') + '>خروجی اکسل</button><button class="btn secondary" type="button" data-fm-action="statistics-print"' + (actionsEnabled ? '' : ' disabled') + '>پرینت</button></div></form>' + result + '</section>' + renderPrintedDeliveryReport();
  }

  function render() {
    if (!root || !root.isConnected) root = document.getElementById('food-menu-root');
    if (!root) return;
    if (!canMenu && !canClose) {
      root.innerHTML = '<div class="fm-alert error">مجوز برنامهٔ غذایی یا مشاهدهٔ سفارش‌ها برای این حساب تعریف نشده است.</div>';
      return;
    }
    if (!Cal) {
      root.innerHTML = '<div class="fm-alert error">تقویم شمسی سامانه بارگذاری نشد. صفحه را تازه‌سازی کنید.</div>';
      return;
    }
    var panel = state.tab === 'calendar' && canMenu ? renderCalendar() + emergencyPanel() : state.tab === 'catalog' && canMenu ? renderCatalog() : state.tab === 'orders' && canClose ? renderOrders() : state.tab === 'cancel-requests' && canClose ? renderCancelRequests() : state.tab === 'statistics' && canClose ? renderStatistics() : '<div class="fm-card fm-empty">این بخش با مجوزهای فعلی در دسترس نیست.</div>';
    var notices = (state.error ? '<div class="fm-alert error">' + esc(state.error) + '</div>' : '') + (state.notice && !state.error ? '<div class="fm-alert good">' + esc(state.notice) + '</div>' : '');
    root.innerHTML = '<div class="fm-intro"><div><h2>برنامه غذایی</h2></div></div>' + notices + navTabs() + panel;
    if (global.ItsmJalali && typeof global.ItsmJalali.enhanceAll === 'function') global.ItsmJalali.enhanceAll(root);
  }

  async function loadStatus() {
    if (!canMenu && !canClose) return null;
    try {
      state.status = await request('food-menu/status');
      if (!state.selectedDate && state.status.today) state.selectedDate = state.status.today;
      return state.status;
    } catch (e) {
      state.status = null;
      state.error = e.message || 'وضعیت سفارش بارگذاری نشد.';
      return null;
    }
  }
  async function loadCatalog() {
    if (!canMenu) return;
    try {
      var result = await request('food-menu/catalog');
      state.catalog = Array.isArray(result.items) ? result.items : [];
    } catch (e) { state.catalog = []; state.error = e.message || 'بانک غذا بارگذاری نشد.'; }
  }
  async function loadMonth() {
    if (!canMenu) return;
    state.loading = true;
    try {
      state.monthData = await request('food-menu/month', { month: monthKey() });
    } catch (e) { state.error = e.message || 'تقویم بارگذاری نشد.'; state.monthData = null; }
    finally { state.loading = false; render(); }
  }
  async function loadOrders(date) {
    if (!canClose) return;
    var selected = normalizeIsoDate(date || state.ordersDate || state.selectedDate);
    if (!selected) return;
    state.ordersDate = selected;
    state.selectedDate = selected;
    state.ordersLoaded = false;
    state.loadingOrders = true;
    render();
    try {
      var result = await request('food-menu/orders', { date: selected });
      state.orders = Array.isArray(result.items) ? result.items : [];
      state.ordersLoaded = true;
      state.error = '';
    } catch (e) { state.orders = []; state.ordersLoaded = false; state.error = e.message || 'سفارش‌های روز بارگذاری نشد.'; }
    finally { state.loadingOrders = false; render(); }
  }

  async function loadCancelRequests() {
    if (!canClose) return;
    state.loadingCancelRequests = true;
    render();
    try {
      var result = await request('food-menu/cancel-requests');
      state.cancelRequests = Array.isArray(result.items) ? result.items : [];
      state.error = '';
    } catch (e) {
      state.cancelRequests = [];
      state.error = e.message || 'درخواست‌های لغو بارگذاری نشد.';
    } finally {
      state.loadingCancelRequests = false;
      render();
    }
  }

  async function decideCancelRequest(id, decision) {
    if (!id) return;
    var ok = decision === 'approve'
      ? window.confirm('سفارش این روز لغو شود؟ رکورد برای سوابق می‌ماند.')
      : window.confirm('این درخواست لغو رد شود؟');
    if (!ok) return;
    try {
      var result = await request('food-menu/cancel-request-decide', null, { method: 'POST', body: JSON.stringify({ id: Number(id), decision: decision }) });
      notify(result.message || (decision === 'approve' ? 'سفارش لغو شد.' : 'درخواست رد شد.'));
      await loadCancelRequests();
    } catch (e) {
      notify(e.message || 'عملیات انجام نشد.', true);
    }
  }

  async function loadStatistics(fromDate, toDate, mode) {
    if (!canClose) return;
    var from = normalizeIsoDate(fromDate || state.statisticsFrom || state.selectedDate);
    var to = normalizeIsoDate(toDate || state.statisticsTo || from);
    var selectedMode = String(mode || state.statisticsMode || 'food');
    if (!from || !to || from > to || (selectedMode !== 'food' && selectedMode !== 'employee')) return;
    state.statisticsFrom = from;
    state.statisticsTo = to;
    state.statisticsMode = selectedMode;
    state.statistics = [];
    state.statisticsLoaded = false;
    state.loadingStatistics = true;
    var requestId = ++state.statisticsRequestId;
    loadPrintedDeliveryReport(from, to);
    render();
    try {
      var result = await request('food-menu/statistics', { from: from, to: to, mode: selectedMode });
      if (requestId !== state.statisticsRequestId) return;
      state.statistics = Array.isArray(result.items) ? result.items : [];
      state.statisticsLoaded = true;
      state.error = '';
    } catch (e) {
      if (requestId !== state.statisticsRequestId) return;
      state.statistics = [];
      state.error = e.message || 'آمار سفارش‌ها بارگذاری نشد.';
    } finally {
      if (requestId === state.statisticsRequestId) {
        state.loadingStatistics = false;
        render();
      }
    }
  }
  async function refreshAll() {
    state.error = ''; state.notice = '';
    await loadStatus();
    if (!state.selectedDate) state.selectedDate = (state.status && state.status.today) || localTodayIso();
    if (!state.ordersDate) state.ordersDate = state.selectedDate;
    if (!state.statisticsFrom) state.statisticsFrom = state.selectedDate;
    if (!state.statisticsTo) state.statisticsTo = state.selectedDate;
    var initialMonth = jalaliMonthFromIso(state.selectedDate);
    if (initialMonth && !state.monthData) { state.year = initialMonth[0]; state.month = initialMonth[1]; }
    var jobs = [];
    if (canMenu) { jobs.push(loadCatalog()); jobs.push(loadMonth()); }
    if (canClose && state.tab === 'orders') jobs.push(loadOrders(state.ordersDate || state.selectedDate));
    if (canClose) jobs.push(loadCancelRequests());
    await Promise.all(jobs);
    render();
  }

  async function saveDay(confirmed, expectedImpact) {
    if (!canMenu || state.daySaving) return;
    var form = root.querySelector('#fm-day-form');
    if (!form) return;
    var body;
    if (confirmed && state.pendingImpact) {
      // Confirmation applies to the exact plan shown in the impact warning;
      // do not rebuild it from disabled/possibly edited form controls.
      body = Object.assign({}, state.pendingImpact);
      body.confirm_impact = true;
      body.expected_impact = Number(expectedImpact || 0);
    } else {
      var formData = new FormData(form);
      var foodIds = orderedDayFoodIds(form, state.selectedDate);
      var statusField = form.querySelector('[name="order_status"]:checked');
      body = {
        date: state.selectedDate,
        food_ids: foodIds,
        order_status: statusField && !statusField.disabled ? String(statusField.value || '') : '',
        note: String(formData.get('note') || '').trim(),
      };
      if (confirmed) { body.confirm_impact = true; body.expected_impact = Number(expectedImpact || 0); }
    }
    state.daySaving = true;
    state.dayError = ''; state.pendingImpact = null; state.pendingImpactExpected = 0; state.pendingImpactMessage = '';
    var button = form.querySelector('[type="submit"]'); if (button) button.disabled = true;
    Array.from(form.querySelectorAll('input,select,textarea,button')).forEach(function (control) { control.disabled = true; });
    root.querySelectorAll('[data-fm-action="confirm-impact"],[data-fm-action="cancel-impact"]').forEach(function (control) { control.disabled = true; });
    try {
      var result = await request('food-menu/day', null, { method: 'POST', body: JSON.stringify(body) });
      state.notice = result.message || 'برنامهٔ روز ذخیره شد.'; state.error = ''; state.dayError = '';
      await loadMonth();
      if (canClose && state.tab === 'orders') await loadOrders(state.ordersDate || state.selectedDate);
    } catch (e) {
      if (e.payload && e.payload.confirmation_required) {
        state.pendingImpact = body;
        state.pendingImpactExpected = Number(e.payload.affected_orders || 0);
        state.pendingImpactMessage = e.payload.message || 'این تغییر سفارش‌های فعال را لغو می‌کند.';
      } else {
        state.dayError = e.message || 'ذخیرهٔ برنامه انجام نشد.';
      }
    } finally { state.daySaving = false; render(); }
  }

  async function saveCatalog(form) {
    if (!canMenu) return;
    var isNew = form.id === 'fm-catalog-add';
    var data = new FormData(form);
    var body = { id: Number(data.get('id') || 0), food_name: String(data.get('food_name') || '').trim(), category: String(data.get('category') || 'سایر'), active: String(data.get('active') || '1') === '1' };
    var saved = false;
    try {
      var result = await request('food-menu/catalog', null, { method: 'POST', body: JSON.stringify(body) });
      state.catalog = Array.isArray(result.items) ? result.items : [];
      state.notice = result.message || 'بانک غذا ذخیره شد.'; state.error = '';
      saved = true;
    } catch (e) { state.error = e.message || 'ذخیرهٔ غذا ناموفق بود.'; }
    render();
    if (isNew) {
      // Keep the new-food box active: cleared after a successful add, text kept on error.
      var input = global.document.querySelector('#fm-catalog-add input[name="food_name"]');
      if (input) {
        if (saved) input.value = '';
        else input.value = String(data.get('food_name') || '');
        input.focus();
      }
    }
  }


  // ترتیب خروجی همان ترتیب نمایش است: در نمای منو، گروه‌ها به ترتیب منو و در هر گروه طبق سرستون مرتب‌شده
  function orderExportRows() {
    var rows = state.orders || [];
    if (state.ordersView !== 'menu') return sortOrderRows(rows);
    var groups = {};
    rows.forEach(function (row) {
      var key = Number(row.menu_no || 0);
      (groups[key] = groups[key] || []).push(row);
    });
    var keys = Object.keys(groups).map(Number).sort(function (a, b) {
      if (a === 0) return 1;
      if (b === 0) return -1;
      return a - b;
    });
    var out = [];
    keys.forEach(function (key) {
      out = out.concat(sortOrderRows(groups[key]).map(function (row) { return { row: row, menu: key }; }));
    });
    return out;
  }

  function downloadOrdersCsv() {
    var headers = ['منو'].concat(ORDER_COLUMNS.map(function (col) { return col.label; }));
    var rows = orderExportRows().map(function (item) {
      var row = item.row !== undefined ? item.row : item;
      var menu = item.row !== undefined ? item.menu : Number(row.menu_no || 0);
      return [
        menu > 0 ? faDigits(menu) : 'بدون منو',
        faDigits(row.national_code || '—'),
        faDigits(row.employee_number || '—'),
        row.full_name || '—',
        row.food_name || '—',
        faDigits(jalaliFromIso(row.food_date) || ''),
        faDigits((jalaliFromIso(row.reserve_date) || '') + ' ' + (row.reserve_time || '').slice(0, 5)).trim(),
        row.status === 'active' ? 'فعال' : 'لغوشده',
        row.is_proxy ? 'نیابتی' : 'شخصی'
      ];
    });
    var filename = 'orders-' + (state.ordersDate || 'day');
    var api = global.ITSM_LIST_SORT;
    if (api && api.exportXlsx) {
      api.exportXlsx('فهرست سفارش‌های روز ' + faDigits(jalaliFromIso(state.ordersDate) || ''), headers, rows, filename, null);
    }
  }

  function downloadOrders() {
    if (!canClose || state.tab !== 'orders' || !state.ordersLoaded || state.loadingOrders || !state.ordersDate) return;
    // اگر کاربر ترتیب نمایش را عوض کرده، خروجی همان ترتیب است؛ وگرنه خروجی سرور بدون تغییر
    if (state.ordersSortTouched) { downloadOrdersCsv(); return; }
    global.location.href = buildUrl('food-menu/orders-export', { date: state.ordersDate });
  }

  function printScopedReport(selector, bodyClass) {
    var doc = global.document;
    var target = root && root.querySelector(selector);
    if (!doc || !doc.body || !target || typeof global.print !== 'function') return;
    var printHost = doc.createElement('div');
    printHost.className = 'fm-print-host';
    printHost.appendChild(target.cloneNode(true));
    doc.body.appendChild(printHost);
    doc.body.classList.add(bodyClass);
    var cleaned = false;
    var cleanupTimer = null;
    function cleanup() {
      if (cleaned) return;
      cleaned = true;
      doc.body.classList.remove(bodyClass);
      if (printHost.parentNode) printHost.parentNode.removeChild(printHost);
      if (cleanupTimer !== null && typeof global.clearTimeout === 'function') global.clearTimeout(cleanupTimer);
      if (typeof global.removeEventListener === 'function') global.removeEventListener('afterprint', cleanup);
    }
    global.addEventListener('afterprint', cleanup, { once: true });
    try {
      global.print();
    } catch (error) {
      cleanup();
      throw error;
    }
    if (!cleaned) cleanupTimer = global.setTimeout(cleanup, 30000);
  }

  function printOrders() {
    if (!canClose || state.tab !== 'orders' || !state.ordersLoaded || state.loadingOrders) return;
    printScopedReport('.fm-daily-orders', 'fm-print-orders');
  }

  function downloadStatistics() {
    if (!canClose || !state.statisticsLoaded || !state.statisticsFrom || !state.statisticsTo) return;
    global.location.href = buildUrl('food-menu/export', { from: state.statisticsFrom, to: state.statisticsTo, mode: state.statisticsMode || 'food' });
  }

  function printStatistics() {
    if (!state.statisticsLoaded) return;
    printScopedReport('.fm-statistics', 'fm-print-statistics');
  }

  function selectDay(iso, currentMonth) {
    if (!currentMonth) return;
    state.selectedDate = iso;
    state.dayError = '';
    state.pendingImpact = null; state.pendingImpactExpected = 0; state.pendingImpactMessage = '';
    state.error = '';
    render();
  }
  function changeMonth(year, month, selectedIso) {
    state.year = Number(year); state.month = Number(month);
    state.selectedDate = selectedIso || Cal.isoDate(state.year, state.month, 1);
    state.error = ''; state.pendingImpact = null; state.pendingImpactExpected = 0; state.pendingImpactMessage = '';
    loadMonth();
  }
  function switchTab(tab) {
    if ((tab === 'calendar' || tab === 'catalog') && !canMenu) return;
    if ((tab === 'orders' || tab === 'statistics' || tab === 'cancel-requests') && !canClose) return;
    state.tab = tab; state.error = ''; state.notice = ''; render();
    if (tab === 'cancel-requests') {
      loadCancelRequests();
    }
    if (tab === 'orders') {
      var defaultOrderDate = state.ordersDate || state.selectedDate || (state.status && state.status.today) || localTodayIso();
      loadOrders(defaultOrderDate);
    }
    if (tab === 'statistics' && !state.statisticsLoaded) {
      loadStatistics(state.statisticsFrom || state.selectedDate, state.statisticsTo || state.selectedDate, state.statisticsMode || 'food');
    }
    if (tab === 'calendar' && !state.monthData && canMenu) loadMonth();
    if (tab === 'catalog' && !state.catalog.length && canMenu) loadCatalog().then(render);
  }

  // ---- سفارش اضطراری (فقط food.emergency) ----
  // ترتیب: ۱) انتخاب کاربر ۲) وارد کردن کد ملی و تطبیق با همان کاربر ۳) ثبت / تغییر سفارش یا لغو سفارش.
  var canEmergency = global.FOOD_TICKET_CAN_EMERGENCY === true;
  function emergencyEnsurePeople() {
    var em = state.emergency = state.emergency || {};
    if (em.people || em.peopleLoading) return;
    em.peopleLoading = true;
    request('food-menu/emergency/people', null).then(function (payload) {
      em.people = payload.items || [];
    }).catch(function (error) {
      em.people = [];
      em.error = error.message || 'فهرست کاربران بارگذاری نشد.';
    }).then(function () {
      em.peopleLoading = false;
      render();
    });
  }
  function emergencyPanel() {
    if (!canEmergency || state.tab !== 'calendar') return '';
    emergencyEnsurePeople();
    var iso = state.selectedDate;
    var day = getDay(iso);
    var em = state.emergency || {};
    var items = day && Array.isArray(day.items) ? day.items.filter(function (item) { return item.item_id && item.food_active !== false; }) : [];
    var status = day && day.order_status === 'closed' ? 'بسته' : 'باز';
    var head = '<div class="fm-card fm-emergency"><div class="fm-toolbar"><div><h3>سفارش اضطراری</h3><span class="fm-small">برای روز ' + esc(faDigits(jalaliFromIso(iso))) + ' (وضعیت: ' + esc(status) + ')؛ ابتدا کاربر را انتخاب کنید، سپس کد ملی او را برای تأیید وارد کنید.</span></div></div>';
    var msgs = (em.error ? '<div class="fm-alert error">' + esc(em.error) + '</div>' : '') + (em.notice && !em.error ? '<div class="fm-alert good">' + esc(em.notice) + '</div>' : '');
    if (!day) {
      return head + msgs + '<div class="fm-empty">برای این روز برنامهٔ غذایی ثبت نشده است.</div></div>';
    }
    if (!em.person) {
      var people = em.people || [];
      var options = '<option value="">— یک کاربر را انتخاب کنید —</option>' + people.map(function (p) {
        return '<option value="' + Number(p.id) + '"' + (Number(em.pickedId) === Number(p.id) ? ' selected' : '') + '>' + esc(p.name) + ' (' + esc(p.username) + ')</option>';
      }).join('');
      var pick = '<div class="fm-emergency-step"><label class="fm-field">۱. کاربر' + (em.peopleLoading ? ' (در حال بارگذاری…)' : '') + '<select name="emergency_person">' + options + '</select></label>'
        + '<button type="button" class="fm-btn" data-em-action="pick"' + (em.peopleLoading ? ' disabled' : '') + '>انتخاب کاربر</button></div>';
      var verify = em.pickedId
        ? '<div class="fm-emergency-step"><label class="fm-field">۲. کد ملی ' + esc(em.pickedName || '') + '<input type="text" name="emergency_nc" inputmode="numeric" maxlength="10" value="' + esc(em.nc || '') + '" autocomplete="off"></label>'
          + '<button type="button" class="fm-btn" data-em-action="verify">تأیید کد ملی</button></div>'
        : '';
      return head + msgs + pick + verify + '</div>';
    }
    var select = items.length
      ? '<select name="emergency_item">' + items.map(function (item) { return '<option value="' + Number(item.item_id) + '">' + esc(item.food_name || '') + '</option>'; }).join('') + '</select>'
      : '<div class="fm-empty">غذایی برای این روز تعریف نشده است.</div>';
    var orders = em.orders || [];
    var hasActive = orders.some(function (order) { return order.status === 'active'; });
    var orderList = orders.length
      ? '<ul class="fm-emergency-orders">' + orders.map(function (order) {
          return '<li>' + esc(order.food_name || '') + ' <span class="fm-small">(' + esc(order.status === 'active' ? 'فعال' : (order.status === 'cancelled' ? 'لغو شده' : order.status)) + ')</span> '
            + (order.status === 'active' ? '<button type="button" class="fm-btn secondary" data-em-action="cancel" data-order-id="' + Number(order.id) + '">لغو سفارش</button>' : '') + '</li>';
        }).join('') + '</ul>'
      : '<div class="fm-small">سفارشی برای این فرد در این روز ثبت نشده است.</div>';
    return head + msgs
      + '<div class="fm-alert good">فرد: ' + esc(em.person.name) + ' (' + esc(em.person.username) + ') — کد ملی تأیید شد.</div>'
      + '<div class="fm-emergency-step"><label class="fm-field">غذا' + select + '</label>'
      + (items.length ? '<button type="button" class="fm-btn" data-em-action="order">' + (hasActive ? 'تغییر سفارش' : 'ثبت سفارش') + '</button>' : '')
      + (hasActive ? '<div class="fm-alert warn">این گزینه فقط در سامانه فیش را «چاپ‌شده» ثبت می‌کند؛ هیچ چاپ فیزیکی انجام نمی‌شود و وضعیت تحویل غذا را هم تأیید نمی‌کند.</div><button type="button" class="fm-btn secondary" data-em-action="issue-manual-ticket">ثبت فیش دستی بدون چاپ</button>' : '')
      + '<button type="button" class="fm-btn secondary" data-em-action="reset">تغییر کاربر</button></div>'
      + '<h4>سفارش‌های این فرد در این روز</h4>' + orderList + '</div>';
  }
  async function emergencyLoadOrders() {
    var em = state.emergency;
    if (!em || !em.person) return;
    var payload = await request('food-menu/emergency/orders', { date: state.selectedDate, employee_id: em.person.id });
    em.orders = payload.items || [];
  }
  function daySearchInput(event) {
    var input = event.target.closest && event.target.closest('[data-fm-day-search]');
    if (!input) return;
    var q = String(input.value || '').trim().replace(/ي/g, 'ی').replace(/ك/g, 'ک').toLowerCase();
    var editor = input.closest('.fm-food-selection') || root;
    editor.querySelectorAll('.fm-cat-group').forEach(function (group) {
      var visible = 0;
      group.querySelectorAll('.fm-food-check').forEach(function (label) {
        var text = String(label.textContent || '').replace(/ي/g, 'ی').replace(/ك/g, 'ک').toLowerCase();
        var match = !q || text.indexOf(q) !== -1;
        label.style.display = match ? '' : 'none';
        if (match) visible++;
      });
      group.style.display = visible || !q ? '' : 'none';
      if (q && visible) {
        group.classList.add('open');
        var items = group.querySelector('.fm-cat-items');
        if (items) items.hidden = false;
        var sign = group.querySelector('.fm-cat-sign');
        if (sign) sign.textContent = '-';
      }
    });
  }

  async function emergencyClick(event) {
    var button = event.target.closest('[data-em-action]');
    if (!button || !canEmergency) return;
    event.preventDefault();
    var em = state.emergency = state.emergency || {};
    var action = button.dataset.emAction;
    em.error = ''; em.notice = '';
    try {
      if (action === 'pick') {
        var picked = String((root.querySelector('[name="emergency_person"]') || {}).value || '');
        if (!picked) throw new Error('ابتدا یک کاربر را انتخاب کنید.');
        var person = (em.people || []).filter(function (p) { return Number(p.id) === Number(picked); })[0];
        em.pickedId = Number(picked);
        em.pickedName = person ? person.name : '';
        em.nc = ''; em.person = null; em.orders = [];
      } else if (action === 'verify') {
        var nc = String((root.querySelector('[name="emergency_nc"]') || {}).value || '').trim();
        em.nc = nc;
        var found = await request('food-menu/emergency/lookup', null, { method: 'POST', body: JSON.stringify({ employee_id: em.pickedId, national_code: nc }) });
        em.person = found.person;
        await emergencyLoadOrders();
      } else if (action === 'reset') {
        state.emergency = { people: em.people };
      } else if (action === 'order') {
        var select = root.querySelector('[name="emergency_item"]');
        var result = await request('food-menu/emergency/order', null, { method: 'POST', body: JSON.stringify({ food_date: state.selectedDate, employee_id: em.person.id, national_code: em.nc, calendar_item_id: Number(select && select.value), emergency: true }) });
        em.notice = result.message || 'سفارش اضطراری ثبت شد.';
        await emergencyLoadOrders();
      } else if (action === 'issue-manual-ticket') {
        if (typeof global.confirm === 'function' && !global.confirm('فیش این سفارش در سامانه «چاپ‌شده» ثبت می‌شود، اما چاپ فیزیکی انجام نمی‌شود. ادامه می‌دهید؟')) return;
        var manualResult = await request('food-menu/emergency/issue-ticket', null, { method: 'POST', body: JSON.stringify({ food_date: state.selectedDate, employee_id: em.person.id, national_code: em.nc }) });
        em.notice = manualResult.message || 'فیش دستی ثبت شد.';
        await emergencyLoadOrders();
      } else if (action === 'cancel') {
        var cancelled = await request('food-menu/emergency/cancel', null, { method: 'POST', body: JSON.stringify({ order_id: Number(button.dataset.orderId), employee_id: em.person.id, national_code: em.nc }) });
        em.notice = cancelled.message || 'سفارش لغو شد.';
        await emergencyLoadOrders();
      }
      if (typeof refreshAll === 'function') refreshAll();
    } catch (error) {
      em.error = error.message || 'عملیات انجام نشد.';
    }
    render();
  }

  function eventClick(event) {
    var dayCat = event.target.closest('[data-fm-daycat]');
    if (dayCat) {
      var group = dayCat.parentNode;
      var body = group.querySelector('.fm-cat-items');
      var willOpen = body.hidden;
      body.hidden = !willOpen;
      group.classList.toggle('open', willOpen);
      dayCat.querySelector('.fm-cat-sign').textContent = willOpen ? '-' : '+';
      dayCat.setAttribute('aria-expanded', willOpen ? 'true' : 'false');
      dayCatalogOpen[dayCat.dataset.fmDaycat] = willOpen;
      return;
    }
    var catToggle = event.target.closest('[data-fm-cat]');
    if (catToggle) { var catName = catToggle.dataset.fmCat; catalogOpen[catName] = !catalogOpen[catName]; render(); return; }
    var tab = event.target.closest('[data-fm-tab]');
    if (tab) { switchTab(tab.dataset.fmTab); return; }
    var deliveredSortBtn = event.target.closest('[data-fm-delivery-sort]');
    if (deliveredSortBtn) {
      var deliveredSortKey = deliveredSortBtn.dataset.fmDeliverySort;
      if (state.deliveredReportSort.key === deliveredSortKey) state.deliveredReportSort.dir = state.deliveredReportSort.dir === 'asc' ? 'desc' : 'asc';
      else state.deliveredReportSort = { key: deliveredSortKey, dir: 'asc' };
      render();
      return;
    }
    var sortBtn = event.target.closest('[data-fm-sort]');
    if (sortBtn) {
      var sortKey = sortBtn.dataset.fmSort;
      state.ordersSortTouched = true;
      if (state.ordersSort.key === sortKey) state.ordersSort.dir = state.ordersSort.dir === 'asc' ? 'desc' : 'asc';
      else state.ordersSort = { key: sortKey, dir: 'asc' };
      render();
      return;
    }
    var action = event.target.closest('[data-fm-action]');
    if (action) {
      var act = action.dataset.fmAction;
      if (act === 'month-prev') { var p = Cal.shiftMonth(state.year, state.month, -1); changeMonth(p[0], p[1]); }
      if (act === 'month-next') { var n = Cal.shiftMonth(state.year, state.month, 1); changeMonth(n[0], n[1]); }
      if (act === 'month-today') {
        if (state.status && state.status.today) { var td = jalaliMonthFromIso(state.status.today); if (td) changeMonth(td[0], td[1], state.status.today); }
        else { var today = new Date(); var j = global.FoodOrderCalendar.jalaliDateFromIso(localTodayIso()); changeMonth(j[0], j[1], Cal.isoDate(j[0], j[1], j[2])); }
      }
      if (act === 'reload-month') loadMonth();
      if (act === 'show-orders') {
        state.ordersDate = state.selectedDate;
        switchTab('orders');
      }
      if (act === 'confirm-impact') saveDay(true, state.pendingImpactExpected);
      if (act === 'cancel-impact') { state.pendingImpact = null; state.pendingImpactExpected = 0; state.pendingImpactMessage = ''; render(); }
      if (act === 'orders-view') { state.ordersView = action.dataset.ordersView === 'menu' ? 'menu' : 'list'; state.ordersSortTouched = state.ordersSortTouched || state.ordersView === 'menu'; render(); }
      if (act === 'orders-export') downloadOrders();
      if (act === 'orders-print') printOrders();
      if (act === 'statistics-export') downloadStatistics();
      if (act === 'statistics-print') printStatistics();
      if (act === 'delivered-report-view') { state.deliveredReportView = action.dataset.view === 'menu' ? 'menu' : 'list'; render(); }
      if (act === 'delivered-report-export') exportPrintedDeliveryReport();
      if (act === 'delivered-report-print') printPrintedDeliveryReport();
      if (act === 'cancel-req-reload') loadCancelRequests();
      if (act === 'cancel-req-approve') decideCancelRequest(Number(action.dataset.id || 0), 'approve');
      if (act === 'cancel-req-reject') decideCancelRequest(Number(action.dataset.id || 0), 'reject');
      if (act === 'orders-today') {
        var todayIso = state.status && state.status.today ? state.status.today : localTodayIso();
        state.selectedDate = todayIso; state.ordersDate = todayIso;
        loadOrders(todayIso);
      }
      return;
    }
    var day = event.target.closest('[data-fm-day]');
    if (day) selectDay(day.dataset.fmDay, day.dataset.fmCurrent === '1');
  }

  // ترتیب منو = ترتیب تیک زدن غذاها در روز. اولین غذای تیک‌خورده منوی ۱ است، و همین ترتیب ذخیره می‌شود.
  function dayPickFor(iso) {
    if (!state.dayPick || state.dayPick.date !== iso) {
      var day = getDay(iso);
      var saved = day && Array.isArray(day.items) ? day.items.map(function (item) { return Number(item.food_id); }) : [];
      state.dayPick = { date: iso, ids: saved };
    }
    return state.dayPick;
  }

  function trackDayPick(input) {
    var pick = dayPickFor(state.selectedDate);
    var id = Number(input.value);
    pick.ids = pick.ids.filter(function (x) { return x !== id; });
    if (input.checked) pick.ids.push(id);
  }

  function orderedDayFoodIds(form, iso) {
    var checked = Array.from(form.querySelectorAll('input[name="food_ids"]:checked')).map(function (input) { return Number(input.value); });
    var ordered = [];
    dayPickFor(iso).ids.forEach(function (id) { if (checked.indexOf(id) >= 0 && ordered.indexOf(id) < 0) ordered.push(id); });
    checked.forEach(function (id) { if (ordered.indexOf(id) < 0) ordered.push(id); });
    return ordered;
  }

  function eventChange(event) {
    var input = event.target;
    if (input && input.name === 'food_ids') { trackDayPick(input); return; }
    if (input && input.matches && input.matches('[data-fm-delivery-field]')) {
      var fields = Array.from(root.querySelectorAll('[data-fm-delivery-field]:checked')).map(function (item) { return item.dataset.fmDeliveryField; });
      if (!fields.length) { input.checked = true; notify('برای گزارش حداقل یک فیلد باید انتخاب شود.', true); return; }
      state.deliveredReportFields = fields;
      saveDeliveredReportFields(fields);
      render();
      return;
    }
    if (!input || input.name !== 'statistics_mode') return;
    var selectedMode = input.value === 'employee' ? 'employee' : 'food';
    var form = input.form;
    var formData = form ? new FormData(form) : null;
    var fromDate = formData ? normalizeIsoDate(formData.get('from')) : state.statisticsFrom;
    var toDate = formData ? normalizeIsoDate(formData.get('to')) : state.statisticsTo;
    state.statisticsMode = selectedMode;
    if (fromDate) state.statisticsFrom = fromDate;
    if (toDate) state.statisticsTo = toDate;
    state.error = '';
    if (fromDate && toDate && fromDate <= toDate) {
      loadStatistics(fromDate, toDate, selectedMode);
    } else {
      state.statisticsRequestId++;
      state.statistics = [];
      state.statisticsLoaded = false;
      state.loadingStatistics = false;
      render();
    }
  }

  function eventSubmit(event) {
    var form = event.target;
    if (form.id === 'fm-day-form') {
      event.preventDefault(); saveDay(false); return;
    }
    if (form.id === 'fm-catalog-add') {
      event.preventDefault(); saveCatalog(form); return;
    }
    if (form.matches('[data-fm-catalog-edit]')) {
      event.preventDefault(); saveCatalog(form); return;
    }
    if (form.id === 'fm-orders-date') {
      event.preventDefault();
      var orderDate = normalizeIsoDate(new FormData(form).get('date'));
      if (!orderDate) { state.error = 'تاریخ روز را به‌درستی انتخاب کنید.'; render(); return; }
      state.error = ''; state.selectedDate = orderDate; state.ordersDate = orderDate; loadOrders(orderDate); return;
    }
    if (form.id === 'fm-statistics-date') {
      event.preventDefault();
      var statisticsForm = new FormData(form);
      var fromDate = normalizeIsoDate(statisticsForm.get('from'));
      var toDate = normalizeIsoDate(statisticsForm.get('to'));
      var statisticsMode = String(statisticsForm.get('statistics_mode') || state.statisticsMode || 'food');
      if (statisticsMode !== 'food' && statisticsMode !== 'employee') { state.error = 'نوع آمار را انتخاب کنید.'; render(); return; }
      if (!fromDate || !toDate) { state.error = 'تاریخ شروع و پایان را به‌درستی انتخاب کنید.'; render(); return; }
      if (fromDate > toDate) { state.error = 'تاریخ پایان باید برابر یا پس از تاریخ شروع باشد.'; render(); return; }
      var spanDays = (Date.parse(toDate + 'T00:00:00Z') - Date.parse(fromDate + 'T00:00:00Z')) / 86400000;
      if (spanDays > 366) { state.error = 'بازهٔ آمار حداکثر یک سال است.'; render(); return; }
      state.error = ''; state.statisticsFrom = fromDate; state.statisticsTo = toDate; state.statisticsMode = statisticsMode; loadStatistics(fromDate, toDate, statisticsMode); return;
    }
  }

  function mount() {
    root = document.getElementById('food-menu-root');
    if (!root || root.dataset.fmMounted === '1') return;
    root.dataset.fmMounted = '1';
    root.addEventListener('click', emergencyClick);
    root.addEventListener('click', eventClick);
    root.addEventListener('change', eventChange);
    root.addEventListener('input', daySearchInput);
    root.addEventListener('submit', eventSubmit);
    var current = state.selectedDate ? jalaliMonthFromIso(state.selectedDate) : null;
    if (current) { state.year = current[0]; state.month = current[1]; }
    render();
    refreshAll();
  }

  global.FoodMenuUI = { html: function () { return '<div id="food-menu-root"><div class="fm-card fm-spinner">در حال آماده‌سازی برنامهٔ غذایی…</div></div>'; }, mount: mount };
  if (typeof document !== 'undefined') document.dispatchEvent(new Event('food-menu-ready'));
  if (typeof module !== 'undefined' && module.exports) module.exports = global.FoodMenuUI;
})(typeof window !== 'undefined' ? window : globalThis);
