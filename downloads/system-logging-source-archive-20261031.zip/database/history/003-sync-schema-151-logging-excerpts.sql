-- Selected logging-table statements from the mixed 003 migration; archival reference only.
CREATE TABLE IF NOT EXISTS activity_logs (
    id BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
    user_id INT UNSIGNED NULL,
    username VARCHAR(190) NULL,
    full_name VARCHAR(190) NULL,
    role VARCHAR(40) NULL,
    action_code VARCHAR(120) NOT NULL,
    action_label VARCHAR(190) NULL,
    module VARCHAR(80) NULL,
    target_type VARCHAR(40) NULL,
    target_id BIGINT UNSIGNED NULL,
    target_label VARCHAR(255) NULL,
    meta_json JSON NULL,
    ip_address VARCHAR(64) NULL,
    computer_name VARCHAR(190) NULL,
    hostname VARCHAR(190) NULL,
    user_agent VARCHAR(255) NULL,
    created_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
    INDEX idx_activity_created (created_at),
    INDEX idx_activity_user (user_id),
    INDEX idx_activity_action (action_code),
    INDEX idx_activity_module (module),
    INDEX idx_activity_ip (ip_address),
    CONSTRAINT fk_activity_user FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE SET NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

ALTER TABLE `activity_logs` ADD COLUMN IF NOT EXISTS `user_id` INT UNSIGNED NULL;

ALTER TABLE `activity_logs` ADD COLUMN IF NOT EXISTS `username` VARCHAR(190) NULL;

ALTER TABLE `activity_logs` ADD COLUMN IF NOT EXISTS `full_name` VARCHAR(190) NULL;

ALTER TABLE `activity_logs` ADD COLUMN IF NOT EXISTS `role` VARCHAR(40) NULL;

ALTER TABLE `activity_logs` ADD COLUMN IF NOT EXISTS `action_code` VARCHAR(120) NOT NULL;

ALTER TABLE `activity_logs` ADD COLUMN IF NOT EXISTS `action_label` VARCHAR(190) NULL;

ALTER TABLE `activity_logs` ADD COLUMN IF NOT EXISTS `module` VARCHAR(80) NULL;

ALTER TABLE `activity_logs` ADD COLUMN IF NOT EXISTS `target_type` VARCHAR(40) NULL;

ALTER TABLE `activity_logs` ADD COLUMN IF NOT EXISTS `target_id` BIGINT UNSIGNED NULL;

ALTER TABLE `activity_logs` ADD COLUMN IF NOT EXISTS `target_label` VARCHAR(255) NULL;

ALTER TABLE `activity_logs` ADD COLUMN IF NOT EXISTS `meta_json` JSON NULL;

ALTER TABLE `activity_logs` ADD COLUMN IF NOT EXISTS `ip_address` VARCHAR(64) NULL;

ALTER TABLE `activity_logs` ADD COLUMN IF NOT EXISTS `computer_name` VARCHAR(190) NULL;

ALTER TABLE `activity_logs` ADD COLUMN IF NOT EXISTS `hostname` VARCHAR(190) NULL;

ALTER TABLE `activity_logs` ADD COLUMN IF NOT EXISTS `user_agent` VARCHAR(255) NULL;

ALTER TABLE `activity_logs` ADD COLUMN IF NOT EXISTS `created_at` DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP;

CREATE TABLE IF NOT EXISTS system_logs (
    id BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
    level VARCHAR(20) NOT NULL DEFAULT 'error',
    context VARCHAR(120) NULL,
    message TEXT NULL,
    meta_json JSON NULL,
    user_id INT UNSIGNED NULL,
    request_uri VARCHAR(255) NULL,
    created_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
    INDEX idx_system_logs_created (created_at),
    INDEX idx_system_logs_level (level)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

ALTER TABLE `system_logs` ADD COLUMN IF NOT EXISTS `level` VARCHAR(20) NOT NULL DEFAULT 'error';

ALTER TABLE `system_logs` ADD COLUMN IF NOT EXISTS `context` VARCHAR(120) NULL;

ALTER TABLE `system_logs` ADD COLUMN IF NOT EXISTS `message` TEXT NULL;

ALTER TABLE `system_logs` ADD COLUMN IF NOT EXISTS `meta_json` JSON NULL;

ALTER TABLE `system_logs` ADD COLUMN IF NOT EXISTS `user_id` INT UNSIGNED NULL;

ALTER TABLE `system_logs` ADD COLUMN IF NOT EXISTS `request_uri` VARCHAR(255) NULL;

ALTER TABLE `system_logs` ADD COLUMN IF NOT EXISTS `created_at` DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP;

CREATE TABLE IF NOT EXISTS system_incidents (
    fingerprint CHAR(40) NOT NULL PRIMARY KEY,
    title VARCHAR(255) NOT NULL,
    status ENUM('open','investigating','resolved') NOT NULL DEFAULT 'open',
    note TEXT NULL,
    updated_by INT UNSIGNED NULL,
    updated_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

ALTER TABLE `system_incidents` ADD COLUMN IF NOT EXISTS `title` VARCHAR(255) NOT NULL;

ALTER TABLE `system_incidents` ADD COLUMN IF NOT EXISTS `status` ENUM('open','investigating','resolved') NOT NULL DEFAULT 'open';

ALTER TABLE `system_incidents` ADD COLUMN IF NOT EXISTS `note` TEXT NULL;

ALTER TABLE `system_incidents` ADD COLUMN IF NOT EXISTS `updated_by` INT UNSIGNED NULL;

ALTER TABLE `system_incidents` ADD COLUMN IF NOT EXISTS `updated_at` DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP;
