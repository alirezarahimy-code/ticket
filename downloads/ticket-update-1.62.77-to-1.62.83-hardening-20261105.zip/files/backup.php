<?php
declare(strict_types=1);

defined('APP_ROOT') || exit;

function backup_root_path(): string
{
    $configured = trim((string) (getenv('ITSM_BACKUP_PATH') ?: ''));
    return $configured !== '' ? $configured : APP_ROOT . '/storage/backups';
}

function backup_mysql_binary(string $tool): ?string
{
    $envKey = $tool === 'mysqldump' ? 'ITSM_MYSQLDUMP_PATH' : 'ITSM_MYSQL_PATH';
    $configured = trim((string) (getenv($envKey) ?: ''));
    $xamppRoot = dirname(APP_ROOT, 2);
    $candidates = array_filter([
        $configured,
        $xamppRoot . DIRECTORY_SEPARATOR . 'mysql' . DIRECTORY_SEPARATOR . 'bin' . DIRECTORY_SEPARATOR . $tool . '.exe',
        $xamppRoot . DIRECTORY_SEPARATOR . 'mysql' . DIRECTORY_SEPARATOR . 'bin' . DIRECTORY_SEPARATOR . $tool,
        '/usr/bin/' . $tool,
        '/usr/local/bin/' . $tool,
    ]);
    foreach ($candidates as $candidate) {
        if (is_file($candidate) && (is_executable($candidate) || PHP_OS_FAMILY === 'Windows')) {
            return $candidate;
        }
    }
    return null;
}

function backup_run_process(string $binary, array $arguments, ?string $inputPath = null, ?string $outputPath = null): void
{
    if (!function_exists('proc_open')) {
        throw new RuntimeException('proc_open در PHP فعال نیست؛ عملیات MySQL از صفحه وب قابل اجرا نیست.');
    }
    $command = escapeshellarg($binary);
    foreach ($arguments as $argument) {
        $command .= ' ' . escapeshellarg((string) $argument);
    }
    $descriptors = [
        0 => $inputPath ? ['file', $inputPath, 'rb'] : ['pipe', 'r'],
        1 => $outputPath ? ['file', $outputPath, 'wb'] : ['pipe', 'w'],
        2 => ['pipe', 'w'],
    ];
    $environment = $_ENV;
    $environment['MYSQL_PWD'] = (string) cfg('database.password', '');
    if (empty($environment['SystemRoot']) && getenv('SystemRoot')) {
        $environment['SystemRoot'] = getenv('SystemRoot');
    }
    if (empty($environment['SystemRoot']) && PHP_OS_FAMILY === 'Windows') {
        $environment['SystemRoot'] = 'C:\\Windows';
    }
    if (empty($environment['PATH']) && getenv('PATH')) {
        $environment['PATH'] = getenv('PATH');
    }
    $process = proc_open($command, $descriptors, $pipes, APP_ROOT, $environment);
    if (!is_resource($process)) {
        throw new RuntimeException('اجرای ابزار MySQL ممکن نیست.');
    }
    if (!$inputPath && isset($pipes[0]) && is_resource($pipes[0])) {
        fclose($pipes[0]);
    }
    $error = isset($pipes[2]) && is_resource($pipes[2]) ? stream_get_contents($pipes[2]) : '';
    if (isset($pipes[2]) && is_resource($pipes[2])) {
        fclose($pipes[2]);
    }
    if (isset($pipes[1]) && is_resource($pipes[1])) {
        stream_get_contents($pipes[1]);
        fclose($pipes[1]);
    }
    $exitCode = proc_close($process);
    if ($exitCode !== 0) {
        throw new RuntimeException(trim((string) $error) ?: 'عملیات MySQL ناموفق بود.');
    }
}

function backup_uploads(string $destination): int
{
    if (!class_exists('ZipArchive')) {
        throw new RuntimeException('افزونه ZipArchive برای پشتیبان‌گیری از پیوست‌ها لازم است.');
    }
    $uploadsRoot = APP_ROOT . '/storage/uploads';
    $archive = new ZipArchive();
    if ($archive->open($destination . '/uploads.zip', ZipArchive::CREATE | ZipArchive::OVERWRITE) !== true) {
        throw new RuntimeException('ساخت آرشیو پیوست‌ها انجام نشد.');
    }
    $count = 0;
    try {
        $uploadsRootReal = is_dir($uploadsRoot) ? realpath($uploadsRoot) : false;
        if (is_dir($uploadsRoot) && !is_string($uploadsRootReal)) {
            throw new RuntimeException('مسیر واقعی پوشهٔ پیوست‌ها قابل تشخیص نیست.');
        }
        if (is_string($uploadsRootReal)) {
            $prefix = rtrim($uploadsRootReal, DIRECTORY_SEPARATOR) . DIRECTORY_SEPARATOR;
            $iterator = new RecursiveIteratorIterator(
                new RecursiveDirectoryIterator($uploadsRootReal, FilesystemIterator::SKIP_DOTS),
                RecursiveIteratorIterator::LEAVES_ONLY
            );
            foreach ($iterator as $file) {
                if ($file->isLink()) {
                    throw new RuntimeException('لینک نمادین در پوشهٔ پیوست‌ها وجود دارد؛ پشتیبان‌گیری برای جلوگیری از خروج از مسیر متوقف شد.');
                }
                if (!$file->isFile()) {
                    continue;
                }
                $realFile = realpath($file->getPathname());
                if (!is_string($realFile) || !str_starts_with($realFile, $prefix)) {
                    throw new RuntimeException('فایل پیوست خارج از پوشهٔ مجاز قرار دارد.');
                }
                $relative = ltrim(str_replace(DIRECTORY_SEPARATOR, '/', substr($realFile, strlen($uploadsRootReal))), '/');
                if (!$archive->addFile($realFile, 'uploads/' . $relative)) {
                    throw new RuntimeException('افزودن یکی از پیوست‌ها به آرشیو انجام نشد: ' . $relative);
                }
                $count++;
            }
        }
        if (!$archive->close()) {
            throw new RuntimeException('بستن آرشیو پیوست‌ها ناموفق بود.');
        }
        return $count;
    } catch (Throwable $exception) {
        $archive->close();
        throw $exception;
    }
}

/** ۱.۶۲.۴۱ — ZIP کردن فایلهای پوشهٔ سامانه (بدون دیتابیس، uploads، storage). */
function backup_system_files_zip(string $destination): array
{
    if (!class_exists('ZipArchive')) {
        return ['ok' => false, 'error' => 'ZipArchive در PHP فعال نیست.'];
    }
    $root = APP_ROOT;
    $rootReal = realpath($root);
    if (!is_string($rootReal)) {
        return ['ok' => false, 'error' => 'مسیر واقعی ریشهٔ سامانه قابل تشخیص نیست.'];
    }
    $skip = ['storage','uploads','downloads','.git','node_modules','vendor','.cache','preview','updates','temp','tmp'];
    $zipPath = $destination . DIRECTORY_SEPARATOR . 'system-files.zip';
    $zip = new ZipArchive();
    if ($zip->open($zipPath, ZipArchive::CREATE | ZipArchive::OVERWRITE) !== true) {
        return ['ok' => false, 'error' => 'ساخت ZIP فایلها ممکن نیست.'];
    }
    $count = 0; $bytes = 0;
    try {
        $iterator = new RecursiveIteratorIterator(
            new RecursiveDirectoryIterator($rootReal, FilesystemIterator::SKIP_DOTS),
            RecursiveIteratorIterator::SELF_FIRST
        );
        foreach ($iterator as $item) {
            $relative = str_replace('\\', '/', substr($item->getPathname(), strlen($rootReal) + 1));
            $top = explode('/', $relative)[0];
            if (in_array($top, $skip, true) || $item->isDir()) {
                continue;
            }
            if ($item->isLink()) {
                throw new RuntimeException('لینک نمادین در فایل‌های سامانه پیدا شد؛ برای جلوگیری از افزودن فایل خارج از ریشه، پشتیبان‌گیری متوقف شد: ' . $relative);
            }
            $realFile = realpath($item->getPathname());
            if (!is_string($realFile) || !str_starts_with($realFile, rtrim($rootReal, DIRECTORY_SEPARATOR) . DIRECTORY_SEPARATOR)) {
                throw new RuntimeException('فایل خارج از ریشهٔ سامانه پیدا شد: ' . $relative);
            }
            if (!$zip->addFile($realFile, $relative)) {
                throw new RuntimeException('افزودن فایل سامانه به آرشیو انجام نشد: ' . $relative);
            }
            $count++;
            $bytes += $item->getSize();
        }
        $info = "بکاپ فایلهای سامانه\nتاریخ: " . date('Y-m-d H:i:s') . "\nتعداد فایلها: {$count}\n"
            . "برای برگردانی: extract کنید و روی پوشهٔ اصلی سامانه کپی کنید.\n";
        if (!$zip->addFromString('BACKUP-INFO.txt', $info)) {
            throw new RuntimeException('افزودن راهنمای پشتیبان به آرشیو انجام نشد.');
        }
        if (!$zip->close()) {
            throw new RuntimeException('بستن آرشیو فایل‌های سامانه ناموفق بود.');
        }
        return ['ok' => true, 'file' => 'system-files.zip', 'files' => $count, 'bytes' => $bytes];
    } catch (Throwable $exception) {
        $zip->close();
        return ['ok' => false, 'error' => $exception->getMessage()];
    }
}

function create_backup_bundle(): array
{
    $dumpBinary = backup_mysql_binary('mysqldump');
    if ($dumpBinary === null) {
        throw new RuntimeException('mysqldump پیدا نشد. مسیر ITSM_MYSQLDUMP_PATH یا XAMPP را بررسی کنید.');
    }
    $root = backup_root_path();
    if (!is_dir($root) && !mkdir($root, 0750, true) && !is_dir($root)) {
        throw new RuntimeException('پوشه پشتیبان‌گیری قابل ایجاد نیست.');
    }
    $name = date('Ymd-His') . '-' . bin2hex(random_bytes(3));
    $destination = $root . DIRECTORY_SEPARATOR . $name;
    if (!mkdir($destination, 0750, true)) {
        throw new RuntimeException('پوشه نسخه پشتیبان ساخته نشد.');
    }
    $dbName = (string) cfg('database.name', 'persian_ticketing');
    $dumpPath = $destination . DIRECTORY_SEPARATOR . $dbName . '.sql';
    backup_run_process($dumpBinary, [
        '--single-transaction', '--routines', '--events', '--triggers',
        '--host=' . (string) cfg('database.host', '127.0.0.1'),
        '--port=' . (int) cfg('database.port', 3306),
        '--user=' . (string) cfg('database.user', ''),
        $dbName,
    ], null, $dumpPath);
    $uploadCount = backup_uploads($destination);
    // ۱.۶۲.۴۱ — بکاپ کامل فایلهای سامانه (جدا از دیتابیس)، قبل از هر بهروزرسانی.
    $filesBackup = backup_system_files_zip($destination);
    if (empty($filesBackup['ok'])) {
        throw new RuntimeException('پشتیبان فایل‌های سامانه کامل نشد: ' . (string) ($filesBackup['error'] ?? 'خطای نامشخص'));
    }
    file_put_contents($destination . DIRECTORY_SEPARATOR . 'manifest.json', json_encode([
        'created_at' => date('c'),
        'database' => $dbName,
        'uploads' => $uploadCount,
        'system_files' => $filesBackup,
    ], JSON_PRETTY_PRINT | JSON_UNESCAPED_UNICODE));
    return ['name' => $name, 'path' => $destination, 'uploads' => $uploadCount, 'system_files' => $filesBackup];
}

function backup_runs(): array
{
    $root = backup_root_path();
    if (!is_dir($root)) {
        return [];
    }
    $runs = [];
    foreach (scandir($root) ?: [] as $name) {
        $path = $root . DIRECTORY_SEPARATOR . $name;
        if ($name === '.' || $name === '..' || !is_dir($path) || !is_file($path . DIRECTORY_SEPARATOR . 'manifest.json')) {
            continue;
        }
        $runs[] = ['name' => $name, 'created_at' => date('Y-m-d H:i:s', (int) filemtime($path)), 'size' => backup_directory_size($path)];
    }
    usort($runs, static fn (array $left, array $right): int => strcmp($right['name'], $left['name']));
    return array_slice($runs, 0, 30);
}

function backup_directory_size(string $path): int
{
    $size = 0;
    if (!is_dir($path)) {
        return 0;
    }
    $iterator = new RecursiveIteratorIterator(new RecursiveDirectoryIterator($path, FilesystemIterator::SKIP_DOTS));
    foreach ($iterator as $file) {
        if ($file->isFile()) {
            $size += $file->getSize();
        }
    }
    return $size;
}

function backup_download_path(string $relative): ?string
{
    $root = realpath(backup_root_path());
    $relative = ltrim(str_replace(['\\', '..'], ['/', ''], $relative), '/');
    $path = $root ? realpath($root . DIRECTORY_SEPARATOR . $relative) : false;
    $prefix = $root ? rtrim($root, DIRECTORY_SEPARATOR) . DIRECTORY_SEPARATOR : '';
    return $path && $root && str_starts_with($path, $prefix) && is_file($path) ? $path : null;
}

function backup_upload_archive_entry(string $name): ?array
{
    if ($name === '' || str_contains($name, "\0") || str_contains($name, '\\')
        || str_starts_with($name, '/') || preg_match('/^[A-Za-z]:/', $name)) {
        return null;
    }
    $directory = str_ends_with($name, '/');
    $normalized = strncasecmp($name, 'uploads/', 8) === 0 ? substr($name, 8) : $name;
    $relative = $directory && str_ends_with($normalized, '/') ? substr($normalized, 0, -1) : $normalized;
    if ($relative === '') {
        return $directory ? ['relative' => '', 'directory' => true] : null;
    }
    if (str_contains($relative, '//')) {
        return null;
    }
    foreach (explode('/', $relative) as $segment) {
        if ($segment === '' || $segment === '.' || $segment === '..'
            || preg_match('/[<>:"|?*\\x00-\\x1F]/', $segment)
            || preg_match('/[. ]$/', $segment)
            || preg_match('/^(CON|PRN|AUX|NUL|COM[1-9]|LPT[1-9])(?:\\..*)?$/i', $segment)) {
            return null;
        }
    }
    return ['relative' => $relative, 'directory' => $directory];
}

/** Validate every entry before writing any restored upload. */
function backup_validate_upload_archive(ZipArchive $archive): array
{
    if ($archive->numFiles > 10000) {
        throw new RuntimeException('تعداد فایل‌های آرشیو پیوست از سقف مجاز بیشتر است.');
    }
    $maxEntry = max(1, (int) (getenv('ITSM_MAX_RESTORE_ENTRY_MB') ?: 256)) * 1024 * 1024;
    $maxTotal = max(1, (int) (getenv('ITSM_MAX_RESTORE_UNPACKED_MB') ?: 1024)) * 1024 * 1024;
    $entries = [];
    $seen = [];
    $total = 0;
    for ($index = 0; $index < $archive->numFiles; $index++) {
        $name = (string) $archive->getNameIndex($index);
        $entry = backup_upload_archive_entry($name);
        if ($entry === null) {
            throw new RuntimeException('مسیر نامعتبر در آرشیو پیوست: ' . $name);
        }
        $relative = $entry['relative'];
        if ($relative !== '') {
            $key = strtolower(rtrim($relative, '/'));
            if (isset($seen[$key])) {
                throw new RuntimeException('نام تکراری یا ناسازگار با Windows در آرشیو پیوست: ' . $name);
            }
            $seen[$key] = ['directory' => $entry['directory']];
        }
        $stat = $archive->statIndex($index);
        if (!is_array($stat)) {
            throw new RuntimeException('اطلاعات ورودی آرشیو پیوست قابل خواندن نیست: ' . $name);
        }
        $size = max(0, (int) ($stat['size'] ?? 0));
        if (!$entry['directory']) {
            $total += $size;
            if ($size > $maxEntry || $total > $maxTotal) {
                throw new RuntimeException('حجم استخراج آرشیو پیوست از سقف مجاز بیشتر است.');
            }
        }
        if (method_exists($archive, 'getExternalAttributesIndex')) {
            $opsys = 0; $attributes = 0;
            if ($archive->getExternalAttributesIndex($index, $opsys, $attributes)) {
                $unixMode = ($attributes >> 16) & 0170000;
                if ($opsys === ZipArchive::OPSYS_UNIX && $unixMode === 0120000) {
                    throw new RuntimeException('لینک نمادین در آرشیو پیوست مجاز نیست: ' . $name);
                }
            }
        }
        $entries[] = ['index' => $index, 'relative' => $relative, 'directory' => $entry['directory'], 'size' => $size];
    }
    foreach (array_keys($seen) as $key) {
        $parts = explode('/', $key);
        array_pop($parts);
        $parent = '';
        foreach ($parts as $part) {
            $parent = $parent === '' ? $part : $parent . '/' . $part;
            if (isset($seen[$parent]) && !$seen[$parent]['directory']) {
                throw new RuntimeException('تعارض فایل/پوشه در آرشیو پیوست: ' . $key);
            }
        }
    }
    return $entries;
}

function restore_upload_archive(array $file): int
{
    if (($file['error'] ?? UPLOAD_ERR_NO_FILE) !== UPLOAD_ERR_OK || !class_exists('ZipArchive')) {
        throw new RuntimeException('آرشیو پیوست معتبر نیست یا افزونه ZIP فعال نیست.');
    }
    $maxBytes = (int) (getenv('ITSM_MAX_RESTORE_MB') ?: 256) * 1024 * 1024;
    if ((int) ($file['size'] ?? 0) <= 0 || (int) $file['size'] > $maxBytes) {
        throw new RuntimeException('حجم آرشیو پیوست برای بازیابی مجاز نیست.');
    }
    $archive = new ZipArchive();
    if ($archive->open((string) $file['tmp_name']) !== true) {
        throw new RuntimeException('بازکردن آرشیو پیوست انجام نشد.');
    }
    try {
        $entries = backup_validate_upload_archive($archive);
        $uploadsRoot = APP_ROOT . '/storage/uploads';
        if (!is_dir($uploadsRoot) && !mkdir($uploadsRoot, 0750, true) && !is_dir($uploadsRoot)) {
            throw new RuntimeException('پوشه پیوست‌ها قابل ایجاد نیست.');
        }
        $uploadsRootReal = realpath($uploadsRoot);
        if (!is_string($uploadsRootReal)) {
            throw new RuntimeException('مسیر واقعی پوشه پیوست‌ها قابل تشخیص نیست.');
        }
        $rootPrefix = rtrim($uploadsRootReal, DIRECTORY_SEPARATOR) . DIRECTORY_SEPARATOR;
        $count = 0;
        foreach ($entries as $entry) {
            if ($entry['directory'] || $entry['relative'] === '') {
                continue;
            }
            $target = $uploadsRootReal . DIRECTORY_SEPARATOR
                . str_replace('/', DIRECTORY_SEPARATOR, $entry['relative']);
            $directory = dirname($target);
            if (!is_dir($directory) && !mkdir($directory, 0750, true) && !is_dir($directory)) {
                throw new RuntimeException('ساخت مسیر پیوست انجام نشد.');
            }
            $directoryReal = realpath($directory);
            if (!is_string($directoryReal)
                || ($directoryReal !== $uploadsRootReal && !str_starts_with($directoryReal . DIRECTORY_SEPARATOR, $rootPrefix))) {
                throw new RuntimeException('مسیر مقصد پیوست از پوشه مجاز خارج شده است.');
            }
            if (is_link($target) || (file_exists($target) && !is_file($target))) {
                throw new RuntimeException('مقصد پیوست فایل عادی نیست: ' . $entry['relative']);
            }
            $input = $archive->getStreamIndex($entry['index']);
            if (!is_resource($input)) {
                throw new RuntimeException('خواندن یکی از پیوست‌ها انجام نشد.');
            }
            $output = @fopen($target, 'wb');
            if (!is_resource($output)) {
                fclose($input);
                throw new RuntimeException('نوشتن یکی از پیوست‌ها انجام نشد.');
            }
            try {
                $copied = stream_copy_to_stream($input, $output);
                if (!is_int($copied) || $copied !== $entry['size']) {
                    throw new RuntimeException('بازیابی کامل یکی از پیوست‌ها انجام نشد: ' . $entry['relative']);
                }
            } finally {
                fclose($input);
                fclose($output);
            }
            $count++;
        }
        return $count;
    } finally {
        $archive->close();
    }
}

function restore_sql_dump(array $file): void
{
    if (($file['error'] ?? UPLOAD_ERR_NO_FILE) !== UPLOAD_ERR_OK || strtolower(pathinfo((string) ($file['name'] ?? ''), PATHINFO_EXTENSION)) !== 'sql') {
        throw new RuntimeException('فایل بازیابی باید یک فایل SQL معتبر باشد.');
    }
    $maxBytes = (int) (getenv('ITSM_MAX_RESTORE_MB') ?: 256) * 1024 * 1024;
    if ((int) ($file['size'] ?? 0) <= 0 || (int) $file['size'] > $maxBytes) {
        throw new RuntimeException('حجم فایل SQL برای بازیابی مجاز نیست.');
    }
    $mysqlBinary = backup_mysql_binary('mysql');
    if ($mysqlBinary === null) {
        throw new RuntimeException('mysql پیدا نشد. مسیر ITSM_MYSQL_PATH یا XAMPP را بررسی کنید.');
    }
    backup_run_process($mysqlBinary, [
        '--host=' . (string) cfg('database.host', '127.0.0.1'),
        '--port=' . (int) cfg('database.port', 3306),
        '--user=' . (string) cfg('database.user', ''),
        (string) cfg('database.name', 'persian_ticketing'),
    ], (string) $file['tmp_name']);
}
