#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""Contract checks for the current aggregate food report implementation.

The PHP checks are structural because this environment does not provide a PHP
runtime; the report UI behavior is exercised separately by a Node test.

Run: python3 tests/test_food_aggregate_report_static.py
"""

from __future__ import annotations

import subprocess
import sys
from pathlib import Path

ROOT = Path(__file__).resolve().parent.parent
PHP = ROOT / "food-ticket.php"
ORDER_PHP = ROOT / "food-order.php"
HTML = ROOT / "food-ticket-web" / "index.html"
JS_TEST = ROOT / "tests" / "js" / "food-aggregate-report.test.js"


def function_region(source: str, start_marker: str, end_marker: str) -> str:
    start = source.find(start_marker)
    end = source.find(end_marker, start + len(start_marker))
    if start < 0 or end < 0:
        return ""
    return source[start:end]


def main() -> int:
    failures: list[str] = []
    checks = 0

    def check(condition: bool, message: str) -> None:
        nonlocal checks
        checks += 1
        if not condition:
            failures.append(message)

    php = PHP.read_text(encoding="utf-8")
    order_php = ORDER_PHP.read_text(encoding="utf-8")
    html = HTML.read_text(encoding="utf-8")

    aggregate = function_region(
        php,
        "function food_ticket_api_aggregate_report(",
        "function food_ticket_aggregate_columns(",
    )
    diagnostics = function_region(
        php,
        "function food_ticket_aggregate_diagnostics(",
        "function food_ticket_api_aggregate_report(",
    )
    order_summary = function_region(
        order_php,
        "function food_order_report_summary(",
        "function food_order_statistics_range(",
    )
    absent = function_region(
        php,
        "function food_ticket_api_absent(",
        "function food_ticket_api_monitoring(",
    )
    check(bool(aggregate), "تابع food_ticket_api_aggregate_report پیدا نشد")
    check(bool(diagnostics), "تابع food_ticket_aggregate_diagnostics پیدا نشد")
    check(bool(order_summary), "تابع food_order_report_summary پیدا نشد")
    check(bool(absent), "تابع food_ticket_api_absent پیدا نشد")

    # Order source and meal scopes: independent lunch and dinner totals.
    check("food_order_report_summary($from, $to, 'lunch')" in aggregate,
          "شمار سفارش‌های ناهار از summary جاری سفارش‌ها گرفته نمی‌شود")
    check("food_order_report_summary($from, $to, 'dinner')" in aggregate,
          "شمار سفارش‌های شام مستقل محاسبه نمی‌شود")
    check("food_date BETWEEN ? AND ? AND meal_type = ?" in order_summary,
          "summary سفارش‌ها باید بازه و وعده را پارامتری فیلتر کند")
    check("GROUP BY food_date, status" in order_summary,
          "summary سفارش‌ها باید وضعیت جاری را به تفکیک روز نگه دارد")
    check("['active' => 0, 'cancelled' => 0, 'total' => 0, 'by_date' => []]" in order_summary,
          "summary سفارش‌ها باید سفارش فعال و لغوشده را جدا کند")

    # Receipt ledger, logical auto receipts, and physical-print distinction.
    check("print_status = 'printed'" in aggregate,
          "گزارش فیش‌ها باید فقط ثبت‌های نهایی را بشمارد")
    check("event_type IN ('printed','print','guest','auto_printed','auto_guest')" in aggregate,
          "انواع legacy، مهمان و فیش خودکار در گزارش لحاظ نشده‌اند")
    check("$counts['auto_printed_lunch']++" in aggregate and "$counts['auto_printed_dinner']++" in aggregate,
          "فیش خودکار پرسنل به تفکیک وعده شمرده نمی‌شود")
    check("$counts['auto_guest_printed_lunch']++" in aggregate and "$counts['auto_guest_printed_dinner']++" in aggregate,
          "فیش خودکار مهمان به تفکیک وعده شمرده نمی‌شود")
    check("$counts['physical_printed_lunch']++" in aggregate and "$counts['physical_printed_dinner']++" in aggregate,
          "چاپ فیزیکی پرسنل از ثبت خودکار جدا نشده است")
    check("$counts['physical_guest_printed_lunch']++" in aggregate and "$counts['physical_guest_printed_dinner']++" in aggregate,
          "چاپ فیزیکی مهمان از ثبت خودکار جدا نشده است")
    check("$counts['printed_final']++" in aggregate and "$counts['printed_dinner']++" in aggregate,
          "مبنای ثبت فیش پرسنل برای ناهار و شام جدا نیست")
    check("food_ticket_auto_receipt_label($eventType" in aggregate,
          "برچسب رویدادهای ثبت خودکار در فهرست فیش‌ها ساخته نمی‌شود")
    check("food_ticket_api_absent($from, $to)" in aggregate,
          "فهرست غایبین از تابع مرجع گزارش غایبین گرفته نمی‌شود")
    check("$expected = $counts['lunch_orders'] - $counts['printed_final'];" in aggregate,
          "تطبیق غایبین باید فقط از سفارش و ثبت فیش ناهار محاسبه شود")
    check("$counts['has_mismatch']" in aggregate and "$counts['difference']" in aggregate,
          "وضعیت و اختلاف تطبیق گزارش نمی‌شود")

    # Diagnostics must expose useful read-only discrepancy sources.
    check("food_ticket_api_orders($fromDate, '', $toDate)" in diagnostics,
          "عیب‌یابی باید ردیف‌های سفارش ناهارِ مرجع را بررسی کند")
    check("event_type IN ('printed','print','guest','auto_printed','auto_guest')" in diagnostics,
          "تفکیک تشخیصی، رویدادهای خودکار/مهمان را پوشش نمی‌دهد")
    check("unprintable_lunch_order_count" in diagnostics and "duplicate_order_identity_count" in diagnostics,
          "عیب‌یابی علت‌های سفارش غیرقابل‌چاپ و تکراری را گزارش نمی‌کند")

    # Reporting paths are read-only and parameterized.
    for region_name, region in (("گزارش", aggregate), ("عیب‌یابی", diagnostics), ("خلاصه سفارش", order_summary)):
        for forbidden in ("DELETE FROM", "DROP TABLE", "UPDATE ", "INSERT INTO", "TRUNCATE"):
            check(forbidden not in region,
                  f"{region_name} نباید دستور تغییردهنده داشته باشد: {forbidden}")
    check("db()->prepare(" in aggregate and "$stmt->execute([$from, $to])" in aggregate,
          "کوئری رخدادهای فیش باید پارامتری باشد")
    check("BETWEEN ? AND ?" in diagnostics and "$countStmt->execute([$fromDate, $toDate])" in diagnostics,
          "کوئری‌های تشخیصی بازهٔ تاریخ پارامتری نیستند")

    # Authorization, endpoints, and export.
    for marker in (
        "'aggregate-report' => 'food.reports'",
        "'aggregate-report-export' => 'food.reports'",
        "$route === 'aggregate-report'",
        "$route === 'aggregate-report-export'",
        "'aggregate-report', 'aggregate-report-export'",
        "columns' => food_ticket_aggregate_columns()",
    ):
        check(marker in php, f"route/API یا مجوز گزارش وجود ندارد: {marker}")
    export = function_region(
        php,
        "function food_ticket_aggregate_export(",
        "function food_ticket_aggregate_row(",
    )
    check("xlsx_build(" in export and "xlsx_send(" in export and ".xlsx" in export,
          "استخراج گزارش باید XLSX واقعی بسازد")
    check("physical_printed_lunch" in export and "auto_printed_lunch" in export,
          "خروجی XLSX باید چاپ فیزیکی و ثبت خودکار را جدا کند")

    # Current panel tabs, summary, filtering, fields, export and print.
    for marker in (
        "const REPORT_TABS=[['classic','گزارشگیری'],['aggregate','گزارش تجمیعی']",
        "function reportAggregateView()",
        "function reportView(){",
        "function reportClassicView(){",
        "function loadAggregate(",
        "function showAggregatePreview()",
        "function aggDownloadUrl()",
        'id="report-filter"',
        'id="aggregate-filter"',
        'data-action="aggregate-export"',
        'data-action="aggregate-print"',
        'data-action="aggregate-today"',
        "data-agg-field=",
        "شام وارد این فهرست نمی‌شود",
        "تطبیق غایبین فقط برای ناهار انجام می‌شود",
        "فیش خودکار در این شمارش نیست",
        "مبنای تطبیق ناهار",
        "فهرست چاپ‌شده",
        "فهرست غایبین",
    ):
        check(marker in html, f"قرارداد UI جاری گزارش وجود ندارد: {marker}")
    for label in (
        "سفارش‌ها", "فیش خودکار پرسنل", "فیش خودکار مهمان",
        "فیش مهمان ثبت‌شده", "چاپ فیزیکی مهمان",
        "ثبت فیش پرسنل (مبنای گزارش)", "چاپ فیزیکی پرسنل",
        "غایبین ناهار",
    ):
        check(label in html, f"شاخص جاری گزارش «{label}» در پنل نیست")

    # Large API data is intentionally excluded from persisted browser state.
    check("aggregate:_ag" in html, "دادهٔ aggregate نباید در persist مرورگر ذخیره شود")
    check("const AGG_DEFAULT_FIELDS=['row','date','pc','name','food','meal_type','kind','status']" in html,
          "فیلدهای پیش‌فرض گزارش باید وعده و نوع فیش را داشته باشند")
    check("PANEL_VERSION='1.37.52'" in html,
          "نسخهٔ پنل برای جلوگیری از بارگذاری cache قدیمی بالا نرفته است")

    # Run the current behavior test against the same UI source.
    if JS_TEST.is_file():
        process = subprocess.run(
            ["node", str(JS_TEST)], cwd=ROOT,
            capture_output=True, text=True, timeout=120,
        )
        check(process.returncode == 0,
              f"تست رفتاری JS ناموفق است: {(process.stdout + process.stderr)[-500:]}")
    else:
        check(False, "تست رفتاری گزارش تجمیعی وجود ندارد")

    print(f"چک‌های قرارداد گزارش تجمیعی: {checks}")
    if failures:
        print(f"\nFAIL — {len(failures)} مورد:")
        for failure in failures:
            print(f"  - {failure}")
        return 1
    print("PASS — قرارداد جاری گزارش تجمیعی (سرور، دسترسی، پنل و رفتار UI) برقرار است.")
    return 0


if __name__ == "__main__":
    sys.exit(main())
