<?php
declare(strict_types=1);

// In-memory SQLite exercise of the real auto-receipt helper; no live DB or printer is used.
function app_error_log(string $message): void {}
function db(): PDO { return $GLOBALS['auto_receipt_pdo']; }
require __DIR__ . '/../food-ticket-auto-receipts.php';

function check_auto_receipt(bool $condition, string $label): void
{
    if (!$condition) {
        throw new RuntimeException('FAIL ' . $label);
    }
    echo 'PASS ' . $label . PHP_EOL;
}

function recent_weekday(DateTimeImmutable $today, int $weekday): string
{
    $daysBack = ((int) $today->format('N') - $weekday + 7) % 7;
    if ($daysBack === 0) {
        $daysBack = 7;
    }
    return $today->modify('-' . $daysBack . ' days')->format('Y-m-d');
}

$pdo = new PDO('sqlite::memory:');
$pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
$GLOBALS['auto_receipt_pdo'] = $pdo;
$pdo->exec('CREATE TABLE food_orders (id INTEGER PRIMARY KEY, employee_id INTEGER, food_date TEXT, meal_type TEXT, status TEXT, calendar_item_id INTEGER)');
$pdo->exec('CREATE TABLE users (id INTEGER PRIMARY KEY, employee_number TEXT, national_code TEXT, first_name TEXT, last_name TEXT, full_name TEXT)');
$pdo->exec('CREATE TABLE food_calendar_items (id INTEGER PRIMARY KEY, food_id INTEGER)');
$pdo->exec('CREATE TABLE food_catalog (id INTEGER PRIMARY KEY, food_name TEXT)');
$pdo->exec('CREATE TABLE food_ticket_events (
    id INTEGER PRIMARY KEY AUTOINCREMENT, source_key TEXT NOT NULL UNIQUE, source_uid TEXT, source_card TEXT,
    punch_date TEXT, punch_time TEXT, personnel_code TEXT, user_id INTEGER, national_code TEXT, full_name TEXT,
    food_type TEXT, ticket_key TEXT, event_type TEXT, print_status TEXT, last_error TEXT, source_payload TEXT,
    processed_at TEXT, meal_type TEXT, delivery_status TEXT, delivered_at TEXT
)');
$pdo->exec('CREATE TABLE food_ticket_daily_absence (absence_date TEXT, user_id INTEGER)');
$pdo->exec('CREATE TABLE food_guest_requests (
    id INTEGER PRIMARY KEY, request_date TEXT, meal_type TEXT, guest_count INTEGER, organization TEXT,
    requester_name TEXT, created_by INTEGER, status TEXT, food_id INTEGER
)');
$pdo->exec('CREATE TABLE holidays (holiday_date TEXT, is_active INTEGER, title TEXT)');

$today = new DateTimeImmutable('today', new DateTimeZone('Asia/Tehran'));
$date = $today->modify('-1 day')->format('Y-m-d');
$pdo->prepare('INSERT INTO holidays (holiday_date, is_active, title) VALUES (?, 1, ?)')->execute([$date, 'تعطیلی آزمون']);
$pdo->exec("INSERT INTO users (id, employee_number, national_code, first_name, last_name, full_name) VALUES
    (1, '101', '001', 'الف', 'یک', 'الف یک'),
    (2, '102', '002', 'ب', 'دو', 'ب دو'),
    (3, '103', '003', 'پ', 'سه', 'پ سه'),
    (4, '104', '004', 'ت', 'چهار', 'ت چهار'),
    (5, '105', '005', 'ث', 'پنج', 'ث پنج')");
$pdo->exec("INSERT INTO food_catalog (id, food_name) VALUES (1, 'ناهار آزمون'), (2, 'شام آزمون')");
$pdo->exec('INSERT INTO food_calendar_items (id, food_id) VALUES (1, 1), (2, 2)');
$orders = $pdo->prepare('INSERT INTO food_orders (id, employee_id, food_date, meal_type, status, calendar_item_id) VALUES (?, ?, ?, ?, ?, ?)');
foreach ([
    [11, 1, $date, 'lunch', 'active', 1],
    [12, 2, $date, 'dinner', 'active', 2],
    [13, 3, $date, 'lunch', 'active', 1],
    [14, 4, $date, 'lunch', 'active', 1],
    [15, 5, $date, 'lunch', 'cancelled', 1],
] as $row) {
    $orders->execute($row);
}
$pdo->prepare('INSERT INTO food_ticket_daily_absence (absence_date, user_id) VALUES (?, 3)')->execute([$date]);
$physical = $pdo->prepare("INSERT INTO food_ticket_events
    (source_key, source_uid, punch_date, personnel_code, user_id, national_code, full_name, food_type, event_type, print_status, meal_type, delivery_status)
    VALUES (?, 'physical-test', ?, '104', 4, '004', 'ت چهار', 'ناهار چاپ‌شده', 'printed', 'printed', 'lunch', 'delivered')");
$physical->execute([str_repeat('a', 64), $date]);
$guestRequests = $pdo->prepare('INSERT INTO food_guest_requests (id, request_date, meal_type, guest_count, organization, requester_name, created_by, status, food_id) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)');
foreach ([
    [21, $date, 'lunch', 2, 'سازمان یک', 'درخواست‌کننده', 1, 'active', 1],
    [22, $date, 'dinner', 1, 'سازمان دو', 'درخواست‌کننده', 1, 'active', 2],
    [23, $date, 'lunch', 4, 'لغوشده', 'درخواست‌کننده', 1, 'cancelled', 1],
    [24, $date, 'lunch', 3, 'بدون مالک', 'درخواست‌کننده', null, 'active', 1],
] as $row) {
    $guestRequests->execute($row);
}

$run = food_ticket_auto_receipts_run($date);
check_auto_receipt($run['holiday'] === true, 'active holiday is recognized');
check_auto_receipt($run['staff_created'] === 2, 'active holiday lunch and dinner staff receipts are created');
check_auto_receipt($run['guest_created'] === 3, 'active guest requests create one logical receipt per guest');
check_auto_receipt($run['skipped_absence'] === 1, 'daily absence suppresses the employee receipt');
check_auto_receipt($run['skipped_real_event'] === 1, 'existing physical receipt suppresses duplicate logical receipt');
check_auto_receipt((int) $pdo->query("SELECT COUNT(*) FROM food_ticket_events WHERE event_type IN ('auto_printed','auto_guest')")->fetchColumn() === 5, 'cancelled and ownerless requests create no auto receipts');
check_auto_receipt((int) $pdo->query("SELECT COUNT(*) FROM food_ticket_events WHERE event_type IN ('auto_printed','auto_guest') AND print_status = 'printed'")->fetchColumn() === 5, 'logical events are marked recorded without enqueueing physical print');
$payload = (string) $pdo->query("SELECT source_payload FROM food_ticket_events WHERE event_type = 'auto_printed' AND meal_type = 'dinner'")->fetchColumn();
check_auto_receipt(str_contains($payload, '"physical_print":false'), 'auto receipt payload explicitly records no physical print');
$repeat = food_ticket_auto_receipts_run($date);
check_auto_receipt($repeat['staff_created'] === 0 && $repeat['guest_created'] === 0 && $repeat['already_registered'] === 5, 're-running the same day is idempotent');

$weekend = food_ticket_auto_receipt_holiday(recent_weekday($today, 4));
check_auto_receipt($weekend['holiday'] && $weekend['weekend'], 'Thursday is recognized as a weekend day');
$weekend = food_ticket_auto_receipt_holiday(recent_weekday($today, 5));
check_auto_receipt($weekend['holiday'] && $weekend['weekend'], 'Friday is recognized as a weekend day');
try {
    food_ticket_auto_receipts_run($today->format('Y-m-d'));
    check_auto_receipt(false, 'current-day auto receipt is rejected');
} catch (RuntimeException $error) {
    check_auto_receipt(str_contains($error->getMessage(), 'به پایان رسیده'), 'current-day auto receipt is rejected');
}
try {
    food_ticket_auto_receipts_run('not-a-date');
    check_auto_receipt(false, 'invalid target date is rejected');
} catch (RuntimeException $error) {
    check_auto_receipt(str_contains($error->getMessage(), 'معتبر نیست'), 'invalid target date is rejected');
}

echo "ALL PASSED" . PHP_EOL;
