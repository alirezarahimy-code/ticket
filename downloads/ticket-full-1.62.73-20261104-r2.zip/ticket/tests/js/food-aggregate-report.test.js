// تست رفتاری UI گزارش تجمیعی — کد واقعی را از food-ticket-web/index.html جدا و با mock اجرا می‌کند.
// اجرا: node tests/js/food-aggregate-report.test.js
const fs = require('fs');
const assert = require('assert');
const path = require('path');

const root = path.resolve(__dirname, '../..');
const html = fs.readFileSync(path.join(root, 'food-ticket-web/index.html'), 'utf8');
const start = html.indexOf('const AGG_FIELDS_KEY=');
const fnEnd = html.indexOf('function reportClassicView(){', start);
assert(start > 0 && fnEnd > start, 'بلوک توابع گزارش تجمیعی در index.html پیدا نشد');
const hStart = html.indexOf("document.addEventListener('click',e=>{\n const sortBtn=", fnEnd);
const hEndMarker = "document.addEventListener('click',e=>{const a=e.target.closest('[data-action]');if(a?.dataset.action==='today-orders'){e.preventDefault();";
const hEnd = html.indexOf(hEndMarker, hStart);
assert(hStart > 0 && hEnd > hStart, 'بلوک هندلرهای گزارش تجمیعی پیدا نشد');
const block = html.slice(start, fnEnd) + '\n' + html.slice(hStart, hEnd);

const storage = new Map();
const listeners = { click: [], change: [], submit: [] };
const created = [];
const toastCalls = [];
const apiCalls = [];
let renderCount = 0;

const env = {
  localStorage: {
    getItem: (key) => (storage.has(key) ? storage.get(key) : null),
    setItem: (key, value) => storage.set(key, String(value)),
  },
  document: {
    addEventListener: (type, handler) => { if (listeners[type]) listeners[type].push(handler); },
    querySelector: () => null,
    querySelectorAll: () => [],
    createElement: () => ({ className: '', innerHTML: '', href: '', download: '', click() {}, remove() {}, style: {} }),
    body: { appendChild: (item) => created.push(item), classList: { add() {}, remove() {} } },
  },
  state: { report: { from: '۱۴۰۵/۰۸/۰۵', to: '۱۴۰۵/۰۸/۰۵' }, reportTab: 'aggregate' },
  view: 'reports',
  serviceMode: true,
  apiBase: '',
  esc: (value) => String(value ?? '').replace(/&/g, '&amp;').replace(/</g, '&lt;'),
  faDate: (value) => String(value ?? ''),
  toFaDigits: (value) => String(value).replace(/\d/g, (digit) => '۰۱۲۳۴۵۶۷۸۹'[digit]),
  isoDateFor: (value) => {
    const normalized = String(value ?? '').replace(/[۰-۹]/g, (digit) => '۰۱۲۳۴۵۶۷۸۹'.indexOf(digit));
    if (/^\d{4}-\d{2}-\d{2}$/.test(normalized)) return normalized;
    const match = normalized.match(/^(\d{4})\/(\d{1,2})\/(\d{1,2})$/);
    if (match) return '2026-' + match[2].padStart(2, '0') + '-' + match[3].padStart(2, '0');
    return null;
  },
  todayIso: () => '2026-10-27',
  todayJalali: () => '۱۴۰۵/۰۸/۰۵',
  formObject: (form) => form._values || {},
  heading: (title, subtitle, actions = '') => `<div class="heading"><h2>${title}</h2><p>${subtitle}</p>${actions}</div>`,
  api: (url) => { apiCalls.push(url); return Promise.resolve({ ok: true, columns: [] }); },
  persist: () => {},
  render: () => { renderCount++; },
  toast: (message) => toastCalls.push(String(message)),
  loadReportMonitoring: () => {},
  reportClassicView: () => '<div id="classic-report">گزارش‌گیری کلاسیک</div>',
  Promise, JSON, Array, String, Number, Math, Object, Set, URLSearchParams,
};

const names = Object.keys(env);
const execute = new Function(...names, `${block}; return {
  reportView, reportAggregateView, aggFields, aggSaveFields, aggRange, aggDateLabel,
  aggCell, aggTable, aggSelectedCols, aggSorted, aggLastName, aggSortValue, loadAggregate,
  aggDownloadUrl, showAggregatePreview, AGG_ALL_FIELDS, AGG_DEFAULT_FIELDS
};`);
const ui = execute(...names.map((name) => env[name]));

function fire(type, target) {
  const event = { target, preventDefault() {}, stopImmediatePropagation() {} };
  for (const handler of listeners[type]) handler(event);
}

// تب کلاسیک و تب گزارش تجمیعی هر دو در فهرست باقی مانده‌اند.
let output = ui.reportView();
assert(output.includes('data-report-tab="classic"') && output.includes('data-report-tab="aggregate"'));
assert(output.includes('گزارشگیری') && output.includes('گزارش تجمیعی'));
env.state.reportTab = 'classic';
assert(ui.reportView().includes('id="classic-report"'), 'تب کلاسیک باید محتوای گزارش‌گیری را حفظ کند');
env.state.reportTab = 'aggregate';

// دادهٔ نمونه، شامل ناهار/شام و چاپ فیزیکی/ثبت خودکار.
env.state.aggregate = {
  counts: {
    lunch_orders: 112, cancelled_orders: 5, order_rows: 117,
    dinner_orders: 8, dinner_cancelled_orders: 1, dinner_order_rows: 9,
    auto_printed_lunch: 10, auto_printed_dinner: 2,
    auto_guest_printed_lunch: 3, auto_guest_printed_dinner: 1,
    guest_printed_lunch: 6, guest_printed_dinner: 2,
    physical_guest_printed_lunch: 3, physical_guest_printed_dinner: 1,
    printed_final: 102, printed_dinner: 8,
    physical_printed_lunch: 92, physical_printed_dinner: 6,
    absent: 10, expected_absent: 10, has_mismatch: false, difference: 0,
  },
  diagnostics: {
    active_lunch_orders: 112, active_dinner_orders: 8, active_other_meal_orders: 0,
    reportable_lunch_rows: 112, unique_lunch_identities: 112,
    matched_printed_lunch_identities: 102, absent_count: 10, difference: 0,
    event_type_status_counts: [],
  },
  printed_people: [
    { pc: '1001', name: 'علی رضایی', food: 'چلوکباب', kind: 'پرسنل', date: '2026-10-27', time: '12:01:00', meal_type: 'lunch', status: 'چاپ‌شده' },
    { pc: '1002', name: 'مریم احمدی', food: 'ثبت خودکار', kind: 'چاپ خودکار', date: '2026-10-27', time: '', meal_type: 'lunch', status: 'چاپ خودکار تعطیلات' },
    { pc: '', name: 'مهمان شام', food: 'شام آزمون', kind: 'چاپ خودکار مهمان', date: '2026-10-27', time: '', meal_type: 'dinner', status: 'چاپ خودکار مهمان شام' },
  ],
  absent_people: [
    { pc: '1003', name: 'مریم احمدی', food: 'قورمه‌سبزی', status: 'غایب', date: '2026-10-27', declared: true, meal_type: 'lunch' },
  ],
  source_notes: [],
};
output = ui.reportAggregateView();
for (const label of ['سفارش‌ها', 'فیش خودکار پرسنل', 'فیش خودکار مهمان', 'ثبت فیش پرسنل (مبنای گزارش)', 'فهرست چاپ‌شده', 'فهرست غایبین']) {
  assert(output.includes(label), `بخش گزارش «${label}» نمایش داده نشد`);
}
for (const label of ['۱۱۲', '۸', '۱۰۲', 'بدون چاپ فیزیکی', 'تطبیق غایبین فقط برای ناهار', 'مریم احمدی', 'غیبت اعلامشده', 'aggregate-export', 'aggregate-print', 'id="aggregate-filter"', 'data-agg-field="name"']) {
  assert(output.includes(label), `مقدار/کنترل «${label}» در گزارش نیست`);
}
assert(output.includes('شام وارد این فهرست نمی‌شود'), 'شام نباید وارد فهرست غایبین ناهار شود');

// مغایرت باید هشدار بصری و توضیح محدودیت تطبیق عددی داشته باشد.
env.state.aggregate.counts.has_mismatch = true;
env.state.aggregate.counts.expected_absent = 12;
env.state.aggregate.counts.difference = 2;
env.state.aggregate.diagnostics.difference = 2;
output = ui.reportAggregateView();
assert(output.includes('class="notice warn"') && output.includes('مغایرت عددی به‌تنهایی'), 'هشدار مغایرت عددی/محدودیت آن نمایش داده نشد');
assert(output.includes('اختلاف ۲'), 'مقدار اختلاف فارسی نمایش داده نشد');
env.state.aggregate.counts.has_mismatch = false;
env.state.aggregate.counts.expected_absent = 10;
env.state.aggregate.counts.difference = 0;
env.state.aggregate.diagnostics.difference = 0;

// انتخاب فیلدها، ذخیره در localStorage و جدول مرتب‌شونده.
storage.clear();
assert.deepStrictEqual(ui.aggFields(), ui.AGG_DEFAULT_FIELDS, 'فهرست فیلدهای پیش‌فرض نادرست است');
ui.aggSaveFields(['pc', 'name']);
assert.deepStrictEqual(ui.aggFields(), ['pc', 'name'], 'ذخیره و بازیابی فیلدهای گزارش کار نمی‌کند');
assert.strictEqual(ui.aggSelectedCols().length, 2);
output = ui.aggTable([{ pc: '1', name: 'الف' }], 'خالی');
assert(output.includes('data-agg-sort="pc"') && output.includes('data-agg-sort="name"'));
assert(!output.includes('data-agg-sort="food"'), 'فیلد انتخاب‌نشده نباید نمایش داده شود');
assert(output.includes('fm-order-block-start') && output.includes('data-no-sort') && output.includes('fm-order-report-table'));
storage.clear();

// مرتب‌سازی نام خانوادگی، شمارهٔ پرسنلی و جهت نزولی.
ui.aggSaveFields(['name']);
const sorted = ui.aggSorted([{ name: 'علی رضایی' }, { name: 'مهدی احمدی' }, { name: 'رضا باقری' }]);
assert.deepStrictEqual(sorted.map((row) => row.name), ['مهدی احمدی', 'رضا باقری', 'علی رضایی']);
storage.clear();
env.state.aggSort = { key: 'pc', dir: 'asc' };
assert.deepStrictEqual(ui.aggSorted([{ pc: '2' }, { pc: '1' }]).map((row) => row.pc), ['1', '2']);
env.state.aggSort = { key: 'name', dir: 'desc' };
assert.deepStrictEqual(ui.aggSorted([{ name: 'علی احمدی' }, { name: 'رضا باقری' }]).map((row) => row.name), ['رضا باقری', 'علی احمدی']);
delete env.state.aggSort;

// کلیک تب، URL خروجی XLSX، پیش‌نمایش چاپ و بازهٔ نامعتبر.
const previewData = env.state.aggregate;
let rendersBefore = renderCount;
fire('click', { closest: (selector) => selector === '[data-report-tab]' ? { dataset: { reportTab: 'classic' } } : null });
assert.strictEqual(env.state.reportTab, 'classic');
assert(renderCount > rendersBefore);
fire('click', { closest: (selector) => selector === '[data-report-tab]' ? { dataset: { reportTab: 'aggregate' } } : null });
assert.strictEqual(env.state.reportTab, 'aggregate');
env.state.aggregate = previewData;
env.state.aggregateLoading = false;
env.state.aggregateError = '';

assert(ui.aggDownloadUrl().includes('/api/aggregate-report-export?') && ui.aggDownloadUrl().includes('fields='));
fire('click', { closest: (selector) => selector === '[data-action]' ? { dataset: { action: 'aggregate-export' } } : null });
const download = created[created.length - 1];
assert(download.href.includes('aggregate-report-export') && download.href.includes('from=') && download.href.includes('to=') && download.href.includes('fields='));
assert(download.download.endsWith('.xlsx'));
fire('click', { closest: (selector) => selector === '[data-action]' ? { dataset: { action: 'aggregate-print' } } : null });
const preview = created[created.length - 1];
assert(preview.className === 'print-preview-layer');
assert(preview.innerHTML.includes('پیش‌نمایش گزارش تجمیعی') && preview.innerHTML.includes('مبنای تطبیق ناهار'));

toastCalls.length = 0;
fire('submit', { id: 'aggregate-filter', matches: (selector) => selector === '#report-filter,#aggregate-filter' || selector === '#aggregate-filter', _values: { from: '۱۴۰۵/۰۸/۱۰', to: '۱۴۰۵/۰۸/۰۱' } });
assert(toastCalls.some((message) => message.includes('معتبر نیست')), 'بازهٔ معکوس باید رد شود');
fire('click', { closest: (selector) => selector === '[data-action]' ? { dataset: { action: 'aggregate-today' } } : null });
assert.strictEqual(env.state.report.from, '۱۴۰۵/۰۸/۰۵');
assert.strictEqual(env.state.report.to, '۱۴۰۵/۰۸/۰۵');

console.log('PASS aggregate report UI: meals, auto/physical distinction, mismatch, fields, sorting, export, print and date validation');
