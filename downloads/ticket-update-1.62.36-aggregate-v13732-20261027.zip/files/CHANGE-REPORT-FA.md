# اصلاح نمایش اسامی (1.37.32)
- مارکاپ جدول عیناً مثل «فیشهای چاپشده و غذای تحویلشده»: کلاس fm-rows fm-order-report-table is-compact، خط جداکننده fm-order-block-start، سلول خالی fm-order-empty-cell.
- data-no-sort اضافه شد تا list-sort.js بلوکبندی را به هم نریزد.
- سرستونهای کلیکی fm-sort-btn، سورت پیشفرض نام خانوادگی.
- بعد از نصب Ctrl+F5.
