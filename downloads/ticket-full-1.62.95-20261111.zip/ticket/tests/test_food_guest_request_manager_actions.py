from pathlib import Path
import unittest

ROOT = Path(__file__).resolve().parents[1]


class FoodGuestRequestManagerActionTests(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        cls.order = (ROOT / "food-order.php").read_text(encoding="utf-8")
        cls.guest_js = (ROOT / "assets/food-order-guest.js").read_text(encoding="utf-8")

    def test_owner_and_support_manager_permissions_are_enforced_server_side(self):
        self.assertIn("function food_guest_request_is_reviewer(array $user)", self.order)
        self.assertIn("food_order_user_is_cancel_reviewer($user)", self.order)
        self.assertIn("user_service_group($user) === 'support'", self.order)
        self.assertIn("(int) ($row['created_by'] ?? 0) === $uid", self.order)
        self.assertIn("food_guest_request_can_manage($user, $row)", self.order)

    def test_update_delete_and_cancel_have_separate_api_routes_and_audit(self):
        for route in ["guest-request-update", "guest-request-delete", "guest-request-cancel"]:
            self.assertIn("$route === '" + route + "'", self.order)
        self.assertIn("food_order_audit('food_guest_request_update'", self.order)
        self.assertIn("food_order_audit('food_guest_request_delete'", self.order)
        self.assertIn("food_order_audit('food_guest_request_cancel'", self.order)
        self.assertIn("UPDATE food_guest_requests SET request_date = ?, meal_type = ?, organization = ?, guest_count = ?, requester_name = ?, note = ?", self.order)
        self.assertIn("DELETE FROM food_guest_requests WHERE id = ?", self.order)

    def test_ui_renders_authorized_edit_cancel_delete_actions(self):
        self.assertIn("if (r.can_edit)", self.guest_js)
        self.assertIn("if (r.can_cancel)", self.guest_js)
        self.assertIn("if (r.can_delete)", self.guest_js)
        self.assertIn("request(editingId ? 'guest-request-update' : 'guest-request'", self.guest_js)
        self.assertIn("request('guest-request-delete'", self.guest_js)
        self.assertIn("request('guest-request-cancel'", self.guest_js)
        self.assertIn("created_by_name", self.guest_js)

    def test_current_day_deadline_and_past_date_are_guarded(self):
        self.assertIn("function food_guest_request_change_window_open(", self.order)
        self.assertIn("food_guest_request_same_day_is_open($now)", self.order)
        self.assertIn("food_guest_request_change_window_open((string) ($row['request_date'] ?? ''))", self.order)

    def test_past_guest_requests_can_be_deleted_without_bypassing_permissions_or_audit(self):
        listing_start = self.order.index("function food_guest_request_list(")
        listing_end = self.order.index("function food_guest_request_create(", listing_start)
        listing = self.order[listing_start:listing_end]
        self.assertIn("$canDelete = $canManage && ($date < $today || food_guest_request_change_window_open($date, $now));", listing)

        delete_start = self.order.index("function food_guest_request_delete(")
        delete_end = self.order.index("function food_order_api_handle(", delete_start)
        delete = self.order[delete_start:delete_end]
        self.assertIn("food_guest_request_can_manage($user, $row)", delete)
        self.assertIn("food_order_audit('food_guest_request_delete'", delete)
        self.assertIn("DELETE FROM food_guest_requests WHERE id = ?", delete)
        self.assertIn("$requestDate >= food_order_today() && !food_guest_request_change_window_open($requestDate)", delete)
        self.assertIn("$canDelete = $canManage && ($date < $today || food_guest_request_change_window_open($date, $now));", listing)


if __name__ == "__main__":
    unittest.main()
