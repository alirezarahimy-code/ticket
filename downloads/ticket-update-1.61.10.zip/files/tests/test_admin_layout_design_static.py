from pathlib import Path
import unittest

ROOT = Path(__file__).resolve().parents[1]


class AdminLayoutDesignStaticTests(unittest.TestCase):
    def test_layout_editor_is_admin_only_and_saves_validated_page_settings(self) -> None:
        module = (ROOT / "admin-layout-design.php").read_text(encoding="utf-8")
        self.assertIn("function admin_layout_design_is_admin(array $user): bool", module)
        self.assertIn("require_primary_admin();", module)
        self.assertIn("require_csrf();", module)
        self.assertIn("function admin_layout_design_validate_styles", module)
        self.assertIn("admin_layout_design_validate_rules($body['rules'] ?? [])", module)
        self.assertIn("save_setting(ADMIN_LAYOUT_DESIGN_SETTING", module)
        self.assertNotIn("<script", module)
        self.assertNotIn("innerHTML", module)

    def test_design_view_is_available_in_shared_pages_and_food_ticket_panel(self) -> None:
        index = (ROOT / "index.php").read_text(encoding="utf-8")
        food_ticket = (ROOT / "food-ticket.php").read_text(encoding="utf-8")
        javascript = (ROOT / "assets/admin-layout-design.js").read_text(encoding="utf-8")
        self.assertIn("data-layout-design-launch", index)
        self.assertIn("admin_layout_design_api_handle($user)", index)
        self.assertIn("data-layout-page=\"food-ticket\"", food_ticket)
        self.assertIn("assets/admin-layout-design.js?v=1", food_ticket)
        self.assertIn("grid-template-columns", javascript)
        self.assertIn("white-space", javascript)
        self.assertIn("data-ald-reset", javascript)

    def test_order_table_has_ninth_action_track_and_keeps_cancel_button_inline(self) -> None:
        css = (ROOT / "assets/food-order.css").read_text(encoding="utf-8")
        self.assertIn("minmax(120px,1fr); gap:8px", css)
        self.assertIn(".fo-my-orders .table-row > td:last-child .button { white-space:nowrap; }", css)


if __name__ == "__main__":
    unittest.main()
