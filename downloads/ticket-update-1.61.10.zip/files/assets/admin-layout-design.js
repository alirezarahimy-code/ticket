(() => {
  'use strict';

  if (!document.body || document.body.dataset.layoutDesignAdmin !== '1') return;
  let launcher = document.querySelector('[data-layout-design-launch]');
  if (!launcher) {
    launcher = document.createElement('button');
    launcher.type = 'button';
    launcher.className = 'ald-floating-launch';
    launcher.dataset.layoutDesignLaunch = '1';
    launcher.dataset.layoutPageTitle = 'سامانه مدیریت غذا';
    launcher.setAttribute('aria-pressed', 'false');
    launcher.textContent = '🎨 طراحی همین صفحه';
    document.body.appendChild(launcher);
  }

  const page = document.body.dataset.layoutPage || 'dashboard';
  const api = 'index.php?layout_design_api=1&layout_page=' + encodeURIComponent(page);
  const propertyTitles = {
    width: 'عرض', 'min-width': 'حداقل عرض', 'max-width': 'حداکثر عرض',
    height: 'ارتفاع', 'min-height': 'حداقل ارتفاع', 'margin-top': 'فاصله از بالا',
    'margin-bottom': 'فاصله از پایین', padding: 'فاصلهٔ داخلی', gap: 'فاصله بین اجزا',
    'row-gap': 'فاصلهٔ ردیف‌ها', 'column-gap': 'فاصلهٔ ستون‌ها', 'font-size': 'اندازهٔ نوشته',
    'line-height': 'ارتفاع خط', 'text-align': 'تراز نوشته', 'white-space': 'شکستن خط',
    display: 'نوع چیدمان', 'grid-template-columns': 'عرض ستون‌ها', 'flex-wrap': 'رفتن به خط بعد',
    'justify-content': 'تراز افقی اجزا', 'align-items': 'تراز عمودی اجزا',
  };
  const selectOptions = {
    'text-align': [['', 'پیش‌فرض'], ['right', 'راست'], ['center', 'وسط'], ['left', 'چپ']],
    'white-space': [['', 'پیش‌فرض'], ['normal', 'شکستن در صورت نیاز'], ['nowrap', 'بدون شکستن خط'], ['pre-wrap', 'حفظ فاصله و شکستن خط']],
    display: [['', 'پیش‌فرض'], ['block', 'بلوک'], ['inline-block', 'بلوک درون‌خطی'], ['inline-flex', 'فلکس درون‌خطی'], ['flex', 'فلکس'], ['grid', 'شبکه']],
    'flex-wrap': [['', 'پیش‌فرض'], ['nowrap', 'یک خط'], ['wrap', 'اجازهٔ خط بعد']],
    'justify-content': [['', 'پیش‌فرض'], ['start', 'ابتدا'], ['center', 'وسط'], ['end', 'انتها'], ['space-between', 'فاصلهٔ مساوی']],
    'align-items': [['', 'پیش‌فرض'], ['start', 'ابتدا'], ['center', 'وسط'], ['end', 'انتها'], ['stretch', 'کشیده']],
  };
  const lengthProps = new Set(['width', 'min-width', 'max-width', 'height', 'min-height', 'margin-top', 'margin-bottom', 'padding', 'gap', 'row-gap', 'column-gap']);
  const textProps = new Set(['font-size', 'line-height', 'grid-template-columns']);
  let rules = [];
  let selected = null;
  let selectedPath = null;
  let active = false;
  let dirty = false;
  let loading = false;
  let panel;
  let hovered = null;

  const esc = (value) => String(value == null ? '' : value).replace(/[&<>"']/g, (char) => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[char]));
  const pathKey = (path) => JSON.stringify(path);

  function makePath(element) {
    const path = [];
    let node = element;
    while (node && node !== document.body && node.nodeType === 1) {
      const tag = node.tagName.toLowerCase();
      if (['script', 'style', 'svg', 'path', 'iframe'].includes(tag)) return null;
      const siblings = node.parentElement ? Array.from(node.parentElement.children).filter((item) => item.tagName === node.tagName) : [];
      const classes = Array.from(node.classList || []).filter((name) => /^[A-Za-z_][A-Za-z0-9_-]{0,59}$/.test(name)).slice(0, 4);
      const id = /^[A-Za-z][A-Za-z0-9_-]{0,79}$/.test(node.id || '') ? node.id : '';
      path.unshift({ tag, id, classes, index: Math.max(1, siblings.indexOf(node) + 1) });
      node = node.parentElement;
    }
    return path.length && path.length <= 18 ? path : null;
  }

  function selectorFor(path) {
    if (!Array.isArray(path) || !path.length) return '';
    return 'body[data-layout-page="' + page + '"] > ' + path.map((part) => {
      let selector = part.tag;
      if (part.id) selector += '#' + part.id;
      (part.classes || []).forEach((name) => { selector += '.' + name; });
      selector += ':nth-of-type(' + Number(part.index) + ')';
      return selector;
    }).join(' > ');
  }

  function applyAll() {
    rules.forEach((rule) => {
      const node = document.querySelector(selectorFor(rule.path));
      if (!node) return;
      Object.entries(rule.styles || {}).forEach(([property, value]) => {
        if (propertyTitles[property] && value !== '') node.style.setProperty(property, value, 'important');
      });
    });
  }

  function removeRule(path) {
    const key = pathKey(path);
    rules = rules.filter((rule) => pathKey(rule.path) !== key);
  }

  function selectedRule(create) {
    if (!selectedPath) return null;
    let rule = rules.find((item) => pathKey(item.path) === pathKey(selectedPath));
    if (!rule && create) {
      rule = { path: selectedPath, styles: {} };
      rules.push(rule);
    }
    return rule || null;
  }

  function previewProperty(property, value) {
    if (!selected) return;
    const rule = selectedRule(Boolean(value));
    if (!rule) {
      selected.style.removeProperty(property);
      return;
    }
    if (!value) delete rule.styles[property];
    else rule.styles[property] = value;
    selected.style.removeProperty(property);
    if (value) selected.style.setProperty(property, value, 'important');
    if (!Object.keys(rule.styles).length) removeRule(selectedPath);
    dirty = true;
    updateButtons();
  }

  function selectedDescription() {
    if (!selected) return 'برای شروع، روی بخش یا کنترلی که می‌خواهید چینش آن را اصلاح کنید کلیک کنید.';
    const bits = [selected.tagName.toLowerCase()];
    if (selected.id) bits.push('#' + selected.id);
    Array.from(selected.classList || []).slice(0, 2).forEach((name) => bits.push('.' + name));
    return 'جزء انتخاب‌شده: ' + bits.join('');
  }

  function renderControls() {
    if (!panel) return;
    const host = panel.querySelector('[data-ald-controls]');
    const desc = panel.querySelector('[data-ald-selection]');
    if (desc) desc.textContent = selectedDescription();
    if (!host) return;
    if (!selected) {
      host.innerHTML = '<p class="ald-empty">برای ویرایش، روی فیلد، دکمه، ستون جدول یا بلوک موردنظر کلیک کنید.</p>';
      return;
    }
    const rule = selectedRule(false);
    const styles = rule ? rule.styles : {};
    host.innerHTML = Object.entries(propertyTitles).map(([property, title]) => {
      const value = styles[property] || '';
      if (selectOptions[property]) {
        return '<label class="ald-control"><span>' + esc(title) + '</span><select data-ald-property="' + esc(property) + '">' + selectOptions[property].map(([optionValue, label]) => '<option value="' + esc(optionValue) + '"' + (value === optionValue ? ' selected' : '') + '>' + esc(label) + '</option>').join('') + '</select></label>';
      }
      const placeholder = property === 'grid-template-columns' ? 'مثال: 42px 1fr 1fr' : (property === 'font-size' ? 'مثال: 14' : (property === 'line-height' ? 'مثال: 1.5' : 'مثال: 120px یا 40%'));
      return '<label class="ald-control"><span>' + esc(title) + '</span><input type="text" inputmode="text" data-ald-property="' + esc(property) + '" value="' + esc(value) + '" placeholder="' + esc(placeholder) + '"></label>';
    }).join('') + '<p class="ald-help">برای حذف یک تغییر، مقدار آن را خالی کنید. مقدارها هنگام ذخیره در سرور اعتبارسنجی می‌شوند.</p>';
  }

  function updateButtons() {
    if (!panel) return;
    const save = panel.querySelector('[data-ald-save]');
    if (save) { save.disabled = loading || !dirty; save.textContent = loading ? 'در حال ذخیره…' : (dirty ? 'ذخیرهٔ چیدمان' : 'تغییری برای ذخیره نیست'); }
    const reset = panel.querySelector('[data-ald-reset]');
    if (reset) reset.disabled = loading || !rules.length;
  }

  function createPanel() {
    if (panel) return panel;
    panel = document.createElement('aside');
    panel.className = 'ald-panel';
    panel.setAttribute('role', 'dialog');
    panel.setAttribute('aria-label', 'طراحی چیدمان صفحه');
    panel.innerHTML = '<div class="ald-head"><div><strong>طراحی همین صفحه</strong><small>' + esc(launcher.dataset.layoutPageTitle || 'صفحهٔ فعلی') + '</small></div><button type="button" class="ald-close" data-ald-close aria-label="بستن">×</button></div>' +
      '<div class="ald-instructions">حالت انتخاب فعال است؛ روی جزء دلخواه کلیک کنید. عملکرد اصلی فرم در این حالت اجرا نمی‌شود.</div>' +
      '<div class="ald-selection" data-ald-selection></div><div class="ald-controls" data-ald-controls></div>' +
      '<div class="ald-actions"><button type="button" class="ald-save" data-ald-save>ذخیرهٔ چیدمان</button><button type="button" class="ald-reset" data-ald-reset>بازگردانی پیش‌فرض</button></div>' +
      '<small class="ald-footnote">تنظیم‌ها فقط ظاهر همین صفحه را تغییر می‌دهند و برای همهٔ کاربران اعمال می‌شوند.</small>';
    document.body.appendChild(panel);
    panel.addEventListener('input', onControlChange);
    panel.addEventListener('change', onControlChange);
    panel.addEventListener('click', (event) => {
      if (event.target.closest('[data-ald-close]')) closeDesign();
      if (event.target.closest('[data-ald-save]')) saveDesign();
      if (event.target.closest('[data-ald-reset]')) resetDesign();
    });
    renderControls();
    return panel;
  }

  function chooseTarget(target) {
    if (!(target instanceof Element)) return null;
    const content = target.closest('.content-wrap,.page,#screen');
    if (!content || target.closest('.topbar,.footer,.notification-toasts,.ald-panel,.ald-floating-launch')) return null;
    const candidate = target.closest('button,input,select,textarea,label,form,fieldset,th,td,tr,table,.card,.form-card,.form-grid,.form-actions,.actions,.table-wrap,.fo-day,.fo-calendar-grid,.grid,.section-title,.page-heading') || target;
    return candidate instanceof Element ? candidate : null;
  }

  function onPointerOver(event) {
    if (!active) return;
    const candidate = chooseTarget(event.target);
    if (hovered && hovered !== selected) hovered.classList.remove('ald-hover');
    hovered = candidate;
    if (hovered && hovered !== selected) hovered.classList.add('ald-hover');
  }

  function onDocumentClick(event) {
    if (!active || event.target.closest('.ald-panel') || event.target.closest('[data-layout-design-launch]')) return;
    const candidate = chooseTarget(event.target);
    if (!candidate) return;
    event.preventDefault();
    event.stopPropagation();
    if (typeof event.stopImmediatePropagation === 'function') event.stopImmediatePropagation();
    if (selected) selected.classList.remove('ald-selected');
    selected = candidate;
    selectedPath = makePath(candidate);
    selected.classList.remove('ald-hover');
    selected.classList.add('ald-selected');
    renderControls();
  }

  function onControlChange(event) {
    const control = event.target.closest('[data-ald-property]');
    if (!control || !selected) return;
    const property = control.dataset.aldProperty;
    let value = String(control.value || '').trim();
    if (lengthProps.has(property) && value && /^\d+(?:\.\d+)?$/.test(value)) value += property === 'font-size' ? 'px' : 'px';
    if (property === 'font-size' && value.endsWith('px')) value = value.slice(0, -2);
    if (property === 'line-height' && value) value = value.replace(',', '.');
    if (textProps.has(property) && property !== 'grid-template-columns' && property !== 'line-height' && value && /^\d+(?:\.\d+)?$/.test(value)) value += 'px';
    previewProperty(property, value);
  }

  async function request(payload, method) {
    const response = await fetch(api, {
      method: method || 'GET',
      credentials: 'same-origin',
      cache: 'no-store',
      headers: Object.assign({ Accept: 'application/json' }, method === 'POST' ? { 'Content-Type': 'application/json', 'X-CSRF-Token': window.ITSM_CSRF || '' } : {}),
      body: method === 'POST' ? JSON.stringify(payload) : undefined,
    });
    const result = await response.json().catch(() => ({}));
    if (!response.ok || !result.ok) throw new Error(result.error || 'ذخیره یا دریافت طراحی انجام نشد.');
    return result;
  }

  async function saveDesign() {
    if (loading || !dirty) return;
    loading = true;
    updateButtons();
    try {
      await request({ action: 'save', page, rules }, 'POST');
      dirty = false;
      if (window.confirm('چیدمان ذخیره شد. صفحه برای اعمال قطعی تنظیم‌ها بازخوانی شود؟')) window.location.reload();
    } catch (error) {
      window.alert(error.message || 'ذخیرهٔ چیدمان انجام نشد.');
    } finally {
      loading = false;
      updateButtons();
    }
  }

  async function resetDesign() {
    if (loading || !rules.length || !window.confirm('تنظیم‌های طراحی این صفحه به حالت پیش‌فرض برگردد؟')) return;
    loading = true;
    updateButtons();
    try {
      await request({ action: 'reset', page }, 'POST');
      window.location.reload();
    } catch (error) {
      window.alert(error.message || 'بازگردانی چیدمان انجام نشد.');
    } finally {
      loading = false;
      updateButtons();
    }
  }

  function closeDesign() {
    if (dirty && !window.confirm('تغییرهای ذخیره‌نشده دور ریخته شود؟')) return;
    active = false;
    document.body.classList.remove('ald-design-mode');
    if (selected) selected.classList.remove('ald-selected');
    if (hovered) hovered.classList.remove('ald-hover');
    selected = null;
    selectedPath = null;
    panel && panel.remove();
    panel = null;
    if (dirty) window.location.reload();
  }

  async function openDesign() {
    if (active) return;
    active = true;
    dirty = false;
    launcher.setAttribute('aria-pressed', 'true');
    document.body.classList.add('ald-design-mode');
    createPanel();
    try {
      const data = await request(null, 'GET');
      document.getElementById('admin-page-layout-rules')?.remove();
      rules = Array.isArray(data.rules) ? data.rules : [];
      applyAll();
      renderControls();
      updateButtons();
    } catch (error) {
      window.alert(error.message || 'تنظیم‌های طراحی دریافت نشد.');
      closeDesign();
    }
  }

  launcher.addEventListener('click', openDesign);
  document.addEventListener('pointerover', onPointerOver, true);
  document.addEventListener('click', onDocumentClick, true);
  document.addEventListener('keydown', (event) => {
    if (event.key === 'Escape' && active) closeDesign();
  });
})();
