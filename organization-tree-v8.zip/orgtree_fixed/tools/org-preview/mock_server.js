/* سرور ساختگی برای تست رابط: همان قراردادهای organization-actions.php را شبیه‌سازی می‌کند */
(function(){
var D = window.PERSIAN_ORG_DATA, hist=[]; var undoStack=[], redoStack=[];
function snap(){ return JSON.stringify({u:D.units,us:D.users}); }
function restore(s){ var o=JSON.parse(s); D.units.length=0; o.u.forEach(x=>D.units.push(x)); D.users.length=0; o.us.forEach(x=>D.users.push(x)); }
function push(label){ undoStack.push({label:label,s:snap()}); redoStack=[]; }
function unit(id){return D.units.filter(u=>u.id==id)[0];}
function user(id){return D.users.filter(u=>u.id==id)[0];}
function sub(id){var o=[id];D.units.forEach(u=>{ if(u.parentId==id){ o=o.concat(sub(u.id)); } });return o;}
function payload(flash){ var p=JSON.parse(JSON.stringify(D)); p.undo=undoStack.length;p.undoLabel=undoStack.length?undoStack[undoStack.length-1].label:'';p.redo=redoStack.length;p.redoLabel=redoStack.length?redoStack[redoStack.length-1].label:'';p.flash=flash||[]; return p; }
var nid=1000;
window.fetch=function(url,opts){
  var fd=opts.body, a=fd.get('action'), f=[];
  function ok(m){f.push({type:'success',message:m});} function bad(m){f.push({type:'danger',message:m});}
  try{
  if(a==='org_create_unit'){ var par=unit(fd.get('parent_id')); push('افزودن'); D.units.push({id:++nid,name:fd.get('unit_name'),code:fd.get('unit_code')||'',parentId:par.id,type:par.type==='ceo'?'deputy':'department',managerId:0,managerIds:[],primaryAdmin:fd.get('is_primary_admin')==='1',sortOrder:nid}); ok('واحد ساخته شد'); }
  else if(a==='org_move_unit'){ var u=unit(fd.get('unit_id')), p=unit(fd.get('parent_id')); if(sub(u.id).indexOf(p.id)>=0){bad('چرخه');} else { push('جابه‌جایی'); u.parentId=p.id; u.type=p.type==='ceo'?'deputy':'department'; var sibs=D.units.filter(x=>x.parentId==p.id&&x.id!=u.id).sort((a,b)=>a.sortOrder-b.sortOrder); var before=+fd.get('before_id'); var idx=sibs.map(x=>x.id).indexOf(before); if(idx<0) sibs.push(u); else sibs.splice(idx,0,u); sibs.forEach((x,i)=>x.sortOrder=i+1); ok('منتقل شد'); } }
  else if(a==='org_set_managers'){ var u2=unit(fd.get('unit_id')); var ids=fd.getAll('user_ids[]').map(Number); push('مدیران'); D.units.forEach(x=>{ if(x.id!==u2.id){ x.managerIds=x.managerIds.filter(i=>ids.indexOf(i)<0); x.managerId=x.managerIds[0]||0; } }); u2.managerIds=ids; u2.managerId=ids[0]||0; ids.forEach(i=>user(i).unitId=u2.type==='ceo'?0:u2.id); ok('مدیران ذخیره شد'); }
  else if(a==='org_assign_members'){ var u3=unit(fd.get('unit_id')); push('کارشناس'); fd.getAll('user_ids[]').forEach(i=>user(+i).unitId=u3.id); ok('اضافه شد'); }
  else if(a==='remove_org_experts'){ push('عزل'); fd.getAll('user_ids[]').forEach(i=>user(+i).unitId=0); ok('عزل شد'); }
  else if(a==='org_bulk_create'){ var base=unit(fd.get('parent_id')), items=JSON.parse(fd.get('items_json')), made=[]; push('چندتایی'); items.forEach(function(it,i){ var par=it.parent<0?base:made[it.parent]; var n={id:++nid,name:it.name,code:it.code,parentId:par.id,type:par.type==='ceo'?'deputy':'department',managerId:0,managerIds:[],primaryAdmin:false,sortOrder:nid}; D.units.push(n); made.push(n); }); ok(items.length+' واحد ساخته شد'); }
  else if(a==='org_remove_unit'){ var u4=unit(fd.get('unit_id')); push('حذف'); var ids2=fd.get('mode')==='promote'?[u4.id]:sub(u4.id); if(fd.get('mode')==='promote'){ D.units.forEach(x=>{ if(x.parentId==u4.id){ x.parentId=u4.parentId; } }); } var keep=D.units.filter(x=>ids2.indexOf(x.id)<0); D.units.length=0; keep.forEach(x=>D.units.push(x)); ok('حذف شد'); }
  else if(a==='org_update_unit'){ var u5=unit(fd.get('unit_id')); push('ویرایش'); u5.name=fd.get('unit_name'); u5.code=fd.get('unit_code')||''; if(fd.get('is_primary_admin')!==null) u5.primaryAdmin=fd.get('is_primary_admin')==='1'; if(fd.get('parent_id') && u5.type!=='ceo'){ u5.parentId=+fd.get('parent_id'); } ok('ذخیره شد'); }
  else if(a==='org_undo'){ var e=undoStack.pop(); redoStack.push({label:e.label,s:snap()}); restore(e.s); ok('بازگشت: '+e.label); }
  else if(a==='org_redo'){ var e2=redoStack.pop(); undoStack.push({label:e2.label,s:snap()}); restore(e2.s); ok('انجام دوباره'); }
  }catch(err){ bad('خطا: '+err.message); }
  window.__lastAction={action:a,fields:Array.from(fd.entries())};
  return Promise.resolve({ text:function(){ return Promise.resolve(JSON.stringify(payload(f))); } });
};
})();
