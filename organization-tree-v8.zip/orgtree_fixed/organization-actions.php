<?php
declare(strict_types=1);

/**
 * درخت سازمان — نسخهٔ ۸
 * اکشن‌های جدید سمت سرور: ساخت/ویرایش/جابه‌جایی واحد (سطوح نامحدود)، چند مدیر برای هر واحد،
 * ساخت چندتایی، حذف با انتخاب حالت، و انجام دوبارهٔ عملیات (Redo).
 *
 * قرارداد قبلی POST و اکشن‌های موجود (assign_org_manager، save_org_assign_users، remove_org_experts،
 * delete_org_unit، reset_org_structure و ...) دست‌نخورده مانده‌اند؛ این فایل فقط اکشن‌های افزوده را اضافه می‌کند.
 * همهٔ اکشن‌ها فقط برای ادمین اصلی/مدیر سامانه مجازند و هر کدام یک مرحله Undo ثبت می‌کنند.
 */

/** حداکثر عمق مجاز درخت (مدیرعامل = ۰). */
function org_max_depth(): int
{
    return 12;
}

/** حداکثر تعداد واحدی که در یک ساخت چندتایی ساخته می‌شود. */
function org_bulk_limit(): int
{
    return 300;
}

function org_action_guard(string $message = 'فقط ادمین اصلی می‌تواند ساختار سازمانی را تغییر دهد.'): array
{
    $admin = require_permission('org.manage');
    if (!user_can_manage_organization($admin)) {
        throw new RuntimeException($message);
    }
    org_ensure_schema();
    return $admin;
}

/** @return int[] شناسه‌های یکتا و مثبت با حفظ ترتیب ورودی */
function org_clean_ids(mixed $raw): array
{
    if (!is_array($raw)) {
        return [];
    }
    $ids = [];
    foreach ($raw as $value) {
        $id = (int) $value;
        if ($id > 0 && !in_array($id, $ids, true)) {
            $ids[] = $id;
        }
    }
    return $ids;
}

function org_clean_name(string $value): string
{
    $name = trim((string) preg_replace('/\s+/u', ' ', $value));
    if ($name === '') {
        throw new RuntimeException('نام واحد الزامی است.');
    }
    if (mb_strlen($name) > 190) {
        throw new RuntimeException('نام واحد حداکثر ۱۹۰ نویسه می‌تواند باشد.');
    }
    return $name;
}

function org_clean_code(string $value): ?string
{
    $code = trim($value);
    if ($code === '') {
        return null;
    }
    if (mb_strlen($code) > 60) {
        throw new RuntimeException('کد واحد حداکثر ۶۰ نویسه می‌تواند باشد.');
    }
    return $code;
}

/** عمق یک واحد (مدیرعامل = ۰). */
function org_unit_depth(int $unitId): int
{
    $depth = 0;
    $guard = 0;
    while ($unitId > 0 && $guard < 60) {
        $guard++;
        $unit = org_unit_by_id($unitId);
        if ($unit === null) {
            break;
        }
        $parentId = (int) ($unit['parent_id'] ?? 0);
        if ($parentId <= 0) {
            break;
        }
        $depth++;
        $unitId = $parentId;
    }
    return $depth;
}

/** ارتفاع زیردرخت (واحد بدون فرزند = ۰). */
function org_unit_height(int $unitId, int $guard = 0): int
{
    if ($guard > 60) {
        return 0;
    }
    $height = 0;
    foreach (org_unit_children($unitId) as $child) {
        $height = max($height, 1 + org_unit_height((int) $child['id'], $guard + 1));
    }
    return $height;
}

/** نوع واحد تابع والد است: زیر مدیرعامل «معاونت»، در بقیهٔ جاها «اداره». */
function org_unit_type_for_parent(array $parent): string
{
    return (string) ($parent['unit_type'] ?? '') === 'ceo' ? 'deputy' : 'department';
}

function org_unit_type_label(string $type): string
{
    return ['ceo' => 'مدیرعامل', 'deputy' => 'معاونت', 'department' => 'اداره'][$type] ?? $type;
}

/** در یک والد (یا برای معاونت‌ها در کل سازمان) نام تکراری مجاز نیست. */
function org_sibling_name_conflict(string $name, int $parentId, string $type, int $exceptId = 0): bool
{
    $needle = mb_strtolower($name);
    if ($type === 'deputy') {
        $query = db()->prepare('SELECT id, name FROM org_units WHERE is_active = 1 AND unit_type = "deputy" AND id <> ?');
        $query->execute([$exceptId]);
    } else {
        $query = db()->prepare('SELECT id, name FROM org_units WHERE is_active = 1 AND parent_id = ? AND id <> ?');
        $query->execute([$parentId, $exceptId]);
    }
    foreach ($query->fetchAll() as $row) {
        if (mb_strtolower((string) $row['name']) === $needle) {
            return true;
        }
    }
    return false;
}

function org_next_sort(int $parentId): int
{
    if (!org_has_sort_column()) {
        return 0;
    }
    $query = db()->prepare('SELECT COALESCE(MAX(sort_order), 0) FROM org_units WHERE parent_id = ? AND is_active = 1');
    $query->execute([$parentId]);
    return (int) $query->fetchColumn() + 1;
}

function org_insert_unit(string $name, ?string $code, int $parentId, string $type, int $isPrimary): int
{
    if (org_has_sort_column()) {
        db()->prepare('INSERT INTO org_units (name, code, parent_id, unit_type, is_primary_admin, is_active, sort_order) VALUES (?, ?, ?, ?, ?, 1, ?)')
            ->execute([$name, $code, $parentId > 0 ? $parentId : null, $type, $isPrimary, org_next_sort($parentId)]);
    } else {
        db()->prepare('INSERT INTO org_units (name, code, parent_id, unit_type, is_primary_admin, is_active) VALUES (?, ?, ?, ?, ?, 1)')
            ->execute([$name, $code, $parentId > 0 ? $parentId : null, $type, $isPrimary]);
    }
    return (int) db()->lastInsertId();
}

/** ترتیب فرزندان یک والد را (با قرار دادن $unitId پیش از $beforeId) یک‌پارچه شماره‌گذاری می‌کند. */
function org_place_unit_in_order(int $parentId, int $unitId, int $beforeId): void
{
    if (!org_has_sort_column()) {
        return;
    }
    $query = db()->prepare('SELECT id FROM org_units WHERE parent_id = ? AND is_active = 1 AND id <> ? ORDER BY sort_order, name, id');
    $query->execute([$parentId, $unitId]);
    $ordered = array_map('intval', $query->fetchAll(PDO::FETCH_COLUMN));
    $position = $beforeId > 0 ? array_search($beforeId, $ordered, true) : false;
    if ($position === false) {
        $ordered[] = $unitId;
    } else {
        array_splice($ordered, (int) $position, 0, [$unitId]);
    }
    $update = db()->prepare('UPDATE org_units SET sort_order = ? WHERE id = ?');
    foreach ($ordered as $index => $id) {
        $update->execute([$index + 1, $id]);
    }
}

/** پس از حذف/جابه‌جایی مدیر: مدیر اصلی (primary) واحد را با اولین مدیر باقی‌مانده هماهنگ می‌کند. */
function org_unit_fix_primary(int $unitId): void
{
    $query = db()->prepare('SELECT user_id FROM org_unit_managers WHERE unit_id = ? ORDER BY is_primary DESC, user_id LIMIT 1');
    $query->execute([$unitId]);
    $first = (int) $query->fetchColumn();
    db()->prepare('UPDATE org_unit_managers SET is_primary = 0 WHERE unit_id = ?')->execute([$unitId]);
    if ($first > 0) {
        db()->prepare('UPDATE org_unit_managers SET is_primary = 1 WHERE unit_id = ? AND user_id = ?')->execute([$unitId, $first]);
    }
    db()->prepare('UPDATE org_units SET manager_user_id = ? WHERE id = ?')->execute([$first > 0 ? $first : null, $unitId]);
}

/** همهٔ مدیران (جدول واسط + ستون قدیمی) یک واحد با حفظ ترتیب. */
function org_unit_all_manager_ids(int $unitId): array
{
    $ids = org_unit_manager_ids($unitId);
    $unit = org_unit_by_id($unitId);
    $legacy = (int) ($unit['manager_user_id'] ?? 0);
    if ($legacy > 0 && !in_array($legacy, $ids, true)) {
        array_unshift($ids, $legacy);
    }
    return $ids;
}

/** ارتقای نقش مدیران یک واحد «ادمین اصلی». */
function org_promote_primary_admin_managers(int $unitId): void
{
    foreach (org_unit_all_manager_ids($unitId) as $managerId) {
        db()->prepare('UPDATE users SET role = "primary_admin", is_primary_admin = 1, is_active = 1 WHERE id = ?')->execute([$managerId]);
    }
}

/**
 * منطق مشترک جابه‌جایی. باید داخل تراکنش و با snapshot قبلی صدا زده شود.
 * @return array{old_type:string,new_type:string,changed:bool}
 */
function org_move_unit_core(array $unit, array $parent, int $beforeId): array
{
    $unitId = (int) $unit['id'];
    $parentId = (int) $parent['id'];
    if ((string) $unit['unit_type'] === 'ceo') {
        throw new RuntimeException('مدیرعامل قابل جابه‌جایی نیست.');
    }
    if ((int) ($parent['is_active'] ?? 0) !== 1) {
        throw new RuntimeException('والد انتخاب‌شده فعال نیست.');
    }
    if ($parentId === $unitId || in_array($parentId, org_unit_subtree_ids($unitId), true)) {
        throw new RuntimeException('یک واحد را نمی‌توان زیر خودش یا زیرمجموعهٔ خودش برد.');
    }
    $newDepth = org_unit_depth($parentId) + 1 + org_unit_height($unitId);
    if ($newDepth > org_max_depth()) {
        throw new RuntimeException('عمق درخت از حداکثر مجاز (' . org_max_depth() . ' سطح) بیشتر می‌شود.');
    }
    $oldType = (string) $unit['unit_type'];
    $newType = org_unit_type_for_parent($parent);
    if (org_sibling_name_conflict((string) $unit['name'], $parentId, $newType, $unitId)) {
        throw new RuntimeException('در مقصد واحدی با همین نام وجود دارد.');
    }
    db()->prepare('UPDATE org_units SET parent_id = ?, unit_type = ? WHERE id = ?')->execute([$parentId, $newType, $unitId]);
    org_place_unit_in_order($parentId, $unitId, $beforeId);
    return ['old_type' => $oldType, 'new_type' => $newType, 'changed' => $oldType !== $newType];
}

function org_action_create_unit(): void
{
    $admin = org_action_guard();
    $snapshot = org_snapshot();
    $name = org_clean_name(post_value('unit_name'));
    $code = org_clean_code(post_value('unit_code'));
    $parent = org_unit_by_id(max(0, (int) post_value('parent_id', '0')));
    if ($parent === null || (int) $parent['is_active'] !== 1) {
        throw new RuntimeException('والد انتخاب‌شده معتبر نیست.');
    }
    if (org_unit_depth((int) $parent['id']) + 1 > org_max_depth()) {
        throw new RuntimeException('عمق درخت از حداکثر مجاز (' . org_max_depth() . ' سطح) بیشتر می‌شود.');
    }
    $type = org_unit_type_for_parent($parent);
    if (org_sibling_name_conflict($name, (int) $parent['id'], $type)) {
        throw new RuntimeException($type === 'deputy' ? 'معاونتی با همین نام وجود دارد.' : 'در همین والد واحدی با همین نام وجود دارد.');
    }
    $isPrimary = post_value('is_primary_admin') === '1' ? 1 : 0;
    db()->beginTransaction();
    $unitId = org_insert_unit($name, $code, (int) $parent['id'], $type, $isPrimary);
    db_commit('index.php');
    org_record_undo('افزودن ' . org_unit_type_label($type) . ' «' . $name . '»', $snapshot);
    save_audit((int) $admin['id'], 'org_unit_saved', null, ['unit_id' => $unitId, 'name' => $name, 'type' => $type, 'created' => 1, 'parent_id' => (int) $parent['id']]);
    flash('success', org_unit_type_label($type) . ' «' . $name . '» ساخته شد.');
    redirect('index.php?page=organization#unit-' . $unitId);
}

function org_action_update_unit(): void
{
    $admin = org_action_guard();
    $snapshot = org_snapshot();
    $unitId = max(0, (int) post_value('unit_id', '0'));
    $unit = org_unit_by_id($unitId);
    if ($unit === null || (int) $unit['is_active'] !== 1) {
        throw new RuntimeException('واحد سازمانی یافت نشد.');
    }
    $name = org_clean_name(post_value('unit_name'));
    $code = org_clean_code(post_value('unit_code'));
    $isCeo = (string) $unit['unit_type'] === 'ceo';
    $parentId = (int) ($unit['parent_id'] ?? 0);
    $requestedParent = max(0, (int) post_value('parent_id', '0'));
    $moved = false;
    $typeChange = ['old_type' => (string) $unit['unit_type'], 'new_type' => (string) $unit['unit_type'], 'changed' => false];
    db()->beginTransaction();
    if (!$isCeo && $requestedParent > 0 && $requestedParent !== $parentId) {
        $parent = org_unit_by_id($requestedParent);
        if ($parent === null) {
            throw new RuntimeException('والد انتخاب‌شده یافت نشد.');
        }
        $typeChange = org_move_unit_core($unit, $parent, 0);
        $moved = true;
        $parentId = $requestedParent;
    }
    $effectiveType = $typeChange['new_type'];
    if (!$isCeo && org_sibling_name_conflict($name, $parentId, $effectiveType, $unitId)) {
        throw new RuntimeException('واحدی با همین نام در همین جایگاه وجود دارد.');
    }
    $isPrimary = (int) ($unit['is_primary_admin'] ?? 0);
    if (array_key_exists('is_primary_admin', $_POST)) {
        $isPrimary = post_value('is_primary_admin') === '1' ? 1 : 0;
    }
    db()->prepare('UPDATE org_units SET name = ?, code = ?, is_primary_admin = ? WHERE id = ?')->execute([$name, $code, $isPrimary, $unitId]);
    if ($isPrimary === 1) {
        org_promote_primary_admin_managers($unitId);
    }
    db_commit('index.php');
    org_record_undo($moved ? 'ویرایش و جابه‌جایی «' . $name . '»' : 'ویرایش «' . $name . '»', $snapshot);
    save_audit((int) $admin['id'], 'org_unit_saved', null, ['unit_id' => $unitId, 'name' => $name, 'type' => $effectiveType, 'moved' => $moved ? 1 : 0, 'primary_admin' => $isPrimary]);
    flash('success', 'تغییرات «' . $name . '» ذخیره شد.' . ($typeChange['changed'] ? ' نوع واحد به «' . org_unit_type_label($effectiveType) . '» تغییر کرد.' : ''));
    redirect('index.php?page=organization#unit-' . $unitId);
}

function org_action_move_unit(): void
{
    $admin = org_action_guard();
    $snapshot = org_snapshot();
    $unitId = max(0, (int) post_value('unit_id', '0'));
    $parentId = max(0, (int) post_value('parent_id', '0'));
    $beforeId = max(0, (int) post_value('before_id', '0'));
    $unit = org_unit_by_id($unitId);
    $parent = org_unit_by_id($parentId);
    if ($unit === null || (int) $unit['is_active'] !== 1 || $parent === null) {
        throw new RuntimeException('واحد یا مقصد انتخاب‌شده معتبر نیست.');
    }
    db()->beginTransaction();
    $result = org_move_unit_core($unit, $parent, $beforeId);
    db_commit('index.php');
    org_record_undo('جابه‌جایی «' . (string) $unit['name'] . '»', $snapshot);
    save_audit((int) $admin['id'], 'org_unit_moved', null, ['unit_id' => $unitId, 'name' => (string) $unit['name'], 'parent_id' => $parentId, 'before_id' => $beforeId, 'type' => $result['new_type']]);
    flash('success', '«' . (string) $unit['name'] . '» به «' . (string) $parent['name'] . '» منتقل شد.' . ($result['changed'] ? ' نوع واحد به «' . org_unit_type_label($result['new_type']) . '» تغییر کرد.' : ''));
    redirect('index.php?page=organization#unit-' . $unitId);
}

function org_action_set_managers(): void
{
    $admin = org_action_guard('فقط ادمین اصلی می‌تواند مدیران سازمان را تغییر دهد.');
    $snapshot = org_snapshot();
    $unitId = max(0, (int) post_value('unit_id', '0'));
    $unit = org_unit_by_id($unitId);
    if ($unit === null || (int) $unit['is_active'] !== 1) {
        throw new RuntimeException('موقعیت سازمانی انتخاب‌شده معتبر نیست.');
    }
    $isCeo = (string) $unit['unit_type'] === 'ceo';
    $newIds = org_clean_ids($_POST['user_ids'] ?? []);
    if (count($newIds) > 12) {
        throw new RuntimeException('برای هر واحد حداکثر ۱۲ مدیر می‌توان تعیین کرد.');
    }
    if ($newIds !== []) {
        $placeholders = implode(',', array_fill(0, count($newIds), '?'));
        $valid = db()->prepare('SELECT id FROM users WHERE id IN (' . $placeholders . ') AND is_active = 1 AND COALESCE(auth_source, "") <> "food"');
        $valid->execute($newIds);
        $validIds = array_map('intval', $valid->fetchAll(PDO::FETCH_COLUMN));
        if (count($validIds) !== count($newIds)) {
            throw new RuntimeException('یکی از کاربران انتخاب‌شده فعال یا معتبر نیست.');
        }
    }
    $oldIds = org_unit_all_manager_ids($unitId);
    $removedIds = array_values(array_diff($oldIds, $newIds));
    db()->beginTransaction();

    // هر کاربر فقط یک سمت مدیریتی دارد؛ از واحدهای دیگر برداشته می‌شود.
    $affectedUnits = [];
    foreach ($newIds as $userId) {
        $other = db()->prepare('SELECT unit_id FROM org_unit_managers WHERE user_id = ? AND unit_id <> ? UNION SELECT id FROM org_units WHERE manager_user_id = ? AND id <> ?');
        $other->execute([$userId, $unitId, $userId, $unitId]);
        foreach ($other->fetchAll(PDO::FETCH_COLUMN) as $otherUnitId) {
            $affectedUnits[(int) $otherUnitId][] = $userId;
        }
        db()->prepare('DELETE FROM org_unit_managers WHERE user_id = ? AND unit_id <> ?')->execute([$userId, $unitId]);
        db()->prepare('UPDATE org_units SET manager_user_id = NULL WHERE manager_user_id = ? AND id <> ?')->execute([$userId, $unitId]);
    }
    foreach ($affectedUnits as $otherUnitId => $movedUserIds) {
        org_unit_fix_primary((int) $otherUnitId);
        $otherUnit = org_unit_by_id((int) $otherUnitId);
        $replacement = (int) ($otherUnit['manager_user_id'] ?? 0);
        foreach ($movedUserIds as $movedUserId) {
            db()->prepare('UPDATE users SET manager_user_id = ? WHERE org_unit_id = ? AND manager_user_id = ?')
                ->execute([$replacement > 0 ? $replacement : null, (int) $otherUnitId, $movedUserId]);
        }
    }

    // جایگزینی فهرست مدیران همین واحد
    db()->prepare('DELETE FROM org_unit_managers WHERE unit_id = ?')->execute([$unitId]);
    $insert = db()->prepare('INSERT INTO org_unit_managers (unit_id, user_id, is_primary) VALUES (?, ?, ?)');
    foreach ($newIds as $index => $userId) {
        $insert->execute([$unitId, $userId, $index === 0 ? 1 : 0]);
    }
    $primaryId = $newIds[0] ?? 0;
    db()->prepare('UPDATE org_units SET manager_user_id = ? WHERE id = ?')->execute([$primaryId > 0 ? $primaryId : null, $unitId]);

    foreach ($newIds as $userId) {
        if ($isCeo) {
            db()->prepare('UPDATE users SET org_unit_id = NULL, manager_user_id = NULL, role = CASE WHEN role IN ("user", "agent") THEN "manager" ELSE role END WHERE id = ?')->execute([$userId]);
        } else {
            db()->prepare('UPDATE users SET org_unit_id = ?, manager_user_id = NULL, role = CASE WHEN role IN ("user", "agent") THEN "manager" ELSE role END WHERE id = ?')->execute([$unitId, $userId]);
        }
    }
    if (!$isCeo) {
        foreach ($removedIds as $removedId) {
            db()->prepare('UPDATE users SET org_unit_id = NULL, manager_user_id = NULL WHERE id = ? AND org_unit_id = ?')->execute([$removedId, $unitId]);
        }
        // کارشناسان بدون مدیر مستقیم به مدیر اصلی جدید وصل می‌شوند.
        if ($primaryId > 0) {
            $memberSql = 'UPDATE users SET manager_user_id = ? WHERE org_unit_id = ? AND manager_user_id IS NULL AND id NOT IN (' . implode(',', array_fill(0, count($newIds), '?')) . ')';
            db()->prepare($memberSql)->execute(array_merge([$primaryId, $unitId], $newIds));
        }
        // کارشناسانی که مدیر مستقیمشان عزل شده به مدیر اصلی جدید (یا هیچ‌کس) منتقل می‌شوند.
        if ($removedIds !== []) {
            $removedMarks = implode(',', array_fill(0, count($removedIds), '?'));
            db()->prepare('UPDATE users SET manager_user_id = ? WHERE org_unit_id = ? AND manager_user_id IN (' . $removedMarks . ')')
                ->execute(array_merge([$primaryId > 0 ? $primaryId : null, $unitId], $removedIds));
        }
    }
    if ((int) ($unit['is_primary_admin'] ?? 0) === 1 && $newIds !== []) {
        $adminMarks = implode(',', array_fill(0, count($newIds), '?'));
        db()->prepare('UPDATE users SET role = "primary_admin", is_primary_admin = 1, is_active = 1 WHERE id IN (' . $adminMarks . ')')->execute($newIds);
    }
    db_commit('index.php');
    org_record_undo($newIds === [] ? 'عزل مدیران «' . (string) $unit['name'] . '»' : 'تعیین مدیران «' . (string) $unit['name'] . '»', $snapshot);
    save_audit((int) $admin['id'], 'org_managers_set', null, ['unit_id' => $unitId, 'name' => (string) $unit['name'], 'user_ids' => $newIds, 'removed_ids' => $removedIds]);
    flash('success', $newIds === [] ? 'مدیران «' . (string) $unit['name'] . '» عزل شدند.' : 'مدیران «' . (string) $unit['name'] . '» ذخیره شد.');
    redirect('index.php?page=organization#unit-' . $unitId);
}

function org_action_bulk_create(): void
{
    $admin = org_action_guard();
    $snapshot = org_snapshot();
    $baseParent = org_unit_by_id(max(0, (int) post_value('parent_id', '0')));
    if ($baseParent === null || (int) $baseParent['is_active'] !== 1) {
        throw new RuntimeException('والد انتخاب‌شده معتبر نیست.');
    }
    $items = json_decode(post_value('items_json', '[]'), true);
    if (!is_array($items) || $items === []) {
        throw new RuntimeException('فهرست واحدها خالی است.');
    }
    if (count($items) > org_bulk_limit()) {
        throw new RuntimeException('در هر بار حداکثر ' . org_bulk_limit() . ' واحد قابل ساخت است.');
    }
    $baseDepth = org_unit_depth((int) $baseParent['id']);
    $created = [];
    $createdMeta = [];
    $siblingNames = [];
    db()->beginTransaction();
    foreach (array_values($items) as $index => $item) {
        if (!is_array($item)) {
            throw new RuntimeException('ردیف ' . ($index + 1) . ' نامعتبر است.');
        }
        $name = org_clean_name((string) ($item['name'] ?? ''));
        $code = org_clean_code((string) ($item['code'] ?? ''));
        $parentIndex = isset($item['parent']) ? (int) $item['parent'] : -1;
        if ($parentIndex >= 0) {
            if ($parentIndex >= $index || !isset($created[$parentIndex])) {
                throw new RuntimeException('والد ردیف ' . ($index + 1) . ' باید پیش از خودش آمده باشد.');
            }
            $parentId = $created[$parentIndex];
            $parentType = (string) $createdMeta[$parentIndex]['type'];
            $depth = (int) $createdMeta[$parentIndex]['depth'] + 1;
        } else {
            $parentId = (int) $baseParent['id'];
            $parentType = (string) $baseParent['unit_type'];
            $depth = $baseDepth + 1;
        }
        if ($depth > org_max_depth()) {
            throw new RuntimeException('ردیف ' . ($index + 1) . ' از حداکثر عمق مجاز (' . org_max_depth() . ' سطح) بیشتر است.');
        }
        $type = $parentType === 'ceo' ? 'deputy' : 'department';
        $key = ($type === 'deputy' ? 'deputy' : (string) $parentId) . '|' . mb_strtolower($name);
        if (isset($siblingNames[$key]) || org_sibling_name_conflict($name, $parentId, $type)) {
            throw new RuntimeException('نام «' . $name . '» (ردیف ' . ($index + 1) . ') تکراری است.');
        }
        $siblingNames[$key] = true;
        $unitId = org_insert_unit($name, $code, $parentId, $type, 0);
        $created[$index] = $unitId;
        $createdMeta[$index] = ['type' => $type, 'depth' => $depth];
    }
    db_commit('index.php');
    org_record_undo('ساخت چندتایی ' . count($created) . ' واحد', $snapshot);
    save_audit((int) $admin['id'], 'org_units_bulk_created', null, ['parent_id' => (int) $baseParent['id'], 'count' => count($created), 'unit_ids' => array_values($created)]);
    flash('success', count($created) . ' واحد زیر «' . (string) $baseParent['name'] . '» ساخته شد.');
    redirect('index.php?page=organization#unit-' . (int) $baseParent['id']);
}

/** حذف واحد با دو حالت: کل زیردرخت (subtree) یا فقط خود واحد با انتقال زیرمجموعه‌ها به والد (promote). */
function org_action_remove_unit(): void
{
    $admin = org_action_guard();
    $snapshot = org_snapshot();
    $unitId = max(0, (int) post_value('unit_id', '0'));
    $unit = org_unit_by_id($unitId);
    if ($unit === null || (int) $unit['is_active'] !== 1) {
        throw new RuntimeException('واحد سازمانی یافت نشد.');
    }
    if ((string) $unit['unit_type'] === 'ceo') {
        throw new RuntimeException('واحد مدیرعامل قابل حذف نیست.');
    }
    $mode = valid_choice(post_value('mode'), ['subtree', 'promote'], 'subtree');
    $parent = org_unit_by_id((int) ($unit['parent_id'] ?? 0));
    if ($mode === 'promote' && ($parent === null || (int) $parent['is_active'] !== 1)) {
        throw new RuntimeException('والد این واحد یافت نشد؛ حذف با انتقال زیرمجموعه ممکن نیست.');
    }
    $ids = $mode === 'promote' ? [$unitId] : org_unit_subtree_ids($unitId);
    $marks = implode(',', array_fill(0, count($ids), '?'));
    $managerQuery = db()->prepare('SELECT user_id FROM org_unit_managers WHERE unit_id IN (' . $marks . ') UNION SELECT manager_user_id FROM org_units WHERE id IN (' . $marks . ') AND manager_user_id IS NOT NULL');
    $managerQuery->execute(array_merge($ids, $ids));
    $managerIds = array_map('intval', $managerQuery->fetchAll(PDO::FETCH_COLUMN));

    db()->beginTransaction();
    if ($mode === 'promote') {
        $childType = org_unit_type_for_parent($parent);
        $moveChild = db()->prepare('UPDATE org_units SET parent_id = ?, unit_type = ? WHERE id = ?');
        foreach (org_unit_children($unitId) as $child) {
            if (org_sibling_name_conflict((string) $child['name'], (int) $parent['id'], $childType, (int) $child['id'])) {
                throw new RuntimeException('نام «' . (string) $child['name'] . '» در والد مقصد تکراری است؛ ابتدا نام را تغییر دهید یا حالت حذف کل زیرمجموعه را انتخاب کنید.');
            }
            $moveChild->execute([(int) $parent['id'], $childType, (int) $child['id']]);
            org_place_unit_in_order((int) $parent['id'], (int) $child['id'], 0);
        }
        // کارشناسان (غیرمدیر) به والد منتقل می‌شوند؛ اگر والد کارشناس نمی‌پذیرد، بدون واحد می‌مانند.
        $destUnit = org_unit_accepts_experts($parent) ? $parent : null;
        $destManager = $destUnit !== null ? (int) ($destUnit['manager_user_id'] ?? 0) : 0;
        $memberSql = 'UPDATE users SET org_unit_id = ?, manager_user_id = ? WHERE org_unit_id = ?';
        $memberParams = [$destUnit !== null ? (int) $destUnit['id'] : null, $destManager > 0 ? $destManager : null, $unitId];
        if ($managerIds !== []) {
            $memberSql .= ' AND id NOT IN (' . implode(',', array_fill(0, count($managerIds), '?')) . ')';
            $memberParams = array_merge($memberParams, $managerIds);
        }
        db()->prepare($memberSql)->execute($memberParams);
        if ($managerIds !== []) {
            db()->prepare('UPDATE users SET org_unit_id = NULL, manager_user_id = NULL WHERE id IN (' . implode(',', array_fill(0, count($managerIds), '?')) . ') AND org_unit_id = ?')
                ->execute(array_merge($managerIds, [$unitId]));
        }
    } else {
        db()->prepare('UPDATE users SET org_unit_id = NULL, manager_user_id = NULL WHERE org_unit_id IN (' . $marks . ')')->execute($ids);
    }
    if ($managerIds !== []) {
        db()->prepare('UPDATE users SET manager_user_id = NULL WHERE manager_user_id IN (' . implode(',', array_fill(0, count($managerIds), '?')) . ')')->execute($managerIds);
    }
    db()->prepare('DELETE FROM org_unit_managers WHERE unit_id IN (' . $marks . ')')->execute($ids);
    db()->prepare('UPDATE org_units SET is_active = 0, manager_user_id = NULL WHERE id IN (' . $marks . ')')->execute($ids);
    db_commit('index.php');
    org_record_undo('حذف «' . (string) $unit['name'] . '»', $snapshot);
    save_audit((int) $admin['id'], 'org_unit_deleted', null, ['unit_id' => $unitId, 'name' => (string) $unit['name'], 'mode' => $mode, 'subtree_ids' => $ids]);
    flash('success', $mode === 'promote' ? '«' . (string) $unit['name'] . '» حذف شد و زیرمجموعه‌ها به والد منتقل شدند.' : '«' . (string) $unit['name'] . '» و زیرمجموعه‌هایش حذف شدند.');
    redirect('index.php?page=organization' . ($parent !== null ? '#unit-' . (int) $parent['id'] : ''));
}

/** افزودن یا انتقال کارشناس به یک واحد (مدیران واحدها پذیرفته نمی‌شوند؛ ابتدا باید از سمت مدیریت برداشته شوند). */
function org_action_assign_members(): void
{
    $admin = org_action_guard('فقط ادمین اصلی می‌تواند اعضای سازمان را تغییر دهد.');
    $snapshot = org_snapshot();
    $unitId = max(0, (int) post_value('unit_id', '0'));
    $unit = $unitId > 0 ? org_unit_by_id($unitId) : null;
    if ($unit === null || (int) $unit['is_active'] !== 1 || !org_unit_accepts_experts($unit)) {
        throw new RuntimeException('کارشناس را فقط می‌توان به معاونت یا اداره وصل کرد.');
    }
    $userIds = org_clean_ids($_POST['user_ids'] ?? []);
    if ($userIds === []) {
        throw new RuntimeException('حداقل یک کاربر انتخاب کنید.');
    }
    $marks = implode(',', array_fill(0, count($userIds), '?'));
    $valid = db()->prepare('SELECT id FROM users WHERE id IN (' . $marks . ') AND is_active = 1 AND COALESCE(auth_source, "") <> "food"');
    $valid->execute($userIds);
    if (count($valid->fetchAll(PDO::FETCH_COLUMN)) !== count($userIds)) {
        throw new RuntimeException('یکی از کاربران انتخاب‌شده فعال یا معتبر نیست.');
    }
    $managing = db()->prepare('SELECT user_id FROM org_unit_managers WHERE user_id IN (' . $marks . ') UNION SELECT manager_user_id FROM org_units WHERE is_active = 1 AND manager_user_id IN (' . $marks . ')');
    $managing->execute(array_merge($userIds, $userIds));
    if ($managing->fetchAll(PDO::FETCH_COLUMN) !== []) {
        throw new RuntimeException('یکی از کاربران انتخاب‌شده مدیر یک واحد است؛ ابتدا او را از سمت مدیریت بردارید.');
    }
    $managerId = (int) ($unit['manager_user_id'] ?? 0);
    db()->beginTransaction();
    $assign = db()->prepare('UPDATE users SET org_unit_id = ?, manager_user_id = ? WHERE id = ?');
    foreach ($userIds as $userId) {
        $assign->execute([$unitId, $managerId > 0 ? $managerId : null, $userId]);
    }
    db_commit('index.php');
    org_record_undo('افزودن کارشناسان به «' . (string) $unit['name'] . '»', $snapshot);
    save_audit((int) $admin['id'], 'org_users_assigned', null, ['unit_id' => $unitId, 'user_ids' => $userIds]);
    flash('success', count($userIds) . ' نفر به «' . (string) $unit['name'] . '» اضافه شد.');
    redirect('index.php?page=organization#unit-' . $unitId);
}

function org_action_undo(): void
{
    $admin = org_action_guard('فقط ادمین اصلی می‌تواند عملیات سازمان را بازگرداند.');
    $label = org_undo_apply();
    if ($label === null) {
        throw new RuntimeException('عملیاتی برای بازگشت وجود ندارد.');
    }
    save_audit((int) $admin['id'], 'org_action_undone', null, ['label' => $label]);
    flash('success', 'بازگشت انجام شد' . ($label !== '' ? ': ' . $label : '.'));
    redirect('index.php?page=organization');
}

function org_action_redo(): void
{
    $admin = org_action_guard('فقط ادمین اصلی می‌تواند عملیات سازمان را دوباره انجام دهد.');
    $label = org_redo_apply();
    if ($label === null) {
        throw new RuntimeException('عملیاتی برای انجام دوباره وجود ندارد.');
    }
    save_audit((int) $admin['id'], 'org_action_redone', null, ['label' => $label]);
    flash('success', 'انجام دوباره: ' . $label);
    redirect('index.php?page=organization');
}

/** اکشن‌های نسخهٔ ۸ را اجرا می‌کند؛ اگر اکشن مال این فایل نبود false برمی‌گرداند. */
function org_handle_v8_action(string $action): bool
{
    $handlers = [
        'org_create_unit' => 'org_action_create_unit',
        'org_update_unit' => 'org_action_update_unit',
        'org_move_unit' => 'org_action_move_unit',
        'org_set_managers' => 'org_action_set_managers',
        'org_bulk_create' => 'org_action_bulk_create',
        'org_remove_unit' => 'org_action_remove_unit',
        'org_assign_members' => 'org_action_assign_members',
        'org_undo' => 'org_action_undo',
        'org_redo' => 'org_action_redo',
    ];
    if (!isset($handlers[$action])) {
        return false;
    }
    $handlers[$action]();
    return true;
}
