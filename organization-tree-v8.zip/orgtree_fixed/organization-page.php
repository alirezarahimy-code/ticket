<?php
declare(strict_types=1);

/**
 * درخت سازمان — نسخهٔ ۸: دادهٔ صفحه و رندر.
 * صفحه خودش را با assets/organization.js می‌سازد؛ این فایل فقط داده را آماده و در دو حالت می‌دهد:
 *  - بارگذاری عادی صفحه (HTML)
 *  - درخواست AJAX با هدر Accept: application/json  ← فقط JSON تازه (بدون بارگذاری مجدد صفحه)
 */

/** کدهای فعالیت مرتبط با سازمان که در «تاریخچه» نمایش داده می‌شوند. */
function org_history_codes(): array
{
    return [
        'org_unit_saved', 'org_unit_moved', 'org_unit_deleted', 'org_managers_set', 'org_units_bulk_created',
        'org_manager_assigned', 'org_manager_removed', 'org_experts_removed', 'org_users_assigned',
        'org_structure_reset', 'org_ceo_saved', 'user_org_updated', 'org_action_undone', 'org_action_redone',
    ];
}

/** @return array<int,array<string,mixed>> */
function org_history_rows(int $limit = 80): array
{
    try {
        activity_logs_ensure();
        $codes = org_history_codes();
        $marks = implode(',', array_fill(0, count($codes), '?'));
        $query = db()->prepare('SELECT id, full_name, action_code, meta_json, created_at FROM activity_logs WHERE action_code IN (' . $marks . ') ORDER BY id DESC LIMIT ' . max(1, min(200, $limit)));
        $query->execute($codes);
        $rows = [];
        foreach ($query->fetchAll() as $row) {
            $meta = json_decode((string) ($row['meta_json'] ?? ''), true);
            $meta = is_array($meta) ? $meta : [];
            $unitIds = [];
            foreach (['unit_id', 'parent_id'] as $key) {
                if (isset($meta[$key]) && (int) $meta[$key] > 0) {
                    $unitIds[] = (int) $meta[$key];
                }
            }
            $userIds = [];
            foreach (['user_id', 'manager', 'manager_user_id'] as $key) {
                if (isset($meta[$key]) && is_scalar($meta[$key]) && (int) $meta[$key] > 0) {
                    $userIds[] = (int) $meta[$key];
                }
            }
            foreach (['user_ids', 'managers'] as $key) {
                if (isset($meta[$key]) && is_array($meta[$key])) {
                    foreach ($meta[$key] as $value) {
                        if ((int) $value > 0) {
                            $userIds[] = (int) $value;
                        }
                    }
                }
            }
            $rows[] = [
                'id' => (int) $row['id'],
                'at' => jalali_date((string) $row['created_at'], true),
                'who' => (string) ($row['full_name'] ?? ''),
                'code' => (string) $row['action_code'],
                'name' => isset($meta['name']) && is_scalar($meta['name']) ? (string) $meta['name'] : '',
                'label' => isset($meta['label']) && is_scalar($meta['label']) ? (string) $meta['label'] : '',
                'count' => isset($meta['count']) ? (int) $meta['count'] : 0,
                'unitIds' => array_values(array_unique($unitIds)),
                'userIds' => array_values(array_unique($userIds)),
            ];
        }
        return $rows;
    } catch (Throwable $exception) {
        return [];
    }
}

/** @return array<string,mixed> */
function org_page_payload(array $viewer): array
{
    org_ensure_schema();
    $canManage = user_can_manage_organization($viewer);
    $order = org_has_sort_column() ? 'ou.sort_order, ou.name, ou.id' : 'ou.name, ou.id';
    $unitRows = db()->query('SELECT ou.*, m.full_name AS manager_name FROM org_units ou LEFT JOIN users m ON m.id = ou.manager_user_id WHERE ou.is_active = 1 ORDER BY ' . $order)->fetchAll();

    $managersByUnit = [];
    foreach (db()->query('SELECT unit_id, user_id FROM org_unit_managers ORDER BY unit_id, is_primary DESC, user_id')->fetchAll() as $row) {
        $managersByUnit[(int) $row['unit_id']][] = (int) $row['user_id'];
    }

    $units = [];
    foreach ($unitRows as $unit) {
        $unitId = (int) $unit['id'];
        $managerIds = $managersByUnit[$unitId] ?? [];
        $legacy = (int) ($unit['manager_user_id'] ?? 0);
        if ($legacy > 0 && !in_array($legacy, $managerIds, true)) {
            array_unshift($managerIds, $legacy);
        }
        $units[] = [
            'id' => $unitId,
            'name' => (string) $unit['name'],
            'code' => (string) ($unit['code'] ?? ''),
            'parentId' => (int) ($unit['parent_id'] ?? 0),
            'type' => (string) $unit['unit_type'],
            'managerId' => $legacy,
            'managerIds' => $managerIds,
            'primaryAdmin' => (int) ($unit['is_primary_admin'] ?? 0) === 1,
            'sortOrder' => (int) ($unit['sort_order'] ?? 0),
        ];
    }

    $userRows = db()->query("SELECT u.id, u.username, u.full_name, u.employee_number, u.national_code, u.role, u.auth_source, u.is_active, u.org_unit_id, u.manager_user_id, u.profile_photo, u.email, u.phone FROM users u WHERE COALESCE(u.auth_source, '') <> 'food' ORDER BY u.full_name")->fetchAll();
    $users = [];
    foreach ($userRows as $row) {
        $photo = basename((string) ($row['profile_photo'] ?? ''));
        $entry = [
            'id' => (int) $row['id'],
            'name' => (string) $row['full_name'],
            'username' => (string) $row['username'],
            'code' => (string) ($row['national_code'] ?: ($row['employee_number'] ?: $row['username'])),
            'active' => (int) $row['is_active'] === 1,
            'unitId' => (int) ($row['org_unit_id'] ?? 0),
            'managerId' => (int) ($row['manager_user_id'] ?? 0),
            'source' => ((string) ($row['auth_source'] ?? '') === 'ldap') ? 'ldap' : 'local',
            'photo' => preg_match('/^profile-[a-f0-9]{36}\.(png|jpg)$/', $photo) === 1 ? substr(md5($photo), 0, 8) : '',
        ];
        if ($canManage) {
            $entry['email'] = (string) ($row['email'] ?? '');
            $entry['phone'] = (string) ($row['phone'] ?? '');
            $entry['role'] = (string) ($row['role'] ?? '');
        }
        $users[] = $entry;
    }

    $meta = org_undo_meta();
    return [
        'canManage' => $canManage,
        'csrf' => csrf_token(),
        'maxDepth' => org_max_depth(),
        'bulkLimit' => org_bulk_limit(),
        'sortSupported' => org_has_sort_column(),
        'undo' => $meta['undo'],
        'undoLabel' => $meta['undoLabel'],
        'undoLabels' => $meta['undoLabels'],
        'redo' => $meta['redo'],
        'redoLabel' => $meta['redoLabel'],
        'currentUser' => ['id' => (int) $viewer['id'], 'name' => (string) $viewer['full_name']],
        'orgName' => (string) setting('app_name', (string) cfg('app.name', 'سازمان')),
        'units' => $units,
        'users' => $users,
        'history' => org_history_rows(),
        'flash' => [],
    ];
}

function org_request_wants_json(): bool
{
    return stripos((string) ($_SERVER['HTTP_ACCEPT'] ?? ''), 'application/json') !== false;
}

function org_json_flags(): int
{
    return JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES | JSON_HEX_TAG | JSON_HEX_AMP | JSON_HEX_APOS | JSON_HEX_QUOT;
}

/** صفحهٔ «مدیریت سازمان». */
function org_render_page(array $organizationUser): never
{
    $payload = org_page_payload($organizationUser);
    if (org_request_wants_json()) {
        $payload['flash'] = take_flash();
        header('Content-Type: application/json; charset=utf-8');
        header('Cache-Control: no-store');
        echo json_encode($payload, org_json_flags());
        exit;
    }
    $json = json_encode($payload, org_json_flags());
    render_header('مدیریت سازمان', $organizationUser);
    echo '<link rel="stylesheet" href="assets/organization.css?v=8">';
    echo '<div class="ot-app" id="ot-app" dir="rtl"><noscript><p class="ot-noscript">برای نمایش درخت سازمان، جاوااسکریپت مرورگر باید فعال باشد.</p></noscript></div>';
    echo '<script nonce="' . e(csp_nonce()) . '">window.PERSIAN_ORG_DATA = ' . $json . ';</script>';
    echo '<script src="assets/organization.js?v=8"></script>';
    render_footer();
    exit;
}

/** ارسال عکس پروفایل یک کاربر برای نمودار سازمان (نیازمند مجوز مشاهدهٔ سازمان). */
function org_serve_user_photo(): never
{
    require_permission('org.view');
    $id = max(0, (int) ($_GET['id'] ?? 0));
    $query = db()->prepare('SELECT profile_photo FROM users WHERE id = ? LIMIT 1');
    $query->execute([$id]);
    $stored = basename((string) ($query->fetchColumn() ?: ''));
    if ($stored === '' || preg_match('/^profile-[a-f0-9]{36}\.(png|jpg)$/', $stored) !== 1) {
        http_response_code(404);
        exit('عکس پیدا نشد.');
    }
    $path = APP_ROOT . '/storage/profile/' . $stored;
    if (!is_file($path)) {
        http_response_code(404);
        exit('عکس روی سرور موجود نیست.');
    }
    $mime = (string) (mime_content_type($path) ?: 'application/octet-stream');
    if (!in_array($mime, ['image/png', 'image/jpeg'], true)) {
        http_response_code(404);
        exit('نوع عکس مجاز نیست.');
    }
    header('Content-Type: ' . $mime);
    header('Cache-Control: private, max-age=86400');
    header('X-Content-Type-Options: nosniff');
    readfile($path);
    exit;
}
