/*!
 * درخت سازمان — نسخهٔ ۸
 * رابط کاربری کامل مدیریت و نمایش ساختار سازمانی (سطوح نامحدود، چند مدیر، جابه‌جایی با کشیدن،
 * باز/بسته‌کردن شاخه‌ها، جستجوی زنده، مینی‌مپ، خروجی PNG/SVG/PDF/Excel/JSON، تم روشن/تیره، Undo/Redo).
 * داده از window.PERSIAN_ORG_DATA می‌آید و عملیات از طریق fetch (بدون بارگذاری مجدد صفحه) انجام می‌شود.
 */
(function () {
'use strict';

var BOOT = window.PERSIAN_ORG_DATA;
var APP = document.getElementById('ot-app');
if (!BOOT || !APP) { return; }

var SCRIPT_SRC = (document.currentScript && document.currentScript.src) || '';
var BASE = SCRIPT_SRC ? SCRIPT_SRC.replace(/[^\/]*$/, '') : 'assets/';
var CFG = { endpoint: 'index.php?page=organization', photo: 'index.php?action=org_user_photo&id=' };

/* ───────────── ابزارهای عمومی ───────────── */
var FA_DIGITS = '۰۱۲۳۴۵۶۷۸۹';
function fa(n) { return String(n).replace(/\d/g, function (d) { return FA_DIGITS.charAt(+d); }); }
function esc(s) {
  return String(s == null ? '' : s).replace(/[&<>"']/g, function (c) {
    return { '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[c];
  });
}
function norm(s) {
  return String(s == null ? '' : s)
    .replace(/[يى]/g, 'ی').replace(/ك/g, 'ک')
    .replace(/[\u064B-\u065F\u200c\u200f\u200e]/g, '')
    .replace(/[۰-۹]/g, function (c) { return '۰۱۲۳۴۵۶۷۸۹'.indexOf(c); })
    .replace(/[٠-٩]/g, function (c) { return '٠١٢٣٤٥٦٧٨٩'.indexOf(c); })
    .toLowerCase().trim();
}
function $(sel, root) { return (root || APP).querySelector(sel); }
function $$(sel, root) { return Array.prototype.slice.call((root || APP).querySelectorAll(sel)); }
function clamp(v, a, b) { return Math.max(a, Math.min(b, v)); }
function debounce(fn, ms) {
  var t = 0;
  return function () { var a = arguments, c = this; clearTimeout(t); t = setTimeout(function () { fn.apply(c, a); }, ms); };
}
function rafThrottle(fn) {
  var pending = false;
  return function () { if (pending) { return; } pending = true; requestAnimationFrame(function () { pending = false; fn(); }); };
}
function cmpFa(a, b) { return String(a).localeCompare(String(b), 'fa'); }
function hueOf(str) { var h = 0, i; for (i = 0; i < str.length; i++) { h = (h * 31 + str.charCodeAt(i)) % 360; } return h; }
function initials(name) {
  var parts = String(name || '').trim().split(/\s+/);
  var a = (parts[0] || '').charAt(0), b = parts.length > 1 ? parts[parts.length - 1].charAt(0) : '';
  return (a + (b ? '\u200c' + b : '')) || '؟';
}
function stamp() { return Date.now().toString(36); }

/* ───────────── آیکن‌ها ───────────── */
var ICONS = {
  plus: '<path d="M12 5v14M5 12h14"/>',
  minus: '<path d="M5 12h14"/>',
  x: '<path d="M18 6 6 18M6 6l12 12"/>',
  check: '<path d="M20 6 9 17l-5-5"/>',
  search: '<circle cx="11" cy="11" r="7"/><path d="m21 21-4.3-4.3"/>',
  chevD: '<path d="m6 9 6 6 6-6"/>',
  chevL: '<path d="m15 18-6-6 6-6"/>',
  chevR: '<path d="m9 18 6-6-6-6"/>',
  chevU: '<path d="m18 15-6-6-6 6"/>',
  more: '<circle cx="12" cy="5" r="1.4"/><circle cx="12" cy="12" r="1.4"/><circle cx="12" cy="19" r="1.4"/>',
  edit: '<path d="M12 20h9"/><path d="M16.5 3.5a2.1 2.1 0 0 1 3 3L7 19l-4 1 1-4Z"/>',
  trash: '<path d="M3 6h18M8 6V4h8v2M19 6l-1 14H6L5 6M10 11v6M14 11v6"/>',
  user: '<circle cx="12" cy="8" r="4"/><path d="M4 21a8 8 0 0 1 16 0"/>',
  users: '<path d="M17 21v-2a4 4 0 0 0-4-4H5a4 4 0 0 0-4 4v2"/><circle cx="9" cy="7" r="4"/><path d="M23 21v-2a4 4 0 0 0-3-3.9M16 3.1a4 4 0 0 1 0 7.8"/>',
  userPlus: '<path d="M16 21v-2a4 4 0 0 0-4-4H6a4 4 0 0 0-4 4v2"/><circle cx="9" cy="7" r="4"/><path d="M19 8v6M22 11h-6"/>',
  undo: '<path d="M3 7v6h6"/><path d="M3 13a9 9 0 1 0 3-7.7L3 8"/>',
  redo: '<path d="M21 7v6h-6"/><path d="M21 13a9 9 0 1 1-3-7.7L21 8"/>',
  download: '<path d="M21 15v4a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2v-4M7 10l5 5 5-5M12 15V3"/>',
  upload: '<path d="M21 15v4a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2v-4M17 8l-5-5-5 5M12 3v12"/>',
  printer: '<path d="M6 9V2h12v7M6 18H4a2 2 0 0 1-2-2v-5a2 2 0 0 1 2-2h16a2 2 0 0 1 2 2v5a2 2 0 0 1-2 2h-2"/><path d="M6 14h12v8H6z"/>',
  fit: '<path d="M8 3H5a2 2 0 0 0-2 2v3M21 8V5a2 2 0 0 0-2-2h-3M3 16v3a2 2 0 0 0 2 2h3M16 21h3a2 2 0 0 0 2-2v-3"/>',
  full: '<path d="M15 3h6v6M9 21H3v-6M21 3l-7 7M3 21l7-7"/>',
  sun: '<circle cx="12" cy="12" r="4"/><path d="M12 2v2M12 20v2M4.9 4.9l1.4 1.4M17.7 17.7l1.4 1.4M2 12h2M20 12h2M4.9 19.1l1.4-1.4M17.7 6.3l1.4-1.4"/>',
  moon: '<path d="M21 12.8A9 9 0 1 1 11.2 3a7 7 0 0 0 9.8 9.8Z"/>',
  shield: '<path d="M12 22s8-4 8-10V5l-8-3-8 3v7c0 6 8 10 8 10Z"/><path d="m9 12 2 2 4-4"/>',
  crown: '<path d="M2 18 4 8l5 4 3-7 3 7 5-4 2 10Z"/><path d="M3 21h18"/>',
  briefcase: '<rect x="2" y="7" width="20" height="14" rx="2"/><path d="M16 7V5a2 2 0 0 0-2-2h-4a2 2 0 0 0-2 2v2M2 13h20"/>',
  folder: '<path d="M22 19a2 2 0 0 1-2 2H4a2 2 0 0 1-2-2V5a2 2 0 0 1 2-2h5l2 3h9a2 2 0 0 1 2 2Z"/>',
  history: '<circle cx="12" cy="12" r="9"/><path d="M12 7v5l3 2"/>',
  alert: '<path d="M10.3 3.9 1.8 18a2 2 0 0 0 1.7 3h17a2 2 0 0 0 1.7-3L13.7 3.9a2 2 0 0 0-3.4 0ZM12 9v4M12 17h.01"/>',
  help: '<circle cx="12" cy="12" r="10"/><path d="M9.1 9a3 3 0 0 1 5.8 1c0 2-3 3-3 3M12 17h.01"/>',
  treeV: '<rect x="9" y="2.5" width="6" height="5" rx="1.2"/><path d="M12 7.5v3.5M5 11h14M5 11v3M19 11v3"/><rect x="2" y="14" width="6" height="5.5" rx="1.2"/><rect x="16" y="14" width="6" height="5.5" rx="1.2"/>',
  treeH: '<rect x="2.5" y="9" width="5" height="6" rx="1.2"/><path d="M7.5 12H11M11 5v14M11 5h3M11 19h3"/><rect x="14" y="2" width="5.5" height="6" rx="1.2"/><rect x="14" y="16" width="5.5" height="6" rx="1.2"/>',
  density: '<path d="M4 6h16M4 12h16M4 18h16"/>',
  list: '<path d="M8 6h13M8 12h13M8 18h13M3 6h.01M3 12h.01M3 18h.01"/>',
  map: '<path d="M1 6v16l7-4 8 4 7-4V2l-7 4-8-4Z"/><path d="M8 2v16M16 6v16"/>',
  move: '<path d="M5 9l-3 3 3 3M9 5l3-3 3 3M15 19l-3 3-3-3M19 9l3 3-3 3M2 12h20M12 2v20"/>',
  grip: '<circle cx="9" cy="6" r="1.2"/><circle cx="15" cy="6" r="1.2"/><circle cx="9" cy="12" r="1.2"/><circle cx="15" cy="12" r="1.2"/><circle cx="9" cy="18" r="1.2"/><circle cx="15" cy="18" r="1.2"/>',
  arrowU: '<path d="M12 19V5M5 12l7-7 7 7"/>',
  arrowD: '<path d="M12 5v14M19 12l-7 7-7-7"/>',
  star: '<path d="m12 2 3.1 6.3 6.9 1-5 4.9 1.2 6.9L12 17.8 5.8 21.1 7 14.2 2 9.3l6.9-1Z"/>',
  sheet: '<path d="M14 2H6a2 2 0 0 0-2 2v16a2 2 0 0 0 2 2h12a2 2 0 0 0 2-2V8Z"/><path d="M14 2v6h6M8 13h8M8 17h8M12 13v8"/>',
  image: '<rect x="3" y="3" width="18" height="18" rx="2"/><circle cx="8.5" cy="8.5" r="1.5"/><path d="m21 15-5-5L5 21"/>',
  code: '<path d="m16 18 6-6-6-6M8 6l-6 6 6 6"/>',
  layers: '<path d="M12 2 2 7l10 5 10-5Z"/><path d="m2 17 10 5 10-5M2 12l10 5 10-5"/>',
  expandAll: '<path d="M7 8l5-5 5 5M7 16l5 5 5-5"/>',
  collapseAll: '<path d="M7 3l5 5 5-5M7 21l5-5 5 5"/>',
  focus: '<circle cx="12" cy="12" r="3"/><path d="M12 2v4M12 18v4M2 12h4M18 12h4"/>',
  copy: '<rect x="9" y="9" width="13" height="13" rx="2"/><path d="M5 15H4a2 2 0 0 1-2-2V4a2 2 0 0 1 2-2h9a2 2 0 0 1 2 2v1"/>',
  panel: '<rect x="3" y="3" width="18" height="18" rx="2"/><path d="M15 3v18"/>',
  panelR: '<rect x="3" y="3" width="18" height="18" rx="2"/><path d="M9 3v18"/>',
  info: '<circle cx="12" cy="12" r="10"/><path d="M12 16v-4M12 8h.01"/>',
  sparkle: '<path d="M12 3v4M12 17v4M3 12h4M17 12h4M6 6l2.5 2.5M15.5 15.5 18 18M18 6l-2.5 2.5M8.5 15.5 6 18"/>'
};
function ico(name, cls) {
  return '<svg class="ot-i' + (cls ? ' ' + cls : '') + '" viewBox="0 0 24 24" aria-hidden="true" focusable="false">' + (ICONS[name] || '') + '</svg>';
}

var TYPES = {
  ceo: { label: 'مدیرعامل', mgr: 'مدیرعامل', icon: 'crown' },
  deputy: { label: 'معاونت', mgr: 'مدیر معاونت', icon: 'briefcase' },
  department: { label: 'اداره', mgr: 'مدیر اداره', icon: 'folder' }
};

/* ───────────── وضعیت ───────────── */
var S = {
  data: null,
  sel: 0,
  busy: false,
  focus: 0,
  collapsed: new Set(),
  autoOpen: new Set(),
  cam: { x: 0, y: 0, k: 1 },
  layout: null,
  search: { q: '', res: [], i: -1, units: new Set(), users: new Set(), trail: new Set() },
  tab: 'people',
  pf: 'free',
  pq: '',
  hl: new Set(),
  hlLabel: '',
  drag: null,
  view: { orient: 'v', density: 'full', theme: 'light', minimap: true, side: true, panel: true, collapsedInit: false }
};
var I = {};

var PKEY = 'otv8:' + ((BOOT.currentUser && BOOT.currentUser.id) || 0);
function loadView() {
  try {
    var raw = window.localStorage.getItem(PKEY);
    if (!raw) { return; }
    var v = JSON.parse(raw);
    if (v && typeof v === 'object') {
      ['orient', 'density', 'theme', 'minimap', 'side', 'panel'].forEach(function (k) { if (v[k] !== undefined) { S.view[k] = v[k]; } });
      if (Array.isArray(v.collapsed)) { S.collapsed = new Set(v.collapsed.map(Number)); S.view.collapsedInit = true; }
    }
  } catch (e) { /* ذخیره‌سازی محلی در دسترس نیست */ }
}
function saveView() {
  try {
    var v = {};
    ['orient', 'density', 'theme', 'minimap', 'side', 'panel'].forEach(function (k) { v[k] = S.view[k]; });
    v.collapsed = Array.from(S.collapsed);
    window.localStorage.setItem(PKEY, JSON.stringify(v));
  } catch (e) { /* ignore */ }
}

/* ───────────── نمایه‌سازی داده ───────────── */
function rebuild() {
  var D = S.data, ids;
  I.unit = new Map(); I.kids = new Map(); I.user = new Map(); I.members = new Map();
  I.managed = new Map(); I.depth = new Map(); I.total = new Map(); I.root = null;
  D.units.forEach(function (u) { I.unit.set(u.id, u); I.kids.set(u.id, []); });
  D.units.forEach(function (u) {
    if (u.parentId && I.kids.has(u.parentId)) { I.kids.get(u.parentId).push(u); }
  });
  I.kids.forEach(function (list) {
    list.sort(function (a, b) { return (a.sortOrder - b.sortOrder) || cmpFa(a.name, b.name) || (a.id - b.id); });
  });
  D.units.forEach(function (u) { if (u.type === 'ceo') { I.root = I.root || u; } });
  if (!I.root) { D.units.forEach(function (u) { if (!u.parentId && !I.root) { I.root = u; } }); }
  D.users.forEach(function (u) { I.user.set(u.id, u); });
  D.units.forEach(function (u) { (u.managerIds || []).forEach(function (id) { if (!I.managed.has(id)) { I.managed.set(id, u.id); } }); });
  D.users.forEach(function (u) {
    if (!u.active || !u.unitId || !I.unit.has(u.unitId) || I.managed.has(u.id)) { return; }
    if (!I.members.has(u.unitId)) { I.members.set(u.unitId, []); }
    I.members.get(u.unitId).push(u);
  });
  I.members.forEach(function (list) { list.sort(function (a, b) { return cmpFa(a.name, b.name); }); });
  function walk(u, d) {
    I.depth.set(u.id, d);
    var t = managersOf(u).filter(function (m) { return m.active; }).length + membersOf(u.id).length;
    (I.kids.get(u.id) || []).forEach(function (k) { t += walk(k, d + 1); });
    I.total.set(u.id, t);
    return t;
  }
  I.maxDepth = 0;
  if (I.root) { walk(I.root, 0); }
  I.depth.forEach(function (d) { I.maxDepth = Math.max(I.maxDepth, d); });
  /* آمار */
  var st = { units: 0, deputies: 0, departments: 0, managers: 0, experts: 0, free: 0, active: 0 };
  D.units.forEach(function (u) {
    if (u.type === 'deputy') { st.deputies++; st.units++; }
    else if (u.type === 'department') { st.departments++; st.units++; }
  });
  var mset = new Set();
  D.units.forEach(function (u) { managersOf(u).forEach(function (m) { if (m.active) { mset.add(m.id); } }); });
  st.managers = mset.size;
  D.users.forEach(function (u) {
    if (!u.active) { return; }
    st.active++;
    if (mset.has(u.id)) { return; }
    if (u.unitId && I.unit.has(u.unitId)) { st.experts++; } else { st.free++; }
  });
  I.stats = st;
  /* مسیر و نمایه جستجو */
  I.search = [];
  D.units.forEach(function (u) {
    I.search.push({ kind: 'unit', id: u.id, text: norm(u.name + ' ' + (u.code || '') + ' ' + pathNames(u.id).join(' ')), title: u.name, sub: pathNames(u.id).slice(0, -1).join(' ‹ ') });
  });
  D.users.forEach(function (u) {
    if (!u.active) { return; }
    I.search.push({ kind: 'user', id: u.id, text: norm(u.name + ' ' + u.username + ' ' + (u.code || '')), title: u.name, sub: userPlace(u) });
  });
  I.issues = computeIssues();
  ids = null;
  if (S.sel && !I.unit.has(S.sel)) { S.sel = 0; }
  if (S.focus && !I.unit.has(S.focus)) { S.focus = 0; }
  Array.from(S.collapsed).forEach(function (id) { if (!I.unit.has(id)) { S.collapsed.delete(id); } });
  if (!S.view.collapsedInit && D.units.length > 40) {
    D.units.forEach(function (u) { if ((I.depth.get(u.id) || 0) >= 2 && (I.kids.get(u.id) || []).length) { S.collapsed.add(u.id); } });
  }
  S.view.collapsedInit = true;
}

function isClosed(id) { return S.collapsed.has(id) && !S.autoOpen.has(id); }
function unitById(id) { return I.unit.get(id) || null; }
function kidsOf(id) { return I.kids.get(id) || []; }
function membersOf(id) { return I.members.get(id) || []; }
function managersOf(u) {
  return (u.managerIds || []).map(function (id) { return I.user.get(id); }).filter(Boolean);
}
function pathOf(id) {
  var out = [], u = unitById(id), g = 0;
  while (u && g++ < 60) { out.unshift(u); u = u.parentId ? unitById(u.parentId) : null; }
  return out;
}
function pathNames(id) { return pathOf(id).map(function (u) { return u.name; }); }
function isDescendant(id, ancestorId) {
  var u = unitById(id), g = 0;
  while (u && g++ < 60) { if (u.id === ancestorId) { return true; } u = u.parentId ? unitById(u.parentId) : null; }
  return false;
}
function subtreeIds(id) {
  var out = [], stack = [id];
  while (stack.length) { var x = stack.pop(); out.push(x); kidsOf(x).forEach(function (k) { stack.push(k.id); }); }
  return out;
}
function subtreeHeight(id) {
  var h = 0;
  kidsOf(id).forEach(function (k) { h = Math.max(h, 1 + subtreeHeight(k.id)); });
  return h;
}
function roleOf(user) {
  var mu = I.managed.get(user.id);
  if (mu) { var u = unitById(mu); return { kind: 'manager', unit: u, label: u ? TYPES[u.type].mgr : 'مدیر' }; }
  if (user.unitId && I.unit.has(user.unitId)) { return { kind: 'expert', unit: unitById(user.unitId), label: 'کارشناس' }; }
  return { kind: 'free', unit: null, label: 'بدون واحد' };
}
function userPlace(user) {
  var r = roleOf(user);
  return r.unit ? r.label + ' · ' + r.unit.name : 'بدون واحد';
}
function suggestedType(parent) { return parent && parent.type === 'ceo' ? 'deputy' : 'department'; }

function computeIssues() {
  var out = [], D = S.data;
  function add(key, level, title, hint, ids) { if (ids.length) { out.push({ key: key, level: level, title: title, hint: hint, ids: ids }); } }
  var noMgr = [], inactive = [], empty = [], dupName = [], dupCode = [], codes = {};
  D.units.forEach(function (u) {
    var ms = managersOf(u), act = ms.filter(function (m) { return m.active; });
    if (!act.length) { noMgr.push(u.id); }
    if (ms.length && ms.length !== act.length) { inactive.push(u.id); }
    if (u.type !== 'ceo' && !kidsOf(u.id).length && !membersOf(u.id).length && !act.length) { empty.push(u.id); }
    var seen = {};
    kidsOf(u.id).forEach(function (k) {
      var key = norm(k.name);
      if (seen[key]) { dupName.push(k.id); dupName.push(seen[key]); } else { seen[key] = k.id; }
    });
    if (u.code) { (codes[norm(u.code)] = codes[norm(u.code)] || []).push(u.id); }
  });
  Object.keys(codes).forEach(function (k) { if (codes[k].length > 1) { dupCode = dupCode.concat(codes[k]); } });
  add('nomgr', 'warn', 'واحدهای بدون مدیر', 'برای این واحدها هنوز مدیری تعیین نشده است.', noMgr);
  add('inactive', 'warn', 'مدیر غیرفعال', 'مدیر این واحدها حساب غیرفعال دارد.', inactive);
  add('dupname', 'warn', 'نام تکراری هم‌ردیف', 'نام این واحدها در همان والد تکرار شده است.', Array.from(new Set(dupName)));
  add('dupcode', 'warn', 'کد تکراری', 'کد این واحدها با واحد دیگری یکسان است.', dupCode);
  add('empty', 'info', 'واحدهای خالی', 'نه مدیر دارند، نه کارشناس و نه زیرواحد.', empty);
  return out;
}

/* ───────────── موتور چیدمان (درخت مرتب با اندازهٔ ثابت کارت) ───────────── */
function cardSize(u, density) {
  if (density === 'compact') { return { w: u.type === 'ceo' ? 250 : (u.type === 'deputy' ? 232 : 216), h: 88 }; }
  return { w: u.type === 'ceo' ? 304 : (u.type === 'deputy' ? 280 : 264), h: u.type === 'ceo' ? 154 : 148 };
}

function computeLayout(o) {
  o = o || {};
  var horiz = (o.orient || S.view.orient) === 'h';
  var density = o.density || S.view.density;
  var rootU = o.rootId ? unitById(o.rootId) : I.root;
  var out = { nodes: [], map: new Map(), links: [], W: 0, H: 0, root: null };
  if (!rootU) { return out; }
  var compact = density === 'compact';
  var gapB = compact ? 18 : 28;
  var gapD = compact ? (horiz ? 64 : 54) : (horiz ? 100 : 76);
  var levels = [], visited = new Set();

  function build(u, depth, parent) {
    visited.add(u.id);
    var sz = cardSize(u, density);
    var n = { id: u.id, u: u, w: sz.w, h: sz.h, depth: depth, parent: parent, kids: [], x: 0, y: 0, b: 0, sb: 0 };
    out.map.set(u.id, n); out.nodes.push(n);
    levels[depth] = Math.max(levels[depth] || 0, horiz ? n.w : n.h);
    if (o.ignoreCollapsed || !isClosed(u.id)) {
      kidsOf(u.id).forEach(function (k) { if (!visited.has(k.id)) { n.kids.push(build(k, depth + 1, n)); } });
    }
    return n;
  }
  var root = build(rootU, 0, null);
  out.root = root;
  function bs(n) { return horiz ? n.h : n.w; }
  function measure(n) {
    var sum = 0;
    n.kids.forEach(function (k) { measure(k); sum += k.sb; });
    sum += Math.max(0, n.kids.length - 1) * gapB;
    n.sb = Math.max(bs(n), sum);
  }
  function place(n, start) {
    if (!n.kids.length) { n.b = start + n.sb / 2; return; }
    var total = Math.max(0, n.kids.length - 1) * gapB;
    n.kids.forEach(function (k) { total += k.sb; });
    var cur = start + (n.sb - total) / 2;
    n.kids.forEach(function (k) { place(k, cur); cur += k.sb + gapB; });
    n.b = (n.kids[0].b + n.kids[n.kids.length - 1].b) / 2;
  }
  measure(root); place(root, 0);
  var starts = [], acc = 0;
  levels.forEach(function (l, i) { starts[i] = acc; acc += l + gapD; });
  var depthTotal = acc - gapD, breadthTotal = root.sb, PAD = 64;
  var Wt = horiz ? depthTotal : breadthTotal, Ht = horiz ? breadthTotal : depthTotal;
  out.nodes.forEach(function (n) {
    var d = starts[n.depth], lv = levels[n.depth], x, y;
    if (horiz) { x = d + (lv - n.w) / 2; y = n.b - n.h / 2; }
    else { x = n.b - n.w / 2; y = d + (lv - n.h) / 2; }
    n.x = PAD + (Wt - (x + n.w));   /* راست‌به‌چپ: اولین فرزند سمت راست */
    n.y = PAD + y;
    if (n.parent) { out.links.push({ from: n.parent, to: n }); }
  });
  out.W = Wt + PAD * 2; out.H = Ht + PAD * 2; out.horiz = horiz; out.gapD = gapD;
  return out;
}

function linkPath(p, c, horiz, gapD) {
  var sx, sy, ex, ey, r, dir, mid;
  if (!horiz) {
    sx = p.x + p.w / 2; sy = p.y + p.h; ex = c.x + c.w / 2; ey = c.y;
    if (Math.abs(ex - sx) < 1) { return 'M' + sx + ' ' + sy + 'V' + ey; }
    mid = ey - gapD / 2; dir = ex > sx ? 1 : -1;
    r = Math.min(14, Math.abs(ex - sx) / 2, Math.max(2, mid - sy), Math.max(2, ey - mid));
    return 'M' + sx + ' ' + sy + 'V' + (mid - r) + 'Q' + sx + ' ' + mid + ' ' + (sx + dir * r) + ' ' + mid +
      'H' + (ex - dir * r) + 'Q' + ex + ' ' + mid + ' ' + ex + ' ' + (mid + r) + 'V' + ey;
  }
  sx = p.x; sy = p.y + p.h / 2; ex = c.x + c.w; ey = c.y + c.h / 2;
  if (Math.abs(ey - sy) < 1) { return 'M' + sx + ' ' + sy + 'H' + ex; }
  mid = ex + gapD / 2; dir = ey > sy ? 1 : -1;
  r = Math.min(14, Math.abs(ey - sy) / 2, Math.max(2, sx - mid), Math.max(2, mid - ex));
  return 'M' + sx + ' ' + sy + 'H' + (mid + r) + 'Q' + mid + ' ' + sy + ' ' + mid + ' ' + (sy + dir * r) +
    'V' + (ey - dir * r) + 'Q' + mid + ' ' + ey + ' ' + (mid - r) + ' ' + ey + 'H' + ex;
}

/* ───────────── آواتار و اجزای کارت ───────────── */
function avatar(u, size, extra) {
  var cls = 'ot-av' + (size ? ' ot-av-' + size : '') + (extra ? ' ' + extra : '') + (!u.active ? ' is-off' : '');
  var img = u.photo ? '<img src="' + CFG.photo + u.id + '&v=' + esc(u.photo) + '" alt="" loading="lazy" draggable="false">' : '';
  return '<span class="' + cls + '" style="--h:' + hueOf(u.name) + '" data-uid="' + u.id + '" title="' + esc(u.name) + '"><span class="ot-av-t">' + esc(initials(u.name)) + '</span>' + img + '</span>';
}

function typeClass(u) { return u.type === 'ceo' ? 'ot-t-ceo' : (u.type === 'deputy' ? 'ot-t-deputy' : 'ot-t-dept'); }

function cardHtml(n) {
  var u = n.u, T = TYPES[u.type] || TYPES.department, compact = S.view.density === 'compact';
  var ms = managersOf(u), act = ms.filter(function (m) { return m.active; }), mem = membersOf(u.id), kids = kidsOf(u.id);
  var can = BOOT.canManage, m0 = ms[0], total = I.total.get(u.id) || 0, h = '';
  h += '<span class="ot-accent"></span><div class="ot-head"><span class="ot-tico">' + ico(T.icon) + '</span>' +
    '<div class="ot-ttl"><b title="' + esc(u.name) + '">' + esc(u.name) + '</b><small>' + esc(T.label) +
    (u.code ? ' <i>·</i> <span class="ot-code">' + esc(u.code) + '</span>' : '') + '</small></div><span class="ot-badges">';
  if (u.primaryAdmin) { h += '<span class="ot-badge ot-b-admin" title="ادمین اصلی — مدیران این واحد دسترسی ادمین اصلی دارند">' + ico('shield') + '</span>'; }
  if (!act.length) { h += '<span class="ot-badge ot-b-warn" title="' + (ms.length ? 'مدیر غیرفعال است' : 'مدیر تعیین نشده') + '">' + ico('alert') + '</span>'; }
  h += '</span><button class="ot-more" data-act="menu" aria-label="گزینه‌های ' + esc(u.name) + '" aria-haspopup="menu" tabindex="-1">' + ico('more') + '</button></div>';
  if (compact) {
    h += '<div class="ot-line">' + (m0 ? avatar(m0, 'xs') + '<span class="ot-line-t' + (m0.active ? '' : ' is-off') + '">' + esc(m0.name) + (ms.length > 1 ? ' <em>+' + fa(ms.length - 1) + '</em>' : '') + '</span>' : '<span class="ot-line-t is-none">بدون مدیر</span>') +
      '<span class="ot-tot" title="کل نفرات این شاخه">' + ico('users') + fa(total) + '</span></div>';
  } else {
    h += '<div class="ot-mgr">';
    if (m0) {
      h += avatar(m0, 'md') + '<div class="ot-mgr-t"><b class="' + (m0.active ? '' : 'is-off') + '">' + esc(m0.name) + '</b><small>' + esc(T.mgr) +
        (ms.length > 1 ? ' · و ' + fa(ms.length - 1) + ' مدیر دیگر' : '') + (m0.active ? '' : ' · غیرفعال') + '</small></div>';
      if (can) { h += '<button class="ot-mini" data-act="managers" title="ویرایش مدیران" tabindex="-1">' + ico('edit') + '</button>'; }
    } else if (can) {
      h += '<button class="ot-slot" data-act="managers" tabindex="-1">' + ico('userPlus') + '<span>تعیین مدیر</span></button>';
    } else { h += '<span class="ot-nomgr">بدون مدیر</span>'; }
    h += '</div><div class="ot-foot">';
    if (u.type === 'ceo') {
      h += '<span class="ot-cnt">' + fa(kids.length) + ' معاونت</span>';
    } else {
      h += '<button class="ot-exp" data-act="members" tabindex="-1" title="' + (can ? 'مدیریت کارشناسان' : 'نمایش کارشناسان') + '">';
      if (mem.length) {
        h += '<span class="ot-stack">' + mem.slice(0, 4).map(function (x) { return avatar(x, 'xs', S.search.users.has(x.id) ? 'is-hit' : ''); }).join('') +
          (mem.length > 4 ? '<span class="ot-av ot-av-xs ot-av-more">+' + fa(mem.length - 4) + '</span>' : '') + '</span><span class="ot-cnt">' + fa(mem.length) + ' کارشناس</span>';
      } else { h += (can ? ico('plus') : '') + '<span class="ot-cnt is-none">' + (can ? 'افزودن کارشناس' : 'بدون کارشناس') + '</span>'; }
      h += '</button>';
    }
    h += '<span class="ot-tot" title="کل نفرات این شاخه (مدیر + کارشناس + زیرمجموعه)">' + ico('users') + fa(total) + '</span></div>';
  }
  if (kids.length) {
    var closed = isClosed(u.id);
    h += '<button class="ot-tog' + (closed ? ' is-closed' : '') + '" data-act="toggle" tabindex="-1" aria-label="' + (closed ? 'باز کردن' : 'بستن') + ' زیرمجموعه‌ها" title="' + (closed ? 'نمایش' : 'پنهان‌کردن') + ' ' + fa(kids.length) + ' زیرواحد"><span>' + fa(kids.length) + '</span>' + ico('chevD') + '</button>';
  }
  if (can) {
    h += '<div class="ot-dz ot-dz-unit" aria-hidden="true"><span data-zone="before"><em>قبل از این</em></span><span data-zone="child"><em>زیرمجموعه</em></span><span data-zone="after"><em>بعد از این</em></span></div>';
    h += '<div class="ot-dz ot-dz-user" aria-hidden="true"><span data-zone="manager"><em>' + ico('crown') + ' مدیر</em></span>' + (u.type === 'ceo' ? '' : '<span data-zone="expert"><em>' + ico('user') + ' کارشناس</em></span>') + '</div>';
  }
  return h;
}

function cardSig(n) {
  var u = n.u, ms = managersOf(u), mem = membersOf(u.id);
  return [u.name, u.code, u.type, u.primaryAdmin ? 1 : 0, ms.map(function (m) { return m.id + (m.active ? 'a' : 'x') + (m.photo || ''); }).join(','),
    mem.length, mem.slice(0, 4).map(function (m) { return m.id + (m.photo || '') + (S.search.users.has(m.id) ? 'h' : ''); }).join(','),
    kidsOf(u.id).length, isClosed(u.id) ? 1 : 0, I.total.get(u.id), S.view.density, BOOT.canManage ? 1 : 0].join('|');
}

/* ───────────── رندر اصلی ───────────── */
var E = {};          /* ارجاع به عناصر ثابت */
var cardEls = new Map();

function render(opts) {
  opts = opts || {};
  var L = computeLayout({ rootId: S.focus || 0 });
  S.layout = L;
  var horiz = L.horiz;
  APP.setAttribute('data-orient', horiz ? 'h' : 'v'); APP.setAttribute('data-density', S.view.density);
  E.world.style.width = L.W + 'px'; E.world.style.height = L.H + 'px';
  E.links.setAttribute('width', L.W); E.links.setAttribute('height', L.H);
  E.links.setAttribute('viewBox', '0 0 ' + L.W + ' ' + L.H);
  var d = '';
  L.links.forEach(function (lk) {
    d += '<path class="ot-link" data-to="' + lk.to.id + '" d="' + linkPath(lk.from, lk.to, horiz, L.gapD) + '"/>';
  });
  E.links.innerHTML = d;
  E.cards.setAttribute('aria-orientation', horiz ? 'horizontal' : 'vertical');
  var seen = new Set();
  L.nodes.forEach(function (n, idx) {
    seen.add(n.id);
    var el = cardEls.get(n.id), fresh = false;
    if (!el) {
      el = document.createElement('div'); el.className = 'ot-card'; el.setAttribute('role', 'treeitem');
      el.dataset.id = String(n.id); el.__sig = ''; fresh = true;
      E.cards.appendChild(el); cardEls.set(n.id, el);
      if (!opts.noEnter) { el.classList.add('ot-enter'); setTimeout(function () { el.classList.remove('ot-enter'); }, 500); }
      el.style.transform = 'translate(' + n.x + 'px,' + n.y + 'px)';
    }
    var sig = cardSig(n);
    if (el.__sig !== sig) { el.innerHTML = cardHtml(n); el.__sig = sig; }
    el.className = 'ot-card ' + typeClass(n.u) + (fresh && !opts.noEnter ? ' ot-enter' : '');
    el.style.width = n.w + 'px'; el.style.height = n.h + 'px';
    el.style.transform = 'translate(' + n.x + 'px,' + n.y + 'px)';
    el.setAttribute('aria-level', String(n.depth + 1));
    el.setAttribute('aria-label', n.u.name + ' — ' + (TYPES[n.u.type] || {}).label);
    if (kidsOf(n.id).length) { el.setAttribute('aria-expanded', n.kids.length ? 'true' : 'false'); } else { el.removeAttribute('aria-expanded'); }
    el.draggable = !!BOOT.canManage && n.u.type !== 'ceo';
    el.style.zIndex = String(L.nodes.length - idx);
  });
  cardEls.forEach(function (el, id) {
    if (!seen.has(id)) { cardEls.delete(id); el.classList.add('ot-leave'); setTimeout(function () { if (el.parentNode) { el.parentNode.removeChild(el); } }, 260); }
  });
  paintState();
  if (opts.relayoutFade) { E.links.classList.add('ot-fade'); requestAnimationFrame(function () { requestAnimationFrame(function () { E.links.classList.remove('ot-fade'); }); }); }
  drawMinimap();
  renderCrumbs();
  var empty = !I.root || (L.nodes.length === 1 && !kidsOf(L.root.id).length);
  E.empty.hidden = !empty;
}

/* کلاس‌های وابسته به انتخاب/جستجو/هشدار روی کارت‌ها (بدون ساخت دوبارهٔ DOM) */
function trailSet() {
  var t = new Set(), u = S.sel ? unitById(S.sel) : null, g = 0;
  while (u && g++ < 60) { t.add(u.id); u = u.parentId ? unitById(u.parentId) : null; }
  return t;
}
function paintState() {
  var trail = trailSet(), q = S.search, searching = !!q.q;
  cardEls.forEach(function (el, id) {
    el.classList.toggle('is-sel', id === S.sel);
    el.classList.toggle('is-hit', searching && q.units.has(id));
    el.classList.toggle('is-trail', searching && q.trail.has(id) && !q.units.has(id));
    el.classList.toggle('is-dim', searching && !q.units.has(id) && !q.trail.has(id));
    el.classList.toggle('is-flag', S.hl.has(id));
    el.setAttribute('aria-selected', id === S.sel ? 'true' : 'false');
    el.tabIndex = (id === S.sel || (!S.sel && S.layout && S.layout.root && S.layout.root.id === id)) ? 0 : -1;
  });
  $$('.ot-link', E.links).forEach(function (p) {
    p.classList.toggle('is-trail', trail.has(+p.getAttribute('data-to')));
  });
  APP.classList.toggle('is-searching', searching);
  APP.classList.toggle('has-flags', S.hl.size > 0);
}

/* ───────────── دوربین (جابه‌جایی و بزرگ‌نمایی) ───────────── */
function applyCam(animate) {
  if (animate) { E.world.classList.add('ot-anim'); clearTimeout(applyCam.t); applyCam.t = setTimeout(function () { E.world.classList.remove('ot-anim'); }, 460); }
  else { E.world.classList.remove('ot-anim'); }
  E.world.style.transform = 'translate(' + S.cam.x + 'px,' + S.cam.y + 'px) scale(' + S.cam.k + ')';
  E.zoomLabel.textContent = fa(Math.round(S.cam.k * 100)) + '٪';
  drawMinimapSoon();
}
function vpSize() { var r = E.viewport.getBoundingClientRect(); return { w: r.width, h: r.height, l: r.left, t: r.top }; }
function zoomAt(factor, cx, cy, animate) {
  var vp = vpSize(), k0 = S.cam.k, k1 = clamp(k0 * factor, 0.12, 2.2);
  if (cx == null) { cx = vp.l + vp.w / 2; cy = vp.t + vp.h / 2; }
  var px = cx - vp.l, py = cy - vp.t;
  S.cam.x = px - (px - S.cam.x) * (k1 / k0);
  S.cam.y = py - (py - S.cam.y) * (k1 / k0);
  S.cam.k = k1;
  applyCam(animate);
}
function setZoom(k, animate) { var vp = vpSize(); zoomAt(k / S.cam.k, vp.l + vp.w / 2, vp.t + vp.h / 2, animate); }
function fitView(animate, only) {
  var L = S.layout; if (!L || !L.W) { return; }
  var vp = vpSize(), pad = 24, b = bounds(only);
  var k = clamp(Math.min((vp.w - pad * 2) / b.w, (vp.h - pad * 2 - 40) / b.h, 1.15), 0.12, 1.15);
  S.cam.k = k;
  S.cam.x = (vp.w - b.w * k) / 2 - b.x * k;
  S.cam.y = (vp.h - b.h * k) / 2 - b.y * k + 12;
  applyCam(animate);
}
function bounds(only) {
  var L = S.layout, x0 = 1e9, y0 = 1e9, x1 = -1e9, y1 = -1e9;
  (L.nodes || []).forEach(function (n) {
    if (only && !only.has(n.id)) { return; }
    x0 = Math.min(x0, n.x); y0 = Math.min(y0, n.y); x1 = Math.max(x1, n.x + n.w); y1 = Math.max(y1, n.y + n.h);
  });
  if (x0 > x1) { return { x: 0, y: 0, w: L.W || 1, h: L.H || 1 }; }
  return { x: x0 - 40, y: y0 - 40, w: x1 - x0 + 80, h: y1 - y0 + 80 };
}
function centerOn(id, k, animate) {
  var n = S.layout && S.layout.map.get(id); if (!n) { return; }
  var vp = vpSize(); if (k) { S.cam.k = clamp(k, 0.12, 2.2); }
  S.cam.x = vp.w / 2 - (n.x + n.w / 2) * S.cam.k;
  S.cam.y = vp.h / 2 - (n.y + n.h / 2) * S.cam.k;
  applyCam(animate !== false);
}
function ensureVisible(id) {
  var n = S.layout && S.layout.map.get(id); if (!n) { return; }
  var vp = vpSize(), k = S.cam.k, m = 40;
  var l = n.x * k + S.cam.x, t = n.y * k + S.cam.y, r = l + n.w * k, b = t + n.h * k, dx = 0, dy = 0;
  if (l < m) { dx = m - l; } else if (r > vp.w - m) { dx = vp.w - m - r; }
  if (t < m) { dy = m - t; } else if (b > vp.h - m) { dy = vp.h - m - b; }
  if (dx || dy) { S.cam.x += dx; S.cam.y += dy; applyCam(true); }
}

/* ───────────── مینی‌مپ ───────────── */
var drawMinimapSoon = rafThrottle(function () { drawMinimap(); });
function minimapGeom() {
  var L = S.layout, c = E.mini; if (!L || !L.W) { return null; }
  var s = Math.min(c.width / L.W, c.height / L.H);
  return { s: s, ox: (c.width - L.W * s) / 2, oy: (c.height - L.H * s) / 2 };
}
function drawMinimap() {
  var c = E.mini; if (!c || !S.view.minimap) { return; }
  var g = c.getContext('2d'), L = S.layout; g.clearRect(0, 0, c.width, c.height);
  var m = minimapGeom(); if (!m) { return; }
  var css = getComputedStyle(APP);
  var col = { ceo: css.getPropertyValue('--ot-ceo').trim() || '#1f3b63', deputy: css.getPropertyValue('--ot-dep').trim() || '#2f6fa7', dept: css.getPropertyValue('--ot-dept').trim() || '#16908b' };
  L.nodes.forEach(function (n) {
    g.fillStyle = n.id === S.sel ? (css.getPropertyValue('--ot-accent').trim() || '#c8952e') : (n.u.type === 'ceo' ? col.ceo : n.u.type === 'deputy' ? col.deputy : col.dept);
    g.globalAlpha = n.id === S.sel ? 1 : 0.85;
    g.fillRect(m.ox + n.x * m.s, m.oy + n.y * m.s, Math.max(2, n.w * m.s), Math.max(2, n.h * m.s));
  });
  g.globalAlpha = 1;
  var vp = vpSize(), vx = -S.cam.x / S.cam.k, vy = -S.cam.y / S.cam.k, vw = vp.w / S.cam.k, vh = vp.h / S.cam.k;
  g.fillStyle = 'rgba(80,140,255,.12)'; g.strokeStyle = css.getPropertyValue('--ot-brand').trim() || '#1b6b5a'; g.lineWidth = 1.6;
  g.fillRect(m.ox + vx * m.s, m.oy + vy * m.s, vw * m.s, vh * m.s);
  g.strokeRect(m.ox + vx * m.s, m.oy + vy * m.s, vw * m.s, vh * m.s);
}

/* ───────────── پوستهٔ صفحه ───────────── */
function tb(act, icon, title, extra) {
  return '<button class="ot-tb' + (extra ? ' ' + extra : '') + '" data-act="' + act + '" title="' + esc(title) + '" aria-label="' + esc(title) + '">' + ico(icon) + '</button>';
}

function buildShell() {
  var can = BOOT.canManage;
  APP.innerHTML =
    '<header class="ot-top">' +
      '<div class="ot-brand"><span class="ot-logo">' + ico('layers') + '</span><div><h1>درخت سازمان</h1><small id="ot-sub"></small></div></div>' +
      '<div class="ot-search" role="search"><label class="ot-sr" for="ot-q">جستجو در واحدها و افراد</label>' + ico('search') +
        '<input id="ot-q" type="search" autocomplete="off" spellcheck="false" placeholder="جستجوی واحد، مدیر یا کارشناس…" aria-controls="ot-results">' +
        '<span class="ot-qcount" id="ot-qcount" aria-live="polite"></span>' +
        '<button class="ot-ibtn" data-act="q-prev" aria-label="نتیجهٔ قبلی" title="قبلی (Shift+Enter)" hidden>' + ico('chevU') + '</button>' +
        '<button class="ot-ibtn" data-act="q-next" aria-label="نتیجهٔ بعدی" title="بعدی (Enter)" hidden>' + ico('chevD') + '</button>' +
        '<button class="ot-ibtn" data-act="q-clear" aria-label="پاک کردن جستجو" hidden>' + ico('x') + '</button>' +
        '<kbd class="ot-kbd" id="ot-qkbd">Ctrl K</kbd><div class="ot-pop ot-results" id="ot-results" role="listbox" hidden></div></div>' +
      '<div class="ot-tools">' +
        (can ? '<button class="ot-btn ot-primary" data-act="add" title="افزودن واحد جدید زیر واحد انتخاب‌شده">' + ico('plus') + '<span>افزودن واحد</span></button>' +
               '<button class="ot-btn" data-act="bulk" title="ساخت چندین واحد با یک فهرست">' + ico('list') + '<span>ساخت چندتایی</span></button>' +
               '<span class="ot-sep"></span>' + tb('undo', 'undo', 'بازگشت (Ctrl+Z)') + tb('redo', 'redo', 'انجام دوباره (Ctrl+Shift+Z)') + '<span class="ot-sep"></span>' : '') +
        tb('orient', 'treeV', 'تغییر جهت نمایش (عمودی/افقی)') + tb('density', 'density', 'نمای فشرده/کامل') + tb('theme', 'sun', 'تم نمایش') +
        '<span class="ot-sep"></span>' +
        tb('expand-all', 'expandAll', 'باز کردن همهٔ شاخه‌ها') + tb('collapse-all', 'collapseAll', 'بستن شاخه‌ها (فقط سطح اول)') + tb('levels', 'layers', 'نمایش تا سطح…') +
        '<span class="ot-sep"></span>' +
        tb('export', 'download', 'خروجی گرفتن') + tb('full', 'full', 'تمام‌صفحه (Shift+F)') + tb('side', 'panelR', 'نمایش/پنهان‌کردن نوار آمار') + tb('panel', 'panel', 'نمایش/پنهان‌کردن پنل جزئیات') + tb('help', 'help', 'راهنما و کلیدهای میانبر (?)') +
      '</div>' +
    '</header>' +
    '<div class="ot-body">' +
      '<aside class="ot-side" aria-label="نمای کلی"><div id="ot-side"></div></aside>' +
      '<main class="ot-stage">' +
        '<div class="ot-crumbs" id="ot-crumbs" hidden></div>' +
        '<div class="ot-viewport" id="ot-viewport" tabindex="-1"><div class="ot-world" id="ot-world"><svg class="ot-links" id="ot-links" xmlns="http://www.w3.org/2000/svg" aria-hidden="true"></svg><div class="ot-cards" id="ot-cards" role="tree" aria-label="درخت سازمان"></div></div></div>' +
        '<div class="ot-empty" id="ot-empty" hidden><div class="ot-empty-card">' + ico('sparkle') + '<h2>ساختار سازمان هنوز خالی است</h2><p>' + (can ? 'با «افزودن واحد» اولین معاونت را بسازید یا با «ساخت چندتایی» یک فهرست کامل را یک‌جا وارد کنید.' : 'هنوز ساختاری ثبت نشده است.') + '</p>' +
          (can ? '<div class="ot-empty-btns"><button class="ot-btn ot-primary" data-act="add">' + ico('plus') + '<span>افزودن معاونت</span></button><button class="ot-btn" data-act="bulk">' + ico('list') + '<span>ساخت چندتایی / نمونه</span></button></div>' : '') + '</div></div>' +
        '<div class="ot-zoombar" role="group" aria-label="بزرگ‌نمایی">' + tb('zoom-out', 'minus', 'کوچک‌نمایی (−)') + '<button class="ot-zl" data-act="zoom-100" id="ot-zl" title="۱۰۰٪ (0)">۱۰۰٪</button>' + tb('zoom-in', 'plus', 'بزرگ‌نمایی (+)') + '<span class="ot-sep"></span>' + tb('fit', 'fit', 'جا شدن در صفحه (F)') + tb('center-sel', 'focus', 'رفتن به واحد انتخاب‌شده') + tb('minimap', 'map', 'نمایش/پنهان‌کردن مینی‌مپ') + '</div>' +
        '<div class="ot-minimap" id="ot-minibox"><canvas id="ot-mini" width="220" height="140" aria-hidden="true"></canvas></div>' +
        '<div class="ot-hint" id="ot-hint" hidden></div>' +
      '</main>' +
      '<aside class="ot-panel" aria-label="جزئیات"><div class="ot-tabs" role="tablist">' +
        '<button role="tab" data-act="tab" data-v="people">' + ico('users') + '<span>افراد</span></button>' +
        '<button role="tab" data-act="tab" data-v="unit">' + ico('folder') + '<span>جزئیات واحد</span></button>' +
        '<button role="tab" data-act="tab" data-v="history">' + ico('history') + '<span>تاریخچه</span></button></div>' +
        '<div class="ot-pbody" id="ot-pbody"></div></aside>' +
    '</div>' +
    '<div class="ot-toasts" id="ot-toasts" role="status" aria-live="polite"></div>' +
    '<div class="ot-live ot-sr" id="ot-live" aria-live="polite"></div>' +
    '<div class="ot-layer" id="ot-layer"></div>' +
    '<div class="ot-busy" id="ot-busy" hidden><span class="ot-spin"></span></div>';
  E.world = $('#ot-world'); E.links = $('#ot-links'); E.cards = $('#ot-cards'); E.viewport = $('#ot-viewport');
  E.zoomLabel = $('#ot-zl'); E.mini = $('#ot-mini'); E.empty = $('#ot-empty'); E.layer = $('#ot-layer');
  E.q = $('#ot-q'); E.results = $('#ot-results'); E.pbody = $('#ot-pbody'); E.side = $('#ot-side');
}

function announce(msg) { var l = $('#ot-live'); if (l) { l.textContent = ''; setTimeout(function () { l.textContent = msg; }, 30); } }

/* ───────────── نوار کناری: آمار و هشدارها ───────────── */
function renderSide() {
  var st = I.stats, h = '';
  h += '<section class="ot-sec"><h2>نمای کلی</h2><div class="ot-stats">';
  [['units', 'واحد', st.units, 'folder', 'units'], ['deputies', 'معاونت', st.deputies, 'briefcase', 'deputy'], ['departments', 'اداره', st.departments, 'folder', 'department'],
   ['managers', 'مدیر', st.managers, 'crown', 'managers'], ['experts', 'کارشناس', st.experts, 'user', 'experts'], ['free', 'بدون واحد', st.free, 'users', 'free']].forEach(function (x) {
    h += '<button class="ot-stat" data-act="stat" data-v="' + x[4] + '"><span class="ot-stat-i">' + ico(x[3]) + '</span><b>' + fa(x[2]) + '</b><small>' + x[1] + '</small></button>';
  });
  h += '</div><p class="ot-sm">عمق درخت: <b>' + fa(I.maxDepth + 1) + '</b> سطح · کاربران فعال: <b>' + fa(st.active) + '</b></p></section>';
  h += '<section class="ot-sec"><h2>بررسی ساختار</h2>';
  if (!I.issues.length) { h += '<div class="ot-ok">' + ico('check') + '<span>مورد مشکوکی در ساختار پیدا نشد.</span></div>'; }
  else {
    h += '<ul class="ot-issues">';
    I.issues.forEach(function (it) {
      h += '<li><button class="ot-issue is-' + it.level + (S.hlLabel === it.key ? ' is-on' : '') + '" data-act="issue" data-v="' + it.key + '">' + ico(it.level === 'warn' ? 'alert' : 'info') +
        '<span><b>' + esc(it.title) + '</b><small>' + esc(it.hint) + '</small></span><em>' + fa(it.ids.length) + '</em></button></li>';
    });
    h += '</ul>';
  }
  if (st.free) { h += '<button class="ot-issue is-info" data-act="stat" data-v="free">' + ico('users') + '<span><b>کاربران بدون واحد</b><small>در پنل «افراد» ببینید و روی کارت‌ها بکشید.</small></span><em>' + fa(st.free) + '</em></button>'; }
  h += '</section>';
  h += '<section class="ot-sec"><h2>راهنمای رنگ‌ها</h2><ul class="ot-legend">' +
    '<li><i class="ot-sw ot-sw-ceo"></i>مدیرعامل</li><li><i class="ot-sw ot-sw-dep"></i>معاونت</li><li><i class="ot-sw ot-sw-dept"></i>اداره و زیرمجموعه‌ها</li>' +
    '<li>' + ico('shield') + 'ادمین اصلی</li><li>' + ico('alert') + 'بدون مدیر / مدیر غیرفعال</li></ul></section>';
  if (BOOT.canManage) {
    h += '<section class="ot-sec ot-tips"><h2>نکتهٔ سریع</h2><p>کاربر را از پنل «افراد» روی کارت بکشید و در ناحیهٔ «مدیر» یا «کارشناس» رها کنید. کارت یک واحد را روی واحد دیگر بکشید تا زیرمجموعه‌اش شود یا کنار هم‌ردیف‌ها رها کنید تا ترتیب عوض شود.</p></section>';
  }
  E.side.innerHTML = h;
  var sub = $('#ot-sub'); if (sub) { sub.textContent = fa(st.units) + ' واحد · ' + fa(st.active) + ' نفر'; }
}

/* ───────────── نان‌ریز (مسیر انتخاب / تمرکز) ───────────── */
function renderCrumbs() {
  var box = $('#ot-crumbs'); if (!box) { return; }
  var pieces = '';
  if (S.focus) {
    pieces += '<span class="ot-focus-tag">' + ico('focus') + 'تمرکز روی شاخه</span>' + pathOf(S.focus).map(function (u) { return '<button class="ot-crumb" data-act="select" data-id="' + u.id + '">' + esc(u.name) + '</button>'; }).join(ico('chevL', 'ot-sepi'));
    pieces += '<button class="ot-btn ot-sm-btn" data-act="unfocus">' + ico('x') + '<span>خروج از تمرکز</span></button>';
  } else if (S.sel) {
    pieces += pathOf(S.sel).map(function (u) { return '<button class="ot-crumb' + (u.id === S.sel ? ' is-cur' : '') + '" data-act="select" data-id="' + u.id + '">' + esc(u.name) + '</button>'; }).join(ico('chevL', 'ot-sepi'));
  }
  box.innerHTML = pieces; box.hidden = !pieces;
}

/* ───────────── پنل چپ: افراد / جزئیات / تاریخچه ───────────── */
var pLimit = 80;
function renderPanel() {
  $$('.ot-tabs [role=tab]').forEach(function (b) {
    var on = b.getAttribute('data-v') === S.tab;
    b.classList.toggle('is-on', on); b.setAttribute('aria-selected', on ? 'true' : 'false');
    if (b.getAttribute('data-v') === 'unit') { b.disabled = !S.sel; }
  });
  if (S.tab === 'unit' && !S.sel) { S.tab = 'people'; }
  E.pbody.innerHTML = S.tab === 'people' ? peopleHtml() : (S.tab === 'unit' ? unitPanelHtml() : historyHtml());
  E.pbody.setAttribute('data-tab', S.tab);
}

function userMatchesFilter(u) {
  var r = roleOf(u);
  switch (S.pf) {
    case 'free': return u.active && r.kind === 'free';
    case 'experts': return u.active && r.kind === 'expert';
    case 'managers': return u.active && r.kind === 'manager';
    case 'inactive': return !u.active;
    default: return u.active;
  }
}
function peopleHtml() {
  var all = S.data.users, counts = { free: 0, experts: 0, managers: 0, all: 0, inactive: 0 };
  all.forEach(function (u) {
    if (!u.active) { counts.inactive++; return; }
    counts.all++; var k = roleOf(u).kind; if (k === 'free') { counts.free++; } else if (k === 'expert') { counts.experts++; } else { counts.managers++; }
  });
  var q = norm(S.pq), list = all.filter(function (u) { return userMatchesFilter(u) && (!q || norm(u.name + ' ' + u.username + ' ' + u.code).indexOf(q) >= 0); });
  var h = '<div class="ot-pfilters" role="group" aria-label="فیلتر افراد">';
  [['free', 'بدون واحد'], ['experts', 'کارشناسان'], ['managers', 'مدیران'], ['all', 'همه'], ['inactive', 'غیرفعال']].forEach(function (f) {
    h += '<button class="ot-chip' + (S.pf === f[0] ? ' is-on' : '') + '" data-act="pf" data-v="' + f[0] + '">' + f[1] + ' <em>' + fa(counts[f[0]]) + '</em></button>';
  });
  h += '</div><div class="ot-psearch">' + ico('search') + '<input id="ot-pq" type="search" placeholder="جستجو در افراد…" value="' + esc(S.pq) + '" autocomplete="off"></div>';
  if (BOOT.canManage && S.pf !== 'inactive') { h += '<p class="ot-dragnote">' + ico('grip') + 'برای انتصاب، فرد را روی کارت یک واحد بکشید.</p>'; }
  h += '<ul class="ot-ulist">';
  if (!list.length) { h += '<li class="ot-none">موردی پیدا نشد.</li>'; }
  list.slice(0, pLimit).forEach(function (u) { h += userRowHtml(u, true); });
  h += '</ul>';
  if (list.length > pLimit) { h += '<button class="ot-btn ot-more-btn" data-act="more-people">نمایش ' + fa(Math.min(80, list.length - pLimit)) + ' نفر بعدی (از ' + fa(list.length - pLimit) + ' باقی‌مانده)</button>'; }
  return h;
}
function srcLabel(u) { return u.source === 'ldap' ? 'دامینی' : 'محلی'; }
function userRowHtml(u, draggable) {
  var r = roleOf(u), tag = r.kind === 'manager' ? '<span class="ot-tag is-mgr">' + esc(r.label) + '</span>' : (r.kind === 'expert' ? '<span class="ot-tag">کارشناس</span>' : '<span class="ot-tag is-free">بدون واحد</span>');
  var can = BOOT.canManage && draggable && u.active;
  return '<li class="ot-urow' + (can ? ' is-drag' : '') + (S.search.users.has(u.id) ? ' is-hit' : '') + '" data-uid="' + u.id + '"' + (can ? ' draggable="true"' : '') + '>' +
    avatar(u, 'md') + '<div class="ot-urow-t"><b>' + esc(u.name) + '</b><small>' + (r.unit ? esc(r.unit.name) : esc(u.username)) + ' · ' + srcLabel(u) + '</small></div>' + tag +
    (r.unit ? '<button class="ot-mini" data-act="goto-unit" data-id="' + r.unit.id + '" title="نمایش واحد در درخت">' + ico('focus') + '</button>' : '') + '</li>';
}

function unitPanelHtml() {
  var u = unitById(S.sel); if (!u) { return '<p class="ot-none">واحدی انتخاب نشده است.</p>'; }
  var T = TYPES[u.type], can = BOOT.canManage, ms = managersOf(u), mem = membersOf(u.id), kids = kidsOf(u.id), total = I.total.get(u.id) || 0;
  var h = '<div class="ot-ud-head ' + typeClass(u) + '"><span class="ot-tico">' + ico(T.icon) + '</span><div><h3>' + esc(u.name) + '</h3><small>' + esc(T.label) + (u.code ? ' · کد ' + esc(u.code) : '') + '</small></div>' +
    (u.primaryAdmin ? '<span class="ot-badge ot-b-admin" title="ادمین اصلی">' + ico('shield') + '</span>' : '') + '</div>';
  h += '<nav class="ot-path" aria-label="مسیر">' + pathOf(u.id).map(function (p) { return '<button data-act="select" data-id="' + p.id + '">' + esc(p.name) + '</button>'; }).join(ico('chevL', 'ot-sepi')) + '</nav>';
  h += '<div class="ot-kpis"><div><b>' + fa(ms.length) + '</b><small>مدیر</small></div><div><b>' + fa(mem.length) + '</b><small>کارشناس مستقیم</small></div><div><b>' + fa(kids.length) + '</b><small>زیرواحد</small></div><div><b>' + fa(total) + '</b><small>کل نفرات شاخه</small></div></div>';
  h += '<div class="ot-acts">';
  if (can) {
    h += '<button class="ot-btn" data-act="edit" data-id="' + u.id + '">' + ico('edit') + '<span>ویرایش</span></button><button class="ot-btn" data-act="add" data-id="' + u.id + '">' + ico('plus') + '<span>زیرواحد</span></button>' +
      (u.type !== 'ceo' ? '<button class="ot-btn" data-act="move" data-id="' + u.id + '">' + ico('move') + '<span>انتقال</span></button>' : '');
  }
  h += '<button class="ot-btn" data-act="focus-branch" data-id="' + u.id + '">' + ico('focus') + '<span>تمرکز</span></button>';
  if (can && u.type !== 'ceo') { h += '<button class="ot-btn is-danger" data-act="delete" data-id="' + u.id + '">' + ico('trash') + '<span>حذف</span></button>'; }
  h += '</div>';
  h += '<section class="ot-ds"><header><h4>' + ico('crown') + ' مدیران</h4>' + (can ? '<button class="ot-link-btn" data-act="managers" data-id="' + u.id + '">تعیین / ویرایش</button>' : '') + '</header>';
  if (!ms.length) { h += '<p class="ot-none">مدیری تعیین نشده است.</p>'; }
  else { h += '<ul class="ot-ulist">' + ms.map(function (m, i) { return '<li class="ot-urow" data-uid="' + m.id + '">' + avatar(m, 'md') + '<div class="ot-urow-t"><b>' + esc(m.name) + '</b><small>' + (i === 0 ? 'مدیر اصلی' : 'مدیر') + (m.active ? '' : ' · غیرفعال') + (can && m.email ? ' · ' + esc(m.email) : '') + '</small></div></li>'; }).join('') + '</ul>'; }
  h += '</section>';
  if (u.type !== 'ceo') {
    h += '<section class="ot-ds"><header><h4>' + ico('users') + ' کارشناسان <em>' + fa(mem.length) + '</em></h4>' + (can ? '<button class="ot-link-btn" data-act="members" data-id="' + u.id + '">افزودن / عزل</button>' : '') + '</header>';
    if (!mem.length) { h += '<p class="ot-none">کارشناسی ثبت نشده است.</p>'; }
    else { h += '<ul class="ot-ulist ot-scroll">' + mem.map(function (m) { return userRowHtml(m, true); }).join('') + '</ul>'; }
    h += '</section>';
  }
  if (kids.length) {
    h += '<section class="ot-ds"><header><h4>' + ico('folder') + ' زیرواحدها <em>' + fa(kids.length) + '</em></h4></header><ul class="ot-sublist">' +
      kids.map(function (k) { return '<li><button data-act="select" data-id="' + k.id + '"><span class="ot-dot ' + typeClass(k) + '"></span><b>' + esc(k.name) + '</b><small>' + fa(I.total.get(k.id) || 0) + ' نفر</small></button></li>'; }).join('') + '</ul></section>';
  }
  var hist = (S.data.history || []).filter(function (e) { return e.unitIds && e.unitIds.indexOf(u.id) >= 0; }).slice(0, 6);
  h += '<section class="ot-ds"><header><h4>' + ico('history') + ' آخرین تغییرات</h4><button class="ot-link-btn" data-act="tab" data-v="history">همه</button></header>' + (hist.length ? '<ul class="ot-hist">' + hist.map(histRow).join('') + '</ul>' : '<p class="ot-none">تغییری ثبت نشده است.</p>') + '</section>';
  return h;
}

var HIST = {
  org_unit_saved: 'ثبت/ویرایش واحد', org_unit_moved: 'جابه‌جایی واحد', org_unit_deleted: 'حذف واحد', org_managers_set: 'تعیین مدیران',
  org_units_bulk_created: 'ساخت چندتایی واحد', org_manager_assigned: 'تعیین مدیر', org_manager_removed: 'عزل مدیر', org_experts_removed: 'عزل کارشناسان',
  org_users_assigned: 'افزودن کارشناسان', org_structure_reset: 'پاک‌سازی کل ساختار', org_ceo_saved: 'تعیین مدیرعامل', user_org_updated: 'تغییر سازمانی کاربر',
  org_action_undone: 'بازگشت عملیات', org_action_redone: 'انجام دوبارهٔ عملیات'
};
function histRow(e) {
  var u = e.unitIds && e.unitIds.length ? unitById(e.unitIds[0]) : null, name = e.name || (u ? u.name : '');
  var extra = e.count ? ' (' + fa(e.count) + ' مورد)' : (e.label ? ': ' + e.label : '');
  var who = (e.userIds || []).slice(0, 2).map(function (id) { var x = I.user.get(id); return x ? x.name : ''; }).filter(Boolean).join('، ');
  return '<li><i class="ot-hdot"></i><div><b>' + esc(HIST[e.code] || e.code) + (name ? ' «' + esc(name) + '»' : '') + esc(extra) + '</b>' + (who ? '<small>' + esc(who) + '</small>' : '') + '<small>' + esc(e.who) + ' · ' + esc(e.at) + '</small></div></li>';
}
function historyHtml() {
  var rows = S.data.history || [];
  return '<p class="ot-sm">آخرین تغییرات ساختار سازمانی (حداکثر ' + fa(rows.length) + ' مورد)</p>' + (rows.length ? '<ul class="ot-hist">' + rows.map(histRow).join('') + '</ul>' : '<p class="ot-none">تاریخچه‌ای ثبت نشده است.</p>');
}

/* ───────────── اعلان‌ها (Toast) ───────────── */
function toast(msg, o) {
  o = o || {};
  var box = $('#ot-toasts'), el = document.createElement('div');
  el.className = 'ot-toast is-' + (o.type || 'success');
  el.innerHTML = ico(o.type === 'error' ? 'alert' : (o.type === 'info' ? 'info' : 'check')) + '<span>' + esc(msg) + '</span>' +
    (o.undo && BOOT.canManage && S.data.undo > 0 ? '<button class="ot-toast-act" data-act="undo">بازگشت</button>' : '') + '<button class="ot-toast-x" aria-label="بستن">' + ico('x') + '</button>';
  box.appendChild(el);
  var close = function () { el.classList.add('is-out'); setTimeout(function () { if (el.parentNode) { el.parentNode.removeChild(el); } }, 220); };
  el.querySelector('.ot-toast-x').addEventListener('click', close);
  var act = el.querySelector('.ot-toast-act'); if (act) { act.addEventListener('click', function () { close(); doUndo(); }); }
  setTimeout(close, o.ms || (o.type === 'error' ? 9000 : 6000));
  announce(msg);
  while (box.children.length > 4) { box.removeChild(box.firstChild); }
}

/* ───────────── پنجره‌های گفت‌وگو ───────────── */
var modalStack = [];
function openModal(o) {
  var id = 'otm' + stamp() + Math.floor(Math.random() * 999), wrap = document.createElement('div');
  wrap.className = 'ot-modal-wrap';
  wrap.innerHTML = '<div class="ot-backdrop"></div><section class="ot-modal ot-m-' + (o.size || 'md') + '" role="dialog" aria-modal="true" aria-labelledby="' + id + '"><header class="ot-modal-head"><h2 id="' + id + '">' + (o.icon ? ico(o.icon) : '') + esc(o.title) + '</h2><button class="ot-ibtn" data-close aria-label="بستن">' + ico('x') + '</button></header>' +
    '<div class="ot-modal-body"></div><footer class="ot-modal-foot"></footer></section>';
  var body = wrap.querySelector('.ot-modal-body'), foot = wrap.querySelector('.ot-modal-foot'), prev = document.activeElement;
  if (typeof o.body === 'string') { body.innerHTML = o.body; } else if (o.body) { body.appendChild(o.body); }
  var ctl = { el: wrap, body: body, foot: foot, closed: false };
  ctl.close = function (result) {
    if (ctl.closed) { return; } ctl.closed = true;
    wrap.classList.add('is-out');
    setTimeout(function () { if (wrap.parentNode) { wrap.parentNode.removeChild(wrap); } }, 160);
    modalStack = modalStack.filter(function (m) { return m !== ctl; });
    if (prev && prev.focus) { try { prev.focus({ preventScroll: true }); } catch (e) { /* ignore */ } }
    if (o.onClose) { o.onClose(result); }
  };
  (o.actions || []).forEach(function (a) {
    var b = document.createElement('button');
    b.className = 'ot-btn' + (a.kind ? ' ot-' + a.kind : ''); b.type = 'button';
    b.innerHTML = (a.icon ? ico(a.icon) : '') + '<span>' + esc(a.label) + '</span>';
    if (a.id) { b.setAttribute('data-id', a.id); }
    b.addEventListener('click', function () { if (b.disabled) { return; } var r = a.onClick ? a.onClick(ctl, b) : true; if (r !== false && a.close !== false) { ctl.close(a.value); } });
    foot.appendChild(b);
  });
  if (!(o.actions || []).length) { foot.hidden = true; }
  wrap.addEventListener('mousedown', function (e) { if (e.target.classList.contains('ot-backdrop') && !o.persist) { ctl.close(); } });
  wrap.querySelector('[data-close]').addEventListener('click', function () { ctl.close(); });
  E.layer.appendChild(wrap); modalStack.push(ctl);
  setTimeout(function () {
    var f = wrap.querySelector('[data-autofocus]') || wrap.querySelector('input:not([type=checkbox]):not([type=hidden]),textarea,select') || wrap.querySelector('.ot-modal-foot .ot-primary') || wrap.querySelector('button');
    if (f) { f.focus(); if (f.select && f.tagName === 'INPUT') { f.select(); } }
  }, 30);
  return ctl;
}
function trapTab(e) {
  var top = modalStack[modalStack.length - 1]; if (!top) { return false; }
  var f = $$('button:not([disabled]),input:not([disabled]),select:not([disabled]),textarea:not([disabled]),[tabindex]:not([tabindex="-1"])', top.el).filter(function (x) { return x.offsetParent !== null; });
  if (!f.length) { return true; }
  var first = f[0], last = f[f.length - 1];
  if (e.shiftKey && document.activeElement === first) { e.preventDefault(); last.focus(); }
  else if (!e.shiftKey && document.activeElement === last) { e.preventDefault(); first.focus(); }
  return true;
}
function confirmBox(o) {
  return new Promise(function (resolve) {
    var done = false;
    openModal({
      title: o.title, icon: o.danger ? 'alert' : 'help', size: 'sm', body: '<div class="ot-confirm">' + (o.html || '<p>' + esc(o.message) + '</p>') + '</div>',
      onClose: function () { if (!done) { resolve(false); } },
      actions: [
        { label: o.ok || 'تأیید', kind: o.danger ? 'danger' : 'primary', onClick: function () { done = true; resolve(true); } },
        { label: 'انصراف', onClick: function () { done = true; resolve(false); } }
      ]
    });
  });
}

/* ───────────── منوی بازشو ───────────── */
var menuEl = null;
function closeMenu() { if (menuEl && menuEl.parentNode) { menuEl.parentNode.removeChild(menuEl); } menuEl = null; }
function openMenu(x, y, items, anchor) {
  closeMenu();
  var m = document.createElement('div'); m.className = 'ot-menu'; m.setAttribute('role', 'menu');
  m.innerHTML = items.map(function (it, i) {
    if (it.sep) { return '<div class="ot-menu-sep" role="separator"></div>'; }
    return '<button role="menuitem" class="ot-mi' + (it.danger ? ' is-danger' : '') + '" data-i="' + i + '"' + (it.disabled ? ' disabled' : '') + '>' + (it.icon ? ico(it.icon) : '') + '<span>' + esc(it.label) + '</span>' + (it.hint ? '<kbd>' + esc(it.hint) + '</kbd>' : '') + '</button>';
  }).join('');
  E.layer.appendChild(m); menuEl = m;
  var r = m.getBoundingClientRect(), vw = window.innerWidth, vh = window.innerHeight;
  var left = x, top = y;
  if (left + r.width > vw - 8) { left = vw - r.width - 8; }
  if (left < 8) { left = 8; }
  if (top + r.height > vh - 8) { top = Math.max(8, vh - r.height - 8); }
  m.style.left = left + 'px'; m.style.top = top + 'px';
  m.addEventListener('click', function (e) {
    var b = e.target.closest('.ot-mi'); if (!b || b.disabled) { return; }
    var it = items[+b.getAttribute('data-i')]; closeMenu(); if (it && it.run) { it.run(); }
  });
  m.addEventListener('keydown', function (e) {
    var bs = $$('.ot-mi:not([disabled])', m), i = bs.indexOf(document.activeElement);
    if (e.key === 'ArrowDown') { e.preventDefault(); bs[(i + 1) % bs.length].focus(); }
    else if (e.key === 'ArrowUp') { e.preventDefault(); bs[(i - 1 + bs.length) % bs.length].focus(); }
    else if (e.key === 'Escape' || e.key === 'Tab') { e.preventDefault(); closeMenu(); if (anchor && anchor.focus) { anchor.focus(); } }
  });
  var first = m.querySelector('.ot-mi:not([disabled])'); if (first) { first.focus(); }
}

function unitMenuItems(u) {
  var can = BOOT.canManage, items = [];
  items.push({ label: 'نمایش جزئیات', icon: 'info', run: function () { select(u.id, { tab: true, center: true }); } });
  items.push({ label: 'تمرکز روی این شاخه', icon: 'focus', run: function () { focusBranch(u.id); } });
  if (kidsOf(u.id).length) {
    items.push({ label: isClosed(u.id) ? 'باز کردن زیرشاخه‌ها' : 'بستن زیرشاخه‌ها', icon: isClosed(u.id) ? 'expandAll' : 'collapseAll', run: function () { toggleNode(u.id); } });
    items.push({ label: 'باز کردن همهٔ زیرشاخه‌ها', icon: 'expandAll', run: function () { expandBranch(u.id, true); } });
  }
  items.push({ label: 'کپی مسیر کامل', icon: 'copy', run: function () { copyText(pathNames(u.id).join(' ‹ ')); } });
  if (can) {
    items.push({ sep: true });
    items.push({ label: 'ویرایش مشخصات', icon: 'edit', hint: 'F2', run: function () { openUnitForm(u.id); } });
    items.push({ label: 'تعیین / ویرایش مدیران', icon: 'crown', run: function () { openManagersDialog(u.id); } });
    if (u.type !== 'ceo') { items.push({ label: 'مدیریت کارشناسان', icon: 'users', run: function () { openMembersDialog(u.id); } }); }
    items.push({ label: 'افزودن زیرواحد', icon: 'plus', run: function () { openUnitForm(0, u.id); } });
    items.push({ label: 'ساخت چندتایی زیرواحد', icon: 'list', run: function () { openBulkDialog(u.id); } });
    if (u.type !== 'ceo') {
      items.push({ label: 'انتقال به…', icon: 'move', run: function () { openMoveDialog(u.id); } });
      items.push({ sep: true });
      items.push({ label: 'حذف واحد', icon: 'trash', hint: 'Del', danger: true, run: function () { openDeleteDialog(u.id); } });
    }
  }
  return items;
}
function copyText(t) {
  var done = function () { toast('کپی شد: ' + t, { type: 'info', ms: 2500 }); };
  if (navigator.clipboard && navigator.clipboard.writeText) { navigator.clipboard.writeText(t).then(done, function () { toast('کپی انجام نشد.', { type: 'error' }); }); return; }
  var ta = document.createElement('textarea'); ta.value = t; ta.style.position = 'fixed'; ta.style.opacity = '0'; document.body.appendChild(ta); ta.select();
  try { document.execCommand('copy'); done(); } catch (e) { toast('کپی انجام نشد.', { type: 'error' }); }
  document.body.removeChild(ta);
}

/* ───────────── انتخاب، باز/بسته‌کردن، تمرکز ───────────── */
function reveal(id) {
  var changed = false, u = unitById(id), g = 0;
  if (S.focus && !isDescendant(id, S.focus)) { S.focus = 0; changed = true; }
  u = u && u.parentId ? unitById(u.parentId) : null;
  while (u && g++ < 60) { if (S.collapsed.has(u.id) || S.autoOpen.has(u.id)) { S.collapsed.delete(u.id); S.autoOpen.delete(u.id); changed = true; } u = u.parentId ? unitById(u.parentId) : null; }
  if (changed) { saveView(); render({ relayoutFade: true, noEnter: true }); }
  return changed;
}
function select(id, o) {
  o = o || {};
  S.sel = id || 0;
  if (id) { reveal(id); if (!o.keepTab) { S.tab = 'unit'; } } else if (S.tab === 'unit') { S.tab = 'people'; }
  paintState(); renderPanel(); renderCrumbs(); drawMinimap();
  if (id) {
    if (o.center) { centerOn(id, o.zoom || null, true); } else { ensureVisible(id); }
    var el = cardEls.get(id);
    if (el && o.focus) { el.focus({ preventScroll: true }); }
    if (o.pulse) { pulse(id); }
  }
}
function pulse(id) { var el = cardEls.get(id); if (!el) { return; } el.classList.remove('ot-pulse'); void el.offsetWidth; el.classList.add('ot-pulse'); setTimeout(function () { el.classList.remove('ot-pulse'); }, 1600); }

function withAnchor(id, fn) {
  var n0 = S.layout && S.layout.map.get(id), before = n0 ? { x: n0.x * S.cam.k + S.cam.x, y: n0.y * S.cam.k + S.cam.y } : null;
  fn();
  var n1 = S.layout && S.layout.map.get(id);
  if (before && n1) { S.cam.x = before.x - n1.x * S.cam.k; S.cam.y = before.y - n1.y * S.cam.k; applyCam(true); }
}
function toggleNode(id) {
  if (!kidsOf(id).length) { return; }
  withAnchor(id, function () {
    if (isClosed(id)) { S.collapsed.delete(id); S.autoOpen.delete(id); } else { S.collapsed.add(id); S.autoOpen.delete(id); }
    saveView(); render({ relayoutFade: true, noEnter: false });
  });
  announce(isClosed(id) ? 'شاخه بسته شد' : 'شاخه باز شد');
}
function expandBranch(id, open) {
  withAnchor(id, function () {
    subtreeIds(id).forEach(function (x) { if (open) { S.collapsed.delete(x); S.autoOpen.delete(x); } else if (x !== id && kidsOf(x).length) { S.collapsed.add(x); } });
    saveView(); render({ relayoutFade: true });
  });
}
function setLevels(n) {            /* نمایش تا سطح n (۱ = فقط مدیرعامل) */
  S.collapsed.clear(); S.autoOpen.clear();
  S.data.units.forEach(function (u) { if ((I.depth.get(u.id) || 0) >= n - 1 && kidsOf(u.id).length) { S.collapsed.add(u.id); } });
  saveView(); render({ relayoutFade: true }); fitView(true);
}
function focusBranch(id) { S.focus = id; render({ relayoutFade: true, noEnter: true }); fitView(true); select(id, { keepTab: true }); }
function unfocus() { var id = S.focus; S.focus = 0; render({ relayoutFade: true, noEnter: true }); fitView(true); if (id) { pulse(id); } }

/* ───────────── جستجو ───────────── */
function runSearch(q) {
  var s = S.search; s.q = q.trim(); s.res = []; s.i = -1; s.units = new Set(); s.users = new Set(); s.trail = new Set(); S.autoOpen = new Set();
  if (!s.q) { finishSearch(); return; }
  var tokens = norm(s.q).split(/\s+/).filter(Boolean), all = [];
  I.search.forEach(function (e) {
    var ok = tokens.every(function (t) { return e.text.indexOf(t) >= 0; });
    if (!ok) { return; }
    var score = (e.kind === 'unit' ? 0 : 1) + (norm(e.title).indexOf(tokens[0]) === 0 ? -2 : 0);
    all.push({ e: e, score: score });
  });
  all.sort(function (a, b) { return a.score - b.score || cmpFa(a.e.title, b.e.title); });
  s.res = all.map(function (x) { return x.e; });
  s.res.forEach(function (e) {
    var uid = 0;
    if (e.kind === 'unit') { s.units.add(e.id); uid = e.id; }
    else { s.users.add(e.id); var us = I.user.get(e.id), mu = I.managed.get(e.id); uid = mu || (us && us.unitId) || 0; if (uid && I.unit.has(uid)) { s.units.add(uid); } }
    var u = uid ? unitById(uid) : null, g = 0;
    while (u && g++ < 60) { s.trail.add(u.id); if (u.id !== uid) { S.autoOpen.add(u.id); } u = u.parentId ? unitById(u.parentId) : null; }
  });
  finishSearch();
}
function finishSearch() {
  var s = S.search, cnt = $('#ot-qcount');
  $$('.ot-ibtn[data-act^=q-]').forEach(function (b) { b.hidden = !s.q; });
  $('#ot-qkbd').hidden = !!s.q;
  cnt.textContent = s.q ? (s.res.length ? fa(s.res.length) + ' نتیجه' : 'نتیجه‌ای نیست') : '';
  render({ relayoutFade: true, noEnter: true });
  renderResults();
  if (s.q && s.res.length) { announce(fa(s.res.length) + ' نتیجه یافت شد'); }
}
function renderResults() {
  var s = S.search, box = E.results;
  if (!s.q) { box.hidden = true; box.innerHTML = ''; return; }
  var top = s.res.slice(0, 12);
  box.innerHTML = top.length ? top.map(function (e, i) {
    return '<button class="ot-res' + (i === s.i ? ' is-on' : '') + '" role="option" data-act="res" data-i="' + i + '">' + ico(e.kind === 'unit' ? 'folder' : 'user') + '<span><b>' + esc(e.title) + '</b><small>' + esc(e.sub || '') + '</small></span></button>';
  }).join('') + (s.res.length > 12 ? '<div class="ot-res-more">و ' + fa(s.res.length - 12) + ' نتیجهٔ دیگر — همه در درخت مشخص شده‌اند.</div>' : '') : '<div class="ot-res-more">موردی پیدا نشد.</div>';
  box.hidden = false;
}
function gotoResult(i) {
  var s = S.search; if (!s.res.length) { return; }
  s.i = (i + s.res.length) % s.res.length;
  var e = s.res[s.i];
  var uid = e.kind === 'unit' ? e.id : (I.managed.get(e.id) || (I.user.get(e.id) || {}).unitId || 0);
  renderResults();
  if (uid && I.unit.has(uid)) { select(uid, { center: true, pulse: true, zoom: Math.max(S.cam.k, 0.85) }); }
  else if (e.kind === 'user') { S.pf = 'free'; S.pq = e.title; S.tab = 'people'; renderPanel(); toast('«' + e.title + '» به واحدی وصل نیست.', { type: 'info' }); }
}
function clearSearch() { E.q.value = ''; runSearch(''); }

/* ───────────── ارسال عملیات به سرور (بدون بارگذاری مجدد) ───────────── */
function setBusy(on) { S.busy = !!on; $('#ot-busy').hidden = !on; APP.classList.toggle('is-busy', !!on); }
function submit(action, fields, o) {
  o = o || {};
  if (S.busy) { return Promise.resolve(false); }
  setBusy(true);
  var fd = new FormData();
  fd.append('csrf', BOOT.csrf); fd.append('action', action);
  Object.keys(fields || {}).forEach(function (k) {
    var v = fields[k];
    if (Array.isArray(v)) { v.forEach(function (x) { fd.append(k + '[]', x); }); } else if (v !== undefined && v !== null) { fd.append(k, v); }
  });
  var before = new Set(S.data.units.map(function (u) { return u.id; }));
  return fetch(CFG.endpoint, { method: 'POST', body: fd, credentials: 'same-origin', headers: { 'Accept': 'application/json' } })
    .then(function (r) { return r.text(); })
    .then(function (txt) {
      var j = null; try { j = JSON.parse(txt); } catch (e) { j = null; }
      if (!j || !j.units) { window.location.reload(); return false; }
      applyPayload(j, before, o); return true;
    })
    .catch(function () { toast('ارتباط با سرور برقرار نشد. دوباره تلاش کنید.', { type: 'error' }); return false; })
    .then(function (ok) { setBusy(false); return ok; });
}
function applyPayload(j, before, o) {
  var flashes = j.flash || [];
  S.data = j; BOOT.csrf = j.csrf || BOOT.csrf; BOOT.canManage = !!j.canManage;
  rebuild();
  var added = j.units.filter(function (u) { return !before.has(u.id); });
  S.search.units = new Set(); S.search.users = new Set(); S.search.trail = new Set(); S.autoOpen = new Set();
  if (S.search.q) { var q = S.search.q; runSearch(q); }
  render({ relayoutFade: true }); renderSide(); updateToolbar();
  var target = o.select || (added.length ? added[0].id : 0);
  if (o.select === 0) { target = 0; }
  if (target && I.unit.has(target)) { reveal(target); select(target, { center: !!added.length || !!o.center, pulse: true, keepTab: o.keepTab }); }
  else { renderPanel(); paintState(); }
  flashes.forEach(function (f) {
    var type = (f.type === 'danger' || f.type === 'error') ? 'error' : (f.type === 'warning' ? 'info' : 'success');
    toast(f.message, { type: type, undo: type === 'success' });
  });
}
function doUndo() { if (S.data.undo > 0) { submit('org_undo', {}, { center: true }); } }
function doRedo() { if (S.data.redo > 0) { submit('org_redo', {}, { center: true }); } }

function updateToolbar() {
  var d = S.data, u = $('[data-act=undo]'), r = $('[data-act=redo]');
  if (u) { u.disabled = !(d.undo > 0); u.title = d.undo > 0 ? 'بازگشت: ' + (d.undoLabel || '') + ' (Ctrl+Z)' : 'چیزی برای بازگشت نیست'; }
  if (r) { r.disabled = !(d.redo > 0); r.title = d.redo > 0 ? 'انجام دوباره: ' + (d.redoLabel || '') + ' (Ctrl+Shift+Z)' : 'چیزی برای انجام دوباره نیست'; }
  var o = $('[data-act=orient]'); if (o) { o.innerHTML = ico(S.view.orient === 'h' ? 'treeH' : 'treeV'); o.classList.toggle('is-on', S.view.orient === 'h'); o.title = S.view.orient === 'h' ? 'نمایش عمودی' : 'نمایش افقی'; }
  var de = $('[data-act=density]'); if (de) { de.classList.toggle('is-on', S.view.density === 'compact'); de.title = S.view.density === 'compact' ? 'نمای کامل کارت‌ها' : 'نمای فشردهٔ کارت‌ها'; }
  var th = $('[data-act=theme]'); if (th) { var dark = APP.getAttribute('data-theme') === 'dark'; th.innerHTML = ico(dark ? 'moon' : 'sun'); th.title = 'تم: ' + (S.view.theme === 'auto' ? 'خودکار' : (S.view.theme === 'dark' ? 'تیره' : 'روشن')) + ' (برای تغییر کلیک کنید)'; }
  var mm = $('[data-act=minimap]'); if (mm) { mm.classList.toggle('is-on', S.view.minimap); }
  var sd = $('[data-act=side]'); if (sd) { sd.classList.toggle('is-on', S.view.side); }
  var pn = $('[data-act=panel]'); if (pn) { pn.classList.toggle('is-on', S.view.panel); }
  $('#ot-minibox').hidden = !S.view.minimap;
  APP.classList.toggle('is-side-off', !S.view.side); APP.classList.toggle('is-panel-off', !S.view.panel);
}
function applyTheme() {
  var t = S.view.theme, dark = t === 'dark' || (t === 'auto' && window.matchMedia && window.matchMedia('(prefers-color-scheme: dark)').matches);
  APP.setAttribute('data-theme', dark ? 'dark' : 'light'); updateToolbar(); drawMinimap();
}

/* ───────────── ابزار فرم‌ها ───────────── */
function parentOptions(excludeId, selectedId) {
  var excl = excludeId ? new Set(subtreeIds(excludeId)) : new Set(), out = '';
  function walk(u, d) {
    if (excl.has(u.id)) { return; }
    out += '<option value="' + u.id + '"' + (u.id === selectedId ? ' selected' : '') + '>' + new Array(d + 1).join('\u2003') + (d ? '↳ ' : '') + esc(u.name) + ' (' + TYPES[u.type].label + ')</option>';
    kidsOf(u.id).forEach(function (k) { walk(k, d + 1); });
  }
  if (I.root) { walk(I.root, 0); }
  return out;
}
function field(label, inner, hint) { return '<label class="ot-f"><span>' + label + '</span>' + inner + (hint ? '<small>' + hint + '</small>' : '') + '</label>'; }

/* ───────────── فرم ساخت/ویرایش واحد ───────────── */
function openUnitForm(unitId, parentId) {
  var edit = unitId ? unitById(unitId) : null, isCeo = edit && edit.type === 'ceo';
  var par = parentId || (edit ? edit.parentId : (S.sel || (I.root && I.root.id) || 0));
  var body = '<div class="ot-form">' +
    field('نام واحد <i>*</i>', '<input id="f-name" maxlength="190" value="' + esc(edit ? edit.name : '') + '" data-autofocus placeholder="مثلاً: معاونت فناوری اطلاعات">') +
    '<div class="ot-f2">' + field('کد واحد (اختیاری)', '<input id="f-code" maxlength="60" value="' + esc(edit ? edit.code : '') + '" placeholder="مثلاً: IT-01">') +
    (isCeo ? '' : field('والد (محل در درخت)', '<select id="f-parent">' + parentOptions(edit ? edit.id : 0, par) + '</select>')) + '</div>' +
    '<p class="ot-note" id="f-type"></p>' +
    (isCeo ? '' : '<label class="ot-check"><input type="checkbox" id="f-admin"' + (edit && edit.primaryAdmin ? ' checked' : '') + '><span><b>این واحد «ادمین اصلی» است</b><small>مدیران این واحد نقش ادمین اصلی سامانه را می‌گیرند. با برداشتن این گزینه، نقش کاربران قبلی خودکار گرفته نمی‌شود؛ از صفحهٔ کاربران بررسی کنید.</small></span></label>') +
    '<p class="ot-err" id="f-err" hidden></p></div>';
  var m = openModal({
    title: edit ? 'ویرایش «' + edit.name + '»' : 'افزودن واحد جدید', icon: edit ? 'edit' : 'plus', body: body,
    actions: [
      { label: edit ? 'ذخیره تغییرات' : 'ساخت واحد', kind: 'primary', icon: 'check', onClick: function () { return save(); }, close: false },
      { label: 'انصراف' }
    ]
  });
  function typeNote() {
    var sel = $('#f-parent', m.el), p = sel ? unitById(+sel.value) : (edit ? unitById(edit.parentId) : null), t = isCeo ? 'ceo' : suggestedType(p), note = $('#f-type', m.el);
    if (!note) { return; }
    var txt = 'نوع واحد: <b>' + TYPES[t].label + '</b>' + (t === 'deputy' ? ' (زیر مدیرعامل؛ در فهرست معاونت‌های درخواست‌کننده می‌آید)' : '');
    if (edit && !isCeo && edit.type !== t) { txt += '<br><span class="ot-warn-t">⚠ با این جابه‌جایی نوع واحد از «' + TYPES[edit.type].label + '» به «' + TYPES[t].label + '» تغییر می‌کند.</span>'; }
    note.innerHTML = txt;
  }
  typeNote(); var ps = $('#f-parent', m.el); if (ps) { ps.addEventListener('change', typeNote); }
  m.el.addEventListener('keydown', function (e) { if (e.key === 'Enter' && e.target.tagName === 'INPUT' && e.target.type !== 'checkbox') { e.preventDefault(); save(); } });
  function save() {
    var name = $('#f-name', m.el).value.trim(), err = $('#f-err', m.el);
    if (!name) { err.textContent = 'نام واحد را وارد کنید.'; err.hidden = false; $('#f-name', m.el).focus(); return false; }
    var f = { unit_name: name, unit_code: $('#f-code', m.el).value.trim() }, adm = $('#f-admin', m.el), sel = $('#f-parent', m.el);
    if (sel) { f.parent_id = sel.value; }
    if (adm) { f.is_primary_admin = adm.checked ? '1' : '0'; }
    if (edit) { f.unit_id = edit.id; }
    var go = function () { m.close(); submit(edit ? 'org_update_unit' : 'org_create_unit', f, edit ? { select: edit.id } : {}); };
    if (adm && adm.checked && !(edit && edit.primaryAdmin)) {
      confirmBox({ title: 'تأیید ادمین اصلی', danger: true, ok: 'بله، ادمین اصلی شود', html: '<p>مدیران «' + esc(name) + '» نقش <b>ادمین اصلی</b> سامانه را می‌گیرند و به همهٔ بخش‌ها دسترسی خواهند داشت. ادامه می‌دهید؟</p>' }).then(function (ok) { if (ok) { go(); } });
      return false;
    }
    go(); return false;
  }
}

/* ───────────── انتخاب کاربر (مشترک) ───────────── */
function pickUsers(o) {
  var sel = new Set(o.selected || []), q = '', filterKey = o.filters ? o.filters[0][0] : 'all';
  var body = document.createElement('div'); body.className = 'ot-picker';
  var m = openModal({
    title: o.title, icon: 'userPlus', size: 'md', body: body,
    actions: [
      { label: o.confirm || 'تأیید', kind: 'primary', icon: 'check', onClick: function () { if (!sel.size) { return false; } o.onPick(Array.from(sel)); }, id: 'pk-ok' },
      { label: 'انصراف' }
    ]
  });
  function list() {
    var tokens = norm(q).split(/\s+/).filter(Boolean);
    return S.data.users.filter(function (u) {
      if (!u.active || (o.exclude && o.exclude.has(u.id))) { return false; }
      if (o.filters) { var f = o.filters.filter(function (x) { return x[0] === filterKey; })[0]; if (f && !f[2](u)) { return false; } }
      var t = norm(u.name + ' ' + u.username + ' ' + u.code);
      return tokens.every(function (k) { return t.indexOf(k) >= 0; });
    });
  }
  function draw() {
    var rows = list(), h = '';
    if (o.filters) { h += '<div class="ot-pfilters">' + o.filters.map(function (f) { return '<button class="ot-chip' + (f[0] === filterKey ? ' is-on' : '') + '" data-f="' + f[0] + '">' + f[1] + '</button>'; }).join('') + '</div>'; }
    h += '<div class="ot-psearch">' + ico('search') + '<input id="pk-q" type="search" placeholder="جستجوی نام، نام کاربری یا کد…" value="' + esc(q) + '" autocomplete="off"></div>';
    h += '<ul class="ot-ulist ot-scroll ot-pick-list">' + (rows.length ? rows.slice(0, 120).map(function (u) {
      var on = sel.has(u.id), hint = o.hint ? o.hint(u) : '', r = roleOf(u);
      return '<li><button class="ot-prow' + (on ? ' is-on' : '') + '" data-u="' + u.id + '" role="' + (o.multi ? 'checkbox' : 'radio') + '" aria-checked="' + on + '">' + avatar(u, 'md') +
        '<span class="ot-urow-t"><b>' + esc(u.name) + '</b><small>' + esc(u.username) + ' · ' + srcLabel(u) + (r.unit ? ' · ' + esc(r.label) + ' ' + esc(r.unit.name) : ' · بدون واحد') + '</small>' + (hint ? '<em class="ot-hint-t">' + esc(hint) + '</em>' : '') + '</span><i class="ot-tick">' + ico('check') + '</i></button></li>';
    }).join('') : '<li class="ot-none">کاربری با این شرایط پیدا نشد.</li>') + '</ul>';
    if (rows.length > 120) { h += '<p class="ot-sm">فقط ۱۲۰ مورد اول نمایش داده شد؛ جستجو را دقیق‌تر کنید.</p>'; }
    h += '<p class="ot-sm" id="pk-count"></p>';
    body.innerHTML = h; count();
    var inp = $('#pk-q', body); inp.focus(); inp.setSelectionRange(inp.value.length, inp.value.length);
    inp.addEventListener('input', function () { q = inp.value; draw(); });
  }
  function count() { var c = $('#pk-count', body), ok = $('[data-id=pk-ok]', m.el); if (c) { c.textContent = sel.size ? fa(sel.size) + ' نفر انتخاب شد' : 'کسی انتخاب نشده است'; } if (ok) { ok.disabled = !sel.size; } }
  body.addEventListener('click', function (e) {
    var f = e.target.closest('[data-f]'); if (f) { filterKey = f.getAttribute('data-f'); draw(); return; }
    var b = e.target.closest('[data-u]'); if (!b) { return; }
    var id = +b.getAttribute('data-u');
    if (o.multi) { if (sel.has(id)) { sel.delete(id); } else { sel.add(id); } b.classList.toggle('is-on', sel.has(id)); b.setAttribute('aria-checked', sel.has(id)); count(); }
    else { sel.clear(); sel.add(id); o.onPick([id]); m.close(); }
  });
  draw();
}

/* ───────────── مدیران واحد (چند مدیر) ───────────── */
function openManagersDialog(unitId) {
  var u = unitById(unitId); if (!u) { return; }
  var list = (u.managerIds || []).filter(function (id) { return I.user.has(id); }), orig = list.join(',');
  var body = document.createElement('div'); body.className = 'ot-mgrs';
  var m = openModal({
    title: 'مدیران «' + u.name + '»', icon: 'crown', body: body, size: 'md',
    actions: [
      { label: 'ذخیره مدیران', kind: 'primary', icon: 'check', id: 'mg-save', onClick: function () { submit('org_set_managers', { unit_id: u.id, user_ids: list }, { select: u.id }); } },
      { label: 'انصراف' }
    ]
  });
  function draw() {
    var h = '<p class="ot-note">اولین نفر <b>مدیر اصلی</b> است؛ روی کارت نمایش داده می‌شود و مدیر مستقیم کارشناسان این واحد خواهد بود. هر نفر فقط یک سمت مدیریتی دارد؛ اگر مدیر واحد دیگری باشد از آنجا برداشته می‌شود.' +
      (u.primaryAdmin ? '<br><b class="ot-warn-t">این واحد «ادمین اصلی» است؛ مدیران آن نقش ادمین اصلی می‌گیرند.</b>' : '') + '</p><ul class="ot-ulist ot-mglist">';
    if (!list.length) { h += '<li class="ot-none">مدیری تعیین نشده است.</li>'; }
    list.forEach(function (id, i) {
      var x = I.user.get(id), mu = I.managed.get(id), other = mu && mu !== u.id ? unitById(mu) : null;
      h += '<li class="ot-urow">' + avatar(x, 'md') + '<div class="ot-urow-t"><b>' + esc(x.name) + '</b><small>' + (i === 0 ? '★ مدیر اصلی' : 'مدیر') + (other ? ' · اکنون مدیر «' + esc(other.name) + '» است' : '') + '</small></div>' +
        '<span class="ot-rowbtns">' + (i > 0 ? '<button class="ot-mini" data-a="star" data-i="' + i + '" title="مدیر اصلی شود">' + ico('star') + '</button>' : '') +
        (i > 0 ? '<button class="ot-mini" data-a="up" data-i="' + i + '" title="بالاتر">' + ico('arrowU') + '</button>' : '') + (i < list.length - 1 ? '<button class="ot-mini" data-a="down" data-i="' + i + '" title="پایین‌تر">' + ico('arrowD') + '</button>' : '') +
        '<button class="ot-mini is-danger" data-a="rm" data-i="' + i + '" title="حذف از مدیران">' + ico('x') + '</button></span></li>';
    });
    h += '</ul><button class="ot-btn" data-a="add">' + ico('userPlus') + '<span>افزودن مدیر</span></button>';
    body.innerHTML = h;
    var sv = $('[data-id=mg-save]', m.el); if (sv) { sv.disabled = list.join(',') === orig; }
  }
  body.addEventListener('click', function (e) {
    var b = e.target.closest('[data-a]'); if (!b) { return; }
    var a = b.getAttribute('data-a'), i = +b.getAttribute('data-i');
    if (a === 'rm') { list.splice(i, 1); } else if (a === 'star') { list.unshift(list.splice(i, 1)[0]); }
    else if (a === 'up') { list.splice(i - 1, 0, list.splice(i, 1)[0]); } else if (a === 'down') { list.splice(i + 1, 0, list.splice(i, 1)[0]); }
    else if (a === 'add') {
      pickUsers({
        title: 'افزودن مدیر به «' + u.name + '»', multi: true, confirm: 'افزودن به مدیران', exclude: new Set(list),
        filters: [['all', 'همه'], ['free', 'بدون واحد', function (x) { return roleOf(x).kind === 'free'; }], ['experts', 'کارشناسان', function (x) { return roleOf(x).kind === 'expert'; }]].map(function (f) { return f.length === 2 ? [f[0], f[1], function () { return true; }] : f; }),
        hint: function (x) { var mu = I.managed.get(x.id); return mu && mu !== u.id ? 'مدیر «' + unitById(mu).name + '» است؛ منتقل می‌شود' : ''; },
        onPick: function (ids) { ids.forEach(function (id) { if (list.indexOf(id) < 0) { list.push(id); } }); draw(); }
      });
      return;
    }
    draw();
  });
  draw();
}

/* ───────────── کارشناسان واحد ───────────── */
function openMembersDialog(unitId) {
  var u = unitById(unitId); if (!u || u.type === 'ceo') { return; }
  var mem = membersOf(u.id), sel = new Set(), body = document.createElement('div');
  var m = openModal({
    title: 'کارشناسان «' + u.name + '»', icon: 'users', body: body, size: 'md',
    actions: [
      { label: 'افزودن کارشناس', kind: 'primary', icon: 'userPlus', close: false, onClick: function () { addMembers(); } },
      { label: 'عزل انتخاب‌شده‌ها', kind: 'danger', icon: 'trash', close: false, id: 'mb-rm', onClick: function () { if (!sel.size) { return; } m.close(); submit('remove_org_experts', { unit_id: u.id, user_ids: Array.from(sel) }, { select: u.id }); } },
      { label: 'بستن' }
    ]
  });
  function draw() {
    var h = '<ul class="ot-ulist ot-scroll">' + (mem.length ? mem.map(function (x) {
      return '<li><button class="ot-prow' + (sel.has(x.id) ? ' is-on' : '') + '" data-u="' + x.id + '" role="checkbox" aria-checked="' + sel.has(x.id) + '">' + avatar(x, 'md') + '<span class="ot-urow-t"><b>' + esc(x.name) + '</b><small>' + esc(x.username) + '</small></span><i class="ot-tick">' + ico('check') + '</i></button></li>';
    }).join('') : '<li class="ot-none">کارشناسی ثبت نشده است.</li>') + '</ul><p class="ot-sm">' + fa(mem.length) + ' کارشناس · برای عزل، افراد را انتخاب کنید.</p>';
    body.innerHTML = h; var rm = $('[data-id=mb-rm]', m.el); if (rm) { rm.disabled = !sel.size; }
  }
  body.addEventListener('click', function (e) {
    var b = e.target.closest('[data-u]'); if (!b) { return; } var id = +b.getAttribute('data-u');
    if (sel.has(id)) { sel.delete(id); } else { sel.add(id); } draw();
  });
  function addMembers() {
    pickUsers({
      title: 'افزودن کارشناس به «' + u.name + '»', multi: true, confirm: 'افزودن', exclude: new Set(mem.map(function (x) { return x.id; }).concat(Array.from(I.managed.keys()))),
      filters: [['free', 'بدون واحد', function (x) { return roleOf(x).kind === 'free'; }], ['experts', 'کارشناسان سایر واحدها (انتقال)', function (x) { return roleOf(x).kind === 'expert'; }], ['all', 'همه', function () { return true; }]],
      hint: function (x) { var r = roleOf(x); return r.kind === 'expert' ? 'اکنون در «' + r.unit.name + '»؛ منتقل می‌شود' : ''; },
      onPick: function (ids) { m.close(); submit('org_assign_members', { unit_id: u.id, user_ids: ids }, { select: u.id }); }
    });
  }
  draw();
}

/* ───────────── انتقال و حذف ───────────── */
function openMoveDialog(unitId) {
  var u = unitById(unitId); if (!u || u.type === 'ceo') { return; }
  var body = '<div class="ot-form">' + field('والد جدید', '<select id="mv-parent">' + parentOptions(u.id, u.parentId) + '</select>') + '<p class="ot-note" id="mv-note"></p></div>';
  var m = openModal({
    title: 'انتقال «' + u.name + '»', icon: 'move', body: body, size: 'sm',
    actions: [{ label: 'انتقال', kind: 'primary', icon: 'check', onClick: function () { var pid = +$('#mv-parent', m.el).value; if (pid !== u.parentId) { moveUnit(u.id, pid, 0); } } }, { label: 'انصراف' }]
  });
  var sel = $('#mv-parent', m.el), note = $('#mv-note', m.el);
  function upd() { var p = unitById(+sel.value), t = suggestedType(p); note.innerHTML = 'نوع واحد پس از انتقال: <b>' + TYPES[t].label + '</b>' + (t !== u.type ? '<br><span class="ot-warn-t">⚠ نوع واحد از «' + TYPES[u.type].label + '» تغییر می‌کند.</span>' : ''); }
  sel.addEventListener('change', upd); upd();
}
function moveUnit(unitId, parentId, beforeId) {
  var u = unitById(unitId), p = unitById(parentId); if (!u || !p) { return Promise.resolve(false); }
  var nt = suggestedType(p), go = function () { return submit('org_move_unit', { unit_id: unitId, parent_id: parentId, before_id: beforeId || 0 }, { select: unitId }); };
  if (nt !== u.type) {
    return confirmBox({ title: 'تغییر نوع واحد', ok: 'انتقال بده', html: '<p>با انتقال «' + esc(u.name) + '» به «' + esc(p.name) + '»، نوع آن از <b>' + TYPES[u.type].label + '</b> به <b>' + TYPES[nt].label + '</b> تغییر می‌کند' + (u.type === 'deputy' ? ' و دیگر در فهرست معاونت‌های درخواست‌کننده نخواهد بود' : '') + '. ادامه می‌دهید؟</p>' }).then(function (ok) { return ok ? go() : false; });
  }
  return go();
}
function openDeleteDialog(unitId) {
  var u = unitById(unitId); if (!u || u.type === 'ceo') { return; }
  var ids = subtreeIds(u.id), kids = kidsOf(u.id), people = ids.reduce(function (a, id) { return a + managersOf(unitById(id)).length + membersOf(id).length; }, 0);
  var h = '<p>واحد «<b>' + esc(u.name) + '</b>» حذف می‌شود.</p><ul class="ot-bul"><li>' + fa(ids.length - 1) + ' زیرواحد</li><li>' + fa(people) + ' نفر (مدیر و کارشناس) از واحد بیرون می‌آیند و به «بدون واحد» می‌روند</li></ul>';
  if (kids.length) {
    h += '<div class="ot-radios"><label><input type="radio" name="dl-mode" value="subtree" checked><span><b>حذف همراه با همهٔ زیرمجموعه‌ها</b><small>این واحد و تمام زیرواحدهایش حذف می‌شوند.</small></span></label>' +
      '<label><input type="radio" name="dl-mode" value="promote"><span><b>حذف فقط این واحد</b><small>زیرواحدها به والد این واحد منتقل می‌شوند و کارشناسان مستقیم نیز به والد می‌روند.</small></span></label></div>';
  }
  h += '<p class="ot-note">بعد از حذف می‌توانید با «بازگشت» (Ctrl+Z) آن را برگردانید.</p>';
  var m = openModal({
    title: 'حذف واحد', icon: 'trash', size: 'sm', body: h,
    actions: [{ label: 'حذف', kind: 'danger', icon: 'trash', onClick: function () { var r = $('input[name=dl-mode]:checked', m.el); submit('org_remove_unit', { unit_id: u.id, mode: r ? r.value : 'subtree' }, { select: u.parentId || 0, keepTab: true }); } }, { label: 'انصراف' }]
  });
}

/* ───────────── ساخت چندتایی واحد ───────────── */
var BULK_TEMPLATES = [
  { name: 'نمونه: معاونت‌های مرسوم', text: 'معاونت اداری و مالی\n- اداره امور مالی\n- اداره امور اداری\n- اداره پشتیبانی\nمعاونت فناوری اطلاعات\n- اداره زیرساخت و شبکه\n- اداره نرم‌افزار\n- اداره پشتیبانی کاربران\nمعاونت برنامه‌ریزی\n- اداره آمار و تحلیل\n- اداره بودجه' },
  { name: 'نمونه: چند سطحی با بخش‌ها', text: 'معاونت فنی و عملیات\n- اداره نگهداری\n-- بخش مکانیک\n-- بخش برق\n- اداره تولید\n-- بخش برنامه‌ریزی تولید\n-- بخش کنترل کیفیت\nمعاونت مالی\n- اداره حسابداری\n-- بخش حقوق و دستمزد\n- اداره خزانه' },
  { name: 'نمونه: با کد واحد (نام | کد)', text: 'معاونت توسعه | DEV\n- اداره تحلیل | DEV-AN\n- اداره طراحی | DEV-DS\nمعاونت منابع انسانی | HR\n- اداره جذب و استخدام | HR-RC\n- اداره آموزش | HR-TR' }
];

function parseBulk(text, parentUnit) {
  var items = [], warns = [], stack = [];
  text.split(/\r?\n/).forEach(function (raw, ln) {
    if (!raw.trim()) { return; }
    var m = /^([\s\u00a0\u2003]*)((?:[-–—•*·]\s*)*)(.*)$/.exec(raw), ws = m[1].replace(/\t/g, '  ').length, marks = (m[2].match(/[-–—•*·]/g) || []).length;
    var level = Math.floor(ws / 2) + marks, rest = m[3].trim();
    if (!rest) { return; }
    var name = rest, code = '', bar = rest.indexOf('|');
    if (bar >= 0) { name = rest.slice(0, bar).trim(); code = rest.slice(bar + 1).trim(); }
    if (!name) { return; }
    if (level > stack.length) { warns.push('خط ' + fa(ln + 1) + ': تورفتگی بیش از حد بود و به نزدیک‌ترین سطح معتبر اصلاح شد.'); level = stack.length; }
    stack.length = level;
    items.push({ name: name, code: code, parent: level === 0 ? -1 : stack[level - 1], level: level, line: ln + 1 });
    stack[level] = items.length - 1;
  });
  var baseDepth = parentUnit ? (I.depth.get(parentUnit.id) || 0) : 0, seen = {}, errors = [];
  var existing = {}; if (parentUnit) { kidsOf(parentUnit.id).forEach(function (k) { existing[norm(k.name)] = true; }); }
  items.forEach(function (it, i) {
    var pt = it.parent < 0 ? (parentUnit ? parentUnit.type : 'department') : items[it.parent].type;
    it.type = pt === 'ceo' ? 'deputy' : 'department';
    it.depth = baseDepth + 1 + it.level;
    if (it.depth > BOOT.maxDepth) { errors.push('«' + it.name + '» از حداکثر عمق مجاز (' + fa(BOOT.maxDepth) + ' سطح) بیشتر است.'); }
    if (it.name.length > 190) { errors.push('نام «' + it.name.slice(0, 20) + '…» بیش از ۱۹۰ نویسه است.'); }
    var key = (it.type === 'deputy' ? 'deputy' : it.parent) + '|' + norm(it.name);
    if (seen[key]) { errors.push('«' + it.name + '» در این فهرست تکراری است.'); } seen[key] = true;
    if (it.parent < 0 && existing[norm(it.name)]) { errors.push('«' + it.name + '» از قبل زیر این والد وجود دارد.'); }
  });
  if (items.length > BOOT.bulkLimit) { errors.push('حداکثر ' + fa(BOOT.bulkLimit) + ' واحد در هر بار قابل ساخت است.'); }
  return { items: items, warns: warns, errors: Array.from(new Set(errors)) };
}

function openBulkDialog(parentId) {
  var par = parentId || S.sel || (I.root && I.root.id) || 0;
  var body = '<div class="ot-form"><div class="ot-f2">' + field('والد (زیر کدام واحد ساخته شود)', '<select id="bk-parent">' + parentOptions(0, par) + '</select>') +
    field('نمونه / فایل', '<div class="ot-inline"><select id="bk-tpl"><option value="">— انتخاب نمونه —</option>' + BULK_TEMPLATES.map(function (t, i) { return '<option value="' + i + '">' + esc(t.name) + '</option>'; }).join('') + '</select>' +
      '<button class="ot-btn" type="button" id="bk-file">' + ico('upload') + '<span>فایل…</span></button><input type="file" id="bk-fin" accept=".txt,.csv,.json,text/plain,text/csv,application/json" hidden></div>') + '</div>' +
    '<div class="ot-bk-grid"><label class="ot-f"><span>فهرست واحدها <i>(هر خط یک واحد)</i></span><textarea id="bk-text" rows="12" spellcheck="false" placeholder="معاونت مالی&#10;- اداره حسابداری&#10;-- بخش حقوق&#10;- اداره خزانه"></textarea>' +
      '<small>برای زیرمجموعه از «-» یا تورفتگی (دو فاصله) استفاده کنید. کد واحد را بعد از «|» بنویسید. مثال: <code>اداره مالی | FIN-01</code></small></label>' +
    '<div class="ot-f"><span>پیش‌نمایش <em id="bk-count"></em></span><div class="ot-bk-prev" id="bk-prev"></div></div></div><p class="ot-err" id="bk-err" hidden></p></div>';
  var m = openModal({
    title: 'ساخت چندتایی واحد', icon: 'list', body: body, size: 'lg',
    actions: [{ label: 'ساخت واحدها', kind: 'primary', icon: 'check', id: 'bk-ok', close: false, onClick: function () { return go(); } }, { label: 'انصراف' }]
  });
  var ta = $('#bk-text', m.el), sel = $('#bk-parent', m.el), prev = $('#bk-prev', m.el), cur = null;
  function upd() {
    var p = unitById(+sel.value); cur = parseBulk(ta.value, p);
    $('#bk-count', m.el).textContent = cur.items.length ? '(' + fa(cur.items.length) + ' واحد)' : '';
    prev.innerHTML = cur.items.length ? cur.items.map(function (it) {
      return '<div class="ot-bk-row" style="--lv:' + it.level + '">' + ico(it.type === 'deputy' ? 'briefcase' : 'folder') + '<b>' + esc(it.name) + '</b>' + (it.code ? '<small>' + esc(it.code) + '</small>' : '') + '<em>' + TYPES[it.type].label + '</em></div>';
    }).join('') : '<p class="ot-none">پیش‌نمایش اینجا نمایش داده می‌شود.</p>';
    var err = $('#bk-err', m.el), msgs = cur.errors.concat(cur.warns);
    err.hidden = !msgs.length; err.className = 'ot-err' + (cur.errors.length ? '' : ' is-warn'); err.innerHTML = msgs.slice(0, 5).map(esc).join('<br>') + (msgs.length > 5 ? '<br>و ' + fa(msgs.length - 5) + ' مورد دیگر…' : '');
    $('[data-id=bk-ok]', m.el).disabled = !cur.items.length || cur.errors.length > 0;
  }
  ta.addEventListener('input', upd); sel.addEventListener('change', upd);
  $('#bk-tpl', m.el).addEventListener('change', function (e) { var t = BULK_TEMPLATES[+e.target.value]; if (t) { ta.value = t.text; upd(); } });
  $('#bk-file', m.el).addEventListener('click', function () { $('#bk-fin', m.el).click(); });
  $('#bk-fin', m.el).addEventListener('change', function (e) {
    var f = e.target.files && e.target.files[0]; if (!f) { return; }
    var rd = new FileReader();
    rd.onload = function () { ta.value = importToText(String(rd.result || ''), f.name); upd(); toast('فایل «' + f.name + '» بارگذاری شد؛ پیش‌نمایش را بررسی کنید.', { type: 'info' }); };
    rd.readAsText(f, 'utf-8');
  });
  function go() {
    upd(); if (!cur.items.length || cur.errors.length) { return false; }
    var pid = +sel.value; S.collapsed.delete(pid);
    m.close();
    submit('org_bulk_create', { parent_id: pid, items_json: JSON.stringify(cur.items.map(function (it) { return { name: it.name, code: it.code, parent: it.parent }; })) }, { select: pid, center: true });
    return false;
  }
  upd();
}
/* تبدیل فایل ورودی (متن / CSV «سطح،نام،کد» / JSON خروجی همین صفحه) به متن تورفته */
function importToText(raw, fname) {
  raw = raw.replace(/^\uFEFF/, '');
  if (/\.json$/i.test(fname) || /^\s*[\[{]/.test(raw)) {
    try {
      var j = JSON.parse(raw), units = Array.isArray(j) ? j : (j.units || []), by = {}, kids = {}, root = null, out = [];
      units.forEach(function (u) { by[u.id] = u; (kids[u.parentId || 0] = kids[u.parentId || 0] || []).push(u); if (u.type === 'ceo') { root = u; } });
      (function walk(id, d) { (kids[id] || []).forEach(function (u) { out.push(new Array(d + 1).join('-') + (d ? ' ' : '') + u.name + (u.code ? ' | ' + u.code : '')); walk(u.id, d + 1); }); })(root ? root.id : 0, 0);
      return out.join('\n');
    } catch (e) { return raw; }
  }
  if (/\.csv$/i.test(fname)) {
    return raw.split(/\r?\n/).map(function (line) {
      var c = line.split(/[,;\t]/).map(function (x) { return x.replace(/^"|"$/g, '').trim(); });
      if (c.length >= 2 && /^\d+$/.test(c[0])) { return new Array(+c[0] + 1).join('-') + (+c[0] ? ' ' : '') + c[1] + (c[2] ? ' | ' + c[2] : ''); }
      return c[0] + (c[1] ? ' | ' + c[1] : '');
    }).join('\n');
  }
  return raw;
}

/* ───────────── خروجی‌ها ───────────── */
function download(blob, name) {
  var a = document.createElement('a'), url = URL.createObjectURL(blob);
  a.href = url; a.download = name; document.body.appendChild(a); a.click();
  setTimeout(function () { document.body.removeChild(a); URL.revokeObjectURL(url); }, 1500);
}
function fileStamp() { var d = new Date(); function p(n) { return (n < 10 ? '0' : '') + n; } return d.getFullYear() + p(d.getMonth() + 1) + p(d.getDate()) + '-' + p(d.getHours()) + p(d.getMinutes()); }
function xml(s) { return String(s == null ? '' : s).replace(/[\u0000-\u0008\u000B\u000C\u000E-\u001F]/g, '').replace(/&/g, '&amp;').replace(/</g, '&lt;').replace(/>/g, '&gt;').replace(/"/g, '&quot;'); }
function faDate() { try { return new Intl.DateTimeFormat('fa-IR', { dateStyle: 'long' }).format(new Date()); } catch (e) { return new Date().toLocaleDateString(); } }

/* فونت صفحه برای SVG/PNG (در صورت دسترسی، به‌صورت base64 داخل SVG گذاشته می‌شود) */
var fontCache = null;
function embedFonts() {
  if (fontCache) { return Promise.resolve(fontCache); }
  var jobs = [];
  try {
    Array.prototype.forEach.call(document.styleSheets, function (sheet) {
      var rules; try { rules = sheet.cssRules; } catch (e) { return; }
      Array.prototype.forEach.call(rules || [], function (r) {
        if (r.type !== 5) { return; }
        var src = r.style.getPropertyValue('src'), m = /url\(["']?([^"')]+)["']?\)/.exec(src); if (!m) { return; }
        var fam = r.style.getPropertyValue('font-family').replace(/["']/g, '').trim(), wt = r.style.getPropertyValue('font-weight') || '400';
        if (fontStack().indexOf(fam) < 0) { return; }
        var url; try { url = new URL(m[1], sheet.href || location.href).href; } catch (e) { return; }
        if (url.indexOf(location.origin) !== 0) { return; }
        jobs.push(fetch(url, { credentials: 'same-origin' }).then(function (res) { return res.ok ? res.arrayBuffer() : null; }).then(function (buf) {
          if (!buf) { return ''; }
          var bin = '', b = new Uint8Array(buf), i; for (i = 0; i < b.length; i += 8192) { bin += String.fromCharCode.apply(null, b.subarray(i, i + 8192)); }
          var fmt = /\.woff2/i.test(url) ? 'woff2' : (/\.woff/i.test(url) ? 'woff' : 'truetype');
          return '@font-face{font-family:"' + fam + '";font-weight:' + wt + ';src:url(data:font/' + fmt + ';base64,' + btoa(bin) + ') format("' + fmt + '")}';
        }).catch(function () { return ''; }));
      });
    });
  } catch (e) { /* ignore */ }
  return Promise.all(jobs).then(function (parts) { fontCache = parts.join(''); return fontCache; });
}

var FONT_STACK = '';
function fontStack() {
  if (!FONT_STACK) { FONT_STACK = (getComputedStyle(APP).fontFamily || 'Tahoma, sans-serif').replace(/"/g, '\''); }
  return FONT_STACK;
}
var measureCtx = null;
function fitText(t, maxW, size, weight) {
  if (!measureCtx) { measureCtx = document.createElement('canvas').getContext('2d'); }
  measureCtx.font = weight + ' ' + size + 'px ' + fontStack().replace(/'/g, '"');
  if (measureCtx.measureText(t).width <= maxW) { return t; }
  var s = t; while (s.length > 1 && measureCtx.measureText(s + '…').width > maxW) { s = s.slice(0, -1); }
  return s + '…';
}

/* ساخت SVG مستقل از DOM از روی چیدمان فعلی */
function buildSvg(o) {
  o = o || {};
  var L = computeLayout({ rootId: S.focus || 0, ignoreCollapsed: o.scope === 'all' }), head = o.title === false ? 0 : 74, W = L.W, H = L.H + head;
  var colors = { ceo: ['#1f3b63', '#e8eef7'], deputy: ['#2f6fa7', '#e6f0fa'], department: ['#16908b', '#e3f4f3'] };
  var f = fontStack(), out = [];
  function T(x, y, text, size, weight, fill, anchor) {
    return '<text x="' + x + '" y="' + y + '" font-size="' + size + '" font-weight="' + weight + '" fill="' + fill + '" direction="rtl" unicode-bidi="plaintext" text-anchor="' + (anchor || 'start') + '">' + xml(text) + '</text>';
  }
  out.push('<rect width="' + W + '" height="' + H + '" fill="#ffffff"/>');
  if (head) {
    out.push(T(W - 40, 40, (BOOT.orgName || 'سازمان') + ' — چارت سازمانی', 24, 700, '#1b2a3d'));
    out.push(T(W - 40, 62, faDate() + ' · ' + fa(I.stats.units) + ' واحد · ' + fa(I.stats.active) + ' نفر' + (S.focus ? ' · شاخهٔ «' + unitById(S.focus).name + '»' : ''), 13, 400, '#64748b'));
  }
  out.push('<g transform="translate(0,' + head + ')">');
  L.links.forEach(function (lk) { out.push('<path d="' + linkPath(lk.from, lk.to, L.horiz, L.gapD) + '" fill="none" stroke="#a9b8c9" stroke-width="2"/>'); });
  L.nodes.forEach(function (n) {
    var u = n.u, c = colors[u.type] || colors.department, x = n.x, y = n.y, w = n.w, h = n.h, right = x + w - 16, compact = S.view.density === 'compact';
    var ms = managersOf(u), m0 = ms[0], mem = membersOf(u.id), total = I.total.get(u.id) || 0;
    out.push('<rect x="' + x + '" y="' + y + '" width="' + w + '" height="' + h + '" rx="14" fill="' + c[0] + '"/>');
    out.push('<rect x="' + x + '" y="' + (y + 6) + '" width="' + w + '" height="' + (h - 6) + '" rx="14" fill="#ffffff" stroke="#d6dfe9"/>');
    out.push('<rect x="' + (x + w - 52) + '" y="' + (y + 14) + '" width="0" height="0"/>');
    out.push('<circle cx="' + (right - 16) + '" cy="' + (y + 32) + '" r="16" fill="' + c[1] + '"/>' + T(right - 16, y + 37, TYPES[u.type].label.charAt(0), 14, 700, c[0], 'middle'));
    var tw = w - 32 - 44 - (u.primaryAdmin ? 24 : 0);
    out.push(T(right - 42, y + 31, fitText(u.name, tw, 15, 700), 15, 700, '#1b2a3d'));
    out.push(T(right - 42, y + 49, TYPES[u.type].label + (u.code ? ' · ' + u.code : ''), 12, 400, '#64748b'));
    if (u.primaryAdmin) { out.push('<circle cx="' + (x + 24) + '" cy="' + (y + 32) + '" r="9" fill="#fff3d6" stroke="#c8952e"/>' + T(x + 24, y + 36, '★', 11, 700, '#9a6b0f', 'middle')); }
    if (compact) {
      out.push(T(right, y + h - 16, m0 ? fitText(m0.name, w - 90, 13, 400) : 'بدون مدیر', 13, 400, m0 ? '#334155' : '#b45309'));
      out.push(T(x + 16, y + h - 16, fa(total) + ' نفر', 12, 400, '#64748b', 'end'));
      return;
    }
    out.push('<line x1="' + (x + 14) + '" x2="' + (x + w - 14) + '" y1="' + (y + 62) + '" y2="' + (y + 62) + '" stroke="#e5ebf2"/>');
    if (m0) {
      out.push('<circle cx="' + (right - 14) + '" cy="' + (y + 86) + '" r="14" fill="hsl(' + hueOf(m0.name) + ',50%,42%)"/>' + T(right - 14, y + 91, initials(m0.name), 12, 700, '#fff', 'middle'));
      out.push(T(right - 36, y + 84, fitText(m0.name, w - 32 - 40, 13, 700), 13, 700, '#1b2a3d'));
      out.push(T(right - 36, y + 101, TYPES[u.type].mgr + (ms.length > 1 ? ' · و ' + fa(ms.length - 1) + ' نفر دیگر' : ''), 11, 400, '#64748b'));
    } else { out.push(T(right, y + 90, 'مدیر تعیین نشده', 13, 400, '#b45309')); }
    out.push('<line x1="' + (x + 14) + '" x2="' + (x + w - 14) + '" y1="' + (y + h - 30) + '" y2="' + (y + h - 30) + '" stroke="#e5ebf2"/>');
    out.push(T(right, y + h - 11, u.type === 'ceo' ? fa(kidsOf(u.id).length) + ' معاونت' : fa(mem.length) + ' کارشناس', 12, 400, '#475569'));
    out.push(T(x + 16, y + h - 11, 'کل: ' + fa(total) + ' نفر', 12, 700, c[0], 'end'));
  });
  out.push('</g>');
  var css = o.fonts || '';
  return { w: W, h: H, svg: '<svg xmlns="http://www.w3.org/2000/svg" width="' + W + '" height="' + H + '" viewBox="0 0 ' + W + ' ' + H + '" font-family="' + f.replace(/"/g, '\'') + '"><style>' + css + '</style>' + out.join('') + '</svg>' };
}

function exportSvg(scope) {
  embedFonts().then(function (css) { var r = buildSvg({ scope: scope, fonts: css }); download(new Blob([r.svg], { type: 'image/svg+xml;charset=utf-8' }), 'org-chart-' + fileStamp() + '.svg'); toast('فایل SVG ذخیره شد.', { type: 'info' }); });
}
function exportPng(scope) {
  toast('در حال ساخت تصویر…', { type: 'info', ms: 1800 });
  embedFonts().then(function (css) {
    var r = buildSvg({ scope: scope, fonts: css }), sc = Math.min(2, 9000 / Math.max(r.w, r.h)), img = new Image();
    img.onload = function () {
      var c = document.createElement('canvas'); c.width = Math.round(r.w * sc); c.height = Math.round(r.h * sc);
      var g = c.getContext('2d'); g.fillStyle = '#fff'; g.fillRect(0, 0, c.width, c.height); g.drawImage(img, 0, 0, c.width, c.height);
      c.toBlob(function (b) { if (b) { download(b, 'org-chart-' + fileStamp() + '.png'); toast('تصویر PNG ذخیره شد.', { type: 'info' }); } else { toast('ساخت PNG ناموفق بود؛ از خروجی SVG استفاده کنید.', { type: 'error' }); } }, 'image/png');
    };
    img.onerror = function () { toast('ساخت PNG ناموفق بود؛ از خروجی SVG استفاده کنید.', { type: 'error' }); };
    img.src = 'data:image/svg+xml;charset=utf-8,' + encodeURIComponent(r.svg);
  });
}

/* چاپ / ذخیره PDF — A3 یا A4 به‌صورت خودکار بر اساس اندازهٔ نمودار */
var printEl = null, printStyle = null;
function preparePrint(scope) {
  cleanupPrint();
  var r = buildSvg({ scope: scope, fonts: '' }), land = r.w >= r.h * 0.85, size = (r.w > 2300 || r.h > 2300) ? 'A3' : 'A4';
  printEl = document.createElement('div'); printEl.id = 'ot-print'; printEl.innerHTML = r.svg;
  var sv = printEl.firstChild; sv.removeAttribute('width'); sv.removeAttribute('height'); sv.setAttribute('preserveAspectRatio', 'xMidYMid meet');
  printStyle = document.createElement('style'); printStyle.textContent = '@page{size:' + size + ' ' + (land ? 'landscape' : 'portrait') + ';margin:8mm}';
  document.head.appendChild(printStyle); document.body.appendChild(printEl); document.body.classList.add('ot-printing');
}
function cleanupPrint() {
  if (printEl && printEl.parentNode) { printEl.parentNode.removeChild(printEl); }
  if (printStyle && printStyle.parentNode) { printStyle.parentNode.removeChild(printStyle); }
  printEl = printStyle = null; document.body.classList.remove('ot-printing');
}
function printChart(scope) { preparePrint(scope); setTimeout(function () { window.print(); }, 120); }

/* Excel واقعی (.xlsx) با دو برگه: واحدها و افراد — بدون هیچ کتابخانه‌ای */
function crc32(buf) {
  var t = crc32.t, c, n, k, i;
  if (!t) { t = crc32.t = []; for (n = 0; n < 256; n++) { c = n; for (k = 0; k < 8; k++) { c = (c & 1) ? (0xEDB88320 ^ (c >>> 1)) : (c >>> 1); } t[n] = c >>> 0; } }
  c = -1; for (i = 0; i < buf.length; i++) { c = t[(c ^ buf[i]) & 255] ^ (c >>> 8); }
  return (c ^ -1) >>> 0;
}
function zipStore(files) {
  var enc = new TextEncoder(), chunks = [], central = [], offset = 0;
  files.forEach(function (f) {
    var nb = enc.encode(f.name), data = enc.encode(f.text), crc = crc32(data), sz = data.length;
    var lh = new DataView(new ArrayBuffer(30));
    lh.setUint32(0, 0x04034b50, true); lh.setUint16(4, 20, true); lh.setUint16(6, 0x0800, true); lh.setUint16(8, 0, true); lh.setUint16(10, 0, true); lh.setUint16(12, 0x21, true);
    lh.setUint32(14, crc, true); lh.setUint32(18, sz, true); lh.setUint32(22, sz, true); lh.setUint16(26, nb.length, true); lh.setUint16(28, 0, true);
    chunks.push(new Uint8Array(lh.buffer), nb, data);
    var ch = new DataView(new ArrayBuffer(46));
    ch.setUint32(0, 0x02014b50, true); ch.setUint16(4, 20, true); ch.setUint16(6, 20, true); ch.setUint16(8, 0x0800, true); ch.setUint16(10, 0, true); ch.setUint16(12, 0, true); ch.setUint16(14, 0x21, true);
    ch.setUint32(16, crc, true); ch.setUint32(20, sz, true); ch.setUint32(24, sz, true); ch.setUint16(28, nb.length, true); ch.setUint32(42, offset, true);
    central.push(new Uint8Array(ch.buffer), nb);
    offset += 30 + nb.length + sz;
  });
  var cd = central.reduce(function (a, b) { return a + b.length; }, 0), end = new DataView(new ArrayBuffer(22));
  end.setUint32(0, 0x06054b50, true); end.setUint16(8, files.length, true); end.setUint16(10, files.length, true); end.setUint32(12, cd, true); end.setUint32(16, offset, true);
  return new Blob(chunks.concat(central, [new Uint8Array(end.buffer)]), { type: 'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet' });
}
function colName(i) { var s = ''; i++; while (i > 0) { var m = (i - 1) % 26; s = String.fromCharCode(65 + m) + s; i = Math.floor((i - 1) / 26); } return s; }
function sheetXml(rows, widths) {
  var x = '<?xml version="1.0" encoding="UTF-8" standalone="yes"?><worksheet xmlns="http://schemas.openxmlformats.org/spreadsheetml/2006/main"><sheetViews><sheetView rightToLeft="1" workbookViewId="0"><pane ySplit="1" topLeftCell="A2" activePane="bottomLeft" state="frozen"/></sheetView></sheetViews><sheetFormatPr defaultRowHeight="18"/><cols>';
  widths.forEach(function (w, i) { x += '<col min="' + (i + 1) + '" max="' + (i + 1) + '" width="' + w + '" customWidth="1"/>'; });
  x += '</cols><sheetData>';
  rows.forEach(function (row, r) {
    x += '<row r="' + (r + 1) + '">';
    row.forEach(function (v, c) {
      var ref = colName(c) + (r + 1);
      if (typeof v === 'number') { x += '<c r="' + ref + '" s="2"><v>' + v + '</v></c>'; }
      else { x += '<c r="' + ref + '" t="inlineStr" s="' + (r === 0 ? 1 : 3) + '"><is><t xml:space="preserve">' + xml(v) + '</t></is></c>'; }
    });
    x += '</row>';
  });
  return x + '</sheetData><autoFilter ref="A1:' + colName(widths.length - 1) + rows.length + '"/></worksheet>';
}
function exportXlsx() {
  var unitRows = [['ردیف', 'سطح', 'نوع', 'نام واحد', 'کد', 'مسیر کامل', 'مدیران', 'کارشناسان مستقیم', 'زیرواحدها', 'کل نفرات شاخه', 'ادمین اصلی']], i = 0;
  (function walk(u) {
    i++; var ms = managersOf(u);
    unitRows.push([i, (I.depth.get(u.id) || 0) + 1, TYPES[u.type].label, u.name, u.code || '', pathNames(u.id).join(' ‹ '), ms.map(function (m) { return m.name; }).join('، '), membersOf(u.id).length, kidsOf(u.id).length, I.total.get(u.id) || 0, u.primaryAdmin ? 'بله' : '']);
    kidsOf(u.id).forEach(walk);
  })(I.root);
  var userRows = [['نام و نام خانوادگی', 'نام کاربری', 'کد', 'منبع', 'سمت در سازمان', 'واحد', 'مسیر واحد', 'وضعیت']];
  S.data.users.forEach(function (u) { var r = roleOf(u); userRows.push([u.name, u.username, u.code || '', u.source === 'ldap' ? 'دامینی' : 'محلی', r.label, r.unit ? r.unit.name : '', r.unit ? pathNames(r.unit.id).join(' ‹ ') : '', u.active ? 'فعال' : 'غیرفعال']); });
  var ns = 'xmlns="http://schemas.openxmlformats.org/spreadsheetml/2006/main"', R = 'http://schemas.openxmlformats.org/officeDocument/2006/relationships', hdr = '<?xml version="1.0" encoding="UTF-8" standalone="yes"?>';
  var files = [
    { name: '[Content_Types].xml', text: hdr + '<Types xmlns="http://schemas.openxmlformats.org/package/2006/content-types"><Default Extension="rels" ContentType="application/vnd.openxmlformats-package.relationships+xml"/><Default Extension="xml" ContentType="application/xml"/><Override PartName="/xl/workbook.xml" ContentType="application/vnd.openxmlformats-officedocument.spreadsheetml.sheet.main+xml"/><Override PartName="/xl/worksheets/sheet1.xml" ContentType="application/vnd.openxmlformats-officedocument.spreadsheetml.worksheet+xml"/><Override PartName="/xl/worksheets/sheet2.xml" ContentType="application/vnd.openxmlformats-officedocument.spreadsheetml.worksheet+xml"/><Override PartName="/xl/styles.xml" ContentType="application/vnd.openxmlformats-officedocument.spreadsheetml.styles+xml"/></Types>' },
    { name: '_rels/.rels', text: hdr + '<Relationships xmlns="http://schemas.openxmlformats.org/package/2006/relationships"><Relationship Id="rId1" Type="' + R + '/officeDocument" Target="xl/workbook.xml"/></Relationships>' },
    { name: 'xl/workbook.xml', text: hdr + '<workbook ' + ns + ' xmlns:r="' + R + '"><sheets><sheet name="واحدها" sheetId="1" r:id="rId1"/><sheet name="افراد" sheetId="2" r:id="rId2"/></sheets></workbook>' },
    { name: 'xl/_rels/workbook.xml.rels', text: hdr + '<Relationships xmlns="http://schemas.openxmlformats.org/package/2006/relationships"><Relationship Id="rId1" Type="' + R + '/worksheet" Target="worksheets/sheet1.xml"/><Relationship Id="rId2" Type="' + R + '/worksheet" Target="worksheets/sheet2.xml"/><Relationship Id="rId3" Type="' + R + '/styles" Target="styles.xml"/></Relationships>' },
    { name: 'xl/styles.xml', text: hdr + '<styleSheet ' + ns + '><fonts count="2"><font><sz val="11"/><name val="Tahoma"/></font><font><b/><sz val="11"/><color rgb="FFFFFFFF"/><name val="Tahoma"/></font></fonts><fills count="3"><fill><patternFill patternType="none"/></fill><fill><patternFill patternType="gray125"/></fill><fill><patternFill patternType="solid"><fgColor rgb="FF1F3B63"/></patternFill></fill></fills><borders count="2"><border><left/><right/><top/><bottom/><diagonal/></border><border><left style="thin"><color rgb="FFD6DFE9"/></left><right style="thin"><color rgb="FFD6DFE9"/></right><top style="thin"><color rgb="FFD6DFE9"/></top><bottom style="thin"><color rgb="FFD6DFE9"/></bottom><diagonal/></border></borders><cellStyleXfs count="1"><xf numFmtId="0" fontId="0" fillId="0" borderId="0"/></cellStyleXfs><cellXfs count="4"><xf numFmtId="0" fontId="0" fillId="0" borderId="0" xfId="0"/><xf numFmtId="0" fontId="1" fillId="2" borderId="1" xfId="0" applyFont="1" applyFill="1" applyBorder="1" applyAlignment="1"><alignment horizontal="center" vertical="center"/></xf><xf numFmtId="0" fontId="0" fillId="0" borderId="1" xfId="0" applyBorder="1" applyAlignment="1"><alignment horizontal="center" vertical="center"/></xf><xf numFmtId="0" fontId="0" fillId="0" borderId="1" xfId="0" applyBorder="1" applyAlignment="1"><alignment horizontal="right" vertical="center" wrapText="0"/></xf></cellXfs><cellStyles count="1"><cellStyle name="Normal" xfId="0" builtinId="0"/></cellStyles></styleSheet>' },
    { name: 'xl/worksheets/sheet1.xml', text: sheetXml(unitRows, [7, 7, 11, 30, 12, 52, 30, 14, 11, 13, 11]) },
    { name: 'xl/worksheets/sheet2.xml', text: sheetXml(userRows, [26, 18, 14, 10, 18, 28, 52, 10]) }
  ];
  download(zipStore(files), 'org-chart-' + fileStamp() + '.xlsx'); toast('فایل Excel ذخیره شد (دو برگه: واحدها و افراد).', { type: 'info' });
}
function exportJson() {
  var data = { version: 8, exportedAt: new Date().toISOString(), orgName: BOOT.orgName || '',
    units: S.data.units.map(function (u) { return { id: u.id, name: u.name, code: u.code, parentId: u.parentId, type: u.type, managerIds: u.managerIds, primaryAdmin: u.primaryAdmin, sortOrder: u.sortOrder }; }),
    users: S.data.users.filter(function (u) { return u.active; }).map(function (u) { return { id: u.id, name: u.name, username: u.username, unitId: u.unitId, managerId: u.managerId }; }) };
  download(new Blob([JSON.stringify(data, null, 2)], { type: 'application/json;charset=utf-8' }), 'org-chart-' + fileStamp() + '.json'); toast('فایل JSON ذخیره شد.', { type: 'info' });
}
function openExportMenu(btn) {
  var r = btn.getBoundingClientRect(), scopeNote = S.focus ? ' (شاخهٔ متمرکز)' : '';
  openMenu(r.left, r.bottom + 6, [
    { label: 'تصویر PNG — نمای فعلی' + scopeNote, icon: 'image', run: function () { exportPng('view'); } },
    { label: 'تصویر PNG — همهٔ شاخه‌ها', icon: 'image', run: function () { exportPng('all'); } },
    { label: 'برداری SVG — نمای فعلی', icon: 'code', run: function () { exportSvg('view'); } },
    { label: 'چاپ / PDF — نمای فعلی', icon: 'printer', run: function () { printChart('view'); } },
    { label: 'چاپ / PDF — همهٔ شاخه‌ها', icon: 'printer', run: function () { printChart('all'); } },
    { sep: true },
    { label: 'Excel (.xlsx) — واحدها و افراد', icon: 'sheet', run: exportXlsx },
    { label: 'JSON (پشتیبان ساختار)', icon: 'code', run: exportJson }
  ], btn);
}

/* ───────────── راهنما ───────────── */
function openHelp() {
  var keys = [['Ctrl + K  یا  /', 'جستجو'], ['Enter / Shift+Enter', 'نتیجهٔ بعدی / قبلی (در جستجو)'], ['کلیدهای جهت‌دار', 'حرکت بین کارت‌ها'], ['Enter', 'نمایش جزئیات واحد'], ['F2', 'ویرایش واحد'], ['Delete', 'حذف واحد'],
    ['Shift + F10', 'منوی واحد'], ['+  /  −  /  0', 'بزرگ‌نمایی / کوچک‌نمایی / ۱۰۰٪'], ['F', 'جا شدن در صفحه'], ['Shift + F', 'تمام‌صفحه'], ['Space + کشیدن', 'جابه‌جایی بوم'], ['Ctrl + چرخ ماوس', 'بزرگ‌نمایی'],
    ['Ctrl + Z / Ctrl + Shift + Z', 'بازگشت / انجام دوباره'], ['Esc', 'پاک‌کردن جستجو، انتخاب و برجسته‌سازی']];
  var h = '<div class="ot-help"><section><h3>کار با درخت</h3><ul class="ot-bul"><li>برای بازکردن یا بستن شاخه، دکمهٔ عددی پایین کارت را بزنید.</li><li>روی کارت کلیک کنید تا جزئیات، مسیر و تاریخچهٔ آن در پنل کناری باز شود.</li>' +
    (BOOT.canManage ? '<li>فرد را از پنل «افراد» روی کارت بکشید: نیمهٔ بالا «مدیر»، نیمهٔ پایین «کارشناس».</li><li>کارت واحد را روی واحد دیگر بکشید تا زیرمجموعه‌اش شود؛ کنارهٔ راست/چپ یک هم‌ردیف رها کنید تا ترتیب عوض شود.</li><li>هر عملیات قابل بازگشت است (تا ' + fa(12) + ' مرحله).</li>' : '') +
    '<li>در بالا می‌توانید جهت نمایش، حالت فشرده، تم تیره و خروجی (PNG، SVG، PDF، Excel) را انتخاب کنید.</li></ul></section><section><h3>کلیدهای میانبر</h3><table class="ot-keys">' + keys.map(function (k) { return '<tr><td><kbd>' + esc(k[0]) + '</kbd></td><td>' + esc(k[1]) + '</td></tr>'; }).join('') + '</table></section></div>';
  openModal({ title: 'راهنمای درخت سازمان', icon: 'help', size: 'lg', body: h, actions: [{ label: 'متوجه شدم', kind: 'primary' }] });
}

/* ───────────── انتخاب نحوهٔ افزودن مدیر در کشیدن/رها کردن ───────────── */
function dropManager(unitId, userId) {
  var u = unitById(unitId), x = I.user.get(userId); if (!u || !x) { return; }
  if ((u.managerIds || []).indexOf(userId) >= 0) { toast('«' + x.name + '» همین حالا مدیر «' + u.name + '» است.', { type: 'info' }); return; }
  var mu = I.managed.get(userId), other = mu && mu !== u.id ? unitById(mu) : null, cur = (u.managerIds || []).filter(function (id) { return I.user.has(id); });
  var note = other ? '<p class="ot-warn-t">«' + esc(x.name) + '» اکنون مدیر «' + esc(other.name) + '» است و از آنجا برداشته می‌شود.</p>' : '';
  var save = function (list) { submit('org_set_managers', { unit_id: u.id, user_ids: list }, { select: u.id }); };
  if (!cur.length) {
    if (other) { confirmBox({ title: 'انتقال مدیر', ok: 'انتقال بده', html: '<p>«' + esc(x.name) + '» مدیر «' + esc(u.name) + '» شود؟</p>' + note }).then(function (ok) { if (ok) { save([userId]); } }); } else { save([userId]); }
    return;
  }
  openModal({
    title: 'تعیین مدیر «' + u.name + '»', icon: 'crown', size: 'sm', body: '<p>«' + esc(x.name) + '» چگونه مدیر «' + esc(u.name) + '» شود؟</p><p class="ot-sm">مدیر فعلی: ' + cur.map(function (id) { return esc(I.user.get(id).name); }).join('، ') + '</p>' + note,
    actions: [
      { label: 'جایگزین مدیر فعلی', kind: 'primary', onClick: function () { save([userId]); } },
      { label: 'افزودن به مدیران', onClick: function () { save(cur.concat([userId])); } },
      { label: 'انصراف' }
    ]
  });
}
function dropExpert(unitId, userId) {
  var u = unitById(unitId), x = I.user.get(userId); if (!u || !x) { return; }
  if (I.managed.has(userId)) { toast('«' + x.name + '» مدیر یک واحد است؛ ابتدا از مدیریت برداشته شود.', { type: 'error' }); return; }
  if (x.unitId === u.id) { toast('«' + x.name + '» همین حالا در «' + u.name + '» است.', { type: 'info' }); return; }
  submit('org_assign_members', { unit_id: u.id, user_ids: [userId] }, { select: u.id });
}

/* ───────────── کشیدن و رها کردن ───────────── */
var dragPtr = null, panRaf = 0;
function markDragTargets(kind, id) {
  cardEls.forEach(function (el, cid) {
    var bad = false;
    if (kind === 'unit') { bad = cid === id || isDescendant(cid, id); }
    el.classList.toggle('ot-nodrop', bad);
  });
}
function endDrag() {
  S.drag = null; APP.classList.remove('ot-dragging-unit', 'ot-dragging-user'); APP.removeAttribute('data-dragrole');
  $$('.is-over', APP).forEach(function (z) { z.classList.remove('is-over'); });
  cardEls.forEach(function (el) { el.classList.remove('ot-nodrop'); });
  dragPtr = null;
}
function autoPan() {
  if (!S.drag || !dragPtr) { panRaf = 0; return; }
  var vp = vpSize(), edge = 70, dx = 0, dy = 0, x = dragPtr.x - vp.l, y = dragPtr.y - vp.t;
  if (x < 0 || y < 0 || x > vp.w || y > vp.h) { panRaf = requestAnimationFrame(autoPan); return; }
  if (x < edge) { dx = (edge - x) / edge * 16; } else if (x > vp.w - edge) { dx = -(x - (vp.w - edge)) / edge * 16; }
  if (y < edge) { dy = (edge - y) / edge * 16; } else if (y > vp.h - edge) { dy = -(y - (vp.h - edge)) / edge * 16; }
  if (dx || dy) { S.cam.x += dx; S.cam.y += dy; applyCam(false); }
  panRaf = requestAnimationFrame(autoPan);
}
function bindDrag() {
  document.addEventListener('dragstart', function (e) {
    if (!BOOT.canManage) { return; }
    var card = e.target.closest && e.target.closest('.ot-card'), row = e.target.closest && e.target.closest('.ot-urow[draggable=true]');
    if (card && APP.contains(card) && card.draggable) {
      var id = +card.dataset.id; S.drag = { kind: 'unit', id: id };
      e.dataTransfer.effectAllowed = 'move'; try { e.dataTransfer.setData('text/plain', 'unit:' + id); } catch (x) { /* ignore */ }
      APP.classList.add('ot-dragging-unit'); markDragTargets('unit', id); closeMenu();
    } else if (row) {
      var uid = +row.getAttribute('data-uid'); S.drag = { kind: 'user', id: uid };
      e.dataTransfer.effectAllowed = 'move'; try { e.dataTransfer.setData('text/plain', 'user:' + uid); } catch (x) { /* ignore */ }
      APP.setAttribute('data-dragrole', I.managed.has(uid) ? 'manager' : 'expert'); APP.classList.add('ot-dragging-user');
    } else { return; }
    if (!panRaf) { panRaf = requestAnimationFrame(autoPan); }
  });
  document.addEventListener('dragover', function (e) {
    if (!S.drag) { return; }
    dragPtr = { x: e.clientX, y: e.clientY };
    var z = e.target.closest && e.target.closest('[data-zone]'), prev = $$('.ot-dz .is-over', APP);
    prev.forEach(function (p) { if (p !== z) { p.classList.remove('is-over'); } });
    if (!z) { return; }
    var card = z.closest('.ot-card'); if (!card || card.classList.contains('ot-nodrop')) { return; }
    var cid = +card.dataset.id, zone = z.getAttribute('data-zone'), u = unitById(cid);
    if (S.drag.kind === 'unit' && (zone === 'before' || zone === 'after') && !u.parentId) { return; }
    if (S.drag.kind === 'user' && zone === 'expert' && (u.type === 'ceo' || I.managed.has(S.drag.id))) { return; }
    e.preventDefault(); e.dataTransfer.dropEffect = 'move'; z.classList.add('is-over');
  });
  document.addEventListener('drop', function (e) {
    if (!S.drag) { return; }
    var z = e.target.closest && e.target.closest('[data-zone]'), d = S.drag; if (!z) { endDrag(); return; }
    var card = z.closest('.ot-card'); if (!card || card.classList.contains('ot-nodrop')) { endDrag(); return; }
    e.preventDefault();
    var cid = +card.dataset.id, zone = z.getAttribute('data-zone'), t = unitById(cid);
    endDrag();
    if (d.kind === 'unit') {
      if (zone === 'child') { moveUnit(d.id, cid, 0); return; }
      var sibs = kidsOf(t.parentId).filter(function (k) { return k.id !== d.id; }), idx = sibs.map(function (k) { return k.id; }).indexOf(cid);
      var beforeId = zone === 'before' ? cid : (sibs[idx + 1] ? sibs[idx + 1].id : 0);
      moveUnit(d.id, t.parentId, beforeId);
    } else if (zone === 'manager') { dropManager(cid, d.id); } else if (zone === 'expert') { dropExpert(cid, d.id); }
  });
  document.addEventListener('dragend', endDrag);
}

/* ───────────── جابه‌جایی بوم با ماوس، چرخ ماوس، مینی‌مپ ───────────── */
var spaceDown = false;
function bindViewport() {
  var vp = E.viewport, pan = null;
  vp.addEventListener('pointerdown', function (e) {
    if (e.button !== 0 && e.button !== 1) { return; }
    if (e.target.closest('.ot-card') && !spaceDown && e.button === 0) { return; }
    if (e.target.closest('.ot-empty-card')) { return; }
    pan = { x: e.clientX, y: e.clientY, cx: S.cam.x, cy: S.cam.y, moved: false, id: e.pointerId };
    try { vp.setPointerCapture(e.pointerId); } catch (x) { /* ignore */ }
    E.world.classList.remove('ot-anim');
  });
  vp.addEventListener('pointermove', function (e) {
    if (!pan || e.pointerId !== pan.id) { return; }
    var dx = e.clientX - pan.x, dy = e.clientY - pan.y;
    if (!pan.moved && Math.abs(dx) + Math.abs(dy) < 4) { return; }
    pan.moved = true; vp.classList.add('is-panning'); S.cam.x = pan.cx + dx; S.cam.y = pan.cy + dy; applyCam(false);
  });
  function up(e) {
    if (!pan || e.pointerId !== pan.id) { return; }
    var moved = pan.moved; pan = null; vp.classList.remove('is-panning');
    if (!moved) { closeMenu(); if (S.hl.size) { clearHighlight(); } if (S.sel) { select(0); } }
  }
  vp.addEventListener('pointerup', up); vp.addEventListener('pointercancel', up);
  vp.addEventListener('wheel', function (e) {
    e.preventDefault();
    if (e.ctrlKey || e.metaKey) { zoomAt(Math.exp(-e.deltaY * (e.deltaMode ? 0.05 : 0.0018)), e.clientX, e.clientY, false); }
    else { S.cam.x -= (e.shiftKey ? e.deltaY : e.deltaX); S.cam.y -= (e.shiftKey ? 0 : e.deltaY); applyCam(false); }
  }, { passive: false });
  /* مینی‌مپ */
  var mm = E.mini, mdrag = false;
  function mmMove(e) {
    var m = minimapGeom(); if (!m) { return; }
    var r = mm.getBoundingClientRect(), x = (e.clientX - r.left) * (mm.width / r.width), y = (e.clientY - r.top) * (mm.height / r.height);
    var wx = (x - m.ox) / m.s, wy = (y - m.oy) / m.s, v = vpSize();
    S.cam.x = v.w / 2 - wx * S.cam.k; S.cam.y = v.h / 2 - wy * S.cam.k; applyCam(false);
  }
  mm.addEventListener('pointerdown', function (e) { mdrag = true; mm.setPointerCapture(e.pointerId); mmMove(e); });
  mm.addEventListener('pointermove', function (e) { if (mdrag) { mmMove(e); } });
  mm.addEventListener('pointerup', function () { mdrag = false; });
  if (window.ResizeObserver) { new ResizeObserver(debounce(function () { drawMinimap(); }, 80)).observe(vp); }
}
function clearHighlight() { S.hl = new Set(); S.hlLabel = ''; S.autoOpen = new Set(S.search.q ? S.autoOpen : []); paintState(); renderSide(); }

/* ───────────── کلیک‌ها ───────────── */
function unitOfEl(t) { var c = t.closest('.ot-card'); return c ? +c.dataset.id : 0; }
function highlightUnits(key, ids, msg) {
  if (S.hlLabel === key) { clearHighlight(); return; }
  S.hl = new Set(ids); S.hlLabel = key;
  ids.forEach(function (id) { var u = unitById(id), g = 0; u = u && u.parentId ? unitById(u.parentId) : null; while (u && g++ < 60) { if (S.collapsed.has(u.id)) { S.autoOpen.add(u.id); } u = u.parentId ? unitById(u.parentId) : null; } });
  if (S.focus) { S.focus = 0; }
  render({ relayoutFade: true, noEnter: true }); renderSide();
  var vis = new Set(ids.filter(function (id) { return S.layout.map.has(id); }));
  if (vis.size) { fitView(true, vis); }
  toast(msg + ' (' + fa(ids.length) + ' مورد) — برای برداشتن برجسته‌سازی Esc بزنید.', { type: 'info' });
}
function onClick(e) {
  var t = e.target.closest('[data-act]');
  if (!t) {
    var card = e.target.closest('.ot-card');
    if (card) { select(+card.dataset.id, { focus: true }); return; }
    var row = e.target.closest('.ot-urow[data-uid]');
    if (row && !e.target.closest('button')) {
      var x = I.user.get(+row.getAttribute('data-uid')), r = x ? roleOf(x) : null;
      if (r && r.unit) { select(r.unit.id, { center: true, pulse: true }); }
    }
    if (!e.target.closest('.ot-search')) { E.results.hidden = true; }
    return;
  }
  var act = t.getAttribute('data-act'), id = +(t.getAttribute('data-id') || unitOfEl(t) || 0), can = BOOT.canManage;
  if (act !== 'menu') { closeMenu(); }
  switch (act) {
    case 'menu': e.stopPropagation(); var u = unitById(id); if (u) { var r2 = t.getBoundingClientRect(); select(id, { keepTab: true }); openMenu(r2.left, r2.bottom + 4, unitMenuItems(u), t); } break;
    case 'managers': if (can) { openManagersDialog(id); } break;
    case 'members': if (can) { openMembersDialog(id); } else { select(id, { center: false }); } break;
    case 'toggle': toggleNode(id); break;
    case 'select': select(id, { center: true, pulse: true }); break;
    case 'goto-unit': select(id, { center: true, pulse: true }); break;
    case 'edit': if (can) { openUnitForm(id); } break;
    case 'add': if (can) { openUnitForm(0, id || S.sel || (I.root && I.root.id)); } break;
    case 'bulk': if (can) { openBulkDialog(id || S.sel); } break;
    case 'move': if (can) { openMoveDialog(id); } break;
    case 'delete': if (can) { openDeleteDialog(id); } break;
    case 'focus-branch': focusBranch(id); break;
    case 'unfocus': unfocus(); break;
    case 'undo': doUndo(); break;
    case 'redo': doRedo(); break;
    case 'orient': S.view.orient = S.view.orient === 'h' ? 'v' : 'h'; saveView(); updateToolbar(); render({ relayoutFade: true, noEnter: true }); fitView(true); break;
    case 'density': S.view.density = S.view.density === 'compact' ? 'full' : 'compact'; saveView(); updateToolbar(); render({ relayoutFade: true, noEnter: true }); fitView(true); break;
    case 'theme': S.view.theme = { light: 'dark', dark: 'auto', auto: 'light' }[S.view.theme] || 'light'; saveView(); applyTheme(); toast('تم: ' + ({ light: 'روشن', dark: 'تیره', auto: 'خودکار (مطابق سیستم)' })[S.view.theme], { type: 'info', ms: 2200 }); break;
    case 'expand-all': S.collapsed.clear(); S.autoOpen.clear(); saveView(); render({ relayoutFade: true }); fitView(true); break;
    case 'collapse-all': setLevels(2); break;
    case 'levels': var rb = t.getBoundingClientRect(), its = []; for (var n = 1; n <= I.maxDepth + 1; n++) { (function (n) { its.push({ label: 'نمایش تا سطح ' + fa(n), icon: 'layers', run: function () { setLevels(n); } }); })(n); } openMenu(rb.left, rb.bottom + 6, its, t); break;
    case 'export': openExportMenu(t); break;
    case 'full': toggleFullscreen(); break;
    case 'help': openHelp(); break;
    case 'zoom-in': zoomAt(1.2, null, null, true); break;
    case 'zoom-out': zoomAt(1 / 1.2, null, null, true); break;
    case 'zoom-100': setZoom(1, true); break;
    case 'fit': fitView(true); break;
    case 'center-sel': if (S.sel) { centerOn(S.sel, null, true); } else { fitView(true); } break;
    case 'side': S.view.side = !S.view.side; saveView(); updateToolbar(); setTimeout(function () { drawMinimap(); }, 300); break;
    case 'panel': S.view.panel = !S.view.panel; saveView(); updateToolbar(); setTimeout(function () { drawMinimap(); }, 300); break;
    case 'minimap': S.view.minimap = !S.view.minimap; saveView(); updateToolbar(); drawMinimap(); break;
    case 'tab': S.tab = t.getAttribute('data-v'); renderPanel(); break;
    case 'pf': S.pf = t.getAttribute('data-v'); pLimit = 80; renderPanel(); break;
    case 'more-people': pLimit += 80; renderPanel(); break;
    case 'stat': statClick(t.getAttribute('data-v')); break;
    case 'issue': var it = I.issues.filter(function (x) { return x.key === t.getAttribute('data-v'); })[0]; if (it) { highlightUnits(it.key, it.ids, it.title); } break;
    case 'res': gotoResult(+t.getAttribute('data-i')); E.results.hidden = true; break;
    case 'q-prev': gotoResult(S.search.i - 1); break;
    case 'q-next': gotoResult(S.search.i + 1); break;
    case 'q-clear': clearSearch(); E.q.focus(); break;
    default: break;
  }
}
function statClick(v) {
  if (v === 'free' || v === 'experts' || v === 'managers') { S.pf = v; S.tab = 'people'; if (!S.view.panel) { S.view.panel = true; updateToolbar(); } renderPanel(); return; }
  var ids = S.data.units.filter(function (u) { return v === 'units' ? u.type !== 'ceo' : u.type === v; }).map(function (u) { return u.id; });
  highlightUnits('stat:' + v, ids, v === 'deputy' ? 'معاونت‌ها' : (v === 'department' ? 'ادارات' : 'واحدها'));
}
function toggleFullscreen() {
  var on = APP.classList.toggle('is-fs');
  if (on && APP.requestFullscreen) { APP.requestFullscreen().catch(function () { /* همان حالت CSS کافی است */ }); }
  else if (!on && document.fullscreenElement && document.exitFullscreen) { document.exitFullscreen(); }
  setTimeout(function () { fitView(false); }, 120);
}

/* ───────────── صفحه‌کلید ───────────── */
function neighborOf(id, dir) {
  var n = S.layout && S.layout.map.get(id); if (!n) { return 0; }
  var horiz = S.layout.horiz, sibs = n.parent ? n.parent.kids : [n], i = sibs.indexOf(n);
  var go = { parent: 'parent', child: 'child', next: 'next', prev: 'prev' }[dir];
  if (go === 'parent') { return n.parent ? n.parent.id : 0; }
  if (go === 'child') { return n.kids.length ? n.kids[0].id : 0; }
  if (go === 'next') { return sibs[i + 1] ? sibs[i + 1].id : 0; }
  return sibs[i - 1] ? sibs[i - 1].id : 0;
}
function onKey(e) {
  var tag = (e.target.tagName || '').toLowerCase(), typing = tag === 'input' || tag === 'textarea' || tag === 'select' || e.target.isContentEditable;
  if (e.key === 'Tab' && modalStack.length) { trapTab(e); return; }
  if (e.key === 'Escape') {
    if (menuEl) { e.preventDefault(); closeMenu(); return; }
    if (modalStack.length) { e.preventDefault(); modalStack[modalStack.length - 1].close(); return; }
    if (S.search.q || !E.results.hidden) { clearSearch(); E.q.blur(); return; }
    if (S.hl.size) { clearHighlight(); return; }
    if (S.focus) { unfocus(); return; }
    if (S.sel) { select(0); return; }
    return;
  }
  if (modalStack.length) { return; }
  var mod = e.ctrlKey || e.metaKey;
  if (mod && (e.key === 'k' || e.key === 'K')) { e.preventDefault(); E.q.focus(); E.q.select(); return; }
  if (e.target === E.q) {
    if (e.key === 'Enter') { e.preventDefault(); gotoResult(e.shiftKey ? S.search.i - 1 : S.search.i + 1); }
    else if (e.key === 'ArrowDown') { e.preventDefault(); gotoResult(S.search.i + 1); } else if (e.key === 'ArrowUp') { e.preventDefault(); gotoResult(S.search.i - 1); }
    return;
  }
  if (mod && (e.key === 'z' || e.key === 'Z') && !typing) { e.preventDefault(); if (e.shiftKey) { doRedo(); } else { doUndo(); } return; }
  if (mod && (e.key === 'y' || e.key === 'Y') && !typing) { e.preventDefault(); doRedo(); return; }
  if (typing || mod || e.altKey) { return; }
  var k = e.key;
  if (k === '/') { e.preventDefault(); E.q.focus(); return; }
  if (k === '?') { openHelp(); return; }
  if (k === '+' || k === '=') { zoomAt(1.2, null, null, true); return; }
  if (k === '-' || k === '_') { zoomAt(1 / 1.2, null, null, true); return; }
  if (k === '0') { setZoom(1, true); return; }
  if (k === 'F' && e.shiftKey) { toggleFullscreen(); return; }
  if (k === 'f' || k === 'F') { fitView(true); return; }
  if (k === ' ') { if (!spaceDown) { spaceDown = true; APP.classList.add('is-space'); } if (e.target === document.body || E.viewport.contains(e.target) || e.target.closest('.ot-card')) { e.preventDefault(); } return; }
  var id = S.sel || (e.target.closest && e.target.closest('.ot-card') ? +e.target.closest('.ot-card').dataset.id : 0);
  if (!id && S.layout && S.layout.root && /^Arrow/.test(k) && (E.viewport.contains(e.target) || e.target === document.body)) { select(S.layout.root.id, { focus: true, keepTab: true }); e.preventDefault(); return; }
  if (!id) { return; }
  var horiz = S.layout && S.layout.horiz, map = horiz ? { ArrowLeft: 'child', ArrowRight: 'parent', ArrowDown: 'next', ArrowUp: 'prev' } : { ArrowDown: 'child', ArrowUp: 'parent', ArrowLeft: 'next', ArrowRight: 'prev' };
  if (map[k]) { e.preventDefault(); var to = neighborOf(id, map[k]); if (to) { select(to, { focus: true, keepTab: true }); } return; }
  if (k === 'Home') { e.preventDefault(); if (S.layout.root) { select(S.layout.root.id, { focus: true, keepTab: true }); } return; }
  if (k === 'Enter') { e.preventDefault(); select(id, { center: false }); if (!S.view.panel) { S.view.panel = true; updateToolbar(); } return; }
  if (k === 'F2' && BOOT.canManage) { e.preventDefault(); openUnitForm(id); return; }
  if (k === 'Delete' && BOOT.canManage) { e.preventDefault(); if (unitById(id).type !== 'ceo') { openDeleteDialog(id); } return; }
  if (k === 'ContextMenu' || (k === 'F10' && e.shiftKey)) { e.preventDefault(); var el = cardEls.get(id); if (el) { var r = el.getBoundingClientRect(); openMenu(r.left + 20, r.top + 40, unitMenuItems(unitById(id)), el); } return; }
  if (k === '*') { expandBranch(id, true); }
}

/* ───────────── راه‌اندازی ───────────── */
/* نمای اولیه: اگر «جا شدن در صفحه» خیلی ریز شود، با زوم خواناتر از بالای درخت شروع می‌کنیم */
function initialView() {
  fitView(false);
  if (S.cam.k < 0.5 && S.layout && S.layout.root) {
    var vp = vpSize(), n = S.layout.root, k = 0.62;
    S.cam.k = k; S.cam.x = vp.w / 2 - (n.x + n.w / 2) * k; S.cam.y = 70 - n.y * k; applyCam(false);
  }
}

function boot() {
  loadView();
  S.data = BOOT; rebuild();
  buildShell();
  applyTheme(); renderSide(); updateToolbar();
  render({ noEnter: true }); renderPanel();
  APP.addEventListener('click', onClick);
  APP.addEventListener('dblclick', function (e) {
    var card = e.target.closest('.ot-card'); if (card && !e.target.closest('[data-act]') && BOOT.canManage) { openUnitForm(+card.dataset.id); }
  });
  APP.addEventListener('contextmenu', function (e) {
    var card = e.target.closest('.ot-card'); if (!card) { return; }
    e.preventDefault(); var id = +card.dataset.id; select(id, { keepTab: true }); openMenu(e.clientX, e.clientY, unitMenuItems(unitById(id)), card);
  });
  APP.addEventListener('error', function (e) { if (e.target && e.target.tagName === 'IMG') { e.target.parentNode && e.target.parentNode.removeChild(e.target); } }, true);
  APP.addEventListener('input', function (e) { if (e.target.id === 'ot-pq') { S.pq = e.target.value; pLimit = 80; var pos = e.target.selectionStart; renderPanel(); var n = $('#ot-pq'); if (n) { n.focus(); n.setSelectionRange(pos, pos); } } });
  E.q.addEventListener('input', debounce(function () { runSearch(E.q.value); }, 140));
  E.q.addEventListener('focus', function () { if (S.search.q) { renderResults(); } });
  document.addEventListener('mousedown', function (e) { if (menuEl && !menuEl.contains(e.target)) { closeMenu(); } if (!e.target.closest('.ot-search')) { E.results.hidden = true; } });
  document.addEventListener('keydown', onKey);
  document.addEventListener('keyup', function (e) { if (e.key === ' ') { spaceDown = false; APP.classList.remove('is-space'); } });
  window.addEventListener('blur', function () { spaceDown = false; APP.classList.remove('is-space'); });
  window.addEventListener('resize', debounce(function () { drawMinimap(); }, 100));
  window.addEventListener('beforeprint', function () { if (!printEl) { preparePrint('view'); } });
  window.addEventListener('afterprint', cleanupPrint);
  document.addEventListener('fullscreenchange', function () { if (!document.fullscreenElement) { APP.classList.remove('is-fs'); } setTimeout(function () { fitView(false); }, 100); });
  if (window.matchMedia) { var mq = window.matchMedia('(prefers-color-scheme: dark)'); if (mq.addEventListener) { mq.addEventListener('change', function () { if (S.view.theme === 'auto') { applyTheme(); } }); } }
  bindViewport(); bindDrag();
  requestAnimationFrame(function () {
    initialView();
    var m = /^#unit-(\d+)$/.exec(window.location.hash || '');
    if (m && I.unit.has(+m[1])) { select(+m[1], { center: true, pulse: true, zoom: Math.max(S.cam.k, 0.8) }); }
    else if (document.fonts && document.fonts.ready) { document.fonts.ready.then(function () { if (!S.sel) { initialView(); } }); }
  });
  (BOOT.flash || []).forEach(function (f) { toast(f.message, { type: f.type === 'danger' ? 'error' : 'success' }); });
  window.OrgTree = { state: S, index: I, render: render, select: select, submit: submit, fit: fitView, layout: computeLayout, buildSvg: buildSvg, parseBulk: parseBulk, exportXlsx: exportXlsx };
}
boot();
})();
