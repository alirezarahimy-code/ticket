from __future__ import annotations

from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]


def read(relative: str) -> str:
    return (ROOT / relative).read_text(encoding="utf-8")


def check(condition: bool, message: str) -> None:
    if not condition:
        raise AssertionError(message)
    print(f"ok - {message}")


org_js = read("assets/organization.js")
org_php = read("organization.php")
index = read("index.php")
style = read("assets/style.css")
guide = read("help-guide.php")
chatbot = read("chatbot.php")
page_php = read("organization-page.php")

check(
    "function org_unit_accepts_experts" in org_php
    and "'department', 'deputy'" in org_php,
    "deputy and department both accept experts",
)

check(
    "COALESCE(u.auth_source, '') <> 'food'" in page_php
    and "NOT (u.auth_source = 'local' AND u.role IN ('local_user','guard'))" not in page_php,
    "org people list includes local users and excludes only food accounts",
)

org_assign = index.split("if ($action === 'save_org_assign_users')", 1)[1].split("if ($action ===", 1)[0]
org_remove = index.split("if ($action === 'remove_org_experts')", 1)[1].split("if ($action ===", 1)[0]
check(
    "org_unit_accepts_experts($unit)" in org_assign
    and "unit_type'] !== 'department'" not in org_assign,
    "assign experts accepts deputy or department",
)
check(
    "org_unit_accepts_experts($unit)" in org_remove
    and "unit_type'] !== 'department'" not in org_remove,
    "remove experts accepts deputy or department",
)

actions = read("organization-actions.php")
org_css = read("assets/organization.css")

check(
    "function org_action_assign_members" in actions
    and "org_unit_accepts_experts($unit)" in actions
    and "مدیر یک واحد است" in actions,
    "assign-members action accepts deputy/department experts and rejects unit managers",
)
check(
    "data-zone=\"expert\"" in org_js and "data-zone=\"manager\"" in org_js and "org_assign_members" in org_js,
    "cards expose manager/expert drop zones that call the safe assign action",
)
check(
    "دامینی" in org_js and "محلی" in org_js and "ldap" in org_js,
    "people lists label domain and local users",
)
check(
    "سمت چپ «افزودن کارشناس»" not in chatbot and "org_chart_experts" in chatbot
    and "index.php?page=organization" in chatbot and "ساخت چندتایی" in chatbot,
    "chatbot answers org-chart questions with the v8 UI wording",
)
check(
    "خواندن نمودار" in guide and "کشیدن و رها کردن" in guide and "ساخت چندتایی" in guide
    and "زیر نوار بالای صفحه" in guide,
    "help guide documents the v8 org tree and keeps the food overlay note",
)
check(
    "organization.css" in page_php and "organization.js" in page_php and "PERSIAN_ORG_DATA" in page_php,
    "organization page loads the v8 assets and data",
)
check(
    ".ot-card" in org_css and ".ot-app[data-theme=\"dark\"]" in org_css and "@media print" in org_css,
    "v8 stylesheet has cards, dark theme and print rules",
)

print("all org chart expert static checks passed")
