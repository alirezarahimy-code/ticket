<?php
declare(strict_types=1);

/**
 * بستن خودکار درخواست‌های «حل‌شده» که کاربر پس از N روز امتیاز نداده است.
 *
 * - مهلت از تنظیم ticket_auto_close_days خوانده می‌شود (پیش‌فرض ۳ روز؛ مقدار 0 = غیرفعال).
 * - درخواستی که کاربر امتیاز داده و منتظر تأیید سوپروایزر است دست‌نخورده می‌ماند.
 * - درخواستی که درخواست لغو در انتظار دارد بسته نمی‌شود؛ اول باید دربارهٔ لغو تصمیم گرفته شود.
 * - کاربر پس از بسته‌شدن خودکار هم هنوز می‌تواند امتیاز ثبت کند.
 *
 * اجرا (روزی یک‌بار، مثلاً با Task Scheduler):
 *   C:\xampp\php\php.exe C:\xampp\htdocs\ticket\cron\ticket_auto_close.php
 */
if (PHP_SAPI !== 'cli') {
    http_response_code(404);
    exit("Not found\n");
}

require dirname(__DIR__) . '/bootstrap.php';
require_once dirname(__DIR__) . '/modules/request-center/WorkflowService.php';
require_once dirname(__DIR__) . '/modules/request-center/lib/functions.php';
if (function_exists('ticket_hot_schema_ensure')) {
    ticket_hot_schema_ensure();
}

$days = (int) (setting('ticket_auto_close_days', '3') ?? '3');
if ($days < 1) {
    echo "ticket_auto_close: disabled\n";
    exit(0);
}

$candidates = db()->query('SELECT t.id, t.requester_id, t.asset_id FROM tickets t LEFT JOIN ticket_ratings tr ON tr.ticket_id = t.id WHERE t.status = "resolved" AND t.cancel_requested_at IS NULL AND COALESCE(t.resolved_at, t.updated_at) <= DATE_SUB(NOW(), INTERVAL ' . $days . ' DAY) AND (tr.id IS NULL OR tr.created_at < t.resolved_at OR (tr.created_at = t.resolved_at AND (SELECT MAX(e.id) FROM ticket_events e WHERE e.ticket_id = t.id AND e.event_type = "rated") < (SELECT MAX(e.id) FROM ticket_events e WHERE e.ticket_id = t.id AND e.to_status = "resolved" AND (e.from_status IS NULL OR e.from_status <> "resolved")))) ORDER BY t.id LIMIT 500')->fetchAll();
$closed = 0;

foreach ($candidates as $row) {
    $ticketId = (int) $row['id'];
    try {
        db()->beginTransaction();
        // Re-check the deadline, status and rating under the same ticket lock used
        // by rating and reopen; the initial candidate list may already be stale.
        $lock = db()->prepare('SELECT id, requester_id, asset_id, resolved_at FROM tickets WHERE id = ? AND status = "resolved" AND cancel_requested_at IS NULL AND COALESCE(resolved_at, updated_at) <= DATE_SUB(NOW(), INTERVAL ' . $days . ' DAY) FOR UPDATE');
        $lock->execute([$ticketId]);
        $current = $lock->fetch();
        if (!$current) {
            db()->rollBack();
            continue;
        }
        $ratingQuery = db()->prepare('SELECT score, created_at FROM ticket_ratings WHERE ticket_id = ? LIMIT 1');
        $ratingQuery->execute([$ticketId]);
        $rating = $ratingQuery->fetch();
        $current['rating_score'] = $rating['score'] ?? null;
        $current['rating_at'] = $rating['created_at'] ?? null;
        if (ticket_rating_is_current($current)) {
            db()->rollBack();
            continue;
        }
        $row = $current;
        $workflow = new RequestCenterWorkflowService(db());
        $closedByPolicy = $workflow->transition($ticketId, 'resolved', 'closed', [
            'closed_at' => RequestCenterSqlExpression::now(),
            'supervisor_note' => 'بسته‌شدن خودکار: کاربر ظرف ' . $days . ' روز پس از حل‌شدن امتیاز ثبت نکرد.',
        ], 'auto_close', [
            'cancel_requested_at' => null,
            'resolved_at' => $current['resolved_at'] ?? null,
        ]);
        if (!$closedByPolicy) {
            db()->rollBack();
            continue;
        }
        $autoCloseMeta = [
            'from_status' => 'resolved',
            'to_status' => 'closed',
            'reason' => 'بسته‌شدن خودکار: کاربر ظرف ' . $days . ' روز پس از حل‌شدن امتیاز ثبت نکرد.',
            'days_without_rating' => $days,
            'resolved_at' => $current['resolved_at'] ?? null,
            'closed_at' => date('Y-m-d H:i:s'),
            'actor_type' => 'system',
        ];
        log_ticket_event($ticketId, null, 'auto_closed', 'resolved', 'closed', $autoCloseMeta);
        $auditSaved = activity_log([
            'user_id' => null,
            'action_code' => 'ticket_auto_closed',
            'module' => 'tickets',
            'target_type' => 'ticket',
            'target_id' => $ticketId,
            'meta' => $autoCloseMeta,
            'result' => 'success',
        ]);
        if (!$auditSaved) {
            throw new RuntimeException('Required audit persistence failed for automatic ticket closure.');
        }
        request_center_notify_user(
            (int) $row['requester_id'],
            'ticket_closed',
            'درخواست شما بسته شد',
            'درخواست ' . ticket_number($ticketId) . ' پس از ' . $days . ' روز بدون پاسخ بسته شد. هنوز می‌توانید امتیاز رضایت خود را ثبت کنید.',
            $ticketId,
            true
        );
        request_center_notify_ticket_staff(
            $ticketId,
            'ticket_closed',
            'درخواست به‌صورت خودکار بسته شد',
            'درخواست ' . ticket_number($ticketId) . ' پس از ' . $days . ' روز بدون امتیاز کاربر بسته شد.',
            null,
            true
        );
        record_asset_history((int) ($row['asset_id'] ?? 0), 'ticket_closed', 'بسته‌شدن خودکار درخواست ' . ticket_number($ticketId), null, $ticketId, 'بدون امتیاز کاربر');
        db()->commit();
        $closed++;
    } catch (Throwable $exception) {
        if (db()->inTransaction()) {
            db()->rollBack();
        }
        app_error_log('ticket_auto_close failed for #' . $ticketId . ': ' . $exception->getMessage());
    }
}

echo 'ticket_auto_close: ' . $closed . " closed\n";
