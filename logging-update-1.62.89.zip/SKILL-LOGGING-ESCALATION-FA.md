# سند مهارت — ارتقاء سیستم لاگینگ

**نسخه:** 1.62.89
**تاریخ:** ۲۰۲۶-۱۱-۰۷ (۱۴۰۵/۰۸/۱۷)
**نوع تغییر:** ارتقاء لاگینگ — تشدید شدت + خلاصهٔ هوشمند

---

## خلاصه

دو قابلیت جدید به سیستم لاگینگ اضافه شد:

1. **تشدید شدت (Severity Escalation)** — هر خطا/هشدار تکراری، شدتش بالاتر می‌ره
2. **خلاصهٔ هوشمند (Smart Summary)** — کارت جمع‌بندی بالای داشبورد لاگ

---

## ۱. تشدید شدت (Severity Escalation)

### رفتار
وقتی یک خطا تکرار بشه، سیستم خودکار شدتش رو بالاتر می‌بره:

| تکرار در ۱ ساعت | سطح | برچسب فارسی |
|---|---|---|
| ۱ بار | `warning` | مشکل جزئی |
| ۳ بار | `error` | مشکل تکراری — نیاز به بررسی |
| ۱۰ بار | `critical` | بحرانی — احتمالاً سرویس قطع شده |
| ۵۰ بار | `critical` | فاجعه — بررسی فوری لازم است |

### ارتقاء سطح
- `warning` با ۱۰+ تکرار → **`error`**
- `error` با ۵۰+ تکرار → **`critical`**

### ذخیره در دیتابیس
دو ستون جدید توی `system_logs`:
- `escalation_count` — تعداد تکرارهای قبلی در پنجرهٔ ۱ ساعت
- `escalation_label` — برچسب فارسی شدت

### نمایش در app.log
کنار هر لاگ، برچسب و شمارش نمایش داده می‌شه:
```
[2026-11-07] [error] db — دیتابیس قطع شد [مشکل تکراری — نیاز به بررسی ×3]
```

### فایل‌های مرتبط
- `lib/logging-escalation.php` — تابع‌های جدید
- `lib/logging-csrf.php` — `system_log` با تشدید
- `lib/logging-core.php` — INSERT با دو ستون جدید
- `bootstrap.php` — require_once جدید
- `migrations/034-logging-escalation.sql` — مهاجرت دیتابیس

---

## ۲. خلاصهٔ هوشمند (Smart Summary)

### رفتار
بالای داشبورد لاگ (`logging-dashboard.php`) یک کارت نمایش داده می‌شه که آخرین ۶۰ دقیقه رو خلاصه می‌کنه:

```
📊 خلاصهٔ هوشمند — ۶۰ دقیقهٔ اخیر — ۱۰ رخداد مهم
  ❌ ۳ بار — SYS-DB-001 — db
  ❌ ۱ بار — SYS-APP-001 — test
  ⚠️ ۲ بار — SYS-AUTH-001 — auth
```

### رنگ‌بندی
- **سبز** — ۰ خطا
- **زرد** — ۱ تا ۹ خطا
- **قرمز** — ۱۰+ خطا

### فایل‌های مرتبط
- `lib/logging-escalation.php` — تابع `logging_smart_summary()`
- `logging-dashboard.php` — داده + نمایش
- `assets/logging-dashboard.css` — استایل کارت

---

## ۳. مهاجرت دیتابیس

**فایل:** `migrations/034-logging-escalation.sql`
**نوع:** افزایشی (idempotent) — قابل اجرای مجدد

### تغییرات
| عمل | جزئیات |
|---|---|
| `ADD COLUMN` | `escalation_count INT UNSIGNED NOT NULL DEFAULT 0` |
| `ADD COLUMN` | `escalation_label VARCHAR(64) NULL` |
| `ADD INDEX` | `idx_system_logs_level_time (level, created_at)` |

### اجرای مهاجرت
```bash
mysql -u root -e "source C:\xampp\htdocs\ticket\migrations\034-logging-escalation.sql" persian_ticketing
```

---

## ۴. چه چیزهایی از قبل داشتیم (و نیازی به تغییر نداشت)

| قابلیت | کجا |
|---|---|
| تشخیص ریشهٔ خطا (۴۰+ الگو) | `lib/log-catalog.php` → `system_error_explain()` |
| نمای زنجیره‌ای (Timeline) | `assets/logging-dashboard.js` |
| تشخیص ناهنجاری (Baseline) | `lib/logging-health-baseline.php` |
| گزارش ایمیلی روزانه | `cron/log_notify.php` |
| Spool + Emergency | `lib/logging-core.php` |
| ممیزی سلامت | `lib/logging-audit.php` |
| بازپخش Spool | `lib/logging-replay.php` |
| فعالیت کاربر | `lib/activity-audit.php` |

---

## ۵. فهرست کامل تغییرات

### فایل جدید
```
+ lib/logging-escalation.php           (۱۰۰ خط — تشدید شدت + خلاصه هوشمند)
+ migrations/034-logging-escalation.sql (مهاجرت دیتابیس)
+ docs/SKILL-LOGGING-ESCALATION-FA.md   (این سند)
```

### فایل تغییر‌داده‌شده
```
~ bootstrap.php                        (+۱ require_once)
~ lib/logging-csrf.php                 (system_log: شمارش + ارتقاء سطح)
~ lib/logging-core.php                 (INSERT با escalation_count/label)
~ logging-dashboard.php                (+smart_summary به داده و نمایش)
~ assets/logging-dashboard.css         (+استایل کارت خلاصه)
~ VERSION                              (1.62.88 → 1.62.89)
```

### جدول دیتابیس تغییر‌داده‌شده
```
~ system_logs                          (+۲ ستون + ۱ ایندکس)
```